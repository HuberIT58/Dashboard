#!/bin/zsh

set -e
cd "${0:A:h}"

for candidate in \
  "$(command -v node 2>/dev/null)" \
  "$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" \
  "/opt/homebrew/bin/node" \
  "/usr/local/bin/node"
do
  if [[ -n "$candidate" && -x "$candidate" ]]; then
    "$candidate" scripts/package-site-update.mjs
    echo
    echo "Done. Upload Updates/website.zip in Website Updater."
    read -k 1 "?Press any key to close..."
    exit 0
  fi
done

echo "Node.js was not found. Install Node.js, then run this file again."
read -k 1 "?Press any key to close..."
exit 1

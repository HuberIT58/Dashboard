import { join } from "node:path";
import { StructuredStore } from "../database.mjs";

const root = join(import.meta.dirname, "..");
const store = new StructuredStore(join(root, ".data", "huber-it.sqlite"), root);
const demoPrefix = "demo-";
const serviceJobCount = 1500;
const contractJobCount = 1500;
const jobIdWidth = String(Math.max(serviceJobCount, contractJobCount)).length;
const paths = {
  customers: join(root, ".data", "customers.json"),
  tickets: join(root, "tickets.txt"),
  employees: join(root, "employees.txt"),
  estimates: join(root, ".data", "estimates.json"),
  invoices: join(root, "invoices.txt"),
  finance: join(root, ".data", "finance.json"),
  bills: join(root, ".data", "bills.json"),
  jobExpenses: join(root, ".data", "job-expenses.json")
};

function readArray(filePath) {
  try {
    const value = JSON.parse(store.read(filePath) || "[]");
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

function readObject(filePath, fallback = {}) {
  try {
    const value = JSON.parse(store.read(filePath) || "{}");
    return value && typeof value === "object" && !Array.isArray(value) ? value : fallback;
  } catch {
    return fallback;
  }
}

function writeValue(filePath, value) {
  store.write(filePath, JSON.stringify(value, null, 2));
}

function isDemo(record) {
  return Boolean(record?.demoData) || String(record?.id || "").startsWith(demoPrefix);
}

function money(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function isoDate(date) {
  return date.toISOString().slice(0, 10);
}

function shiftedDate(days) {
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  date.setDate(date.getDate() + days);
  return date;
}

function timestamp(daysAgo, hour = 9) {
  const date = shiftedDate(-daysAgo);
  date.setHours(hour, 15, 0, 0);
  return date.toISOString();
}

function choice(values, index, offset = 0) {
  return values[(index * 7 + offset) % values.length];
}

function amountInRange(index, count, minimum, maximum) {
  if (index === 0) return minimum;
  if (index === count - 1) return maximum;
  const ratio = ((index * 19) % (count - 1)) / (count - 1);
  return money(minimum + (maximum - minimum) * ratio);
}

function realRecords(filePath) {
  return readArray(filePath).filter((record) => !isDemo(record));
}

const currentFinance = readObject(paths.finance, {});
const realFinance = {
  groups: Array.isArray(currentFinance.groups) && currentFinance.groups.length
    ? currentFinance.groups
    : [
        { id: "bonus-pool", name: "Bonus Pool", percent: 5 },
        { id: "employee-labor", name: "Employee Labor", percent: 35 },
        { id: "operating", name: "Operating", percent: 60 }
      ],
  laborGroupId: String(currentFinance.laborGroupId || "employee-labor"),
  payments: (Array.isArray(currentFinance.payments) ? currentFinance.payments : [])
    .filter((record) => !isDemo(record)),
  expenses: (Array.isArray(currentFinance.expenses) ? currentFinance.expenses : [])
    .filter((record) => !isDemo(record))
};

const cleanCollections = {
  customers: realRecords(paths.customers),
  tickets: realRecords(paths.tickets),
  estimates: realRecords(paths.estimates),
  invoices: realRecords(paths.invoices),
  bills: realRecords(paths.bills),
  jobExpenses: realRecords(paths.jobExpenses)
};

if (process.argv.includes("--remove")) {
  for (const [name, records] of Object.entries(cleanCollections)) {
    writeValue(paths[name], records);
  }
  writeValue(paths.finance, realFinance);
  console.log("Removed the complete linked demo dataset. Real records were preserved.");
  process.exit(0);
}

const employeeNames = readArray(paths.employees)
  .filter((employee) => employee.status !== "Inactive")
  .map((employee) => `${employee.firstName || ""} ${employee.lastName || ""}`.trim())
  .filter(Boolean);
if (!employeeNames.length) employeeNames.push("Christian Huber");

const firstNames = [
  "Avery", "Morgan", "Jordan", "Taylor", "Cameron", "Riley", "Parker", "Casey",
  "Dakota", "Reese", "Logan", "Quinn", "Hayden", "Emerson", "Finley", "Skyler",
  "Rowan", "Blake", "Jamie", "Drew"
];
const lastNames = [
  "Bennett", "Carter", "Dawson", "Ellis", "Foster", "Griffin", "Hayes", "Irwin",
  "Jensen", "Keller", "Lawson", "Miller", "Nelson", "Owens", "Palmer", "Reed",
  "Sawyer", "Turner", "Walker", "Young"
];
const companyWords = [
  "Prairie", "Dakota", "Falls", "Summit", "Riverbend", "Heartland", "Blue Sky",
  "Northern", "Frontier", "Meadow", "Copper", "Pioneer"
];
const companyTypes = [
  "Dental", "Storage", "Clinic", "Market", "Construction", "Apartments",
  "Manufacturing", "Fitness", "Auto Center", "Accounting", "Hospitality", "Warehouse"
];
const serviceTypes = [
  "Security", "Wifi & Networking", "Access Control",
  "Networked Audio & Video", "Superlink", "Other"
];
const serviceDescriptions = [
  "Camera connectivity repair and recording verification",
  "Wireless coverage upgrade and access point installation",
  "Door reader replacement and credential testing",
  "Network switch cleanup and equipment documentation",
  "Environmental sensor installation and alert configuration",
  "Audio zone repair and paging verification",
  "Preventive maintenance and firmware review",
  "Network performance troubleshooting"
];
const contractDescriptions = [
  "Campus camera modernization",
  "Building-wide managed wireless deployment",
  "Multi-door access control installation",
  "Network rack, switching, and structured cabling build",
  "Security system and recording storage modernization",
  "Superlink sensor and automation rollout",
  "Warehouse network infrastructure deployment",
  "Integrated security, access, and network upgrade"
];
const materialItems = [
  { name: "UniFi G5 Camera", sku: "DEMO-UVC-G5", unitCost: 129 },
  { name: "UniFi Access Point", sku: "DEMO-U7-PRO", unitCost: 189 },
  { name: "Cat6 Cable", sku: "DEMO-CAT6", unitCost: 0.32 },
  { name: "Access Reader", sku: "DEMO-UA-READER", unitCost: 159 },
  { name: "Patch Cable", sku: "DEMO-PATCH", unitCost: 8.5 },
  { name: "Superlink Sensor", sku: "DEMO-SENSOR", unitCost: 79 }
];
const priorities = ["Normal", "High", "Normal", "Low", "Urgent"];
const scheduledTimes = ["08:00", "09:30", "11:00", "13:00", "14:30", "16:00"];
const paymentMethods = ["ACH", "Bank Transfer", "Check", "Credit Card"];
const jobExpenseCategories = ["Material", "Office", "Food", "Hotel", "Travel", "Equipment Rental", "Permit"];

const demoCustomers = Array.from({ length: 40 }, (_, index) => {
  const number = index + 1;
  const firstName = choice(firstNames, index, 2);
  const lastName = choice(lastNames, index, 5);
  const company = `${choice(companyWords, index)} ${choice(companyTypes, index, 3)}`;
  return {
    id: `demo-customer-${String(number).padStart(3, "0")}`,
    name: `${firstName} ${lastName}`,
    company,
    phone: `605-555-${String(1000 + number).slice(-4)}`,
    email: `demo.customer${number}@example.com`,
    primaryAddress: `${100 + number * 7} Demo Avenue, Sioux Falls, SD 5710${number % 10}`,
    additionalLocations: number % 6 === 0
      ? `${500 + number} Sample Street, Demo Branch ${number / 6}`
      : "",
    notes: `DEMO DATA - Fictional customer ${number}.`,
    updatedAt: timestamp(number % 25, 8 + (number % 8)),
    updatedBy: "demo-seeder",
    demoData: true
  };
});

const maxTicketNumber = cleanCollections.tickets.reduce(
  (highest, record) => Math.max(highest, Number(record.number) || 0), 1000
);
const maxEstimateNumber = cleanCollections.estimates.reduce(
  (highest, record) => Math.max(highest, Number(record.number) || 0), 0
);
const maxInvoiceNumber = cleanCollections.invoices.reduce(
  (highest, record) => Math.max(highest, Number(record.number) || 0), 0
);

const demoTickets = [];
const demoEstimates = [];
const demoInvoices = [];
const demoPayments = [];
const demoJobExpenses = [];

function workLogs(ticketId, status, assignees, index, type) {
  if (status === "Open") return [];
  const phaseHours = type === "Contract"
    ? money(12 + (index % 8) * 7.5)
    : money(2 + (index % 6) * 0.75);
  const records = [{
    id: `${ticketId}-work-1`,
    username: "demo-seeder",
    employeeName: assignees[0],
    hours: phaseHours,
    status: "In Progress",
    resolution: type === "Contract"
      ? "Completed an installation phase and documented project progress."
      : "Diagnosed the issue and completed the primary service work.",
    loggedAt: timestamp(Math.max(1, 12 - (index % 10)), 10)
  }];
  if (status === "Closed") {
    records.push({
      id: `${ticketId}-work-2`,
      username: "demo-seeder",
      employeeName: assignees.at(-1),
      hours: type === "Contract" ? money(8 + (index % 5) * 4) : money(1 + (index % 4) * 0.5),
      status: "Closed",
      resolution: "Finished the remaining work, tested the system, and completed customer handoff.",
      loggedAt: timestamp(index % 5, 15)
    });
  }
  return records;
}

function createJob(type, index) {
  const isContract = type === "Contract";
  const globalIndex = isContract ? serviceJobCount + index : index;
  const customer = demoCustomers[(globalIndex * 3) % demoCustomers.length];
  const status = ["Open", "In Progress", "Closed"][(index + (isContract ? 1 : 0)) % 3];
  const amount = isContract
    ? amountInRange(index, contractJobCount, 50000, 2500000)
    : amountInRange(index, serviceJobCount, 1000, 3500);
  const jobSequence = String(index + 1).padStart(jobIdWidth, "0");
  const id = `demo-${type.toLowerCase()}-${jobSequence}`;
  const assigneeCount = index % 5 === 0 && employeeNames.length > 1 ? 2 : 1;
  const assignees = Array.from({ length: assigneeCount }, (_, cursor) =>
    employeeNames[(index + cursor) % employeeNames.length]
  );
  const logs = workLogs(id, status, assignees, index, type);
  const material = choice(materialItems, index, isContract ? 2 : 0);
  const usedItems = status === "Open" ? [] : [{
    id: `${id}-material-1`,
    catalogId: "",
    name: material.name,
    sku: material.sku,
    variationName: "",
    quantity: isContract ? 12 + (index % 24) : 1 + (index % 3),
    unitCost: material.unitCost,
    username: "demo-seeder",
    employeeName: assignees[0],
    loggedAt: logs[0]?.loggedAt || timestamp(1)
  }];
  const description = isContract
    ? choice(contractDescriptions, index)
    : choice(serviceDescriptions, index);
  const ticketNumber = maxTicketNumber + globalIndex + 1;
  const estimateId = `demo-estimate-${type.toLowerCase()}-${jobSequence}`;
  const paymentMode = index % 5;
  const paymentFraction = paymentMode === 0 || paymentMode === 4
    ? 1
    : paymentMode === 1 ? 0.5 : paymentMode === 2 ? 0.25 : 0;
  const estimateStatus = paymentFraction === 1 && status === "Closed"
    ? "Paid"
    : status === "Closed" ? "Done" : status === "In Progress" ? "In Progress" : "Accepted";
  const ticket = {
    id,
    number: ticketNumber,
    ticketType: type,
    isOffice: false,
    officeTitle: "",
    sourceEstimateId: estimateId,
    customerId: customer.id,
    customer: customer.name,
    company: customer.company,
    phone: customer.phone,
    email: customer.email,
    address: customer.primaryAddress,
    serviceType: choice(serviceTypes, index, isContract ? 1 : 0),
    description: `[DEMO] ${description}`,
    priority: choice(priorities, index, 2),
    status,
    assignedToMany: assignees,
    assignedTo: assignees.join(", "),
    assigneeProgress: assignees.map((employeeName) => ({
      employeeName,
      username: "demo-seeder",
      status: status === "Closed" ? "Closed" : status,
      updatedAt: timestamp(index % 8)
    })),
    reassignmentFlags: [],
    scheduledDate: isoDate(shiftedDate(status === "Open" ? 2 + (index % 12) : -(index % 20))),
    scheduledTime: choice(scheduledTimes, index, 1),
    hoursUsed: String(logs.reduce((sum, log) => sum + Number(log.hours || 0), 0)),
    legacyHours: 0,
    workLogs: logs,
    usedItems,
    attachments: [],
    internalMessages: status === "Open" ? [] : [{
      id: `${id}-message-1`,
      username: "demo-seeder",
      employeeName: assignees[0],
      fromOffice: false,
      message: status === "Closed"
        ? "Demo job completed and ready for office review."
        : "Demo job is active and progress has been recorded.",
      createdAt: timestamp(index % 7, 14)
    }],
    resolution: status === "Closed" ? logs.at(-1)?.resolution || "" : "",
    projectWorkspace: isContract ? {
      name: `DEMO Project - ${customer.company}`,
      notes: `Fictional contract workspace with a value of $${amount.toLocaleString("en-US")}.`,
      documentPaths: [],
      updatedAt: timestamp(index % 8),
      updatedBy: "demo-seeder"
    } : undefined,
    createdAt: timestamp(55 - (index % 40), 9),
    updatedAt: timestamp(index % 10, 16),
    updatedBy: "demo-seeder",
    demoData: true,
    demoAmount: amount
  };
  const lineName = isContract ? "Contract project" : "Service labor and materials";
  const estimate = {
    id: estimateId,
    number: maxEstimateNumber + globalIndex + 1,
    customerId: customer.id,
    customer: customer.name,
    title: description,
    jobType: type,
    ticketId: id,
    lines: [{ name: lineName, quantity: 1, rate: amount, total: amount }],
    materialItems: [],
    catalogMaterialTotal: 0,
    additionalMaterialCost: 0,
    automaticMaterialCost: 0,
    manualAdditionalMaterialCost: 0,
    additionalCharges: 0,
    appliedMaterialRules: [],
    materialTotal: 0,
    subtotal: amount,
    taxRate: 0,
    tax: 0,
    total: amount,
    status: estimateStatus,
    validUntil: isoDate(shiftedDate(30)),
    notes: "DEMO DATA - Linked estimate for workflow testing.",
    terms: "Demo terms: payment due according to the associated agreement.",
    convertedAt: ticket.createdAt,
    updatedAt: ticket.updatedAt,
    updatedBy: "demo-seeder",
    demoData: true
  };
  demoTickets.push(ticket);
  demoEstimates.push(estimate);

  if (!isContract && status === "Closed") {
    const invoiceId = `demo-invoice-${jobSequence}`;
    const invoiceStatus = paymentFraction === 1 ? "Paid" : "Sent";
    const invoice = {
      id: invoiceId,
      number: maxInvoiceNumber + index + 1,
      ticketId: id,
      ticketNumber,
      customer: customer.name,
      company: customer.company,
      email: customer.email,
      phone: customer.phone,
      address: customer.primaryAddress,
      laborHours: Number(ticket.hoursUsed) || 0,
      laborRate: 0,
      laborTotal: 0,
      materials: [],
      materialTotal: 0,
      customCharges: [{ name: lineName, quantity: 1, rate: amount, total: amount }],
      customChargeTotal: amount,
      additionalCharges: 0,
      taxRate: 0,
      tax: 0,
      subtotal: amount,
      total: amount,
      status: invoiceStatus,
      issueDate: isoDate(shiftedDate(-(18 - (index % 18)))),
      dueDate: isoDate(shiftedDate(12 - (index % 18))),
      notes: "DEMO DATA - Fictional service invoice.",
      paymentInstructions: "Demo payment instructions. Do not remit payment.",
      updatedAt: ticket.updatedAt,
      updatedBy: "demo-seeder",
      demoData: true
    };
    estimate.invoiceId = invoiceId;
    demoInvoices.push(invoice);
    if (paymentFraction > 0) {
      demoPayments.push({
        id: `demo-payment-service-${jobSequence}`,
        invoiceId,
        contractTicketId: "",
        description: `Payment for INV-${String(invoice.number).padStart(4, "0")}`,
        amount: money(amount * paymentFraction),
        date: isoDate(shiftedDate(-(index % 12))),
        method: choice(paymentMethods, index),
        reference: `DEMO-SVC-${String(index + 1).padStart(4, "0")}`,
        note: paymentFraction === 1 ? "Demo payment in full." : "Demo partial payment.",
        createdAt: timestamp(index % 12, 11),
        createdBy: "demo-seeder",
        markedInvoicePaid: paymentFraction === 1,
        demoData: true
      });
    }
  } else if (isContract && paymentFraction > 0) {
    demoPayments.push({
      id: `demo-payment-contract-${jobSequence}`,
      invoiceId: "",
      contractTicketId: id,
      description: `Payment for C-${String(ticketNumber).padStart(4, "0")}`,
      amount: money(amount * paymentFraction),
      date: isoDate(shiftedDate(-(index % 20))),
      method: choice(paymentMethods, index, 1),
      reference: `DEMO-CON-${String(index + 1).padStart(4, "0")}`,
      note: paymentFraction === 1 ? "Demo contract payment in full." : "Demo contract progress payment.",
      createdAt: timestamp(index % 20, 11),
      createdBy: "demo-seeder",
      demoData: true
    });
  }

  if (status !== "Open") {
    const baseCost = isContract ? amount * (0.08 + (index % 5) * 0.018) : amount * 0.08;
    const expenseCount = isContract ? 3 : 2;
    for (let cursor = 0; cursor < expenseCount; cursor += 1) {
      const category = choice(jobExpenseCategories, index + cursor, isContract ? 2 : 0);
      demoJobExpenses.push({
        id: `demo-job-expense-${type.toLowerCase()}-${jobSequence}-${cursor + 1}`,
        jobId: id,
        category,
        employeeName: assignees[cursor % assignees.length],
        description: `DEMO ${category.toLowerCase()} cost for ${description.toLowerCase()}.`,
        amount: money(baseCost * (cursor === 0 ? 0.55 : cursor === 1 ? 0.3 : 0.15)),
        date: isoDate(shiftedDate(-(index % 18))),
        createdAt: timestamp(index % 18, 13),
        createdBy: "demo-seeder",
        demoData: true
      });
    }
  }
}

for (let index = 0; index < serviceJobCount; index += 1) createJob("Service", index);
for (let index = 0; index < contractJobCount; index += 1) createJob("Contract", index);

const operatingGroupId = realFinance.groups.find((group) =>
  String(group.name || "").toLowerCase().includes("operating")
)?.id || realFinance.groups[0]?.id || "operating";
const generalExpenseNames = [
  "Office supplies", "Fuel and mileage", "Software subscriptions", "Insurance premium",
  "Phone service", "Internet service", "Tool replacement", "Warehouse supplies",
  "Marketing materials", "Vehicle maintenance", "Training materials", "Shipping",
  "Professional services", "Safety equipment", "Uniforms", "Equipment rental"
];
const demoGeneralExpenses = generalExpenseNames.map((description, index) => ({
  id: `demo-finance-expense-${String(index + 1).padStart(3, "0")}`,
  groupId: operatingGroupId,
  description: `[DEMO] ${description}`,
  employee: employeeNames[index % employeeNames.length],
  amount: money(35 + ((index * 137) % 2200)),
  date: isoDate(shiftedDate(-(index * 2))),
  note: "Fictional company operating expense.",
  createdAt: timestamp(index * 2, 10),
  createdBy: "demo-seeder",
  demoData: true
}));

const billTemplates = [
  ["Office lease", "Bill", 2850, "Monthly"],
  ["Business insurance", "Bill", 680, "Monthly"],
  ["Internet and phones", "Bill", 425, "Monthly"],
  ["Software subscriptions", "Bill", 590, "Monthly"],
  ["Warehouse utilities", "Bill", 740, "Monthly"],
  ["Vehicle insurance", "Bill", 2100, "Yearly"],
  ["Professional licensing", "Bill", 850, "Yearly"],
  ["Equipment lease", "Bill", 1275, "Monthly"],
  ["Service vehicle loan", "Loan", 68400, "Monthly"],
  ["Warehouse improvement loan", "Loan", 185000, "Monthly"],
  ["Equipment financing", "Loan", 92000, "Monthly"]
];
const demoBills = billTemplates.map(([name, type, value, frequency], index) => {
  const paid = index % 3 === 0;
  const overdue = !paid && index % 3 === 1;
  const dueDate = isoDate(shiftedDate(paid ? 10 + index : overdue ? -(5 + index) : 8 + index));
  const monthlyPayment = type === "Loan" ? money(950 + index * 115) : 0;
  const amount = type === "Loan" ? monthlyPayment : value;
  const id = `demo-bill-${String(index + 1).padStart(3, "0")}`;
  const payments = paid ? [{
    id: `${id}-payment-1`,
    billId: id,
    name: `[DEMO] ${name}`,
    amount,
    dueDate,
    paidAt: timestamp(index % 10, 9),
    paidBy: "demo-seeder",
    ...(type === "Loan" ? {
      principalApplied: amount,
      remainingLoanBalance: money(value - amount)
    } : {})
  }] : [];
  return {
    id,
    name: `[DEMO] ${name}`,
    type,
    amount,
    monthlyPayment,
    originalLoanAmount: type === "Loan" ? value : 0,
    remainingLoanAmount: type === "Loan" ? money(value - (paid ? amount : 0)) : 0,
    frequency,
    dueDate,
    status: paid ? "Paid" : "Unpaid",
    note: "Fictional recurring company obligation.",
    payments,
    createdAt: timestamp(45 - index),
    updatedAt: timestamp(index % 8),
    updatedBy: "demo-seeder",
    demoData: true
  };
});

writeValue(paths.customers, [...cleanCollections.customers, ...demoCustomers]);
writeValue(paths.tickets, [...cleanCollections.tickets, ...demoTickets]);
writeValue(paths.estimates, [...cleanCollections.estimates, ...demoEstimates]);
writeValue(paths.invoices, [...cleanCollections.invoices, ...demoInvoices]);
writeValue(paths.jobExpenses, [...cleanCollections.jobExpenses, ...demoJobExpenses]);
writeValue(paths.bills, [...cleanCollections.bills, ...demoBills]);
writeValue(paths.finance, {
  ...realFinance,
  payments: [...realFinance.payments, ...demoPayments],
  expenses: [...realFinance.expenses, ...demoGeneralExpenses]
});

const serviceAmounts = demoTickets.filter((ticket) => ticket.ticketType === "Service")
  .map((ticket) => ticket.demoAmount);
const contractAmounts = demoTickets.filter((ticket) => ticket.ticketType === "Contract")
  .map((ticket) => ticket.demoAmount);
const received = money(demoPayments.reduce((sum, payment) => sum + payment.amount, 0));
const invoiced = money(demoInvoices.reduce((sum, invoice) => sum + invoice.total, 0));
const contracted = money(demoEstimates.filter((estimate) => estimate.jobType === "Contract")
  .reduce((sum, estimate) => sum + estimate.total, 0));

console.log("Seeded a complete linked demo company dataset:");
console.log(`  Customers: ${demoCustomers.length}`);
console.log(`  Service jobs: ${serviceJobCount.toLocaleString("en-US")} (${Math.min(...serviceAmounts).toLocaleString("en-US", { style: "currency", currency: "USD" })} - ${Math.max(...serviceAmounts).toLocaleString("en-US", { style: "currency", currency: "USD" })})`);
console.log(`  Contract jobs: ${contractJobCount.toLocaleString("en-US")} (${Math.min(...contractAmounts).toLocaleString("en-US", { style: "currency", currency: "USD" })} - ${Math.max(...contractAmounts).toLocaleString("en-US", { style: "currency", currency: "USD" })})`);
console.log(`  Estimates: ${demoEstimates.length}; invoices: ${demoInvoices.length}; payments: ${demoPayments.length}`);
console.log(`  Service invoiced: ${invoiced.toLocaleString("en-US", { style: "currency", currency: "USD" })}`);
console.log(`  Contract value: ${contracted.toLocaleString("en-US", { style: "currency", currency: "USD" })}`);
console.log(`  Payments received: ${received.toLocaleString("en-US", { style: "currency", currency: "USD" })}`);
console.log(`  Job expenses: ${demoJobExpenses.length}; general expenses: ${demoGeneralExpenses.length}; bills and loans: ${demoBills.length}`);
console.log('Run with "--remove" to remove only demo records from every seeded collection.');

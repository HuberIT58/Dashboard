import {
  copyFileSync,
  existsSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  readdirSync,
  rmSync
} from "node:fs";
import { tmpdir } from "node:os";
import { basename, dirname, join, relative, resolve, sep } from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const updates = join(root, "Updates");
const output = join(updates, "website.zip");
const legacyOutput = join(root, "website-update.zip");
const stagingParent = mkdtempSync(join(tmpdir(), "huber-site-update-"));
const staging = join(stagingParent, "Website");

const skippedRoots = new Set([
  ".agents",
  ".codex",
  ".data",
  ".git",
  ".pnpm-store",
  "dashboard-desktop",
  "dashboard-native",
  "email-desktop",
  "office-suite-desktop",
  "design-center-desktop",
  "ios-lidar-scanner",
  "huber-browser",
  "huber-server-shell",
  "network-tester",
  "node_modules",
  "tmp",
  "Updates",
  "xcloud"
]);

const skippedFiles = new Set([
  ".DS_Store",
  ".env",
  "Create App Installer.command",
  "Create Dashboard Server Installer.command",
  "Create Email App.command",
  "Create Office Suite.command",
  "Create Windows App Installer.command",
  "env.txt",
  "full-logo.eps",
  "users.txt",
  "tickets.txt",
  "employees.txt",
  "time-records.txt",
  "schedule-events.txt",
  "roles.txt",
  "inventory.txt",
  "catalog.txt",
  "notifications.txt",
  "invoices.txt"
]);

function copyDeployable(source, target) {
  for (const name of readdirSync(source)) {
    const sourcePath = join(source, name);
    const relativePath = relative(root, sourcePath);
    const topLevel = relativePath.split(sep)[0];
    const isTopLevel = relativePath === name;
    const isGeneratedPackage = isTopLevel && /\.(?:dmg|exe|zip)$/i.test(name);
    const isEnvironmentFile = name === ".env" || name.startsWith(".env.");
    const isLocalTextFile = isTopLevel && /\.txt$/i.test(name) && name !== "version.txt";
    if (skippedRoots.has(topLevel) || skippedFiles.has(relativePath) || skippedFiles.has(name) || isGeneratedPackage || isEnvironmentFile || isLocalTextFile) continue;

    const stats = lstatSync(sourcePath);
    if (stats.isSymbolicLink()) continue;
    const targetPath = join(target, name);
    if (stats.isDirectory()) {
      mkdirSync(targetPath, { recursive: true });
      copyDeployable(sourcePath, targetPath);
    } else if (stats.isFile()) {
      mkdirSync(dirname(targetPath), { recursive: true });
      copyFileSync(sourcePath, targetPath);
    }
  }
}

try {
  mkdirSync(updates, { recursive: true });
  mkdirSync(staging, { recursive: true });
  copyDeployable(root, staging);
  if (existsSync(output)) rmSync(output);
  if (existsSync(legacyOutput)) rmSync(legacyOutput);

  const result = spawnSync("zip", ["-qr", output, basename(staging)], {
    cwd: stagingParent,
    encoding: "utf8"
  });
  if (result.status !== 0) {
    throw new Error(result.stderr || "The zip command failed.");
  }

  const sizeMb = (lstatSync(output).size / (1024 * 1024)).toFixed(1);
  console.log(`Website update ready: ${output} (${sizeMb} MB)`);
  console.log("Upload Updates/website.zip in Website Updater.");
} finally {
  rmSync(stagingParent, { recursive: true, force: true });
}

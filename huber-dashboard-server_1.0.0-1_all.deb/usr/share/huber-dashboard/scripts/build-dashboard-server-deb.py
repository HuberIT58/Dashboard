#!/usr/bin/env python3
"""Package the deployable website ZIP as a portable Ubuntu server installer."""

from __future__ import annotations

import hashlib
import io
import json
import re
import tarfile
import time
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "Updates" / "website.zip"
OUT = ROOT / "Updates"
DEPLOYMENT = ROOT / "deployment" / "dashboard-server"
VERSION = f"{json.loads((ROOT / 'package.json').read_text())['version']}-1"


def info(name: str, mode: int, size: int = 0, directory: bool = False) -> tarfile.TarInfo:
    result = tarfile.TarInfo(f"./{name}")
    result.type = tarfile.DIRTYPE if directory else tarfile.REGTYPE
    result.mode = mode
    result.uid = result.gid = 0
    result.uname = result.gname = "root"
    result.mtime = int(time.time())
    result.size = 0 if directory else size
    return result


def tar_bytes(entries: list[tuple[str, bytes, int]]) -> bytes:
    output = io.BytesIO()
    dirs: set[str] = set()
    for name, _, _ in entries:
        parent = Path(name).parent
        while str(parent) != ".":
            dirs.add(str(parent))
            parent = parent.parent
    with tarfile.open(fileobj=output, mode="w:xz", format=tarfile.GNU_FORMAT) as tar:
        for name in sorted(dirs, key=lambda item: (item.count("/"), item)):
            tar.addfile(info(name, 0o755, directory=True))
        for name, data, mode in entries:
            tar.addfile(info(name, mode, len(data)), io.BytesIO(data))
    return output.getvalue()


def member(name: str, data: bytes) -> bytes:
    header = (
        f"{name:<16}{int(time.time()):<12}{0:<6}{0:<6}"
        f"{0o100644:<8o}{len(data):<10}`\n"
    ).encode("ascii")
    return header + data + (b"\n" if len(data) % 2 else b"")


def main() -> None:
    if not SOURCE.is_file():
        raise SystemExit("Run Create Website Update.command before building the server installer.")
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+-[0-9]+", VERSION):
        raise SystemExit("package.json version is not valid for a Debian package.")
    site_entries = []
    with zipfile.ZipFile(SOURCE) as site:
        for record in site.infolist():
            name = record.filename
            if record.is_dir():
                continue
            if not name.startswith("Website/") or ".." in Path(name).parts:
                raise SystemExit(f"Unexpected website ZIP entry: {name}")
            if (record.external_attr >> 16) & 0o170000 == 0o120000:
                raise SystemExit(f"Symbolic link in website ZIP: {name}")
            site_entries.append((f"usr/share/huber-dashboard/{name[8:]}", site.read(record), 0o644))
    if not any(name.endswith("/server.mjs") for name, _, _ in site_entries):
        raise SystemExit("The website ZIP has no server.mjs.")
    service = (DEPLOYMENT / "huber-dashboard.service").read_bytes()
    data = tar_bytes(site_entries + [
        ("lib/systemd/system/huber-dashboard.service", service, 0o644),
    ])
    control = (
        f"Package: huber-dashboard-server\nVersion: {VERSION}\nArchitecture: all\n"
        "Maintainer: Huber I.T. Professionals\n"
        "Depends: ca-certificates, curl, xz-utils, tar, systemd, passwd, util-linux\n"
        "Description: Huber I.T. dashboard and operations server\n"
        " Installs the dashboard as a systemd service on Ubuntu.\n"
    ).encode()
    control_tar = tar_bytes([
        ("control", control, 0o644),
        ("postinst", (DEPLOYMENT / "postinst").read_bytes(), 0o755),
        ("prerm", (DEPLOYMENT / "prerm").read_bytes(), 0o755),
    ])
    OUT.mkdir(exist_ok=True)
    package = OUT / f"huber-dashboard-server_{VERSION}_all.deb"
    package.write_bytes(
        b"!<arch>\n" + member("debian-binary", b"2.0\n")
        + member("control.tar.xz", control_tar) + member("data.tar.xz", data)
    )
    digest = hashlib.sha256(package.read_bytes()).hexdigest()
    package.with_suffix(".deb.sha256").write_text(f"{digest}  {package.name}\n", encoding="ascii")
    print(f"Dashboard server installer: {package} ({package.stat().st_size / 1048576:.1f} MB)")


if __name__ == "__main__":
    main()

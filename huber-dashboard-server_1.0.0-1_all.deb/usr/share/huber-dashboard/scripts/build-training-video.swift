import AppKit
import AVFoundation
import CoreVideo

let root = URL(fileURLWithPath: "/Users/christian/Documents/Website")
let imagePaths = [
  "assets/training/document-maker-intro.png",
  ".data/training-capture-0.png",
  ".data/training-capture-1.png",
  ".data/training-capture-2.png",
  ".data/training-capture-3.png",
  ".data/training-capture-4.png",
  ".data/training-capture-5.png",
  ".data/training-capture-6.png",
  "assets/training/document-maker-outro.png"
]
let durations = [3.0, 2.0, 4.0, 4.0, 5.0, 4.0, 4.0, 4.0, 3.0]
let images: [CGImage] = imagePaths.map { path in
  let image = NSImage(contentsOf: root.appendingPathComponent(path))!
  return image.cgImage(forProposedRect: nil, context: nil, hints: nil)!
}
let width = 1280, height = 720, fps: Int32 = 30
let outputURL = root.appendingPathComponent("assets/training/document-maker-guide.mp4")
try? FileManager.default.removeItem(at: outputURL)

let writer = try AVAssetWriter(outputURL: outputURL, fileType: .mp4)
let settings: [String: Any] = [
  AVVideoCodecKey: AVVideoCodecType.h264,
  AVVideoWidthKey: width,
  AVVideoHeightKey: height,
  AVVideoCompressionPropertiesKey: [
    AVVideoAverageBitRateKey: 4_000_000,
    AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel
  ]
]
let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
input.expectsMediaDataInRealTime = false
let attributes: [String: Any] = [
  kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
  kCVPixelBufferWidthKey as String: width,
  kCVPixelBufferHeightKey as String: height
]
let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: attributes)
guard writer.canAdd(input) else { fatalError("Unable to add video input") }
writer.add(input)
guard writer.startWriting() else { fatalError(writer.error?.localizedDescription ?? "Unable to start writer") }
writer.startSession(atSourceTime: .zero)

func makeFrame(current: CGImage, next: CGImage?, transition: CGFloat) -> CVPixelBuffer {
  var buffer: CVPixelBuffer?
  CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
    attributes as CFDictionary, &buffer)
  let pixelBuffer = buffer!
  CVPixelBufferLockBaseAddress(pixelBuffer, [])
  let context = CGContext(data: CVPixelBufferGetBaseAddress(pixelBuffer), width: width, height: height,
    bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer),
    space: CGColorSpaceCreateDeviceRGB(),
    bitmapInfo: CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue)!
  context.setFillColor(NSColor.black.cgColor)
  context.fill(CGRect(x: 0, y: 0, width: width, height: height))
  context.setAlpha(1 - transition)
  context.draw(current, in: CGRect(x: 0, y: 0, width: width, height: height))
  if let next, transition > 0 {
    context.setAlpha(transition)
    context.draw(next, in: CGRect(x: 0, y: 0, width: width, height: height))
  }
  CVPixelBufferUnlockBaseAddress(pixelBuffer, [])
  return pixelBuffer
}

var frameIndex: Int64 = 0
for index in images.indices {
  let frameCount = Int(durations[index] * Double(fps))
  let transitionFrames = index < images.count - 1 ? Int(0.35 * Double(fps)) : 0
  for localFrame in 0..<frameCount {
    while !input.isReadyForMoreMediaData { Thread.sleep(forTimeInterval: 0.002) }
    let transition = localFrame >= frameCount - transitionFrames && transitionFrames > 0
      ? CGFloat(localFrame - (frameCount - transitionFrames)) / CGFloat(transitionFrames)
      : 0
    let buffer = makeFrame(current: images[index], next: index + 1 < images.count ? images[index + 1] : nil,
      transition: transition)
    let time = CMTime(value: frameIndex, timescale: fps)
    guard adaptor.append(buffer, withPresentationTime: time) else {
      fatalError(writer.error?.localizedDescription ?? "Unable to append frame")
    }
    frameIndex += 1
  }
}
input.markAsFinished()
let semaphore = DispatchSemaphore(value: 0)
writer.finishWriting { semaphore.signal() }
semaphore.wait()
guard writer.status == .completed else { fatalError(writer.error?.localizedDescription ?? "Video export failed") }
print(outputURL.path)

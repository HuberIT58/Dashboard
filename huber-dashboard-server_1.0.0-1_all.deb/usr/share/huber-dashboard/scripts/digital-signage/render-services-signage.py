#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import math
import shutil

ROOT = Path(__file__).resolve().parents[2]
ASSETS = ROOT / "assets"
FRAMES = ROOT / ".signage-frames"
WIDTH, HEIGHT, FPS, DURATION = 1920, 1080, 30, 30

FONT_REGULAR = "/System/Library/Fonts/Supplemental/Arial.ttf"
FONT_BOLD = "/System/Library/Fonts/Supplemental/Arial Bold.ttf"

SERVICES = [
    {
        "title": "Security",
        "eyebrow": "PROTECT WHAT MATTERS",
        "icon": "icon-security.png",
        "accent": (47, 209, 216),
        "bullets": ["AI-assisted camera systems", "Recording, storage & remote viewing", "Coverage planning, repairs & upgrades"],
    },
    {
        "title": "Wi-Fi & Networking",
        "eyebrow": "FAST. STABLE. CONNECTED.",
        "icon": "icon-wifi-networking.png",
        "accent": (79, 145, 234),
        "bullets": ["Business and residential networks", "Routing, firewalls & structured cabling", "Coverage testing & performance support"],
    },
    {
        "title": "Access Control",
        "eyebrow": "SMARTER ENTRY MANAGEMENT",
        "icon": "icon-access-control.png",
        "accent": (57, 196, 145),
        "bullets": ["Door access system installation", "Cards, fobs, keypads & credentials", "Locks, strikes, repairs & maintenance"],
    },
    {
        "title": "Networked Audio & Video",
        "eyebrow": "CONNECTED EXPERIENCES",
        "icon": "icon-audio-video.png",
        "accent": (244, 165, 63),
        "bullets": ["Displays, speakers & conference rooms", "Streaming and media system support", "Zone configuration & troubleshooting"],
    },
    {
        "title": "Superlink",
        "eyebrow": "INTELLIGENT BUILDING AUTOMATION",
        "icon": "icon-superlink.png",
        "accent": (229, 95, 115),
        "bullets": ["Vape and air detection", "AI speakers, motion & smart alerts", "Relay integrations & automation support"],
    },
]


def font(size, bold=False):
    return ImageFont.truetype(FONT_BOLD if bold else FONT_REGULAR, size)


def clamp(value, low=0.0, high=1.0):
    return max(low, min(high, value))


def smooth(value):
    value = clamp(value)
    return value * value * (3 - 2 * value)


def fade_window(local_time, duration, edge=0.65):
    return smooth(local_time / edge) * smooth((duration - local_time) / edge)


def fit_image(image, max_width, max_height):
    image = image.copy()
    image.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)
    return image


def centered_text(draw, xy, text, text_font, fill, anchor="mm"):
    draw.text(xy, text, font=text_font, fill=fill, anchor=anchor)


def draw_background(frame_number, accent=(47, 209, 216)):
    image = Image.new("RGB", (WIDTH, HEIGHT), (7, 15, 24))
    draw = ImageDraw.Draw(image, "RGBA")

    # Quiet architectural grid with a moving scan line.
    for x in range(0, WIDTH, 96):
        draw.line((x, 0, x, HEIGHT), fill=(116, 146, 164, 13), width=1)
    for y in range(0, HEIGHT, 96):
        draw.line((0, y, WIDTH, y), fill=(116, 146, 164, 13), width=1)
    scan_x = int((frame_number * 4.2) % (WIDTH + 420)) - 210
    for offset in range(-100, 101, 10):
        alpha = int(18 * (1 - abs(offset) / 110))
        draw.line((scan_x + offset, 0, scan_x + offset, HEIGHT), fill=(*accent, alpha), width=8)

    # Circuit traces keep the frame active without turning it into decoration soup.
    trace = (*accent, 50)
    draw.line((0, 180, 250, 180, 330, 260, 570, 260), fill=trace, width=3)
    draw.ellipse((560, 250, 580, 270), outline=(*accent, 115), width=3)
    draw.line((WIDTH, 820, 1640, 820, 1540, 720, 1320, 720), fill=trace, width=3)
    draw.ellipse((1308, 708, 1332, 732), outline=(*accent, 115), width=3)
    return image


def draw_brand_lockup(image, alpha=255, compact=False):
    layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    logo = fit_image(Image.open(ASSETS / "logo.png").convert("RGBA"), 86 if compact else 124, 86 if compact else 124)
    logo.putalpha(logo.getchannel("A").point(lambda value: value * alpha // 255))
    x, y = (72, 54) if compact else (112, 82)
    layer.alpha_composite(logo, (x, y))
    draw.text((x + logo.width + 22, y + (18 if compact else 17)), "Huber I.T. Professionals", font=font(34 if compact else 42, True), fill=(238, 246, 250, alpha))
    draw.text((x + logo.width + 22, y + (56 if compact else 68)), "NETWORKING  •  SECURITY  •  AUTOMATION", font=font(15 if compact else 18, True), fill=(150, 174, 188, alpha))
    image.paste(layer, (0, 0), layer)


def draw_intro(frame_number, local_time, duration):
    alpha = int(255 * fade_window(local_time, duration, 0.8))
    image = draw_background(frame_number)
    layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    progress = smooth(clamp(local_time / 1.25))
    logo = fit_image(Image.open(ASSETS / "logo.png").convert("RGBA"), int(270 + 55 * progress), int(270 + 55 * progress))
    logo.putalpha(logo.getchannel("A").point(lambda value: value * alpha // 255))
    layer.alpha_composite(logo, ((WIDTH - logo.width) // 2, 175 - int(18 * progress)))
    centered_text(draw, (WIDTH // 2, 590), "Huber I.T. Professionals", font(74, True), (242, 249, 252, alpha))
    centered_text(draw, (WIDTH // 2, 685), "COMPLETE TECHNOLOGY SERVICES", font(27, True), (47, 209, 216, alpha))
    line_width = int(650 * smooth(clamp((local_time - 0.35) / 1.15)))
    draw.rounded_rectangle((WIDTH // 2 - line_width // 2, 743, WIDTH // 2 + line_width // 2, 749), 3, fill=(47, 209, 216, alpha))
    centered_text(draw, (WIDTH // 2, 810), "Installation  •  Repair  •  Maintenance  •  Support", font(27), (171, 191, 202, alpha))
    image.paste(layer, (0, 0), layer)
    return image


def draw_service(frame_number, service, local_time, duration, service_index):
    accent = service["accent"]
    image = draw_background(frame_number, accent)
    alpha = int(255 * fade_window(local_time, duration, 0.55))
    enter = smooth(clamp(local_time / 0.8))
    layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    draw_brand_lockup(layer, alpha, compact=True)

    icon_panel_x = int(120 - (1 - enter) * 90)
    draw.rounded_rectangle((icon_panel_x, 265, icon_panel_x + 510, 825), radius=22, fill=(15, 31, 43, 225), outline=(*accent, 170), width=3)
    draw.rectangle((icon_panel_x, 265, icon_panel_x + 10, 825), fill=(*accent, alpha))
    icon = fit_image(Image.open(ASSETS / service["icon"]).convert("RGBA"), 290, 290)
    icon.putalpha(icon.getchannel("A").point(lambda value: value * alpha // 255))
    layer.alpha_composite(icon, (icon_panel_x + (510 - icon.width) // 2, 354))
    centered_text(draw, (icon_panel_x + 255, 725), f"0{service_index + 1}", font(23, True), (*accent, alpha))

    text_x = int(735 + (1 - enter) * 110)
    draw.text((text_x, 315), service["eyebrow"], font=font(22, True), fill=(*accent, alpha))
    draw.text((text_x, 370), service["title"], font=font(72, True), fill=(242, 249, 252, alpha))
    draw.rounded_rectangle((text_x, 480, text_x + 675, 486), radius=3, fill=(*accent, alpha))

    for index, bullet in enumerate(service["bullets"]):
        bullet_alpha = int(alpha * smooth(clamp((local_time - 0.42 - index * 0.18) / 0.48)))
        y = 548 + index * 96
        draw.ellipse((text_x, y + 13, text_x + 18, y + 31), fill=(*accent, bullet_alpha))
        draw.text((text_x + 46, y), bullet, font=font(33), fill=(205, 219, 226, bullet_alpha))

    # Timeline tells a passing viewer how much of the loop remains.
    timeline_y = 974
    draw.line((118, timeline_y, WIDTH - 118, timeline_y), fill=(104, 126, 139, 90), width=3)
    segment_width = (WIDTH - 236) / len(SERVICES)
    for index in range(len(SERVICES)):
        x1 = 118 + index * segment_width
        x2 = x1 + segment_width - 18
        fill = (*accent, alpha) if index == service_index else (116, 137, 149, 100)
        draw.rounded_rectangle((x1, timeline_y - 5, x2, timeline_y + 5), radius=5, fill=fill)

    image.paste(layer, (0, 0), layer)
    return image


def draw_outro(frame_number, local_time, duration):
    image = draw_background(frame_number)
    alpha = int(255 * fade_window(local_time, duration, 0.85))
    enter = smooth(clamp(local_time / 0.75))
    layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    logo = fit_image(Image.open(ASSETS / "logo.png").convert("RGBA"), 245, 245)
    logo.putalpha(logo.getchannel("A").point(lambda value: value * alpha // 255))
    layer.alpha_composite(logo, (220, 280))
    text_x = int(570 + (1 - enter) * 80)
    draw.text((text_x, 265), "Ready for a better", font=font(45), fill=(174, 194, 205, alpha))
    draw.text((text_x, 325), "connected experience?", font=font(70, True), fill=(242, 249, 252, alpha))
    draw.rounded_rectangle((text_x, 450, text_x + 900, 456), radius=3, fill=(47, 209, 216, alpha))
    draw.text((text_x, 505), "605-787-0103", font=font(58, True), fill=(47, 209, 216, alpha))
    draw.text((text_x, 590), "www.huberitps.com", font=font(38), fill=(211, 224, 231, alpha))
    draw.text((text_x, 690), "SECURITY  •  NETWORKING  •  ACCESS  •  AUDIO/VIDEO  •  AUTOMATION", font=font(21, True), fill=(149, 171, 184, alpha))
    image.paste(layer, (0, 0), layer)
    return image


def render_frame(frame_number):
    time = frame_number / FPS
    if time < 4:
        return draw_intro(frame_number, time, 4)
    if time < 26.5:
        service_index = min(4, int((time - 4) // 4.5))
        local_time = (time - 4) - service_index * 4.5
        return draw_service(frame_number, SERVICES[service_index], local_time, 4.5, service_index)
    return draw_outro(frame_number, time - 26.5, 3.5)


def main():
    if FRAMES.exists():
        shutil.rmtree(FRAMES)
    FRAMES.mkdir(parents=True)
    total = FPS * DURATION
    for frame_number in range(total):
        frame = render_frame(frame_number)
        frame.save(FRAMES / f"frame-{frame_number:04d}.jpg", quality=92, subsampling=0)
        if frame_number % 90 == 0:
            print(f"Rendered {frame_number}/{total} frames")
    print(f"Rendered {total} frames to {FRAMES}")


if __name__ == "__main__":
    main()

import AVFoundation
import AppKit
import CoreVideo
import Foundation

guard CommandLine.arguments.count >= 3 else {
    fputs("Usage: swift encode-mp4.swift <frames-directory> <output.mp4>\n", stderr)
    exit(2)
}

let frameDirectory = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
let outputURL = URL(fileURLWithPath: CommandLine.arguments[2])
let frameRate: Int32 = 30
let width = 1920
let height = 1080

let files = try FileManager.default.contentsOfDirectory(at: frameDirectory, includingPropertiesForKeys: nil)
    .filter { $0.pathExtension.lowercased() == "jpg" }
    .sorted { $0.lastPathComponent < $1.lastPathComponent }

guard !files.isEmpty else {
    fputs("No JPG frames found.\n", stderr)
    exit(3)
}

try? FileManager.default.removeItem(at: outputURL)
let writer = try AVAssetWriter(outputURL: outputURL, fileType: .mp4)
let settings: [String: Any] = [
    AVVideoCodecKey: AVVideoCodecType.h264,
    AVVideoWidthKey: width,
    AVVideoHeightKey: height,
    AVVideoCompressionPropertiesKey: [
        AVVideoAverageBitRateKey: 8_000_000,
        AVVideoExpectedSourceFrameRateKey: frameRate,
        AVVideoMaxKeyFrameIntervalKey: 60
    ]
]
let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
input.expectsMediaDataInRealTime = false
let adaptor = AVAssetWriterInputPixelBufferAdaptor(
    assetWriterInput: input,
    sourcePixelBufferAttributes: [
        kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
        kCVPixelBufferWidthKey as String: width,
        kCVPixelBufferHeightKey as String: height,
        kCVPixelBufferCGImageCompatibilityKey as String: true,
        kCVPixelBufferCGBitmapContextCompatibilityKey as String: true
    ]
)

guard writer.canAdd(input) else {
    fputs("Unable to add video input.\n", stderr)
    exit(4)
}
writer.add(input)
guard writer.startWriting() else {
    fputs("Unable to start video writer: \(writer.error?.localizedDescription ?? "unknown error")\n", stderr)
    exit(5)
}
writer.startSession(atSourceTime: .zero)

for (index, file) in files.enumerated() {
    autoreleasepool {
        while !input.isReadyForMoreMediaData {
            Thread.sleep(forTimeInterval: 0.002)
        }
        guard let image = NSImage(contentsOf: file),
              let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil),
              let pool = adaptor.pixelBufferPool else {
            fputs("Unable to decode \(file.lastPathComponent).\n", stderr)
            return
        }
        var optionalBuffer: CVPixelBuffer?
        guard CVPixelBufferPoolCreatePixelBuffer(nil, pool, &optionalBuffer) == kCVReturnSuccess,
              let buffer = optionalBuffer else {
            fputs("Unable to create pixel buffer.\n", stderr)
            return
        }
        CVPixelBufferLockBaseAddress(buffer, [])
        if let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue
        ) {
            context.setFillColor(NSColor.black.cgColor)
            context.fill(CGRect(x: 0, y: 0, width: width, height: height))
            context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        }
        CVPixelBufferUnlockBaseAddress(buffer, [])
        let presentationTime = CMTime(value: CMTimeValue(index), timescale: frameRate)
        if !adaptor.append(buffer, withPresentationTime: presentationTime) {
            fputs("Unable to append frame \(index): \(writer.error?.localizedDescription ?? "unknown error")\n", stderr)
        }
        if index % 90 == 0 {
            print("Encoded \(index)/\(files.count) frames")
        }
    }
}

input.markAsFinished()
let semaphore = DispatchSemaphore(value: 0)
writer.finishWriting { semaphore.signal() }
semaphore.wait()

guard writer.status == .completed else {
    fputs("Encoding failed: \(writer.error?.localizedDescription ?? "unknown error")\n", stderr)
    exit(6)
}
print("Created \(outputURL.path)")

# SQLite Database Migration

The website now stores structured records in:

`Website/.data/huber-it.sqlite`

Uploaded documents, ticket attachments, signatures, and receipt images remain in
their existing folders. This keeps large files out of the database while their
records and permissions stay database-backed.

## Server Requirement

Use Node.js 22.5 or newer:

```bash
node --version
```

The recommended Ubuntu version is the current Node.js 22 LTS release.

## First Start

Stop the existing website process, update the Website folder, and start it normally:

```bash
cd /path/to/Website
node server.mjs
```

On the first start, existing JSON and text records are imported automatically.
The original files remain in place and continue to be refreshed as rollback
snapshots. Repeated starts do not duplicate data.

## Verification

After signing in as `Huber58`, open **Server Diagnostics**. The
`huber-it.sqlite` row should show **Healthy**. Test these workflows before
removing any old server copy:

- Sign in and sign out
- Open employee records and service tickets
- Open Finance, Bills, Banking, and Profit & Loss
- Open Documents and download a file
- Generate and revoke a customer portal code

## Backups

Existing Friday and manual backups include the SQLite database. The backup
script checkpoints pending database changes before creating the archive.
Restore now reopens the restored database automatically.

## Rollback

Keep a full backup from immediately before deployment. To return temporarily to
the file-backed version:

1. Stop the website server.
2. Restore the pre-migration Website folder or backup archive.
3. Start the older `server.mjs`.

The refreshed JSON and text snapshots allow the older version to read records
created while SQLite was active.

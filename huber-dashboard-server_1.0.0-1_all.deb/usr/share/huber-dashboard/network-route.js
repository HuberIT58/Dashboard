(function () {
  "use strict";

  const routeParameter = "huber-route";

  function normalizeBaseUrl(value) {
    try {
      const url = new URL(String(value || "").trim());
      if (!/^https?:$/.test(url.protocol)) return "";
      return url.origin;
    } catch {
      return "";
    }
  }

  async function fetchWithTimeout(url, timeoutMs, { json = false, probe = false } = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, {
        cache: "no-store",
        credentials: probe ? "omit" : "same-origin",
        headers: probe ? { "X-Huber-LAN-Probe": "1" } : {},
        signal: controller.signal
      });
      return json ? (response.ok ? await response.json() : null) : response;
    } finally {
      clearTimeout(timeout);
    }
  }

  async function resolve(options = {}) {
    if (location.protocol === "file:") return { route: "file" };

    try {
      const config = await fetchWithTimeout("/api/network-route", 3000, { json: true });
      if (!config) return { route: "public" };
      const lanOrigin = normalizeBaseUrl(config.lanBaseUrl);
      const configuredTimeout = Number(config.probeTimeoutMs || 1200);
      const timeoutMs = Number.isFinite(configuredTimeout)
        ? Math.min(3000, Math.max(500, configuredTimeout)) : 1200;

      if (!lanOrigin || lanOrigin === location.origin) return { route: lanOrigin ? "lan" : "public" };

      // Secure browser pages may only probe another secure origin. The desktop
      // application can still use a private HTTP address directly.
      if (location.protocol === "https:" && !lanOrigin.startsWith("https:")) {
        return { route: "public", reason: "secure-lan-url-required" };
      }

      options.statusElement && (options.statusElement.textContent = "Checking for the local server...");
      const health = await fetchWithTimeout(`${lanOrigin}/api/lan-health`, timeoutMs, { probe: true });
      if (!health.ok) throw new Error("Local server did not answer.");

      const destination = new URL(location.href);
      destination.protocol = new URL(lanOrigin).protocol;
      destination.host = new URL(lanOrigin).host;
      destination.searchParams.set(routeParameter, "lan");
      location.replace(destination.href);
      return { route: "lan", redirecting: true };
    } catch {
      if (options.statusElement?.textContent === "Checking for the local server...") {
        options.statusElement.textContent = "";
      }
      return { route: "public" };
    }
  }

  window.HuberNetworkRoute = { resolve };
}());

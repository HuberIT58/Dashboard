/* Controls and request coordination for the mail workspace. */
(() => {
  const $ = selector => document.querySelector(selector);
  $('.account-card').innerHTML = '<strong>Mailbox</strong><span>Zoho POP / SMTP</span>';
  $('.list-controls').innerHTML = '<select id="message-filter" aria-label="Filter current page"><option value="all">All messages</option><option value="unread">Unread on page</option><option value="flagged">Flagged on page</option></select>';
  const newFolder = document.createElement('button');
  newFolder.type = 'button';
  newFolder.className = 'folder';
  newFolder.title = 'New folder';
  newFolder.setAttribute('aria-label', 'New folder');
  newFolder.innerHTML = '<span class="folder-icon" aria-hidden="true">+</span><span>New folder</span>';
  newFolder.addEventListener('click', () => openFolderDialog('create'));
  $('#draft-folder').after(newFolder);

  const originalRender = renderMessages;
  renderMessages = function () {
    originalRender();
    if (state.isLocalDrafts) return;
    const filter = $('#message-filter').value;
    for (const row of $('#message-list').querySelectorAll('[data-uid]')) {
      const message = state.messages.find(item => String(item.uid) === row.dataset.uid);
      row.hidden = filter === 'unread' ? message?.seen : filter === 'flagged' ? !message?.flagged : false;
    }
    if (state.messages.length && !$('#message-list [data-uid]:not([hidden])')) {
      const empty = document.createElement('p');
      empty.className = 'list-empty';
      empty.textContent = 'No matching messages on this page.';
      $('#message-list').append(empty);
    }
  };
  $('#message-filter').addEventListener('change', renderMessages);
  const originalClear = clearReader;
  clearReader = function () { readerRequest++; originalClear(); };

  // Preserve a new draft's identity while autosave and Close overlap.
  let draftSave = Promise.resolve();
  let sending = false;
  saveDraft = function () {
    const values = composeValues();
    if (!values.to && !values.subject && !values.userText) return draftSave;
    const operation = draftSave.catch(() => {}).then(async () => {
      $('#draft-state').textContent = 'Saving...';
      const result = await api('/api/mail/drafts', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({id: state.draftId, ...values})
      });
      state.draftId = result.draft.id;
      $('#delete-draft').hidden = false;
      $('#draft-state').textContent = 'Draft saved';
      await loadDrafts();
    });
    draftSave = operation;
    return operation;
  };
  $('#compose-dialog').addEventListener('cancel', event => {event.preventDefault(); closeCompose();});
  const originalClose = closeCompose;
  closeCompose = async function () {if (!sending) await originalClose();};
  const originalDelete = deleteDraft;
  deleteDraft = async function () {
    clearTimeout(scheduleDraft.timer);
    await draftSave;
    return originalDelete();
  };
  const originalSend = sendMessage;
  $('#compose-form').removeEventListener('submit', originalSend);
  $('#compose-form').addEventListener('submit', async event => {
    event.preventDefault();
    if (sending) return;
    sending = true;
    clearTimeout(scheduleDraft.timer);
    $('#compose-form').inert = true;
    try {
      await draftSave;
      await originalSend(event);
    } catch (error) { toast(error.message); }
    finally { sending = false; $('#compose-form').inert = false; }
  });

  // A refresh event's currentTarget is cleared before awaited requests finish.
  const refresh = $('#refresh'), replacement = refresh.cloneNode(true);
  refresh.replaceWith(replacement);
  replacement.addEventListener('click', async () => {
    replacement.disabled = true;
    replacement.classList.add('refreshing');
    try {
      await Promise.all([loadDrafts(), loadMessages({force: true})]);
      await loadFolders();
      toast('Mailbox refreshed.');
    } catch (error) { toast(error.message); }
    finally { replacement.disabled = false; replacement.classList.remove('refreshing'); }
  });

  const originalLoad = loadMessages;
  let listRequest = 0;
  loadMessages = async function (options = {}) {
    const request = ++listRequest;
    $('.status-sync').textContent = 'Syncing mailbox...';
    try {
      await originalLoad(options);
      if (request !== listRequest) return;
      $('.mail-status').dataset.error = 'false';
      $('.status-sync').textContent = 'Updated ' + new Date().toLocaleTimeString([], {hour: 'numeric', minute: '2-digit'});
      $('.status-account .status-ok').textContent = 'Mailbox connected';
    } catch (error) {
      if (request === listRequest) {
        $('.mail-status').dataset.error = 'true';
        $('.status-sync').textContent = 'Sync failed';
        $('.status-account .status-ok').textContent = 'Connection needs attention';
      }
      throw error;
    }
  };
  $('.status-sync').textContent = 'Connecting...';
  $('.status-account .status-ok').textContent = 'Checking mailbox';
  window.addEventListener('resize', () => {$('#close-reader').hidden = innerWidth > 760;});
})();

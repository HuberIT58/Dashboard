# Financial Integrations Setup

## Bank Statements

Banking uses statement imports and does not require external bank credentials.
From Banking, import a statement exported by the bank in CSV, OFX, QFX, or QBO
format. The server reads the transactions and then discards the uploaded file.

The Plaid connector is no longer used. Because the website updater preserves the
Ubuntu `.env` file, old `PLAID_*` lines can be removed from that file whenever
convenient; the application no longer reads them.

CSV statements should include Date, Description, and Amount columns, or separate
Debit and Credit columns. During import, choose whether a positive value in a
single Amount column represents a deposit or a withdrawal. Importing the same
statement again does not create duplicate transactions.

## Zoho Payments

The customer portal uses Zoho's embedded checkout for service invoices and
contract payments. Card details and bank credentials go directly to Zoho and
are never stored by this server.

In Zoho Payments, finish account verification first. Then create:

1. An API key under Developer Space for the embedded checkout widget.
2. An organization OAuth client with the scopes
   `ZohoPay.payments.CREATE,ZohoPay.payments.READ`.
3. An offline OAuth refresh token for the same Zoho Payments account.
4. A webhook with the signing key copied into `.env`.

Add these values to `.env` on Ubuntu:

```env
ZOHO_PAYMENTS_ACCOUNT_ID=replace-with-zoho-payments-account-id
ZOHO_PAYMENTS_API_KEY=replace-with-widget-api-key
ZOHO_PAYMENTS_CLIENT_ID=replace-with-org-client-id
ZOHO_PAYMENTS_CLIENT_SECRET=replace-with-org-client-secret
ZOHO_PAYMENTS_REFRESH_TOKEN=replace-with-oauth-refresh-token
ZOHO_PAYMENTS_WEBHOOK_SIGNING_KEY=replace-with-webhook-signing-key
ZOHO_PAYMENTS_DOMAIN=US
ZOHO_PAYMENTS_ACCOUNTS_URL=https://accounts.zoho.com
ZOHO_PAYMENTS_API_BASE=https://payments.zoho.com/api/v1
```

Create the webhook at:

`https://www.huberitps.com/api/zoho-payments-webhook`

Subscribe it to:

- `payment.succeeded`
- `payment.pending`
- `payment.failed`

The OAuth authorization request must use your Zoho Payments account as the
organization and request offline access. Zoho returns the refresh token only
during the initial authorization flow, so store it in `.env` immediately.

Before accepting live payments, test one card payment and one ACH payment.
Confirm that the customer portal balance, invoice status, Finance payment
record, and Job Workspace all update after the webhook is delivered.

Restart `server.mjs` after changing `.env`.

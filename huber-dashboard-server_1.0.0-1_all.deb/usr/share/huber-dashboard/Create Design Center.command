#!/bin/zsh
set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"
UPDATES="$ROOT/Updates"
mkdir -p "$UPDATES"
RUNTIME="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies"
export PATH="$RUNTIME/node/bin:$RUNTIME/bin:$PATH"
NODE="$RUNTIME/node/bin/node"
PNPM="$RUNTIME/bin/fallback/pnpm"

cd "$ROOT/design-center-desktop"
"$PNPM" install --ignore-workspace
"$NODE" node_modules/electron-builder/out/cli/cli.js --mac dmg zip

DMG="$(find "$ROOT/design-center-desktop/dist" -maxdepth 1 -name 'Huber Design Center-*-arm64.dmg' -print | sort | tail -1)"
if [[ -z "$DMG" ]]; then
  echo "Huber Design Center DMG was not created."
  exit 1
fi

cp "$DMG" "$UPDATES/Huber-Design-Center.dmg"
open -R "$UPDATES/Huber-Design-Center.dmg"
echo "Created $UPDATES/Huber-Design-Center.dmg"

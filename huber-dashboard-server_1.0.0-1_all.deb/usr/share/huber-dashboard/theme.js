(function () {
  // Track same-origin data reads without delaying requests or changing responses.
  const readFetch = window.fetch.bind(window);
  let activeReads = 0, loadingTimer, loadingIndicator;
  function endRead() {
    activeReads--;
    if (activeReads) return;
    clearTimeout(loadingTimer);
    if (loadingIndicator) loadingIndicator.hidden = true;
    if (document.body) delete document.body.dataset.huberLoading;
  }
  window.fetch = async function(input, options) {
    const url = new URL(input instanceof Request ? input.url : input, location.href);
    const method = String(options?.method || (input instanceof Request ? input.method : 'GET')).toUpperCase();
    if (url.origin !== location.origin || !url.pathname.startsWith('/api/') || method !== 'GET') return readFetch(input, options);
    if (++activeReads === 1) loadingTimer = setTimeout(() => {
      if (!document.body || !activeReads) return;
      if (!loadingIndicator) {
        loadingIndicator = document.createElement('div');
        loadingIndicator.className = 'huber-loading-indicator';
        loadingIndicator.setAttribute('role', 'progressbar');
        loadingIndicator.setAttribute('aria-label', 'Loading data');
        document.body.append(loadingIndicator);
      }
      loadingIndicator.hidden = false;
      document.body.dataset.huberLoading = 'true';
    }, 250);
    try { return await readFetch(input, options); } finally { endRead(); }
  };
  function polishWorkspace(root = document) {
    const find = selector => [...(root.matches?.(selector) ? [root] : []), ...root.querySelectorAll(selector)];
    // Replace only standalone decorative glyphs, never user-entered content.
    const glyphs = {
      '\u{1f514}': ['Notifications', '<path d="M10.268 21a2 2 0 0 0 3.464 0"/><path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"/>'],
      '\u2699': ['Settings', '<path d="M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915"/><circle cx="12" cy="12" r="3"/>']
    };
    find('button').forEach(button => {
      if (button.children.length) return;
      const icon = glyphs[button.textContent.trim().replace(/\ufe0f/g,'')];
      if (!icon) return;
      if (!button.hasAttribute('aria-label')) button.setAttribute('aria-label',icon[0]);
      button.title ||= icon[0];
      button.innerHTML = `<svg class="huber-line-icon" viewBox="0 0 24 24" aria-hidden="true">${icon[1]}</svg>`;
    });
    find('table').forEach(table => {
      const columns = [...table.querySelectorAll('thead tr:first-child th')].map((th,index) => /^(total|amount|balance|paid|rate|cost|wage|subtotal)$/i.test(th.textContent.trim()) ? index : -1).filter(i=>i>=0);
      for (const row of table.rows) for (const index of columns) row.cells[index]?.classList.add('huber-money');
    });
  }
  document.addEventListener('DOMContentLoaded', () => {
    polishWorkspace();
    let queued = false;
    const roots = new Set();
    new MutationObserver(records => {
      for (const record of records) {
        if (!record.addedNodes.length) continue;
        const table = record.target.closest?.('table');
        if (table) roots.add(table);
        for (const node of record.addedNodes) if (node.nodeType === 1) roots.add(node);
      }
      if (queued || !roots.size) return;
      queued = true;
      requestAnimationFrame(() => { queued = false; for (const root of roots) if (root.isConnected) polishWorkspace(root); roots.clear(); });
    }).observe(document.body, {childList:true,subtree:true});
  }, {once:true});
  const professionalScript = document.createElement("script");
  professionalScript.src = "/professional-ui.js";
  professionalScript.defer = true;
  document.head.append(professionalScript);
  const storageKey = "huber-account-theme";
  const media = window.matchMedia("(prefers-color-scheme: dark)");
  const choices = [
    "professional", "midnight", "contrast", "modern",
    "coastal", "ember", "orchard", "steel",
    "system", "light", "dark"
  ];
  const darkStyles = new Set(["midnight", "ember", "steel"]);
  const auditStyleId = "huber-theme-audit-style";
  const surfaceFixClass = "huber-theme-surface-fix";
  const controlFixClass = "huber-theme-control-fix";
  let surfaceGuardObserver = null;
  let surfaceGuardFrame = 0;
  const pendingSurfaceRoots = new Set();
  let currentChoice = "system";
  try { currentChoice = localStorage.getItem(storageKey) || "system"; } catch {}

  function installThemeAuditStyle() {
    if (document.getElementById(auditStyleId)) return;
    const style = document.createElement("style");
    style.id = auditStyleId;
    style.textContent = `
      html[data-theme="dark"] {
        color-scheme: dark;
      }

      html[data-theme="dark"] .${surfaceFixClass} {
        border-color: var(--line, #3a484e) !important;
        background-color: var(--panel, #182226) !important;
        color: var(--ink, var(--text, #edf3f5)) !important;
      }

      html[data-theme="dark"] .${controlFixClass} {
        border-color: #526168 !important;
        background-color: #0d171c !important;
        color: var(--ink, var(--text, #edf3f5)) !important;
      }

      html[data-theme="dark"] :where(
        body, main
      ) {
        background-color: var(--page, var(--bg, #101719)) !important;
        color: var(--ink, var(--text, #edf3f5)) !important;
      }

      html[data-theme="dark"] :where(
        .panel, .panel-body, .panel-head, .metric, .metrics, .table-wrap,
        .form, .section-box, .line-table, .line-row, .request, .customer,
        .account, .device-section, .settings-layout, .role-editor,
        .ticket-form, .ticket-detail, .ticket-details, .record-form,
        .event-form, .invoice-form, .invoice-view, .charge-builder,
        .charge-line, .charge-list, .saved-charge, .history, .explorer,
        .folder-pane, .folder-tools, .organizer, .group, .group-row,
        .dialog-body, dialog, article, .empty, .notice, .hint, .upload-box,
        .preview-box, .ocr-lines, .result, .required-panel, .setup-key,
        .recovery, .photo-field, .contact-card, .today-card, .today-ticket,
        .notification, .popup-notification, .service-announcement,
        .availability-form, .availability-row, .pto-metric, .pto-settings
      ) {
        border-color: var(--line, #3a484e) !important;
        background-color: var(--panel, #182226) !important;
        color: var(--ink, var(--text, #edf3f5)) !important;
      }

      html[data-theme="dark"] :where(
        input:not([type="checkbox"]):not([type="radio"]),
        select, textarea, .control, .search, .filter, .field select,
        .line-row input, .import-table input, .import-table select,
        .import-table textarea
      ) {
        border-color: #526168 !important;
        background-color: #0d171c !important;
        color: var(--ink, var(--text, #edf3f5)) !important;
      }

      html[data-theme="dark"] :where(
        button, .button, .row-button, .header-link, .header-actions a,
        .top a, .topbar a, .back, .secondary, .action, .command,
        .download, .close, .dialog-close, .new-role, .remove-device,
        .form-actions button, .actions button, .row-actions button,
        .template-tools button, .template-tools select, .tab-button,
        .mode-action, .small, .print, .breadcrumb, .tree-folder,
        .restore, .delete-file, .wipe-actions button, .receipt-link
      ) {
        border-color: #526168 !important;
        background-color: #111a1e !important;
        color: var(--ink, var(--text, #edf3f5)) !important;
      }

      html[data-theme="dark"] :where(
        .primary, .save, .submit, .new, .clock-button, .add-charge,
        .organizer-save, .actions .approve, .login-panel button,
        .tab-button.active, button.primary, a.primary
      ) {
        border-color: var(--accent, #28a9b3) !important;
        background-color: #087f8c !important;
        color: #fff !important;
      }

      html[data-theme="dark"] :where(
        .danger, .delete, .deny, .remove, .row-actions .danger,
        .template-tools button[data-delete-template]
      ) {
        border-color: #a65b55 !important;
        background-color: #2b1d1d !important;
        color: #ffaaa3 !important;
      }

      html[data-theme="dark"] :where(
        th, thead, .line-head, .weekday, .day-heading, .role-list
      ) {
        border-color: var(--line, #3a484e) !important;
        background-color: #243137 !important;
        color: #d9e3e6 !important;
      }

      html[data-theme="dark"] :where(
        td, tr, .line-head span, .line-row > *, .breakdown-row,
        .device-row, .entry, .history-row
      ) {
        border-color: #334147 !important;
      }

      html[data-theme="dark"] :where(
        p, label, small, .muted, .status-line, .note, .toolbar p,
        .section-heading span, .panel-head p, .metric span, .description,
        .sku, .type, .entry span, .request span, .customer span,
        .device-row span, .account span, .position, .empty
      ) {
        color: var(--muted, #aab7bc) !important;
      }

      html[data-theme="dark"] :where(
        button:not(:disabled), a, .row-button, .button, .action
      ):hover {
        border-color: var(--accent, #28a9b3) !important;
        color: var(--ink, var(--text, #edf3f5)) !important;
      }
    `;
    const append = () => document.head.append(style);
    if (document.head) append();
    else document.addEventListener("DOMContentLoaded", append, { once: true });
  }

  function neutralLightBackground(value) {
    const match = String(value || "").match(
      /^rgba?\(\s*([\d.]+)[, ]+\s*([\d.]+)[, ]+\s*([\d.]+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/i
    );
    if (!match || (match[4] !== undefined && Number(match[4]) < 0.08)) return false;
    const channels = match.slice(1, 4).map(Number);
    return Math.min(...channels) >= 220 && Math.max(...channels) - Math.min(...channels) <= 36;
  }

  function preserveSurface(element) {
    return Boolean(element.closest(`
      [data-theme-preserve], .paper, .badge-card, .badge-photo,
      .document-preview, .document-sheet, .slide-canvas, .slide-stage,
      .print-slide, .signature-pad, .saved-signature, .photo-preview,
      .video-art, .player-frame, .swatch, .color-swatch, .asset-label,
      .label-preview, .logo-preview
    `)) || element.matches("img,canvas,svg,video,iframe,progress,input[type='color']");
  }

  function auditSurface(element) {
    if (!(element instanceof HTMLElement) || preserveSurface(element)) return;
    if (document.documentElement.dataset.theme !== "dark") {
      element.classList.remove(surfaceFixClass, controlFixClass);
      return;
    }
    if (element.classList.contains(surfaceFixClass) ||
        element.classList.contains(controlFixClass) || element.hidden) return;
    const style = getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden" ||
        style.backgroundImage !== "none" || !neutralLightBackground(style.backgroundColor)) return;
    const isControl = element.matches("button,input,select,textarea,option");
    element.classList.add(isControl ? controlFixClass : surfaceFixClass);
  }

  function runSurfaceAudit(root = document) {
    const selector = [
      "body", "main", "dialog", "form", "fieldset", "section", "article",
      "aside", "nav", "table", "thead", "tbody", "tr", "td", "th",
      "label", "div", "button", "input", "select", "textarea"
    ].join(",");
    if (root instanceof Element && root.matches(selector)) auditSurface(root);
    root.querySelectorAll?.(selector).forEach(auditSurface);
  }

  function scheduleSurfaceAudit(root = document) {
    if (document.documentElement.dataset.theme !== "dark") return;
    pendingSurfaceRoots.add(root);
    if (surfaceGuardFrame) return;
    surfaceGuardFrame = requestAnimationFrame(() => {
      surfaceGuardFrame = 0;
      const roots = [...pendingSurfaceRoots];
      pendingSurfaceRoots.clear();
      if (document.documentElement.dataset.theme !== "dark") return;
      // Keep a pending whole-page audit, but coalesce overlapping changed subtrees.
      roots.filter((candidate) => (candidate === document || candidate.isConnected) &&
        !roots.some((other) => other !== candidate && other.contains(candidate)))
        .forEach(runSurfaceAudit);
    });
  }

  function installSurfaceGuard() {
    if (!document.body || surfaceGuardObserver) return;
    surfaceGuardObserver = new MutationObserver((records) => {
      if (document.documentElement.dataset.theme !== "dark") return;
      for (const record of records) {
        if (record.type === "attributes") scheduleSurfaceAudit(record.target);
        else record.addedNodes.forEach((node) => {
          if (node instanceof Element) scheduleSurfaceAudit(node);
        });
      }
    });
    surfaceGuardObserver.observe(document.body, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ["class", "style", "hidden", "open"]
    });
    document.addEventListener("pointerover", (event) => {
      if (event.target instanceof HTMLElement) scheduleSurfaceAudit(event.target);
    }, true);
    scheduleSurfaceAudit();
  }

  function effectiveTheme(choice) {
    if (choice === "system") return media.matches ? "midnight" : "professional";
    if (choice === "light") return "professional";
    if (choice === "dark") return "midnight";
    return choice;
  }

  function applyTheme(choice) {
    installThemeAuditStyle();
    const normalized = choices.includes(choice) ? choice : "system";
    const effective = effectiveTheme(normalized);
    currentChoice = normalized;
    try { localStorage.setItem(storageKey, normalized); } catch {}
    document.documentElement.dataset.themeChoice = normalized;
    document.documentElement.dataset.themeStyle = effective;
    document.documentElement.dataset.theme = darkStyles.has(effective) ? "dark" : "light";
    if (!darkStyles.has(effective)) {
      document.querySelectorAll(`.${surfaceFixClass}, .${controlFixClass}`)
        .forEach((element) => element.classList.remove(surfaceFixClass, controlFixClass));
    }
    if (document.body) {
      document.body.dataset.themeStyle = effective;
      document.body.dataset.theme = darkStyles.has(effective) ? "dark" : "light";
      installSurfaceGuard();
    }
    scheduleSurfaceAudit();
    window.dispatchEvent(new CustomEvent("huber-theme-change", {
      detail: { choice: normalized, effective }
    }));
  }

  applyTheme(currentChoice);
  media.addEventListener("change", () => {
    if (currentChoice === "system") applyTheme("system");
  });
  document.addEventListener("DOMContentLoaded", () => {
    applyTheme(currentChoice);
    installSurfaceGuard();
  }, { once: true });
  window.addEventListener("storage", (event) => {
    if (event.key === storageKey || event.key === null) applyTheme(event.newValue || "system");
  });

  window.huberTheme = {
    current: () => currentChoice,
    apply: applyTheme,
    save: async (choice) => {
      const response = await fetch("/api/theme", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ theme: choice })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "Unable to save theme.");
      applyTheme(result.theme);
      return result.theme;
    }
  };

  fetch("/api/theme", { cache: "no-store" })
    .then((response) => response.ok ? response.json() : null)
    .then((result) => {
      if (result?.theme) applyTheme(result.theme);
    })
    .catch(() => {});
})();

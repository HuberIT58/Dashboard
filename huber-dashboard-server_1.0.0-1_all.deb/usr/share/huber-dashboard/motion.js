(function () {
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  if (reduceMotion.matches) {
    document.documentElement.dataset.reduceMotion = "true";
    return;
  }

  function markEntranceItems(root = document) {
    const selectors = [
      ".dashboard-link", ".metric", ".operation", ".panel",
      ".request", "article", ".schedule-day", ".customer"
    ];
    root.querySelectorAll(selectors.join(",")).forEach((element, index) => {
      if (element.dataset.motionReady) return;
      element.dataset.motionReady = "true";
      element.style.setProperty("--motion-order", String(Math.min(index, 12)));
      element.classList.add("motion-reveal");
    });
  }

  function animateValue(element) {
    if (reduceMotion.matches || !element.isConnected || element.closest("[hidden]")) return;
    element.animate([
      { opacity: 0.45, transform: "translateY(3px)" },
      { opacity: 1, transform: "translateY(0)" }
    ], { duration: 220, easing: "ease-out" });
  }

  function updateLoadingState(element) {
    const text = String(element.textContent || "").toLowerCase();
    const loading = element.disabled && /sync|load|sav|upload|generat|connect/.test(text);
    element.classList.toggle("motion-loading", loading);
  }

  function observeChanges() {
    const observer = new MutationObserver((records) => {
      if (reduceMotion.matches) return;
      const changedMetrics = new Set();
      for (const record of records) {
        if (record.type === "childList") {
          record.addedNodes.forEach((node) => {
            if (!(node instanceof Element)) return;
            markEntranceItems(node);
            if (node.matches(".metric strong,.operation strong,.finance-metrics strong")) {
              changedMetrics.add(node);
            }
            node.querySelectorAll?.(".metric strong,.operation strong,.finance-metrics strong")
              .forEach((metric) => changedMetrics.add(metric));
          });
        }
        const target = record.target instanceof Element
          ? record.target
          : record.target.parentElement;
        if (!target) continue;
        const metric = target.closest(".metric strong,.operation strong,.finance-metrics strong");
        if (metric) changedMetrics.add(metric);
        if (target.matches("button")) updateLoadingState(target);
        if (record.attributeName === "hidden" && !target.hidden &&
            target.matches(".view,[role='tabpanel']")) {
          target.classList.remove("motion-view-enter");
          requestAnimationFrame(() => target.classList.add("motion-view-enter"));
        }
      }
      changedMetrics.forEach(animateValue);
    });
    observer.observe(document.body, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: ["hidden", "disabled"]
    });
  }

  function prepareDialogs() {
    document.querySelectorAll("dialog").forEach((dialog) => {
      dialog.addEventListener("close", () => dialog.classList.remove("motion-dialog-open"));
      const original = dialog.showModal?.bind(dialog);
      if (!original || dialog.dataset.motionDialog) return;
      dialog.dataset.motionDialog = "true";
      dialog.showModal = () => {
        original();
        requestAnimationFrame(() => dialog.classList.add("motion-dialog-open"));
      };
    });
  }

  function initialize() {
    document.documentElement.classList.add("motion-enabled");
    markEntranceItems();
    prepareDialogs();
    document.querySelectorAll("button").forEach(updateLoadingState);
    observeChanges();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize, { once: true });
  } else {
    initialize();
  }
})();

# Huber Office Suite

Huber Office Suite combines company documents, presentations, and spreadsheets in one dedicated Mac app.

## Build the Mac installer

Double-click `Create Office Suite.command`, or run:

```sh
./Create\ Office\ Suite.command
```

The finished installer is created as `Huber-Office-Suite.dmg` in the Website `Updates` folder.

The app uses the live company server and shares authentication with the Huber Dashboard and Huber Email apps.

On supported Macs, Office Suite automatically requests Touch ID when the shared login session has expired. Open Dashboard 0.3.3 or newer once first to provision the macOS-encrypted shared credential. Cancelling Touch ID leaves the normal login page available.

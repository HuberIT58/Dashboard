# Huber App Installer

The installer reads its application list from the Ubuntu server. Only `Huber58`
can publish or replace packages.

## Initial setup

1. Upload `website.zip` through Website Updater. This adds the catalog and
   chunked DMG and EXE publishing endpoints to `server.mjs`.
2. Allow `server.mjs` to restart when Website Updater reports that a restart is
   scheduled.
3. Open Website Updater again and use **Publish Installer Application**.
4. Select **Huber Dashboard**, enter version `0.2.1`, and choose:
   `Updates/Huber-Dashboard.dmg`
5. Select **XCloud**, enter version `0.4.0`, and choose:
   `Updates/XCloud.dmg`
6. Install `Huber-App-Installer.dmg` on each Mac.
7. Install `Huber-App-Installer-Windows.exe` on each 64-bit Windows computer.

When publishing a Windows application, select **Windows 64-bit (.exe)** and
choose its NSIS installer. Mac and Windows releases use the same application ID;
the server keeps a separate package for each operating system and processor.

## Publishing future applications

Use the **Custom application** preset, assign a permanent lowercase ID, and
publish its DMG or EXE. Reuse that same ID for later versions. The new version
replaces only the matching platform package. On Windows, installed applications
offer **Update / Reinstall** so the latest verified installer can be run.

The server verifies the full upload and records its SHA-256 checksum. Huber App
Installer verifies every downloaded DMG or EXE against that checksum before
opening it.

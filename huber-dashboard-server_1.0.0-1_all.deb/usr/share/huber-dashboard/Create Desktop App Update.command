#!/bin/zsh

set -e
cd "${0:A:h}"

NODE=""
PNPM=""
for candidate in \
  "$(command -v node 2>/dev/null)" \
  "$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" \
  "/opt/homebrew/bin/node" \
  "/usr/local/bin/node"
do
  if [[ -n "$candidate" && -x "$candidate" ]]; then
    NODE="$candidate"
    break
  fi
done

for candidate in \
  "$(command -v pnpm 2>/dev/null)" \
  "$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback/pnpm" \
  "/opt/homebrew/bin/pnpm" \
  "/usr/local/bin/pnpm"
do
  if [[ -n "$candidate" && -x "$candidate" ]]; then
    PNPM="$candidate"
    break
  fi
done

if [[ -z "$NODE" || -z "$PNPM" ]]; then
  echo "Node.js or pnpm was not found."
  read -k 1 "?Press any key to close..."
  exit 1
fi

export PATH="${NODE:h}:${PNPM:h}:$PATH"
cd dashboard-desktop
CURRENT_VERSION=$("$NODE" -p "require('./package.json').version")
echo "Current desktop version: $CURRENT_VERSION"
echo "The new version must be higher than the version already installed."
read "DESKTOP_VERSION?New desktop version: "

if [[ -z "$DESKTOP_VERSION" ]]; then
  echo "No version entered. Nothing was changed."
  read -k 1 "?Press any key to close..."
  exit 1
fi

"$NODE" scripts/set-version.mjs "$DESKTOP_VERSION"
"$PNPM" run release:mac

echo
echo "Desktop version $DESKTOP_VERSION is ready."
echo "Choose Updates/desktop-app-update.zip in Website Updater."
read -k 1 "?Press any key to close..."

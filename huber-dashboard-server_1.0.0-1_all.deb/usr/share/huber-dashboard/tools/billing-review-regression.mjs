import assert from 'node:assert/strict';
import {mkdtempSync, rmSync, readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomBytes} from 'node:crypto';
import vm from 'node:vm';
import {StructuredStore} from '../database.mjs';

// Exercise production handlers without starting services or reading customer data.
const source = readFileSync(new URL('../server.mjs', import.meta.url), 'utf8');
function extract(name) {
  const start = source.search(new RegExp(`^(?:async )?function ${name}\\(`, 'm'));
  assert.ok(start >= 0, name);
  return source.slice(start, source.indexOf('\n}', start) + 2);
}
const root = mkdtempSync(join(tmpdir(), 'huber-review-'));
const store = new StructuredStore(join(root, 'test.sqlite'), root);
const read = key => JSON.parse(store.read(join(root, `${key}.json`)));
const write = (key, value) => store.write(join(root, `${key}.json`), JSON.stringify(value));
let failure = '', delayed = false;
const pending = [];
const noop = () => {};
const context = vm.createContext({
  randomBytes, structuredStore: store,
  getSession: () => ({username: 'test'}), hasPermission: () => true,
  readJsonBody: request => delayed ? new Promise(resolve => pending.push(resolve)) : request.payload,
  readBills: () => read('bills'), writeBills: value => write('bills', value),
  readFinance: () => read('finance'), writeFinance: value => write('finance', value),
  readInvoices: () => read('invoices'), writeInvoices: value => {
    if (failure === 'invoice') throw Error('simulated invoice failure');
    write('invoices', value);
  },
  readZohoPaymentSessions: () => read('sessions'), writeZohoPaymentSessions: value => {
    if (failure === 'mapping') throw Error('simulated mapping failure');
    write('sessions', value);
  },
  readTickets: () => read('tickets'),
  billSummary: bills => ({bills}), businessToday: () => '2026-09-20',
  logActivity: noop, logSystemActivity: noop, broadcastAllServiceEvent: noop,
  zohoPaymentMethod: () => 'Card',
  sendJson: (res, status, body) => {res.writeHead(status, {}); res.end(JSON.stringify(body));},
  getCustomerPortalSession: () => 'customer-a',
  readCustomers: () => [{id: 'customer-a', name: 'Same Name'}],
  contractPaymentSummaries: () => [], zohoPaymentsConfigured: () => true,
  createInvoiceZohoPaymentSession: async () => ({id: 'checkout'})
});
vm.runInContext(['billingTransaction', 'handleBills', 'handleBillsParsed', 'createBillPayment',
  'recordBillPayment', 'reconcileBankTransaction', 'roundMoney', 'invoicePaidAmount',
  'invoicePaymentStatus', 'recordZohoPayment', 'recordZohoPaymentParsed', 'handleCustomerPortal']
  .map(extract).join('\n'), context);
const response = () => ({writeHead(status) {this.status = status;}, end(body) {this.body = JSON.parse(body);}});
try {
  write('bills', ['a', 'b'].map(id => ({id, name: id, type: 'Bill', amount: 100, status: 'Unpaid', payments: []})));
  delayed = true;
  const a = response(), b = response();
  const first = context.handleBills({method: 'POST'}, a);
  const second = context.handleBills({method: 'POST'}, b);
  pending.shift()({action: 'mark-paid', id: 'a'}); await first;
  pending.shift()({action: 'mark-paid', id: 'b'}); await second;
  assert.equal(a.status, 200); assert.equal(b.status, 200);
  assert.ok(read('bills').every(bill => bill.payments.length === 1 && bill.status === 'Paid'));
  delayed = false;
  console.log('PASS: overlapping bill payments both survive');

  write('bills', [{id: 'loan', name: 'Loan', type: 'Loan', remainingLoanAmount: 100, monthlyPayment: 100, payments: []}]);
  const match = amount => context.reconcileBankTransaction({id: 'bank', amount}, {targetType: 'bill', targetId: 'loan'}, {username: 'test'});
  assert.throws(() => match(150), /exceeds/);
  assert.equal(read('bills')[0].payments.length, 0);
  assert.equal(match(100).amount, 100);
  assert.equal(read('bills')[0].remainingLoanAmount, 0);
  assert.throws(() => match(1), /exceeds|no remaining/);
  console.log('PASS: oversized loan withdrawals reject; exact payoff succeeds');

  write('tickets', [{id: 'own', customerId: 'customer-a'}, {id: 'other', customerId: 'customer-b', customer: 'Same Name'}, {id: 'legacy', customer: 'Same Name'}]);
  write('invoices', ['own', 'other', 'legacy'].map(id => ({id, ticketId: id, customer: 'Same Name', status: 'Sent', total: 100})));
  write('finance', {payments: []});
  const listing = response();
  await context.handleCustomerPortal({method: 'GET', url: '/api/customer-portal'}, listing);
  assert.deepEqual(listing.body.invoices.map(invoice => invoice.id), ['own']);
  for (const id of ['other', 'legacy', 'own']) {
    const res = response();
    await context.handleCustomerPortal({method: 'POST', url: '/api/customer-portal-checkout', payload: {invoiceId: id}}, res);
    assert.equal(res.status, id === 'own' ? 200 : 404);
  }
  console.log('PASS: portal listing and checkout require linked customer ID');

  const mapping = {id: 'session', paymentType: 'invoice', recordId: 'own', amount: 100, status: 'created'};
  const payment = {payment_id: 'processor', amount: 100, currency: 'USD', status: 'succeeded'};
  write('sessions', [mapping]);
  for (const point of ['invoice', 'mapping']) {
    failure = point;
    assert.throws(() => context.recordZohoPayment(payment, mapping), /simulated/);
    assert.equal(read('finance').payments.length, 0);
    assert.equal(read('invoices')[0].status, 'Sent');
    assert.equal(read('sessions')[0].status, 'created');
  }
  failure = '';
  assert.equal(context.recordZohoPayment(payment, mapping).recorded, true);
  assert.equal(context.recordZohoPayment(payment, mapping).recorded, false);
  assert.equal(read('finance').payments.length, 1);
  // Recover incomplete records left by older releases, without duplicating money.
  write('sessions', [mapping]);
  const invoices = read('invoices'); invoices[0].status = 'Sent'; write('invoices', invoices);
  context.recordZohoPayment(payment, mapping);
  assert.equal(read('finance').payments.length, 1);
  assert.equal(read('invoices')[0].status, 'Paid');
  assert.equal(read('sessions')[0].status, 'succeeded');
  console.log('PASS: processor writes roll back together; retries deduplicate and repair legacy partial saves');
} finally {
  store.close();
  rmSync(root, {recursive: true, force: true});
}

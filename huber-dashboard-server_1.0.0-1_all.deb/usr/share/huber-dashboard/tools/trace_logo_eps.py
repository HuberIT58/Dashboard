from pathlib import Path
import cv2
import numpy as np

SOURCE = Path('/Users/christian/Documents/full-logo-original-upscaled-5120.png')
OUT = Path('/Users/christian/Documents/Website')

img = cv2.imread(str(SOURCE), cv2.IMREAD_COLOR)
if img is None:
    raise SystemExit(f'Cannot read {SOURCE}')
b, g, r = cv2.split(img)
mx = np.maximum.reduce([b, g, r])
mn = np.minimum.reduce([b, g, r])

# Separate the colored emblem and neutral-white type from the black trailer field.
color_mask = ((mx > 55) & ((b.astype(np.int16) - r.astype(np.int16) > 24) |
                           (g.astype(np.int16) - r.astype(np.int16) > 24))).astype(np.uint8) * 255
white_mask = ((mx > 72) & ((mx.astype(np.int16) - mn.astype(np.int16)) < 38)).astype(np.uint8) * 255

kernel = np.ones((3, 3), np.uint8)
color_mask = cv2.morphologyEx(color_mask, cv2.MORPH_CLOSE, kernel)
white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_CLOSE, kernel)

H, W = img.shape[:2]
PAGE_W, PAGE_H = 1200.0, 960.0
sx, sy = PAGE_W / W, PAGE_H / H

def contours(mask):
    cs, hierarchy = cv2.findContours(mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
    result = []
    for c in cs:
        if abs(cv2.contourArea(c)) < 10:
            continue
        a = cv2.approxPolyDP(c, 1.25, True).reshape(-1, 2)
        if len(a) >= 3:
            result.append(a)
    return result

color_contours = contours(color_mask)
white_contours = contours(white_mask)

def ps_path(cs):
    lines = []
    for c in cs:
        x, y = c[0]
        lines.append(f'{x*sx:.3f} {(H-y)*sy:.3f} moveto')
        for x, y in c[1:]:
            lines.append(f'{x*sx:.3f} {(H-y)*sy:.3f} lineto')
        lines.append('closepath')
    return '\n'.join(lines)

header = '''%!PS-Adobe-3.0 EPSF-3.0
%%Title: Huber I.T. Professionals Vinyl Logo
%%Creator: contour trace from supplied original
%%BoundingBox: 0 0 1200 960
%%HiResBoundingBox: 0 0 1200 960
%%LanguageLevel: 3
%%Pages: 1
%%EndComments
'''

def write_cut():
    body = [header, 'newpath', ps_path(color_contours), '0.145 0.820 0.835 setrgbcolor eofill',
            'newpath', ps_path(white_contours), '1 1 1 setrgbcolor eofill', 'showpage\n%%EOF\n']
    (OUT / 'vinyl-logo-cut.eps').write_text('\n'.join(body))

def write_print():
    # Apply a genuine PostScript axial gradient inside the exact traced emblem silhouette.
    body = [header, 'gsave', 'newpath', ps_path(color_contours), 'eoclip newpath',
            '''<< /ShadingType 2 /ColorSpace /DeviceRGB /Coords [600 760 600 245]
            /Function << /FunctionType 2 /Domain [0 1] /C0 [0.13 0.85 0.81]
            /C1 [0.35 0.41 0.94] /N 1 >> /Extend [true true] >> shfill''',
            'grestore', 'newpath', ps_path(white_contours), '1 1 1 setrgbcolor eofill',
            'showpage\n%%EOF\n']
    (OUT / 'vinyl-logo-print.eps').write_text('\n'.join(body))

write_cut()
write_print()

# High-resolution visual proof on black, created from the traced masks themselves.
proof = np.zeros_like(img)
proof[color_mask > 0] = (213, 209, 39)  # BGR cyan
proof[white_mask > 0] = (255, 255, 255)
cv2.imwrite(str(OUT / 'vinyl-logo-trace-proof.png'), proof)

source_fg = ((color_mask > 0) | (white_mask > 0))
print(f'color contours={len(color_contours)}, white contours={len(white_contours)}')
print(f'foreground pixels={int(source_fg.sum())}, page={W}x{H}')

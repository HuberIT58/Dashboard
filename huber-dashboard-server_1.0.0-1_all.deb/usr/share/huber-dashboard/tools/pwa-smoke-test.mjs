const baseUrl = (process.env.PWA_BASE_URL || "https://www.huberitps.com").replace(/\/$/, "");

const pages = [
  "/",
  "/index.html",
  "/login.html",
  "/servicelogin.html",
  "/dashboard-app.webmanifest",
  "/service-app.webmanifest",
  "/service-worker.js"
];

let failures = 0;

for (const page of pages) {
  const url = `${baseUrl}${page}`;
  try {
    const response = await fetch(url, { redirect: "manual" });
    const ok = response.status >= 200 && response.status < 400;
    console.log(`${ok ? "PASS" : "FAIL"} ${response.status} ${url}`);
    if (!ok) failures += 1;
  } catch (error) {
    failures += 1;
    console.log(`FAIL ERR ${url} ${error.message}`);
  }
}

if (failures) {
  console.error(`PWA smoke test failed: ${failures} check${failures === 1 ? "" : "s"} failed.`);
  process.exit(1);
}

console.log("PWA smoke test passed.");

import CoreGraphics
import CoreText
import Foundation

func number(_ value: CGFloat) -> String {
    let text = String(format: "%.3f", Double(value))
    return text.replacingOccurrences(of: #"\.?0+$"#, with: "", options: .regularExpression)
}

func svgPath(_ path: CGPath) -> String {
    var commands: [String] = []
    path.applyWithBlock { pointer in
        let element = pointer.pointee
        switch element.type {
        case .moveToPoint:
            commands.append("M\(number(element.points[0].x)) \(number(element.points[0].y))")
        case .addLineToPoint:
            commands.append("L\(number(element.points[0].x)) \(number(element.points[0].y))")
        case .addQuadCurveToPoint:
            commands.append("Q\(number(element.points[0].x)) \(number(element.points[0].y)) \(number(element.points[1].x)) \(number(element.points[1].y))")
        case .addCurveToPoint:
            commands.append("C\(number(element.points[0].x)) \(number(element.points[0].y)) \(number(element.points[1].x)) \(number(element.points[1].y)) \(number(element.points[2].x)) \(number(element.points[2].y))")
        case .closeSubpath:
            commands.append("Z")
        @unknown default:
            break
        }
    }
    return commands.joined(separator: " ")
}

func outlinedText(_ text: String, fontName: String, size: CGFloat, tracking: CGFloat,
                  centerX: CGFloat, baseline: CGFloat) -> String {
    let font = CTFontCreateWithName(fontName as CFString, size, nil)
    let scalars = Array(text.utf16)
    var glyphs = Array(repeating: CGGlyph(), count: scalars.count)
    scalars.withUnsafeBufferPointer { scalarBuffer in
        glyphs.withUnsafeMutableBufferPointer { glyphBuffer in
            _ = CTFontGetGlyphsForCharacters(
                font, scalarBuffer.baseAddress!, glyphBuffer.baseAddress!, scalars.count
            )
        }
    }
    var advances = Array(repeating: CGSize.zero, count: glyphs.count)
    glyphs.withUnsafeBufferPointer { glyphBuffer in
        advances.withUnsafeMutableBufferPointer { advanceBuffer in
            _ = CTFontGetAdvancesForGlyphs(
                font, .horizontal, glyphBuffer.baseAddress!, advanceBuffer.baseAddress!, glyphs.count
            )
        }
    }
    let totalWidth = advances.reduce(0) { $0 + $1.width } + tracking * CGFloat(max(0, glyphs.count - 1))
    var cursor = centerX - totalWidth / 2
    var paths: [String] = []
    for index in glyphs.indices {
        if let glyphPath = CTFontCreatePathForGlyph(font, glyphs[index], nil) {
            var transform = CGAffineTransform(a: 1, b: 0, c: 0, d: -1, tx: cursor, ty: baseline)
            if let transformed = glyphPath.copy(using: &transform) {
                paths.append("    <path d=\"\(svgPath(transformed))\"/>")
            }
        }
        cursor += advances[index].width + tracking
    }
    return paths.joined(separator: "\n")
}

let wordmark = outlinedText("HUBER I.T.", fontName: "HelveticaNeue-Thin",
                            size: 104, tracking: 3, centerX: 640, baseline: 724)
let subtitle = outlinedText("PROFESSIONALS", fontName: "HelveticaNeue-Thin",
                            size: 44, tracking: 30, centerX: 640, baseline: 807)
let phone = outlinedText("605-787-0103", fontName: "HelveticaNeue-Thin",
                         size: 86, tracking: 2, centerX: 640, baseline: 925)

let svg = #"""
<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" viewBox="0 0 1280 1024" preserveAspectRatio="xMidYMid meet">
  <title>Huber I.T. Professionals vehicle graphics master</title>
  <desc>Smooth Bezier production artwork. No raster images and no live fonts.</desc>
  <defs>
    <linearGradient id="brand" gradientUnits="userSpaceOnUse" x1="0" y1="210" x2="0" y2="625">
      <stop offset="0" stop-color="#20d9cf"/>
      <stop offset="0.5" stop-color="#37b8df"/>
      <stop offset="1" stop-color="#5d6df0"/>
    </linearGradient>
  </defs>
  <g id="background" inkscape:groupmode="layer" inkscape:label="Background">
    <rect width="1280" height="1024" fill="#000"/>
  </g>
  <g id="emblem" inkscape:groupmode="layer" inkscape:label="Smooth Gradient Emblem" fill="none" stroke="url(#brand)" stroke-width="19" stroke-linecap="round" stroke-linejoin="round">
    <path d="M454 360 C471 284 535 224 612 211 C657 203 701 214 737 239"/>
    <path d="M804 309 C832 354 843 406 836 458 C824 544 750 594 660 599 C563 604 484 546 455 453"/>
    <path d="M449 390 H493 L583 351 H690 L768 263"/>
    <path d="M449 424 H548 L584 389 H724"/>
    <path d="M449 458 H495 L605 560"/>
    <path d="M535 374 L596 292 H605"/>
    <path d="M548 424 L592 478 H625"/>
    <circle cx="649" cy="274" r="22"/>
    <circle cx="782" cy="263" r="22"/>
    <circle cx="756" cy="398" r="22"/>
    <circle cx="655" cy="486" r="22"/>
  </g>
  <g id="company-name" inkscape:groupmode="layer" inkscape:label="Huber I.T. Bezier Outlines" fill="#fff" fill-rule="evenodd">
\#(wordmark)
  </g>
  <g id="professional-name" inkscape:groupmode="layer" inkscape:label="Professionals Bezier Outlines" fill="#fff" fill-rule="evenodd">
\#(subtitle)
  </g>
  <g id="phone-number" inkscape:groupmode="layer" inkscape:label="Phone Number Bezier Outlines" fill="#fff" fill-rule="evenodd">
\#(phone)
  </g>
</svg>
"""#

let output = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    .appendingPathComponent("huber-logo-vehicle-master.svg")
try svg.write(to: output, atomically: true, encoding: .utf8)
let transparent = svg.replacingOccurrences(
    of: "<g id=\"background\" inkscape:groupmode=\"layer\" inkscape:label=\"Background\">",
    with: "<g id=\"background\" inkscape:groupmode=\"layer\" inkscape:label=\"Background\" display=\"none\">"
)
let transparentOutput = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    .appendingPathComponent("huber-logo-vehicle-transparent.svg")
try transparent.write(to: transparentOutput, atomically: true, encoding: .utf8)
print(output.path)
print(transparentOutput.path)

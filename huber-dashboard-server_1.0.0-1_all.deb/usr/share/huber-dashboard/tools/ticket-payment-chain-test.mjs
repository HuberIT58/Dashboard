import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { randomBytes } from 'node:crypto';

// Run the real handlers with isolated persistence and no network/server startup.
const source = await readFile(new URL('../server.mjs', import.meta.url), 'utf8');
function extract(name) {
  const start = source.search(new RegExp(`^(?:async )?function ${name}\\(`, 'm'));
  if (start < 0) throw new Error(`Missing ${name}`);
  const end = source.indexOf('\n}', start) + 2;
  return source.slice(start, end);
}
let state, failures = 0;
const clone = value => structuredClone(value);
const context = vm.createContext({
  URL, Date, Math, Number, String, Array, Set, Map, Boolean, Object, structuredClone, randomBytes,
  getSession: () => ({username:'Huber58'}), hasPermission: () => true,
  readJsonBody: async request => clone(request.payload),
  sendJson: (response,status,body) => Object.assign(response,{status,body:clone(body)}),
  billingTransaction: (response, operation) => {
    const before=clone(state);
    try { operation(response); if(response.status>=400)state=before; }
    catch(error){state=before;throw error;}
  },
  readTickets: () => clone(state.tickets), writeTickets: value => {state.tickets=clone(value);},
  readInvoices: () => clone(state.invoices), writeInvoices: value => {state.invoices=clone(value);},
  readFinance: () => clone(state.finance), writeFinance: value => {state.finance=clone(value);},
  readBankData: () => clone(state.bank), writeBankData: value => {state.bank=clone(value);}, bankingResponse: bank => ({ok:true,...clone(bank)}),
  readEstimates: () => [], writeEstimates: () => {}, readEmployees: () => [],
  readApprovalPolicies: () => ({requireInvoiceVoids:false}),
  normalizedTicketAssignees: () => [], setTicketAssignees: () => {},
  availabilityWarningsForTicket: () => [], createTicketNotification: () => {},
  logActivity: () => {}, broadcastAllServiceEvent: () => {},
  ticketLabel: ticket => `T-${ticket.number}`,
  validDateOnly: value => /^\d{4}-\d{2}-\d{2}$/.test(value||'') ? value : '',
  publicOrigin: () => 'http://fixture.invalid',
  contractPaymentSummaries: () => [], calculateLaborCost: () => ({total:0,employees:[]}),
  readBills: () => [], billSummary: () => ({bills:[],payments:[],summary:{paymentTotal:0,unpaid:0,overdue:0,overdueCount:0}})
});
vm.runInContext(['handleTickets','handleTicketsParsed','handleInvoices','handleInvoicesParsed','handleFinance','handleFinanceParsed','handleBanking','handleBankingParsed','invoicePaidAmount','invoicePaymentStatus','calculateFinance','reconcileBankTransaction','undoBankReconciliation','roundMoney'].map(extract).join('\n'),context);
const call = async (handler, method, payload={}) => {
  const response={};
  await context[handler]({method,payload,url:'/api/invoices',headers:{}},response);
  return response;
};
function reset(){ state={tickets:[],invoices:[],finance:{payments:[],expenses:[],groups:[]},bank:{accounts:[],transactions:[]}}; }
function check(condition,label){ console.log(`${condition?'PASS':'FAIL'}: ${label}`); if(!condition)failures++; }
const ticket={id:'fixture-ticket',number:1,customer:'Fixture customer',description:'Replace network switch',ticketType:'Service',status:'Open',hoursUsed:2,usedItems:[{name:'Cable',sku:'C1',quantity:2,unitCost:25}]};
const invoicePayload={ticketId:ticket.id,laborHours:2,laborRate:100,taxRate:10,status:'Sent',issueDate:'2026-09-19'};
async function seed(){
  reset();
  await call('handleTickets','POST',{ticket:{...ticket,status:'Closed'}});
  return (await call('handleInvoices','POST',invoicePayload)).body.invoice;
}
const pay=(id,amount,requestId=randomBytes(16).toString('hex'))=>call('handleFinance','POST',{action:'add-payment',requestId,invoiceId:id,amount,method:'Cash',date:'2026-09-19'});
reset();
check((await call('handleTickets','POST',{ticket})).status===200,'Create service ticket');
check((await call('handleInvoices','POST',invoicePayload)).status===409,'Block issued invoice on open ticket');
await call('handleTickets','POST',{ticket:{...ticket,status:'Closed'}});
let invoice=(await call('handleInvoices','POST',invoicePayload)).body.invoice;
check(invoice.total===275,'Closed ticket becomes invoice: $200 labor + $50 materials + $25 tax');
check((await call('handleInvoices','POST',invoicePayload)).status===409,'Block duplicate invoice');
await pay(invoice.id,100);
let detail=(await call('handleInvoices','GET')).body.invoices[0];
check(detail.paidAmount===100&&detail.balance===175&&detail.status==='Sent','Partial payment retains $175 balance');
check((await pay(invoice.id,176)).status===400,'Reject overpayment');
await pay(invoice.id,175);
detail=(await call('handleInvoices','GET')).body.invoices[0];
check(detail.paidAmount===275&&detail.balance===0&&detail.status==='Paid','Final payment settles invoice');
const firstPayment=state.finance.payments[0].id;
await call('handleFinance','DELETE',{action:'delete-payment',id:firstPayment});
detail=(await call('handleInvoices','GET')).body.invoices[0];
check(detail.balance===100&&detail.status!=='Paid','Deleting earlier partial payment reopens $100 balance');

invoice=await seed();
check((await call('handleInvoices','POST',{...invoicePayload,id:invoice.id,status:'Paid'})).status===409,'Reject unsupported manual Paid status');
detail=(await call('handleInvoices','GET')).body.invoices[0];
check(detail.paidAmount===state.finance.payments.reduce((n,p)=>n+p.amount,0),'Paid amount is backed by payment records after manual status change');

invoice=await seed();
await call('handleInvoices','POST',{...invoicePayload,id:invoice.id,status:'Void'});
check((await pay(invoice.id,50)).status>=400,'Reject payments against void invoice');

invoice=await seed();
await Promise.all([pay(invoice.id,50),pay(invoice.id,60)]);
check(state.finance.payments.length===2&&state.finance.payments.reduce((n,p)=>n+p.amount,0)===110,'Concurrent payments both survive persistence');

invoice=await seed();
await pay(invoice.id,275);
await call('handleInvoices','POST',{...invoicePayload,id:invoice.id,laborRate:200,status:'Paid'});
detail=(await call('handleInvoices','GET')).body.invoices[0];
check(detail.balance===220,'Increasing a settled invoice preserves actual payments and exposes new balance');

invoice=await seed();
await call('handleTickets','DELETE',{id:ticket.id});
check(state.tickets.some(t=>t.id===ticket.id),'Ticket with issued invoice is protected from orphaning');

invoice=await seed();
await pay(invoice.id,100);
check((await call('handleInvoices','POST',{...invoicePayload,id:invoice.id,status:'Void'})).status===409,'Reject voiding a partially paid invoice');
const summary=(await call('handleFinance','GET')).body.summary;
check(summary.received===100&&summary.outstanding===175,'Finance summary agrees with invoice payment ledger');
const bank=context.reconcileBankTransaction({id:'bank-1',amount:-175,date:'2026-09-19',name:'Deposit'},{targetType:'invoice',targetId:invoice.id},{username:'Huber58'});
check((await call('handleFinance','DELETE',{action:'delete-payment',id:bank.recordId})).status===409,'Bank payment cannot be deleted outside reconciliation');
context.undoBankReconciliation(bank);
check((await call('handleInvoices','GET')).body.invoices[0].balance===175,'Undo bank reconciliation restores balance');

reset();
await call('handleTickets','POST',{ticket:{...ticket,status:'Closed'}});
const concurrent=await Promise.all([call('handleInvoices','POST',invoicePayload),call('handleInvoices','POST',invoicePayload)]);
check(state.invoices.length===1&&concurrent.some(r=>r.status===409),'Concurrent invoice creation cannot duplicate or overwrite invoices');
invoice=state.invoices[0];
await call('handleInvoices','POST',{...invoicePayload,id:invoice.id,status:'Draft'});
check((await pay(invoice.id,50)).status===409,'Draft invoice cannot receive manual payment');
let blocked=false;
try{context.reconcileBankTransaction({amount:-50},{targetType:'invoice',targetId:invoice.id},{username:'Huber58'});}catch{blocked=true;}
check(blocked,'Draft invoice cannot receive reconciled bank payment');

invoice=await seed();
const retryId=randomBytes(16).toString('hex');
await pay(invoice.id,50,retryId);
check((await pay(invoice.id,50,retryId)).body.replayed&&state.finance.payments.length===1,'Retry returns saved result without recording a second payment');
check((await pay(invoice.id,60,retryId)).status===409,'Reusing request ID with changed amount is rejected');
await call('handleFinance','DELETE',{action:'delete-payment',id:state.finance.payments[0].id});
await pay(invoice.id,50,retryId);
check(state.finance.payments.length===0,'Retry cannot resurrect deleted payment');
blocked=false;
try{context.reconcileBankTransaction({id:'large-deposit',amount:-500},{targetType:'invoice',targetId:invoice.id},{username:'Huber58'});}catch{blocked=true;}
check(blocked&&state.finance.payments.length===0,'Oversized bank deposit rejects without partial allocation');
reset();
const created=await Promise.all(['one','two'].map(id=>call('handleTickets','POST',{ticket:{...ticket,id,number:99}})));
check(new Set(created.map(r=>r.body.ticket.number)).size===2&&state.tickets.every(t=>t.number!==99),'Server allocates distinct ticket numbers, ignoring stale client numbers');
invoice=await seed();
state.bank.transactions=[{id:'deposit-1',amount:-50,date:'2026-09-19',name:'Bank deposit'}];
const matches=await Promise.all([1,2].map(()=>call('handleBanking','POST',{action:'reconcile',transactionId:'deposit-1',targetType:'invoice',targetId:invoice.id})));
check(state.finance.payments.length===1&&matches.some(r=>r.status===400),'Concurrent bank reconciliation creates exactly one payment');
state.bank.transactions.push({id:'deposit-large',amount:-500,date:'2026-09-19',name:'Large deposit'});
await call('handleBanking','POST',{action:'reconcile',transactionId:'deposit-large',targetType:'invoice',targetId:invoice.id});
check(!state.bank.transactions[1].reconciliation&&state.finance.payments.length===1,'Rejected oversized deposit stays unreconciled');
console.log(`\n${failures} readiness checks failed. No production data or files were accessed.`);
process.exitCode=failures?1:0;

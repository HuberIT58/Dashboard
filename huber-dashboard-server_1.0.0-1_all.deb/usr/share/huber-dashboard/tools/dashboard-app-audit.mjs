import assert from "node:assert/strict";
import { readFile, readdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve, extname } from "node:path";
import { createRequire } from "node:module";
import { Script } from "node:vm";
import { spawnSync } from "node:child_process";

// The virtual origin below never reaches a server. All data is synthetic.
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");
const root = fileURLToPath(new URL("../", import.meta.url));
const browser = await chromium.launch({ headless: true, ...(process.env.BROWSER_CHANNEL ? { channel: process.env.BROWSER_CHANNEL } : {}) });
const context = await browser.newContext({ timezoneId: "America/Denver" });
const page = await context.newPage();
const errors = [];
page.on("pageerror", error => errors.push(error.message));
const alerts = [];
page.on("dialog", async dialog => { alerts.push(dialog.message()); await dialog.dismiss(); });
const customers = ["A", "B"].map(id => ({ id, name: `Customer ${id}`, email: `${id}@example.invalid`, ticketCount: 0 }));
customers.push({ id: 'C" onmouseover="alert(1)', name: "Quoted identifier", ticketCount: 0 });
const finance = {
  summary: {}, groups: [], payments: [], billPayments: [], expenses: [], labor: [], employeeNames: [], contracts: [],
  invoices: [{ id: "invoice-a", number: 1, customer: "Example", total: 10, balance: 10, paid: 0 }]
};
const pending = new Map();
let holdHistory = false, holdReceipts = false, holdSave = false, saveCount = 0;
await context.route("**/*", async route => {
  const url = new URL(route.request().url());
  assert.equal(url.origin, "http://dashboard.test", "Unexpected external request");
  const json = body => route.fulfill({ json: body });
  if (url.pathname === "/auth-status") return json({ authenticated: true });
  if (url.pathname === "/api/tickets") {
    if (route.request().method() === "POST") { saveCount++;pending.set("ticket-save", route);return; }
    return json({ tickets: [] });
  }
  if (url.pathname === "/api/customers") return json({ customers });
  if (["/api/customer-history", "/api/customer-communications"].includes(url.pathname)) {
    if (holdHistory) { pending.set(`${url.pathname}:${url.searchParams.get("customerId")}`, route); return; }
    return json({ history: [], jobs: [], communications: [] });
  }
  if (url.pathname === "/api/finance") {
    if (route.request().method() === "POST") {
      saveCount++;
      if (holdSave) { pending.set("save", route); return; }
    }
    return json(finance);
  }
  if (url.pathname === "/api/receipts") {
    if (holdReceipts && url.searchParams.has("entityId")) { pending.set(`receipts:${url.searchParams.get("entityId")}`, route); return; }
    return json({ receipts: [] });
  }
  if (url.pathname === "/api/receipts/upload") return route.abort("failed");
  if (url.pathname.startsWith("/api/")) return json({});
  // Shared scripts are audited by their own regression suites; isolate page behavior here.
  if (url.pathname.endsWith(".js")) return route.fulfill({ contentType: "text/javascript", body: "" });
  const path = resolve(root, `.${url.pathname}`);
  if (!path.startsWith(root.endsWith("/") ? root : `${root}/`)) return route.abort();
  try {
    const contentType = ({ ".html": "text/html", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml" })[extname(path)] || "application/octet-stream";
    return route.fulfill({ contentType, body: await readFile(path) });
  } catch { return route.fulfill({ status: 404, body: "Fixture resource not found" }); }
});

async function awaitPending(key) {
  for (let i = 0; i < 150 && !pending.has(key); i++) await new Promise(resolve => setTimeout(resolve, 20));
  assert.ok(pending.has(key), `Request did not arrive: ${key}`);
  const route = pending.get(key);pending.delete(key);return route;
}
async function settleCustomer(id, name) {
  await (await awaitPending(`/api/customer-history:${id}`)).fulfill({ json: { jobs: [{ number: name, service: "Service", href: "/job-workspace.html", type: "Service" }] } });
  await (await awaitPending(`/api/customer-communications:${id}`)).fulfill({ json: { communications: [] } });
}

try {
  const parser = await context.newPage();
  let scripts = 0, pages = 0;
  for (const file of (await readdir(root)).filter(file => file.endsWith(".html"))) {
    const html = await readFile(resolve(root, file), "utf8");
    const inline = await parser.evaluate(html => [...new DOMParser().parseFromString(html, "text/html").scripts]
      .filter(script => !script.src && ["", "text/javascript", "application/javascript", "module"].includes(script.type))
      .map(script => ({ text: script.textContent, module: script.type === "module" })), html);
    for (const [index, script] of inline.entries()) {
      if (script.module) {
        const checked = spawnSync(process.execPath, ["--check", "--input-type=module"], { input: script.text, encoding: "utf8" });
        assert.equal(checked.status, 0, `${file} script ${index}: ${checked.stderr}`);
      } else new Script(script.text, { filename: `${file}:inline-${index}` });
      scripts++;
    }
    pages++;
  }
  await parser.close();
  console.log(`PASS: parsed ${scripts} inline scripts across all ${pages} top-level HTML pages`);
  const rootScripts = (await readdir(root)).filter(file => /\.(?:m?js)$/.test(file));
  for (const file of rootScripts) {
    const checked = spawnSync(process.execPath, ["--check", resolve(root, file)], { encoding: "utf8" });
    assert.equal(checked.status, 0, `${file}: ${checked.stderr}`);
  }
  console.log(`PASS: syntax checked all ${rootScripts.length} top-level JavaScript files without executing them`);

  await page.goto("http://dashboard.test/customers.html");
  await page.locator('[data-id="A"]').waitFor();
  assert.equal(await page.locator("#customers [onmouseover]").count(), 0);
  assert.equal(await page.locator("#customers button").last().getAttribute("data-id"), customers[2].id);
  console.log("PASS: customer identifiers cannot inject HTML attributes");
  holdHistory = true;
  await page.locator('[data-id="A"]').click();
  await page.locator('[data-tab="timeline"]').click();
  await page.locator("#close-dialog").click();
  await page.locator('[data-id="B"]').click();
  await page.locator('[data-tab="timeline"]').click();
  await settleCustomer("B", "Job B");
  await page.locator("#customer-timeline").getByText("Job B", { exact: false }).waitFor();
  await settleCustomer("A", "Job A");
  await page.waitForTimeout(80);
  assert.match(await page.locator("#customer-timeline").innerText(), /Job B/);
  assert.doesNotMatch(await page.locator("#customer-timeline").innerText(), /Job A/);
  console.log("PASS: stale customer responses cannot replace the active customer timeline");

  await page.clock.setFixedTime(new Date("2026-09-08T02:30:00Z"));
  await page.goto("http://dashboard.test/finance.html");
  await page.locator('#payment-target option[value="invoice:invoice-a"]').waitFor({ state: "attached" });
  assert.equal(await page.locator("#payment-date").inputValue(), "2026-09-07");
  assert.equal(await page.locator("#expense-date").inputValue(), "2026-09-07");
  holdSave = true;
  for (const selector of ["#payment-form", "#expense-form", "#group-form"]) {
    const before = saveCount;
    await page.locator(selector).evaluate(form => {
      form.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
      form.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
    });
    const request = await awaitPending("save");
    assert.equal(saveCount, before + 1);
    assert.equal(await page.locator(selector).getAttribute("aria-busy"), "true");
    await request.fulfill({ status: 500, json: { message: "Fixture save failed" } });
    await page.waitForFunction(selector => !document.querySelector(selector).hasAttribute("aria-busy"), selector);
    assert.equal(await page.locator(`${selector} button[type="submit"]`).isEnabled(), true);
  }
  console.log("PASS: payment, expense and group saves reject double submission and recover on failure; local dates preserved");

  await page.locator('[data-view="payments"]').click();
  await page.locator("#payment-target").selectOption("invoice:invoice-a");
  assert.equal(await page.locator("#payment-description").isDisabled(), true);
  await page.locator("#payment-form").dispatchEvent("submit");
  await (await awaitPending("save")).fulfill({ json: finance });
  await page.waitForFunction(() => !document.querySelector("#payment-form").hasAttribute("aria-busy"));
  assert.equal(await page.locator("#payment-description").isEnabled(), true);
  console.log("PASS: custom payment description re-enabled after saving a linked invoice payment");

  holdReceipts = true;
  await page.evaluate(() => {
    for (const id of ["expense-a", "expense-b"]) {
      const button=document.createElement("button");button.dataset.receipts="expense";button.dataset.entityId=id;
      button.id=id;document.body.append(button);
    }
    document.querySelector("#expense-a").click();
  });
  const receiptA = await awaitPending("receipts:expense-a");
  await page.locator("#close-receipts").click();
  await page.evaluate(() => document.querySelector("#expense-b").click());
  const receiptB = await awaitPending("receipts:expense-b");
  await receiptB.fulfill({ json: { receipts: [{ id: "b", entityId: "expense-b", name: "Receipt B", uploadedAt: "2026-09-07" }] } });
  await page.locator("#receipt-list").getByText("Receipt B").waitFor();
  await receiptA.fulfill({ json: { receipts: [{ id: "a", entityId: "expense-a", name: "Receipt A", uploadedAt: "2026-09-07" }] } });
  await page.waitForTimeout(80);
  assert.match(await page.locator("#receipt-list").innerText(), /Receipt B/);
  assert.doesNotMatch(await page.locator("#receipt-list").innerText(), /Receipt A/);
  await page.locator("#receipt-file").setInputFiles({ name: "receipt.txt", mimeType: "text/plain", buffer: Buffer.from("synthetic receipt") });
  await page.locator("#upload-receipt").click();
  await page.waitForFunction(() => !document.querySelector("#upload-receipt").disabled);
  assert.ok(alerts.some(message => /fetch/i.test(message)), "Upload failure should be reported");
  await page.locator("#close-receipts").click();
  console.log("PASS: receipt target isolation and upload error recovery");

  await page.goto("http://dashboard.test/service-tickets.html");
  await page.locator("#add-ticket").click();
  await page.locator("#ticket-dialog").waitFor();
  const beforeTicketSave = saveCount;
  await page.locator("#ticket-form").evaluate(form => {
    Object.defineProperty(crypto, "randomUUID", {value: undefined, configurable: true});
    document.querySelector("#record-id").value="";
    document.querySelector("#customer").value="Synthetic Customer";
    document.querySelector("#description").value="Synthetic service request";
    form.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
    form.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
  });
  const ticketRequest = await awaitPending("ticket-save");
  const generatedTicketId = ticketRequest.request().postDataJSON().ticket.id;
  assert.match(generatedTicketId, /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/);
  assert.equal(saveCount, beforeTicketSave + 1);
  assert.equal(await page.evaluate(() => tickets.length), 0);
  await ticketRequest.fulfill({ status: 500, json: { message: "Synthetic ticket save failure" } });
  await page.waitForFunction(() => !document.querySelector("#ticket-form").hasAttribute("aria-busy"));
  assert.equal(await page.evaluate(() => tickets.length), 0);
  assert.equal(await page.locator("#record-id").inputValue(), generatedTicketId);
  const afterFailure = saveCount;
  await page.locator("#ticket-form").dispatchEvent("submit");
  const retry = await awaitPending("ticket-save");
  assert.equal(retry.request().postDataJSON().ticket.id, generatedTicketId);
  assert.equal(saveCount, afterFailure + 1);
  await retry.fulfill({ json: { ok: true } });
  await page.waitForFunction(() => !document.querySelector("#ticket-dialog").open);
  assert.equal(await page.evaluate(() => tickets.length), 1);
  console.log("PASS: failed tickets never enter the list; successful retries retain one ID and one record");
  assert.deepEqual(errors, []);
  console.log("PASS: no uncaught page errors; no real records or production endpoints accessed");
} catch (error) {
  console.error("Fixture diagnostics:", { errors, alerts, url: page.url(), receipt: await page.locator("#receipt-context").textContent({ timeout: 500 }).catch(() => "not on receipts page") });
  throw error;
} finally {
  await browser.close();
}

import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

// Run with NODE_PATH pointing to the bundled node_modules, or install Playwright locally.
// All browser traffic is fulfilled/aborted here; no server or live data is used.
const { chromium } = createRequire(import.meta.url)("playwright");
const root = new URL("../", import.meta.url);
const sources = new Map();
for (const path of ["dashboard.html", "login.html", "servicelogin.html", "theme.js",
  "theme.css", "motion.js", "modal-dismiss.js", "network-route.js", "service-worker.js"]) {
  sources.set(`/${path}`, await readFile(new URL(path, root), "utf8"));
}
const origin = "http://dashboard-audit.test";
const logo = await readFile(new URL("assets/logo.png", root));
const browser = await chromium.launch({ headless: true, channel: process.env.CHROME_CHANNEL || "chrome" });
let passed = 0;
const pass = (name) => { passed++; console.log(`PASS ${name}`); };

async function fixture(path, { blockedStorage = false, width = 1440, height = 1000 } = {}) {
  const context = await browser.newContext({ viewport: { width, height }, serviceWorkers: "block" });
  const page = await context.newPage();
  const errors = [];
  const calls = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.addInitScript(({ blockedStorage }) => {
    delete window.EventSource;
    if (blockedStorage) {
      for (const key of ["localStorage", "sessionStorage"]) {
        Object.defineProperty(window, key, { get() { throw new DOMException("Disabled", "SecurityError"); } });
      }
    } else {
      const today = new Intl.DateTimeFormat("en-CA", {
        timeZone: "America/Denver", year: "numeric", month: "2-digit", day: "2-digit"
      }).format(new Date());
      localStorage.setItem(`huber-morning-briefing:auditor:${today}`, "shown");
    }
  }, { blockedStorage });
  await context.route("**/*", async (route) => {
    const url = new URL(route.request().url());
    if (url.origin !== origin) return route.abort();
    calls.push(url.pathname);
    if (url.pathname === "/assets/logo.png") return route.fulfill({ contentType: "image/png", body: logo });
    let body = sources.get(url.pathname);
    if (body !== undefined) {
      if (url.pathname.endsWith(".html")) {
        body = body.replace("</head>", '<link rel="stylesheet" href="/theme.css"><script src="/theme.js" defer></script><script src="/motion.js" defer></script></head>');
      }
      return route.fulfill({ body, contentType: url.pathname.endsWith(".html") ? "text/html" : url.pathname.endsWith(".css") ? "text/css" : "text/javascript" });
    }
    if (url.pathname.endsWith(".txt")) return route.fulfill({ body: "audit fixture", contentType: "text/plain" });
    const mocks = {
      "/auth-status": { authenticated: path === "/dashboard.html", username: "auditor", employeeName: "Audit User", role: "employee", permissions: ["customers", "service-tickets"], setupRequired: false },
      "/api/theme": { theme: "professional" },
      "/api/network-route": { lanBaseUrl: "", connectionRoute: "local" },
      "/api/time": { active: null },
      "/api/app-store": { apps: [] },
      "/api/dashboard-layout": { layout: {}, profiles: ["Default"], activeProfile: "Default" },
      "/api/dashboard-summary": { alerts: [], operations: { jobsToday: [] } },
      "/api/notifications": { notifications: [] },
      "/api/announcements": { announcements: [] },
      "/api/global-search": { results: [] }
    };
    if (url.pathname in mocks) return route.fulfill({ json: mocks[url.pathname] });
    if (url.pathname === "/customers.html") return route.fulfill({ contentType: "text/html", body: "<title>Customer Records</title><main><h1>Fixture Customers</h1></main>" });
    return route.fulfill({ status: 404, body: "Fixture resource unavailable" });
  });
  await page.goto(origin + path);
  await page.waitForFunction(() => Boolean(window.huberTheme));
  if (path === "/dashboard.html") {
    await page.waitForFunction(() => document.querySelector("#logged-in-user").textContent === "Audit User");
    await page.evaluate(async () => { await new Promise((resolve) => setTimeout(resolve, 150)); });
    await page.evaluate(() => document.querySelectorAll("dialog[open]").forEach((dialog) => dialog.close()));
  } else await page.waitForFunction(() => !document.querySelector("button[type=submit]").disabled);
  return { context, page, errors, calls };
}

try {
  const login = await fixture("/login.html");
  assert.equal(login.calls.filter((path) => path === "/api/network-route").length, 1);
  pass("login performs one LAN route check");
  await login.page.locator('#password').fill('test-password-123');
  await login.page.locator('#password-visibility').click();
  assert.equal(await login.page.locator('#password').getAttribute('type'), 'text');
  assert.equal(await login.page.locator('#password-visibility').getAttribute('aria-label'), 'Hide password');
  await login.page.locator('#password-visibility').click();
  assert.equal(await login.page.locator('#password').getAttribute('type'), 'password');
  await login.page.locator('#password').fill('');
  await login.page.evaluate(() => window.huberTheme.apply('dark'));
  await login.page.screenshot({ path: '/tmp/dashboard-login-modern.png' });
  for (const width of [320, 390, 900, 2560]) {
    await login.page.setViewportSize({ width, height: 800 });
    assert.ok(await login.page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  }
  await login.page.setViewportSize({ width: 1440, height: 1000 });
  pass('login password visibility and responsive layout');
  let posts = 0;
  await login.context.route("**/login", async (route) => {
    posts++;
    await new Promise((resolve) => setTimeout(resolve, 100));
    await route.fulfill({ status: 401, json: { ok: false, twoFactorRequired: true } });
  });
  await login.page.locator("#username").fill("auditor");
  await login.page.locator("#password").fill("fixture-password");
  await login.page.evaluate(() => {
    const form = document.querySelector("form");
    form.dispatchEvent(new Event("submit", { cancelable: true }));
    form.dispatchEvent(new Event("submit", { cancelable: true }));
  });
  await login.page.waitForFunction(() => !document.querySelector("#two-factor-label").hidden);
  assert.equal(posts, 1);
  assert.equal(await login.page.locator("#two-factor-code").evaluate((el) => el === document.activeElement), true);
  assert.deepEqual(login.errors, []);
  pass("login coalesces duplicate submits and focuses MFA input");
  await login.context.close();

  const dashboard = await fixture("/dashboard.html");
  const { page } = dashboard;
  assert.equal(await page.evaluate(() => {
    const payment = commandActions.find((action) => action.label === "Record Payment");
    return new URL(payment.href, location.href).searchParams.get("view");
  }), "payments");
  pass("Record Payment shortcut selects the finance payments view");
  await page.locator("#search-toggle").click();
  await page.locator("#command-palette-input").waitFor({ state: "visible" });
  await page.waitForFunction(() => document.activeElement.id === "command-palette-input");
  await page.keyboard.press("Shift+Tab");
  assert.equal(await page.evaluate(() => document.activeElement.closest("#command-palette") !== null), true);
  assert.equal(await page.locator("header.topbar").evaluate((el) => el.inert), true);
  await page.keyboard.press("Escape");
  assert.equal(await page.evaluate(() => document.activeElement.id), "search-toggle");
  assert.equal(await page.locator("header.topbar").evaluate((el) => el.inert), false);
  pass("command modal contains focus and restores launcher/background");

  await page.locator("#search-toggle").click();
  await page.evaluate(() => {
    window.auditPendingSearches = {};
    const original = window.fetch;
    window.fetch = (url, options) => String(url).startsWith("/api/global-search")
      ? new Promise((resolve) => { window.auditPendingSearches[new URL(url, location.href).searchParams.get("q")] = resolve; })
      : original(url, options);
  });
  await page.locator("#command-palette-input").fill("older");
  await page.waitForFunction(() => window.auditPendingSearches.older);
  await page.locator("#command-palette-input").fill("newer");
  await page.waitForFunction(() => window.auditPendingSearches.newer);
  await page.evaluate(() => window.auditPendingSearches.newer(new Response(JSON.stringify({ results: [
    { title: "New result", href: '/customers.html?name=" onmouseover="bad', type: "Customer", detail: "Fixture" },
    { title: "Unsafe", href: "javascript:alert(1)", type: "Customer" }
  ] }), { status: 200 })));
  await page.waitForFunction(() => document.querySelector("#command-palette-results").textContent.includes("New result"));
  await page.evaluate(() => window.auditPendingSearches.older(new Response(JSON.stringify({ results: [{ title: "Old result", href: "/customers.html" }] }), { status: 200 })));
  await page.evaluate(() => new Promise(requestAnimationFrame));
  assert.equal(await page.locator("#command-palette-results").textContent().then((text) => text.includes("Old result")), false);
  assert.equal(await page.locator("#command-palette-results a").count(), 1);
  assert.equal(await page.locator("#command-palette-results a").getAttribute("onmouseover"), null);
  pass("search ignores out-of-order replies and rejects unsafe/attribute-breaking links");
  await page.keyboard.press("Escape");

  await page.evaluate(() => {
    const first = document.querySelector("#organizer-dialog");
    const second = document.querySelector("#notification-dialog");
    second.showModal();
    first.showModal();
    first.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, button: 0, isPrimary: true, clientX: -1, clientY: -1 }));
  });
  assert.equal(await page.locator("#organizer-dialog").evaluate((el) => el.open), false);
  assert.equal(await page.locator("#notification-dialog").evaluate((el) => el.open), true);
  await page.evaluate(() => document.querySelector("#notification-dialog").close());
  pass("backdrop dismissal follows top-layer order rather than DOM order");

  await page.evaluate(() => {
    window.auditComputedStyles = 0;
    const original = window.getComputedStyle;
    window.getComputedStyle = (...args) => { window.auditComputedStyles++; return original(...args); };
    window.huberTheme.apply("dark");
  });
  await page.evaluate(() => new Promise((resolve) => setTimeout(resolve, 100)));
  await page.evaluate(() => {
    window.auditComputedStyles = 0;
    const node = document.createElement("div");
    node.id = "audit-surface";
    node.style.backgroundColor = "white";
    document.querySelector("main").append(node);
  });
  await page.waitForFunction(() => document.querySelector("#audit-surface").classList.contains("huber-theme-surface-fix"));
  assert.ok(await page.evaluate(() => window.auditComputedStyles) < 40);
  await page.evaluate(() => window.huberTheme.apply("light"));
  assert.equal(await page.locator(".huber-theme-surface-fix").count(), 0);
  pass("theme audits changed subtree without whole-page computed-style scans");
  await page.evaluate(() => {
    const metric = document.createElement("div");
    metric.className = "metric";
    metric.innerHTML = '<strong id="audit-metric">0</strong>';
    document.querySelector("main").append(metric);
  });
  await page.evaluate(() => new Promise(requestAnimationFrame));
  await page.evaluate(() => {
    window.auditAnimations = 0;
    const metric = document.querySelector("#audit-metric");
    metric.animate = () => { window.auditAnimations++; };
    metric.textContent = "1";
    metric.textContent = "2";
  });
  assert.equal(await page.evaluate(() => window.auditAnimations), 1);
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.evaluate(() => { document.querySelector("#audit-metric").textContent = "3"; });
  assert.equal(await page.evaluate(() => window.auditAnimations), 1);
  pass("shared motion batches metric changes and honors updated reduced-motion preference");
  await page.screenshot({ path: "/tmp/dashboard-ui-audit-desktop.png", fullPage: true });
  assert.ok(await page.locator('.workspace-nav-group summary .workspace-icon svg').count() > 0);
  const folder = page.locator('.workspace-nav-group').first();
  await folder.locator('summary').click();
  assert.equal(await folder.evaluate(el => el.open), false);
  await folder.locator('summary').click();
  assert.equal(await folder.evaluate(el => el.open), true);
  assert.equal(await page.locator('#workspace-nav-home').getAttribute('aria-current'), 'page');
  pass('sidebar folder icons, disclosure, and active navigation state');
  await page.locator("#account-menu-toggle").click();
  assert.equal(await page.locator("#account-card").isVisible(), true);
  assert.equal(await page.locator("#account-card .account-menu-icon svg").count(), 8);
  await page.locator(".account-profile-actions summary").click();
  assert.equal(await page.locator("#new-dashboard-profile").isVisible(), true);
  await page.evaluate(() => window.huberTheme.apply("dark"));
  await page.screenshot({ path: "/tmp/dashboard-account-menu.png" });
  await page.keyboard.press("Escape");
  assert.equal(await page.locator("#account-card").isVisible(), false);
  assert.equal(await page.locator("#account-menu-toggle").getAttribute("aria-expanded"), "false");
  await page.locator("#account-menu-toggle").click();
  await page.locator("header .identity").click();
  assert.equal(await page.locator("#account-card").isVisible(), false);
  pass("account menu icons, profile disclosure, Escape and outside-click dismissal");
  assert.deepEqual(dashboard.errors, []);
  await dashboard.context.close();

  const overview = await fixture('/dashboard.html', { width: 1920, height: 1080 });
  await overview.context.route('**/api/dashboard-summary', route => route.fulfill({ json: {
    alerts: [{ id: 'fixture-alert', title: 'Unassigned service ticket', detail: 'Network inspection is awaiting assignment.', href: '/service-tickets.html' }],
    operations: { jobsToday: Array.from({ length: 4 }, (_, i) => ({ id: `job-${i}`, customer: ['Acme Manufacturing', 'Northwind Traders', 'Summit Financial', 'Greenleaf Logistics'][i], assignedTo: 'Chris Huber', scheduledTime: `${9+i}:00`, serviceType: 'Networking', status: 'Scheduled', address: 'Fixture service address' })), unassignedJobs: 1, overdueInvoices: { count: 3, total: 24870 }, pendingApprovals: 2 }
  } }));
  await overview.page.evaluate(async () => { window.huberTheme.apply('dark'); await loadDashboardSummary('auditor'); });
  assert.equal(await overview.page.locator('#operations-grid .operation').count(), 4);
  assert.equal(await overview.page.locator('#dispatch-overview-rows tr').count(), 4);
  assert.equal(await overview.page.locator('#alert-list .alert-action').first().isVisible(), true);
  assert.equal(await overview.page.locator('#office-clock-action').isVisible(), true);
  await overview.page.screenshot({ path: '/tmp/dashboard-overview-modern.png', fullPage: true });
  for (const width of [390, 900, 1440, 2560]) {
    await overview.page.setViewportSize({ width, height: 1000 });
    assert.ok(await overview.page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), `Overview fits ${width}px`);
  }
  assert.deepEqual(overview.errors, []);
  pass('populated overview totals, schedule, visible alert controls and responsive layout');
  await overview.context.close();

  const restricted = await fixture("/dashboard.html", { blockedStorage: true });
  await restricted.page.evaluate(() => recordRecentDestination({ id: "customers", href: "/customers.html", title: "Customers" }));
  await restricted.page.locator("#search-toggle").click();
  assert.equal(await restricted.page.locator("#command-palette").isVisible(), true);
  assert.deepEqual(restricted.errors, []);
  pass("blocked browser storage does not disable dashboard or theme initialization");
  await restricted.context.close();

  for (const width of [320, 390, 1440]) {
    const mobile = await fixture("/servicelogin.html", { width, height: 800 });
    assert.ok(await mobile.page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    assert.ok(await mobile.page.locator("#username").evaluate((el) => el.getBoundingClientRect().right <= innerWidth));
    assert.ok(!(await mobile.page.locator('meta[name="viewport"]').getAttribute("content")).includes("user-scalable=no"));
    await mobile.context.close();
  }
  pass("service login fits 320/390/1440px viewports and permits zoom");

  for (const width of [320, 390, 1440]) {
    const compact = await fixture("/dashboard.html", { width, height: 700 });
    assert.ok(await compact.page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    await compact.page.locator("#search-toggle").click();
    if (width === 390) await compact.page.screenshot({ path: "/tmp/dashboard-ui-audit-mobile.png", fullPage: true });
    assert.ok(await compact.page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    await compact.page.keyboard.press("Escape");
    await compact.page.locator("#account-menu-toggle").click();
    const menuBox = await compact.page.locator("#account-card").boundingBox();
    assert.ok(menuBox.x >= 0 && menuBox.x + menuBox.width <= width, "Account menu fits viewport");
    await compact.context.close();
  }
  pass("dashboard and command palette fit 320/390/1440px viewports");
} finally {
  await browser.close();
}

// Exercise service worker caching and route timeouts entirely in memory.
const listeners = {};
const deleted = [];
const cached = new Map();
const cache = { put: async (key, response) => cached.set(key, response), match: async (key) => cached.get(key) };
const worker = vm.createContext({
  URL, Response, Set, Promise,
  self: { location: { origin }, addEventListener: (name, handler) => { listeners[name] = handler; }, skipWaiting() {}, clients: { claim() {} } },
  caches: { open: async () => cache, keys: async () => ["unrelated-cache", "huber-apps-v29", "huber-apps-v30", "huber-apps-v31"], delete: async (key) => { deleted.push(key); } },
  fetch: async (path) => path === "/service-dashboard.html"
    ? { ok: true, redirected: true } : new Response(path)
});
vm.runInContext(sources.get("/service-worker.js"), worker);
let work;
listeners.activate({ waitUntil: (promise) => { work = promise; } });
await work;
assert.deepEqual(deleted, ["huber-apps-v29", "huber-apps-v30"]);
listeners.install({ waitUntil: (promise) => { work = promise; } });
await work;
assert.ok(cached.has("/network-route.js") && cached.has("/modal-dismiss.js"));
assert.ok(cached.has("/professional-ui.js") && cached.has("/professional-ui.css"));
assert.equal(cached.has("/service-dashboard.html"), false);
worker.fetch = async () => new Response("authenticated shell");
listeners.fetch({ request: { method: "GET", url: origin + "/service-dashboard.html?fixture=1" },
  respondWith: (promise) => { work = promise; }, waitUntil() {} });
await work;
assert.equal(await cached.get("/service-dashboard.html").text(), "authenticated shell");
pass("worker skips login redirects and refreshes protected shell under a stable cache key");
worker.fetch = async () => { throw new Error("offline"); };
listeners.fetch({ request: { method: "GET", url: origin + "/network-route.js?v=fixture" }, respondWith: (promise) => { work = promise; } });
assert.equal(await (await work).text(), "/network-route.js");
let intercepted = false;
listeners.fetch({ request: { method: "GET", url: origin + "/api/theme" }, respondWith: () => { intercepted = true; } });
assert.equal(intercepted, false);
pass("offline shell includes routing scripts, handles query versions, preserves other caches and excludes APIs");

const routeContext = vm.createContext({
  URL, AbortController, window: {}, location: { protocol: "https:", origin: "https://fixture.test" },
  setTimeout: (callback, ms) => { assert.equal(ms, 3000); return setTimeout(callback, 1); }, clearTimeout,
  fetch: (_url, { signal }) => new Promise((_resolve, reject) => signal.addEventListener("abort", () => reject(new Error("timeout"))))
});
vm.runInContext(sources.get("/network-route.js"), routeContext);
assert.equal((await routeContext.window.HuberNetworkRoute.resolve()).route, "public");
pass("stalled routing config times out to public login");
console.log(`\n${passed} bounded dashboard checks passed. Source: ${fileURLToPath(root)}`);

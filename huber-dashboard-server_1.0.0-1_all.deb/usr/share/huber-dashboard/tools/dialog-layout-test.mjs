import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { createRequire } from 'node:module';
const { chromium }=createRequire(import.meta.url)('playwright');
const root=new URL('../',import.meta.url);
const browser=await chromium.launch({channel:'chrome',headless:true});
let checks=0;
try {
  const page=await browser.newPage();
  await page.route('**/*',route=>route.abort());
  const css=await readFile(new URL('theme.css',root),'utf8');
  for(const file of (await readdir(root)).filter(f=>f.endsWith('.html'))){
    const html=await readFile(new URL(file,root),'utf8');
    if(!html.includes('<dialog'))continue;
    // Static fixture: keep real markup/CSS without authentication or data writes.
    const clean=html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
    await page.setContent(clean);
    await page.addStyleTag({content:css});
    const dialogs=page.locator('dialog:not(#presenter-dialog):not(.player-dialog):not(.compose-dialog)');
    for(const theme of ['light','dark']){
      await page.evaluate(theme=>document.documentElement.dataset.theme=theme,theme);
      for(const width of [390,1440]){
        await page.setViewportSize({width,height:900});
        for(let i=0;i<await dialogs.count();i++){
          const dialog=dialogs.nth(i);
          await dialog.evaluate(e=>e.showModal());
          const r=await dialog.boundingBox();
          assert.ok(r && Math.abs(r.x+r.width/2-width/2)<2 && Math.abs(r.y+r.height/2-450)<2,`${file} ${i} ${theme} ${width} centered`);
          assert.ok(r.x>=0 && r.y>=0 && r.width<=width && r.height<=900,`${file} fits`);
          await dialog.evaluate(e=>e.close());
          checks++;
        }
      }
    }
  }
  console.log(`PASS: ${checks} dialog layout checks across dashboard pages, light/dark and mobile/desktop.`);
}finally{await browser.close();}

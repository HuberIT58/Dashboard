import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
const {chromium}=createRequire(import.meta.url)('playwright');
const browser=await chromium.launch({channel:'chrome',headless:true});
try {
  const page=await browser.newPage({reducedMotion:'reduce'});
  let release;
  await page.route('**/*',async route=>{
    const path=new URL(route.request().url()).pathname;
    if(path==='/api/slow'){release=()=>route.fulfill({json:{ok:true}});return;}
    if(path==='/api/theme')return route.fulfill({json:{theme:'dark'}});
    if(path==='/theme.js'||path==='/theme.css')return route.fulfill({body:await readFile(new URL('..'+path,import.meta.url)),contentType:path.endsWith('.js')?'text/javascript':'text/css'});
    if(path==='/')return route.fulfill({contentType:'text/html',body:'<html><head><link rel="stylesheet" href="/theme.css"><script src="/theme.js" defer></script></head><body><button id="bell">&#128276;</button><div class="table-wrap"><table><thead><tr><th>Total</th></tr></thead><tbody><tr><td>$10.00</td></tr></tbody></table></div></body></html>'});
    return route.fulfill({status:404,body:''});
  });
  await page.goto('http://appearance.test/');
  await page.waitForFunction(()=>document.querySelector('#bell svg'));
  assert.equal(await page.locator('#bell').getAttribute('aria-label'),'Notifications');
  assert.equal(await page.locator('td').getAttribute('class'),'huber-money');
  await page.evaluate(()=>{window.pendingRead=fetch('/api/slow')});
  await page.locator('.huber-loading-indicator:not([hidden])').waitFor();
  assert.equal(await page.locator('.huber-loading-indicator').evaluate(e=>getComputedStyle(e).animationName),'none');
  await release();
  await page.evaluate(()=>window.pendingRead);
  assert.ok(await page.locator('.huber-loading-indicator').isHidden());
  console.log('PASS: accessible icons, currency alignment, real-request loading completion and reduced motion.');
}finally{await browser.close();}

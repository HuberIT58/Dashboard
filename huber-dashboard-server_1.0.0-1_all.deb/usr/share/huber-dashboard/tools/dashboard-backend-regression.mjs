import assert from "node:assert/strict";
import { test } from "node:test";
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync, existsSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, normalize, extname, resolve, sep } from "node:path";
import { pathToFileURL } from "node:url";
import { createHash, randomBytes } from "node:crypto";
import { PassThrough } from "node:stream";
import vm from "node:vm";

const source = readFileSync(process.env.DASHBOARD_BACKEND_SOURCE || new URL("../server.mjs", import.meta.url), "utf8");
const { StructuredStore } = await import(process.env.DASHBOARD_BACKEND_DATABASE
  ? pathToFileURL(process.env.DASHBOARD_BACKEND_DATABASE).href : new URL("../database.mjs", import.meta.url).href);

// Extract declarations only: importing server.mjs would initialize real services.
function isolated(name, dependencies = {}) {
  const start = source.search(new RegExp(`^(?:async )?function ${name}\\(`, "m"));
  assert.notEqual(start, -1, `Missing function ${name}`);
  const end = source.indexOf("\n}", start) + 2;
  return vm.runInNewContext(`(${source.slice(start, end)})`, {
    Buffer, URL, Date, Set, Map, console, ...dependencies
  });
}

function fixture(t) {
  const root = mkdtempSync(join(tmpdir(), "dashboard-backend-"));
  t.after(() => rmSync(root, { recursive: true, force: true }));
  return root;
}

function response() {
  return {
    writeHead(status, headers) { this.status = status; this.headers = headers; },
    end(body) { this.body = body; }
  };
}

const sendJson = (res, status, body) => Object.assign(res, { status, body });
const noop = () => {};
const clone = (value) => JSON.parse(JSON.stringify(value));

test("static paths cannot bypass private data or page authorization", (t) => {
  const root = fixture(t) + sep;
  mkdirSync(join(root, ".data"));
  writeFileSync(join(root, ".data", "fixture.json"), '{"synthetic":"private"}');
  for (const file of ["dashboard.html", "Dashboard.html", "account.html", "index.html", "public asset.js"]) {
    writeFileSync(join(root, file), "<head></head><body>fixture</body>");
  }
  const serve = (session = null) => isolated("serveStatic", {
    root, normalize, join, extname, existsSync, readFileSync,
    getSession: () => session, hasPermission: () => false,
    mimeTypes: { ".html": "text/html", ".js": "text/javascript" }
  });
  for (const url of ["/.data/fixture.json", "/%2edata/fixture.json", "/.data%2ffixture.json", "/public%2f..%2f.data%2ffixture.json"]) {
    const res = response();
    serve()({ url, method: "GET", headers: { host: "localhost" } }, res);
    assert.equal(res.status, 404, url);
  }
  for (const url of ["/dashboard.html", "/%64ashboard.html", "/Dashboard.html", "/public%2f..%2fdashboard.html"]) {
    const res = response();
    serve()({ url, method: "GET", headers: { host: "localhost" } }, res);
    assert.equal(res.status, 302, url);
    assert.equal(res.headers.Location, "/login.html");
  }
  for (const url of ["/", "/public%20asset.js"]) {
    const res = response();
    serve()({ url, method: "GET", headers: { host: "localhost" } }, res);
    assert.equal(res.status, 200, url);
  }
  const malformed = response();
  serve()({ url: "/%xx", method: "GET", headers: { host: "localhost" } }, malformed);
  assert.equal(malformed.status, 400);
});

test("required two-factor enrollment can load account page", (t) => {
  const root = fixture(t) + sep;
  writeFileSync(join(root, "account.html"), "<head></head>");
  const serve = isolated("serveStatic", {
    root, normalize, join, extname, existsSync, readFileSync,
    getSession: () => ({ username: "fixture", twoFactorEnrollmentRequired: true }),
    hasPermission: () => false, mimeTypes: { ".html": "text/html" }
  });
  const res = response();
  serve({ url: "/account.html?two-factor=required", method: "GET", headers: { host: "localhost" } }, res);
  assert.equal(res.status, 200);
});

test("structured exclusive creation cannot overwrite an existing store", (t) => {
  const root = fixture(t);
  const store = new StructuredStore(join(root, "fixture.sqlite"), root);
  t.after(() => store.close());
  const file = join(root, "users.txt");
  const write = isolated("writeFileSync", {
    structuredStore: store, structuredPaths: new Set([resolve(file)]), resolve,
    fsExistsSync: existsSync, fsWriteFileSync: writeFileSync, writeLegacyStructuredSnapshots: false
  });
  write(file, "first|fixture\n", { flag: "wx" });
  assert.throws(() => write(file, "second|fixture\n", { flag: "wx" }), { code: "EEXIST" });
  assert.equal(store.read(file), "first|fixture\n");
});

test("overlapping setup requests cannot replace the first owner", async () => {
  let users = [];
  const pending = [];
  const setup = isolated("handleSetup", {
    readUsers: () => clone(users), readJsonBody: () => new Promise((done) => pending.push(done)),
    validUsername: () => true, randomBytes, hashPassword: () => "fixture-hash", usersPath: "fixture.txt",
    writeFileSync: (_file, content) => { users = [{ username: content.split("|")[0] }]; },
    createSession: (_req, res) => { res.status = 200; }, sendJson, allPermissions: []
  });
  const first = {}, second = {};
  const a = setup({}, first), b = setup({}, second);
  pending[0]({ username: "first", password: "fixture-password" });
  await a;
  pending[1]({ username: "second", password: "fixture-password" });
  await b;
  assert.equal(first.status, 200);
  assert.equal(second.status, 409);
  assert.equal(users[0].username, "first");
});

test("sessions reject removed users and refresh current permissions", () => {
  const sessions = new Map([["token", { username: "fixture", expiresAt: Date.now() + 60000, permissions: ["security"] }]]);
  let users = [{ username: "fixture", permissions: [], role: "Employee", employeeName: "Current Name" }];
  let persisted = 0;
  const get = isolated("getSession", {
    sessions, getCookieValues: () => ["token"], hashSessionToken: (token) => token,
    restoreSessionFromStore: () => null, readUsers: () => users,
    twoFactorEnrollmentStatus: () => ({ required: false }), persistSessions: () => { persisted += 1; }
  });
  assert.equal(get({}).permissions.length, 0);
  assert.equal(get({}).employeeName, "Current Name");
  users = [];
  assert.equal(get({}), null);
  assert.equal(sessions.size, 0);
  assert.equal(persisted, 1);
});

test("overlapping time-clock requests preserve both employees", async () => {
  let records = [];
  const pending = [];
  const handle = isolated("handleTime", {
    getSession: (req) => ({ username: req.username }), readTimeRecords: () => clone(records),
    readJsonBody: () => new Promise((done) => pending.push(done)), completedMutation: () => null,
    writeTimeRecords: (value) => { records = clone(value); }, randomBytes, sendJson,
    rememberMutation: noop, broadcastServiceEvent: noop, broadcastAllServiceEvent: noop
  });
  const a = handle({ method: "POST", username: "first" }, {});
  const b = handle({ method: "POST", username: "second" }, {});
  pending[0]({ action: "clock-in" });
  await a;
  pending[1]({ action: "clock-in" });
  await b;
  assert.deepEqual(records.map((record) => record.username), ["first", "second"]);
});

test("slow account update cannot revert another user's access changes", async () => {
  let users = [{ username: "fixture", salt: "salt", hash: "old" }, { username: "other", permissions: ["security"] }];
  let finishBody;
  const handle = isolated("handleAccount", {
    getSession: () => ({ username: "fixture" }), readUsers: () => clone(users),
    readJsonBody: () => new Promise((done) => { finishBody = done; }), verifyPassword: () => true,
    randomBytes, hashPassword: () => "new", writeUsers: (value) => { users = clone(value); },
    invalidateUserSessions: noop, invalidateTrustedTwoFactorDevices: noop, logActivity: noop, sendJson
  });
  const res = {};
  const pending = handle({ method: "POST" }, res);
  users[1].permissions = [];
  finishBody({ action: "change-password", currentPassword: "fixture", newPassword: "fixture-password" });
  await pending;
  assert.equal(res.status, 200);
  assert.deepEqual(users[1].permissions, []);
});

for (const removeUser of [false, true]) {
  test(`slow avatar upload ${removeUser ? "cannot restore a deleted user" : "preserves current account security fields"}`, async () => {
    let users = [
      { username: "fixture", hash: "old-hash", totpSecret: "old-secret", permissions: ["security"] },
      { username: "other", permissions: ["security"] }
    ];
    let finishBody, imageWrites = 0, userWrites = 0;
    const handle = isolated("handleAccountAvatar", {
      getSession: () => ({ username: "fixture" }), readUsers: () => clone(users),
      readJsonBody: () => new Promise((done) => { finishBody = done; }), createHash,
      accountAvatarsPath: "fixture-avatars",
      saveImageDataUrl: () => { imageWrites += 1; return { filePath: "fixture-avatar.png" }; },
      writeUsers: (value) => { userWrites += 1; users = clone(value); },
      logActivity: noop, sendJson
    });
    const res = {};
    const pending = handle({ method: "POST" }, res);
    users[0].hash = "new-hash";
    users[0].totpSecret = "new-secret";
    users[0].permissions = [];
    users[1].permissions = [];
    if (removeUser) users.shift();
    const current = clone(users);
    finishBody({ image: "fixture-image" });
    await pending;
    assert.equal(res.status, removeUser ? 404 : 200);
    assert.equal(imageWrites, removeUser ? 0 : 1);
    assert.equal(userWrites, removeUser ? 0 : 1);
    if (!removeUser) {
      assert.equal(users[0].avatarPath, "fixture-avatar.png");
      delete users[0].avatarPath;
      delete users[0].avatarUpdatedAt;
    }
    assert.deepEqual(users, current);
  });
}

for (const [firstMethod, secondMethod] of [["POST", "POST"], ["POST", "DELETE"], ["DELETE", "POST"], ["DELETE", "DELETE"]]) {
  test(`overlapping Document Maker ${firstMethod}/${secondMethod} requests preserve committed changes`, async () => {
    let records = [{ id: "a", name: "A" }, { id: "b", name: "B" }];
    const pendingBodies = [], removedExports = [];
    const handle = isolated("handleCompanyDocuments", {
      getSession: () => ({ username: "fixture" }), hasPermission: () => true,
      readCompanyDocuments: () => clone(records),
      readJsonBody: () => new Promise((done) => pendingBodies.push(done)),
      cleanCompanyDocument: (payload, existing) => ({ ...existing, ...payload }),
      companyDocumentsPath: "fixture-documents.json",
      writeFileSync: (_path, content) => { records = JSON.parse(content); },
      exportCompanyDocumentToFileBrowser: async () => "fixture-export.pdf",
      removeExportedFile: (_folder, id) => removedExports.push(id),
      logActivity: noop, sendJson
    });
    const first = {}, second = {};
    const a = handle({ method: firstMethod, url: "/api/company-documents" }, first);
    const b = handle({ method: secondMethod, url: "/api/company-documents" }, second);
    pendingBodies[0]({ id: firstMethod === "POST" ? "c" : "a", name: "C" });
    await a;
    pendingBodies[1]({ id: secondMethod === "POST" ? "d" : "b", name: "D" });
    await b;
    assert.equal(first.status, 200);
    assert.equal(second.status, 200);
    const expected = [
      ...(firstMethod === "POST" ? ["a"] : []),
      ...(secondMethod === "POST" ? ["b"] : []),
      ...(firstMethod === "POST" ? ["c"] : []),
      ...(secondMethod === "POST" ? ["d"] : [])
    ];
    assert.deepEqual(records.map((record) => record.id), expected);
    assert.deepEqual(removedExports, [
      ...(firstMethod === "DELETE" ? ["a"] : []),
      ...(secondMethod === "DELETE" ? ["b"] : [])
    ]);
  });
}

for (const [firstMethod, secondMethod] of [["POST", "POST"], ["POST", "DELETE"], ["DELETE", "POST"], ["DELETE", "DELETE"]]) {
  test(`overlapping customer ${firstMethod}/${secondMethod} requests preserve committed changes`, async () => {
    let customers = [{ id: "a", name: "A" }, { id: "b", name: "B" }];
    const pendingBodies = [];
    const handle = isolated("handleCustomers", {
      getSession: () => ({ username: "fixture" }), hasPermission: () => true,
      readCustomers: () => clone(customers),
      readJsonBody: () => new Promise((done) => pendingBodies.push(done)),
      writeCustomers: (records) => { customers = clone(records); },
      readTickets: () => [], readWarranties: () => [], readCustomerCommunications: () => [],
      structuredClone, randomBytes, logActivity: noop, sendJson
    });
    const first = {}, second = {};
    const a = handle({ method: firstMethod }, first);
    const b = handle({ method: secondMethod }, second);
    pendingBodies[0](firstMethod === "POST"
      ? { customer: { id: "a", name: "Updated A" } } : { id: "a" });
    await a;
    pendingBodies[1](secondMethod === "POST"
      ? { customer: { id: "b", name: "Updated B" } } : { id: "b" });
    await b;
    assert.equal(first.status, 200);
    assert.equal(second.status, 200);
    assert.deepEqual(customers.map(({ id, name }) => ({ id, name })), [
      ...(firstMethod === "POST" ? [{ id: "a", name: "Updated A" }] : []),
      ...(secondMethod === "POST" ? [{ id: "b", name: "Updated B" }] : [])
    ]);
  });
}

test("JSON request decoding preserves UTF-8 split across chunks", async () => {
  const request = new PassThrough();
  const pending = isolated("readJsonBody")(request);
  const bytes = Buffer.from('{"name":"caf\u00e9"}');
  const split = bytes.indexOf(0xc3) + 1;
  request.write(bytes.subarray(0, split));
  request.end(bytes.subarray(split));
  assert.equal((await pending).name, "caf\u00e9");
});

test("aborted JSON requests reject instead of waiting forever", async () => {
  const request = new PassThrough();
  const pending = isolated("readJsonBody")(request);
  request.emit("aborted");
  await assert.rejects(Promise.race([
    pending, new Promise((done) => setTimeout(done, 25))
  ]), /aborted/);
});

test("SQLite cache detects external commits with identical timestamps", (t) => {
  const root = fixture(t), path = join(root, "records.json");
  const first = new StructuredStore(join(root, "fixture.sqlite"), root);
  const second = new StructuredStore(join(root, "fixture.sqlite"), root);
  t.after(() => { second.close(); first.close(); });
  first.write(path, '[{"id":"old"}]');
  first.read(path);
  const timestamp = first.info(path).updatedAt;
  second.write(path, '[{"id":"new"}]');
  second.database.prepare("UPDATE store_collections SET updated_at = ? WHERE store_key = ?").run(timestamp, second.key(path));
  assert.equal(JSON.parse(first.read(path))[0].id, "new");
});

test("rolled-back nested writes do not survive in SQLite read cache", (t) => {
  const root = fixture(t), path = join(root, "records.json");
  const store = new StructuredStore(join(root, "fixture.sqlite"), root);
  t.after(() => store.close());
  const RealDate = globalThis.Date;
  globalThis.Date = class extends RealDate { constructor(...args) { super(...(args.length ? args : [1700000000000])); } };
  try {
    store.write(path, '[{"id":"committed"}]');
    store.read(path);
    assert.throws(() => store.withSavepoint(() => {
      store.write(path, '[{"id":"rolled-back"}]');
      throw new Error("fixture rollback");
    }), /fixture rollback/);
    assert.equal(JSON.parse(store.read(path))[0].id, "committed");
    assert.equal(store.integrityCheck(), true);
  } finally {
    globalThis.Date = RealDate;
  }
});

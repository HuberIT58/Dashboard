import assert from "node:assert/strict";
import { readFile, mkdir } from "node:fs/promises";
import { createRequire } from "node:module";
import { restoreBounds } from "../dashboard-desktop/app/window-state.mjs";
const { chromium } = createRequire(import.meta.url)("playwright");
const root = new URL("../", import.meta.url);
const browser = await chromium.launch({ channel: "chrome", headless: true });
let passed = 0;
const check = (value, name) => { assert.ok(value, name); console.log(`PASS ${++passed}: ${name}`); };
try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", e => errors.push(e.message));
  page.on("dialog", d => d.dismiss());
  let fail = false, hold = false, pending;
  const fixture = `<html><head><style>:root{--panel:#182226;--ink:#edf3f5;--line:#34434a;--accent:#28a9b3}body{background:#101719;color:#edf3f5}dialog{background:#182226;color:white}td,th{padding:20px}</style><script src="/professional-ui.js" defer></script></head><body>
  <main><div class="toolbar"><input id="search" type="search"><select id="status-filter"><option value="">All</option><option>Open</option></select></div>
  <div class="table-wrap"><table><thead><tr><th>Name</th><th>Quantity</th></tr></thead><tbody><tr><td>B</td><td>10</td></tr><tr><td>A</td><td>2</td></tr></tbody></table></div></main>
  <button id="new" onclick="document.querySelector('dialog').showModal()">New</button><dialog id="ticket-dialog"><div class="dialog-head">Ticket</div><form><input id="name"><button type="submit">Save</button></form><button id="close-dialog" onclick="document.querySelector('dialog').close()">Close</button></dialog>
  <script>document.querySelector('form').onsubmit=async(e)=>{e.preventDefault(); const r=await fetch('/api/tickets',{method:'POST',body:'{}'}); if(r.ok) document.querySelector('dialog').close();};</script></body></html>`;
  await context.route("**/*", async route => {
    const p = new URL(route.request().url()).pathname;
    if (p === "/service-tickets.html") return route.fulfill({ body: fixture, contentType: "text/html" });
    if (p === "/auth-status") return route.fulfill({ json: { authenticated: true, username: "fixture" } });
    if (p === "/api/tickets") {
      if (hold) { pending = route; return; }
      return route.fulfill({ status: fail ? 500 : 200, json: { ok: !fail, message: "Fixture rejected" } });
    }
    if (["/professional-ui.js", "/professional-ui.css"].includes(p)) return route.fulfill({ body: await readFile(new URL(p.slice(1), root)), contentType: p.endsWith("js") ? "text/javascript" : "text/css" });
    return route.abort();
  });
  await page.goto("http://fixture.test/service-tickets.html");
  await page.locator(".professional-sort").first().waitFor();
  await page.locator(".professional-sort").first().click();
  check(await page.locator("tbody td").first().textContent() === "A", "Text sorting");
  await page.locator(".professional-sort").nth(1).click();
  check(await page.locator("tbody td").first().textContent() === "A", "Numeric sorting");
  await page.locator("summary").click();
  await page.getByLabel("Table density").selectOption("Compact");
  await page.getByLabel("Name column width").fill("240");
  await page.locator("#search").fill("saved query");
  await page.reload();
  await page.waitForFunction(() => document.querySelector('table').dataset.density === 'Compact');
  check(await page.locator("#search").inputValue() === "saved query", "Per-account search preferences restored");
  check(await page.locator("th").first().evaluate(e => e.style.minWidth) === "240px", "Column width restored");
  await page.locator("#new").click();
  await page.locator("#name").fill("unsaved");
  await page.locator("#close-dialog").click();
  check(await page.locator("dialog").evaluate(e => e.open), "Rejected discard keeps editor open");
  check(await page.evaluate(() => !window.HuberProfessional.canLeave()), "Workspace navigation respects dirty editor");
  fail = true;
  await page.locator('button[type="submit"]').click();
  await page.getByRole("status").filter({ hasText: "Fixture rejected" }).waitFor();
  check(await page.locator("dialog").evaluate(e => e.open), "Failed save retains editor");
  fail = false; hold = true;
  await page.locator('button[type="submit"]').click();
  await page.waitForFunction(() => document.querySelector('[role=status]').textContent.includes('Saving'));
  check(await page.evaluate(() => !window.HuberProfessional.canLeave()), "Pending save prevents navigation");
  await pending.fulfill({ json: { ok: true } });
  await page.waitForFunction(() => !document.querySelector('dialog').open);
  check(await page.evaluate(() => window.HuberProfessional.canLeave()), "Successful save clears dirty state");
  check(await page.getByRole("status").isVisible(), "Save confirmation stays visible after editor closes");
  check(errors.length === 0, "No browser errors");
  const displays = [{ workArea: { x: 0, y: 0, width: 1920, height: 1080 } }];
  check(restoreBounds({ x: 20, y: 20, width: 1200, height: 800 }, displays).x === 20, "Window position restored");
  check(restoreBounds({ x: 9000, y: 0, width: 1200, height: 800 }, displays).x === undefined, "Disconnected monitor position rejected");
  check(restoreBounds({ x: 10, y: 10, width: -1, height: 5 }, displays).width === 900, "Window bounds clamped");
  await page.locator("#new").click();
  await mkdir(new URL("../tmp/professional-ui/", import.meta.url), { recursive: true });
  await page.screenshot({ path: new URL("../tmp/professional-ui/drawer.png", import.meta.url).pathname });
  const actual = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const ticketFixtures = Array.from({ length: 8 }, (_, index) => ({
    id: `ticket-${index}`, number: index + 1, customer: ['Acme Manufacturing', 'Northwind Traders', 'Summit Financial', 'Greenleaf Logistics'][index % 4],
    company: 'Test customer', ticketType: index === 7 ? 'Contract' : 'Service', serviceType: 'Wifi & Networking',
    priority: index === 1 ? 'Urgent' : 'Normal', status: ['Open', 'In Progress', 'Closed'][index % 3],
    assignedTo: 'Chris Huber', scheduledDate: '2026-09-19', hoursUsed: '1.5', description: 'Investigate intermittent network connectivity.', resolution: '',
    usedItems: [], workLogs: [], attachments: [], phases: [], internalMessages: []
  }));
  await actual.route("**/*", async route => {
    const p = new URL(route.request().url()).pathname;
    if (p === "/auth-status") return route.fulfill({ json: { authenticated: true, username: "fixture", permissions: ["service-tickets"] } });
    if (p === '/api/tickets') return route.fulfill({ json: { ok: true, tickets: ticketFixtures } });
    if (p.startsWith("/api/")) return route.fulfill({ json: { ok: true, tickets: [], customers: [], employees: [], items: [], reasons: [], theme: "dark" } });
    if (!/^\/[a-zA-Z0-9_.-]+$/.test(p) && p !== "/assets/logo.png") return route.abort();
    try {
      let body = await readFile(new URL(p.slice(1), root));
      if (p.endsWith(".html")) body = Buffer.from(body.toString().replace("</head>", '<link rel="stylesheet" href="/theme.css"><script src="/theme.js" defer></script></head>'));
      return route.fulfill({ body, contentType: p.endsWith(".html") ? "text/html" : p.endsWith(".css") ? "text/css" : p.endsWith(".js") ? "text/javascript" : "image/png" });
    } catch { return route.fulfill({ status: 404, body: "" }); }
  });
  const realPage = await actual.newPage();
  await realPage.goto("http://fixture.test/service-tickets.html");
  await realPage.locator(".professional-table-options").waitFor();
  const dashboardSource = await readFile(new URL('dashboard.html', root), 'utf8');
  const prepareEmbedded = dashboardSource.slice(dashboardSource.indexOf('    function prepareEmbeddedWorkspacePage('), dashboardSource.indexOf('    function createWorkspaceFrame('));
  await realPage.evaluate(`(() => { ${prepareEmbedded}; prepareEmbeddedWorkspacePage({ contentDocument: document }); })()`);
  await realPage.waitForFunction(() => document.querySelectorAll('#ticket-list tr').length === 7);
  await realPage.screenshot({ path: new URL('../tmp/professional-ui/ticket-list.png', import.meta.url).pathname });
  check(await realPage.locator('#ticket-list button[aria-label="Edit"] svg').count() === 7, 'Accessible ticket action icons rendered');
  await realPage.locator('#search').fill('Northwind');
  await realPage.waitForFunction(() => document.querySelectorAll('#ticket-list tr').length === 2);
  await realPage.locator('#search').fill('');
  await realPage.locator('#status-filter').selectOption('Closed');
  await realPage.waitForFunction(() => document.querySelectorAll('#ticket-list tr').length === 2);
  check(true, 'Search and status filtering retained');
  await realPage.locator('#status-filter').selectOption('');
  await realPage.locator('[data-ticket-type="Contract"]').click();
  check(await realPage.locator('#add-ticket-label').textContent() === 'New Contract Ticket', 'Contract creation mode retained');
  await realPage.locator('[data-ticket-type="Service"]').click();
  await realPage.locator('#ticket-list tr').first().click();
  check(await realPage.locator('#ticket-details-dialog').isVisible(), 'Ticket rows open details');
  check(!await realPage.locator('#view-signature-block').isVisible(), 'Absent signature stays hidden');
  await realPage.screenshot({ path: new URL('../tmp/professional-ui/ticket-details.png', import.meta.url).pathname });
  await realPage.locator('#close-ticket-details').click();
  await realPage.locator('#ticket-list button[data-action="log"]').first().click();
  check(await realPage.locator('#work-log-dialog').isVisible(), 'Work Log action retained');
  await realPage.locator('#close-work-log').click();
  const editButton = realPage.locator('#ticket-list button[data-action="edit"]').first();
  const selectedId = await editButton.getAttribute('data-id');
  await editButton.click();
  await realPage.locator('#ticket-dialog[open]').waitFor();
  check(await realPage.locator('#record-id').inputValue() === selectedId, 'Edit action loads selected ticket');
  await realPage.locator('#cancel-dialog').click();
  for (const width of [390, 900, 1920, 2560]) {
    await realPage.setViewportSize({ width, height: 1000 });
    check(await realPage.evaluate(() => document.documentElement.scrollWidth <= innerWidth), `Ticket workspace fits ${width}px`);
  }
  await realPage.setViewportSize({ width: 1440, height: 1000 });
  await realPage.locator("#add-ticket").click();
  await realPage.locator("#ticket-dialog[open]").waitFor();
  const rect = await realPage.locator("#ticket-dialog").boundingBox();
  check(Math.abs(rect.x + rect.width / 2 - 720) < 3, "Real service ticket dialog centered horizontally");
  check(Math.abs(rect.y + rect.height / 2 - 500) < 3, "Real service ticket dialog centered vertically");
  check(rect.width > rect.height, "Ticket editor uses landscape proportions");
  await realPage.locator('#ticket-dialog').evaluate(e => e.scrollTop = 0);
  await realPage.screenshot({ path: new URL("../tmp/professional-ui/service-tickets.png", import.meta.url).pathname, animations: 'disabled' });
  await realPage.setViewportSize({ width: 900, height: 640 });
  const narrow = await realPage.locator("#ticket-dialog").boundingBox();
  check(narrow.width <= 900 && narrow.height <= 640, "Drawer fits smallest desktop window");
  console.log(`${passed} checks passed`);
} finally { await browser.close(); }

import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const root = new URL("../", import.meta.url).pathname;
const eps = readFileSync(join(root, "vinyl-logo-print.eps"), "utf8");
const pageHeight = 960;

function extractPath(after, before) {
  const start = eps.indexOf(after);
  const end = eps.indexOf(before, start + after.length);
  if (start < 0 || end < 0) throw new Error(`Unable to locate EPS section: ${after}`);
  return eps.slice(start + after.length, end);
}

function parseSubpaths(source) {
  const lines = source.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const paths = [];
  let commands = [];
  let points = [];
  for (const line of lines) {
    const match = line.match(/^(-?[\d.]+)\s+(-?[\d.]+)\s+(moveto|lineto)$/);
    if (match) {
      const x = Number(match[1]);
      const y = pageHeight - Number(match[2]);
      const command = match[3] === "moveto" ? "M" : "L";
      if (command === "M" && commands.length) {
        paths.push({ d: `${commands.join(" ")} Z`, points });
        commands = [];
        points = [];
      }
      commands.push(`${command}${x.toFixed(3)} ${y.toFixed(3)}`);
      points.push([x, y]);
    } else if (line === "closepath" && commands.length) {
      paths.push({ d: `${commands.join(" ")} Z`, points });
      commands = [];
      points = [];
    }
  }
  if (commands.length) paths.push({ d: `${commands.join(" ")} Z`, points });
  return paths;
}

function bounds(path) {
  const xs = path.points.map(([x]) => x);
  const ys = path.points.map(([, y]) => y);
  return {
    minX: Math.min(...xs), maxX: Math.max(...xs),
    minY: Math.min(...ys), maxY: Math.max(...ys)
  };
}

function compoundPathMarkup(paths) {
  return `      <path d="${paths.map((path) => path.d).join(" ")}"/>`;
}

function outlinedTextMarkup(paths) {
  const boxes = paths.map(bounds);
  const roots = [];
  const children = new Map();
  for (let index = 0; index < paths.length; index += 1) {
    const box = boxes[index];
    const containers = boxes.map((candidate, candidateIndex) => ({ candidate, candidateIndex }))
      .filter(({ candidate, candidateIndex }) => candidateIndex !== index &&
        candidate.minX < box.minX && candidate.maxX > box.maxX &&
        candidate.minY < box.minY && candidate.maxY > box.maxY)
      .sort((a, b) =>
        (a.candidate.maxX - a.candidate.minX) * (a.candidate.maxY - a.candidate.minY) -
        (b.candidate.maxX - b.candidate.minX) * (b.candidate.maxY - b.candidate.minY)
      );
    if (!containers.length) roots.push(index);
    else {
      const parent = containers[0].candidateIndex;
      children.set(parent, [...(children.get(parent) || []), index]);
    }
  }
  return roots.map((index) => {
    const members = [paths[index], ...(children.get(index) || []).map((child) => paths[child])];
    return `      <path d="${members.map((path) => path.d).join(" ")}" fill-rule="evenodd"/>`;
  }).join("\n");
}

const emblemSource = extractPath("gsave\nnewpath", "eoclip newpath");
const typeSource = extractPath("grestore\nnewpath", "1 1 1 setrgbcolor eofill");
const emblem = parseSubpaths(emblemSource);
const type = parseSubpaths(typeSource);

const wordmark = [];
const subtitle = [];
const phone = [];
for (const path of type) {
  const box = bounds(path);
  const centerY = (box.minY + box.maxY) / 2;
  if (centerY < 700) wordmark.push(path);
  else if (centerY < 790) subtitle.push(path);
  else phone.push(path);
}

function svg(includeBackground) {
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="1200" height="960" viewBox="0 0 1200 960">
  <title>Huber I.T. Professionals outlined vector logo</title>
  <desc>Production vector artwork reconstructed from the approved high-resolution master. All visible artwork is outlined; no raster images or font references.</desc>
  <defs>
    <linearGradient id="brand-gradient" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#20d9cf"/>
      <stop offset="0.5" stop-color="#36b9df"/>
      <stop offset="1" stop-color="#5d6df0"/>
    </linearGradient>
  </defs>
  <g id="background" inkscape:groupmode="layer" inkscape:label="Background"${includeBackground ? "" : " display=\"none\""}>
    <rect width="1200" height="960" fill="#000"/>
  </g>
  <g id="emblem" inkscape:groupmode="layer" inkscape:label="Gradient Emblem" fill="url(#brand-gradient)" fill-rule="evenodd" clip-rule="evenodd">
${compoundPathMarkup(emblem)}
  </g>
  <g id="company-name" inkscape:groupmode="layer" inkscape:label="Huber I.T. Outlines" fill="#fff" fill-rule="evenodd">
${outlinedTextMarkup(wordmark)}
  </g>
  <g id="professional-name" inkscape:groupmode="layer" inkscape:label="Professionals Outlines" fill="#fff" fill-rule="evenodd">
${outlinedTextMarkup(subtitle)}
  </g>
  <g id="phone-number" inkscape:groupmode="layer" inkscape:label="Phone Number Outlines" fill="#fff" fill-rule="evenodd">
${outlinedTextMarkup(phone)}
  </g>
</svg>\n`;
}

writeFileSync(join(root, "huber-logo-vector-master.svg"), svg(true));
writeFileSync(join(root, "huber-logo-vector-transparent.svg"), svg(false));
console.log(`emblem=${emblem.length}, wordmark=${wordmark.length}, subtitle=${subtitle.length}, phone=${phone.length}`);

import assert from "node:assert/strict";
import { readFile, readdir, mkdir } from "node:fs/promises";
import { createRequire } from "node:module";
const { chromium } = createRequire(import.meta.url)("playwright");
const root = new URL("../", import.meta.url);
const dashboard = await readFile(new URL("dashboard.html", root), "utf8");
const prepare = dashboard.slice(dashboard.indexOf("    function prepareEmbeddedWorkspacePage("), dashboard.indexOf("    function createWorkspaceFrame("));
const browser = await chromium.launch({ channel: "chrome", headless: true });
let checks = 0;
try {
  const page = await browser.newPage();
  await page.route("**/*", route => route.abort());
  for (const file of await readdir(root)) {
    if (!file.endsWith(".html") || file === "dashboard.html") continue;
    const source = await readFile(new URL(file, root), "utf8");
    if (!/<main class="shell(?:\s|")/.test(source)) continue;
    // Layout-only fixtures retain actual markup/styles without running app API calls.
    await page.setContent(source.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ""));
    await page.evaluate(`(() => { ${prepare}; prepareEmbeddedWorkspacePage({contentDocument:document}); })()`);
    for (const width of [700, 1214, 1694, 2334, 3214]) {
      await page.setViewportSize({ width, height: 1000 });
      const box = await page.locator("main.shell").first().boundingBox();
      const gutter = width <= 760 ? 24 : 40;
      assert.ok(box && Math.abs(box.width - (width - gutter)) < 2, `${file} fills ${width}px workspace`);
      assert.ok(Math.abs(box.x - gutter / 2) < 2, `${file} balanced gutters`);
      checks++;
    }
    if (file === "invoices.html") {
      await page.setViewportSize({ width: 2334, height: 1000 });
      await mkdir(new URL("tmp/responsive-workspace/", root), { recursive: true });
      await page.screenshot({ path: new URL("tmp/responsive-workspace/invoices.png", root).pathname });
      await page.emulateMedia({ media: "print" });
      assert.ok((await page.locator("main.shell").boundingBox()).width <= 1200, "Print width unchanged");
      await page.emulateMedia({ media: "screen" });
    }
  }
  console.log(`PASS: ${checks} real-page viewport checks; print layout unchanged.`);
} finally {
  await browser.close();
}

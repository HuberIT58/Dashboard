import assert from 'node:assert/strict';
import {readFile, mkdir} from 'node:fs/promises';
import {createRequire} from 'node:module';
const {chromium} = createRequire(import.meta.url)('playwright');
const root = new URL('../', import.meta.url);
const browser = await chromium.launch({channel:'chrome', headless:true});
try {
  const context = await browser.newContext({viewport:{width:1440,height:900}});
  const messages = ['Network upgrade proposal','Scheduled maintenance','Your service report','Project kickoff'].map((subject,i)=>({uid:String(i+1),subject,from:[{name:['Sarah Johnson','Michael Lee','Huber Support','David Patel'][i],address:'fixture@example.invalid'}],to:[{address:'test@example.invalid'}],date:'2026-09-20T10:00:00Z',seen:i>1,flagged:i===2,text:'Hello Christian,\n\nThe network upgrade is scheduled for next week. Please review the attached scope and let us know your preferred maintenance window.\n\nThank you,\nSarah'}));
  let failSave = false, saves = 0, sends = 0;
  await context.route('**/*', async route => {
    const url = new URL(route.request().url()), path = url.pathname;
    if(path === '/api/mail/status') return route.fulfill({json:{configured:true,account:'test@example.invalid',settings:{email:'test@example.invalid',fromName:'Test User'}}});
    if(path === '/api/mail/folders') return route.fulfill({json:{account:'test@example.invalid',folders:[{path:'INBOX',specialUse:'\\Inbox',unseen:2},{path:'archive',specialUse:'\\Archive'},{path:'local:projects',name:'Projects',local:true}]}});
    if(path === '/api/mail/messages') return route.fulfill({json:{messages,total:80,pages:2,page:Number(url.searchParams.get('page'))}});
    if(path === '/api/mail/message') {const uid=url.searchParams.get('uid');if(uid==='1')await new Promise(r=>setTimeout(r,250));return route.fulfill({json:{message:messages.find(m=>m.uid===uid)}});}
    if(path === '/api/mail/drafts') {
      if(route.request().method()==='POST'){saves++;return route.fulfill({status:failSave?500:200,json:failSave?{message:'Test save failure'}:{draft:{id:'draft-1'}}});}
      return route.fulfill({json:{drafts:[]}});
    }
    if(path === '/api/mail/send'){sends++;await new Promise(r=>setTimeout(r,100));return route.fulfill({json:{ok:true}});}
    if(path.startsWith('/api/')) return route.fulfill({json:{contacts:[]}});
    try{let body=await readFile(new URL(path.slice(1),root));if(path.endsWith('.html'))body=Buffer.from(body.toString().replace('</head>','<link rel="stylesheet" href="/theme.css"><script src="/theme.js" defer></script></head>'));return route.fulfill({body,contentType:path.endsWith('.html')?'text/html':path.endsWith('.js')?'text/javascript':path.endsWith('.css')?'text/css':'image/png'});}catch{return route.fulfill({status:404,body:''});}
  });
  const page=await context.newPage(), errors=[];
  await page.addInitScript(()=>{if(window===window.top)localStorage.setItem('huber-account-theme','midnight');});
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://email.test/email.html');
  await page.waitForSelector('[data-uid]');
  assert.equal(await page.locator('#pager').isVisible(),true);
  await page.locator('#next-page').click();await page.waitForFunction(()=>document.querySelector('#page-label').textContent==='Page 2 of 2');
  await page.locator('#refresh').click();await page.waitForFunction(()=>!document.querySelector('#refresh').disabled);
  await page.locator('#message-filter').selectOption('flagged');assert.equal(await page.locator('[data-uid]:visible').count(),1);
  await page.locator('#message-filter').selectOption('all');
  await page.evaluate(()=>{openMessage('1');openMessage('2');});
  await page.waitForTimeout(400);assert.equal(await page.locator('#read-subject').textContent(),'Scheduled maintenance');
  await page.locator('#new-message').click();
  await page.locator('#compose-to').fill('fixture@example.invalid');
  await page.locator('#compose-body').fill('Test draft content');
  failSave=true;
  await page.locator('#close-compose').click();await page.waitForTimeout(100);
  assert.equal(await page.locator('#compose-dialog').isVisible(),true);
  failSave=false;
  await page.locator('#close-compose').click();await page.waitForFunction(()=>!document.querySelector('#compose-dialog').open);
  assert.ok(saves>=2);
  await page.locator('#new-message').click();
  await page.locator('#compose-to').fill('fixture@example.invalid');
  await page.locator('#compose-subject').fill('Fixture send');
  await page.locator('#compose-body').fill('Synthetic message only');
  await page.evaluate(()=>{const form=document.querySelector('#compose-form');form.requestSubmit();form.requestSubmit();});
  await page.waitForFunction(()=>!document.querySelector('#compose-dialog').open);
  assert.equal(sends,1);
  await page.locator('#toast').evaluate(node=>node.hidden=true);
  await mkdir(new URL('tmp/email-ui/',root),{recursive:true});
  for(const width of [390,900,1440,2560]) {
    await page.setViewportSize({width,height:900});
    await page.screenshot({path:new URL(`tmp/email-ui/email-${width}.png`,root).pathname});
    assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`Fits ${width}`);
    const reader=await page.locator('#reader').boundingBox();assert.ok(reader.x+reader.width<=width+1,`Reader fits ${width}`);
  }
  assert.deepEqual(errors,[]);
  console.log('PASS: pagination, refresh, filtering, stale message responses, draft failure recovery, duplicate-send suppression and layout at 390/900/1440/2560px. No real email sent.');
}finally{await browser.close();}

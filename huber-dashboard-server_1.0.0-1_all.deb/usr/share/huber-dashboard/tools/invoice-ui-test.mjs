import assert from 'node:assert/strict';
import { readFile, mkdir } from 'node:fs/promises';
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const root = new URL('../', import.meta.url);
const browser = await chromium.launch({ channel:'chrome', headless:true });
try {
  const context = await browser.newContext({ viewport:{width:1440,height:900} });
  const invoices = Array.from({length:80}, (_,i)=>({id:`invoice-${i}`,number:i+1,customer:i===0?'Northwind':'Customer '+i,company:'Example Company',ticketId:'ticket-1',ticketNumber:1,issueDate:'2026-09-19',dueDate:'2026-10-19',total:1250,subtotal:1250,tax:0,taxRate:0,status:i%2?'Paid':'Sent',paidAmount:i%2?1250:0,balance:i%2?0:1250,laborTotal:1250,laborHours:10,laborRate:125}));
  await context.route('**/*',async route=>{
    const path=new URL(route.request().url()).pathname;
    if(path==='/auth-status')return route.fulfill({json:{authenticated:true,username:'fixture',permissions:['invoices']}});
    if(path==='/api/invoices')return route.fulfill({json:{invoices,tickets:[{id:'ticket-1',number:1,customer:'Northwind',hoursUsed:10}],canDeleteInvoices:true}});
    if(path.startsWith('/api/'))return route.fulfill({json:{theme:'dark',charges:[],instructions:[]}});
    try {
      let body=await readFile(new URL(path.slice(1),root));
      if(path.endsWith('.html'))body=Buffer.from(body.toString().replace('</head>','<link rel="stylesheet" href="/theme.css"><script src="/theme.js" defer></script></head>'));
      return route.fulfill({body,contentType:path.endsWith('.html')?'text/html':path.endsWith('.js')?'text/javascript':path.endsWith('.css')?'text/css':'image/png'});
    }catch{return route.fulfill({status:404,body:''});}
  });
  const page=await context.newPage(), errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://invoice.test/invoices.html');
  await page.waitForFunction(()=>document.querySelectorAll('#invoice-list tr').length===75);
  const dashboard=await readFile(new URL('dashboard.html',root),'utf8');
  const prepare=dashboard.slice(dashboard.indexOf('    function prepareEmbeddedWorkspacePage('),dashboard.indexOf('    function createWorkspaceFrame('));
  await page.evaluate(`(()=>{${prepare};prepareEmbeddedWorkspacePage({contentDocument:document});})()`);
  await page.locator('#show-more-invoices').click();
  assert.equal(await page.locator('#invoice-list tr').count(),80);
  await page.locator('#search').fill('Northwind');
  assert.equal(await page.locator('#invoice-list tr').count(),1);
  await page.getByRole('button',{name:'View invoice',exact:true}).click();
  assert.equal(await page.locator('#view-number').textContent(),'INV-0001');
  await page.locator('#close-view').click();
  await page.getByRole('button',{name:'Edit invoice',exact:true}).click();
  assert.equal(await page.locator('#labor-rate').inputValue(),'125');
  await page.locator('#cancel-form').click();
  await page.locator('#search').fill('');
  await page.locator('#status-filter').selectOption('Paid');
  assert.equal(await page.locator('#invoice-list tr').count(),40);
  await page.locator('#search').fill('no match');
  assert.equal(await page.locator('#empty').textContent(),'No invoices match your filters.');
  await page.locator('#search').fill('');
  await page.locator('#status-filter').selectOption('');
  await mkdir(new URL('tmp/invoice-ui/',root),{recursive:true});
  for(const width of [390,900,1440,2560]){
    await page.setViewportSize({width,height:900});
    assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`Page fits ${width}`);
    await page.locator('#new-invoice').click();
    assert.ok(await page.locator('#invoice-dialog').evaluate(e=>e.scrollWidth<=e.clientWidth),`Editor fits ${width}`);
    const box=await page.locator('#invoice-dialog').boundingBox();
    assert.ok(Math.abs(box.x+box.width/2-width/2)<2 && Math.abs(box.y+box.height/2-450)<2,`Editor centered ${width}`);
    if(width===1440){
      await page.locator('#invoice-dialog').evaluate(e=>e.scrollTop=0);
      await page.screenshot({path:new URL('tmp/invoice-ui/editor.png',root).pathname,animations:'disabled'});
    }
    await page.locator('#cancel-form').click();
    await page.screenshot({path:new URL(`tmp/invoice-ui/invoices-${width}.png`,root).pathname});
  }
  assert.deepEqual(errors,[]);
  console.log('PASS: invoice search, filters, pagination, view, edit, new and responsive geometry at four sizes.');
}finally{await browser.close();}

import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const root = new URL('../', import.meta.url);
const browser = await chromium.launch({ channel: 'chrome', headless: true });
let checks = 0;
const check = (value, label) => { assert.ok(value, label); console.log(`PASS ${++checks}: ${label}`); };
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const errors = [], calls = [];
  page.on('pageerror', e => errors.push(e.message));
  let failure = false, pending = null, hold = false;
  await page.route('**/*', async route => {
    const url = new URL(route.request().url());
    const path = url.pathname;
    if (['/update.html', '/theme.css'].includes(path)) {
      let body = await readFile(new URL(path.slice(1), root), 'utf8');
      if (path.endsWith('.html')) body = body.replace('</head>', '<link rel="stylesheet" href="/theme.css"></head>');
      return route.fulfill({ body, contentType: path.endsWith('html') ? 'text/html' : 'text/css' });
    }
    if (path === '/assets/logo.png') return route.fulfill({ body: await readFile(new URL('assets/logo.png', root)), contentType: 'image/png' });
    if (path.startsWith('/api/')) {
      calls.push({ path, stage: url.searchParams.get('stage'), body: route.request().postData() });
      if (hold) { pending = route; return; }
      if (failure) return route.fulfill({ status: 400, json: { message: 'Package rejected by server' } });
      return route.fulfill({ json: { ok: true, message: 'Release published', updatedFiles: 5, manifest: { sha256: 'abc' }, app: { sha256: 'def' }, uploadId: 'fixture', received: 7 } });
    }
    return route.fulfill({ body: '', contentType: 'text/javascript' });
  });
  await page.goto('http://updater.test/update.html');
  await page.evaluate(() => document.documentElement.dataset.theme = 'dark');
  const file = (name) => ({ name, mimeType: 'application/zip', buffer: Buffer.from('fixture') });
  check(await page.locator('[role=tabpanel]:visible').count() === 1, 'Website opens as the only visible destination');
  await page.locator('#tab-website').focus();
  await page.keyboard.press('ArrowRight');
  check(await page.locator('#pane-desktop').isVisible(), 'Keyboard tabs select desktop destination');
  await page.locator('#desktop-update-file').setInputFiles(file('desktop-app-update.zip'));
  await page.locator('#desktop-update-button').click();
  await page.waitForFunction(() => document.querySelector('#desktop-update-status').textContent === 'Desktop update published.');
  check(calls.some(x => x.path === '/api/desktop-update'), 'Desktop publication uses existing endpoint');
  await page.locator('#tab-website').click();
  await page.locator('#zip-file').setInputFiles(file('wrong.zip'));
  await page.locator('#upload-button').click();
  check(!calls.some(x => x.path === '/api/site-update'), 'Wrong website package blocked before upload');
  await page.locator('#zip-file').setInputFiles(file('website.zip'));
  hold = true;
  await page.locator('#upload-button').click();
  // Route interception pauses transmission; emulate its upload-complete callback.
  await page.evaluate(() => startProcessingProgress());
  await page.waitForFunction(() => document.querySelector('#update-intro').classList.contains('processing'));
  check(await page.locator('#tab-desktop').isDisabled(), 'Destination changes blocked during deployment');
  check(await page.locator('#zip-file').isDisabled(), 'Package cannot change during deployment');
  check((await page.locator('#update-intro-status').textContent()).includes('Waiting for server'), 'Server processing is not presented as fabricated progress');
  await pending.fulfill({ json: { ok: true, message: 'Website updated', updatedFiles: 5, restartScheduled: true } });
  hold = false;
  await page.waitForFunction(() => document.querySelector('#status').textContent === 'Update complete.');
  check(await page.locator('#result').isVisible() && await page.locator('#tab-desktop').isEnabled(), 'Confirmed completion remains visible and unlocks controls');
  failure = true;
  await page.locator('#upload-button').click();
  await page.waitForFunction(() => document.querySelector('#status').textContent.includes('Package rejected'));
  check(await page.locator('#upload-button').isEnabled(), 'Rejected upload shows error and permits retry');
  failure = false;
  await page.locator('#tab-tester').click();
  await page.locator('#tester-update-file').setInputFiles(file('huber-network-tester-1.2.3.zip'));
  check(await page.locator('#tester-update-version').inputValue() === '1.2.3', 'Tester version detection retained');
  await page.locator('#tester-update-button').click();
  await page.waitForFunction(() => document.querySelector('#tester-update-status').textContent === 'Network Tester update published.');
  check(calls.filter(x => x.path.includes('network-tester')).map(x => x.stage).join(',') === 'start,chunk,complete', 'Tester retains chunked publishing sequence');
  await page.locator('#tab-installer').click();
  await page.locator('#installer-preset').selectOption('office-suite');
  check(await page.locator('#installer-id').inputValue() === 'huber-office-suite', 'Office Suite preset retained');
  await page.locator('#installer-preset').selectOption('design-center');
  await page.locator('#installer-target').selectOption('win-x64');
  check((await page.locator('#installer-file').getAttribute('accept')).includes('.exe'), 'Windows package filter retained');
  await page.locator('#installer-file').setInputFiles(file('Huber-Design-Center.exe'));
  await page.locator('#installer-publish-button').click();
  await page.waitForFunction(() => document.querySelector('#installer-status').textContent === 'Application published.');
  check(calls.filter(x => x.path.includes('desktop-installer')).map(x => x.stage).join(',') === 'start,chunk,complete', 'Installer retains chunked publishing sequence');
  for (const width of [390, 900, 1440, 2560]) {
    await page.setViewportSize({ width, height: 1000 });
    for (const id of ['website', 'desktop', 'tester', 'installer']) {
      await page.locator(`#tab-${id}`).click();
      check(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), `${id} fits ${width}px viewport`);
    }
  }
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.reload();
  await page.evaluate(() => document.documentElement.dataset.theme = 'dark');
  await page.screenshot({ path: '/tmp/updater-dark.png' });
  await page.locator('#tab-installer').click();
  await page.screenshot({ path: '/tmp/updater-installer.png' });
  await page.evaluate(() => document.documentElement.dataset.theme = 'light');
  await page.setViewportSize({ width: 390, height: 1000 });
  await page.screenshot({ path: '/tmp/updater-mobile.png', fullPage: true });
  check(errors.length === 0, `No browser errors: ${errors.join(', ')}`);
} finally { await browser.close(); }

import assert from 'node:assert/strict';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {chromium}=require('playwright');
const root=resolve(import.meta.dirname,'..');
const browser=await chromium.launch({channel:'chrome',headless:true});
const context=await browser.newContext();
await context.addInitScript(()=>{window.EventSource=class{addEventListener(){}};Object.defineProperty(crypto,'randomUUID',{value:undefined,configurable:true});});
const page=await context.newPage(),errors=[],pending=new Map();
page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.dismiss());
let hold=false,expenseCount=0;
const job=id=>({ticket:{id,number:id==='a'?101:102,customer:id==='a'?'Northwind Manufacturing':'Acme Services',company:'Synthetic test customer',ticketType:'Service',status:'In Progress',description:'Network upgrade and workstation deployment',scheduledDate:'2026-09-20',assignedTo:'Test Technician',hoursUsed:2,workLogs:[],usedItems:[],attachments:[],internalMessages:[]},permissions:{invoicing:true,estimates:true,documents:true,communications:true,warranties:true,designCenter:true},invoices:[],estimates:[],payments:[],equipment:[],designs:[],timeline:[],financials:{invoiceTotal:275,paidTotal:100,balance:175},metrics:{laborEntries:[]},expenseCategories:['Material','Other'],employees:['Test Technician'],expenses:[],project:{name:'Site upgrade',notes:'',documentPaths:[],linkedDocuments:[]},availableDocuments:[],workflow:{nextStep:{label:'Complete work',detail:'Record labor and materials'},completed:2,total:5},workflowAudit:{requiredPassed:2,required:5,checks:[]}});
const finance={summary:{outstanding:12000,received:28000,expenses:4200,labor:6500,billsDue:900,netIncome:17300},groups:[{id:'g',name:'Operations',percent:100,balance:1500,allocated:3000,expenses:500,laborCost:1000}],payments:[],billPayments:[],expenses:[],labor:[],employeeNames:['Test Technician'],contracts:[],invoices:[{id:'i',number:101,customer:'Northwind Manufacturing',total:275,balance:175,paid:100}]};
await context.route('**/*',async route=>{
 const url=new URL(route.request().url()),method=route.request().method();assert.equal(url.origin,'http://operations.test');
 if(url.pathname==='/api/job-workspace'){
  const id=url.searchParams.get('jobId');
  if(method==='PATCH'){pending.set('project',route);return;}
  if(id&&hold){pending.set(id,route);return;}
  return route.fulfill({json:id?{job:job(id)}:{jobs:['a','b'].map(id=>({...job(id).ticket,label:`T-${id}`}))}});
 }
 if(url.pathname==='/api/job-expenses'){expenseCount++;pending.set('expense',route);return;}
 if(url.pathname==='/api/finance')return route.fulfill({json:finance});
 if(url.pathname==='/auth-status')return route.fulfill({json:{authenticated:true}});
 if(url.pathname.startsWith('/api/'))return route.fulfill({json:{receipts:[]}});
 if(url.pathname.endsWith('.js'))return route.fulfill({contentType:'text/javascript',body:''});
 try{return route.fulfill({body:await readFile(resolve(root,`.${url.pathname}`)),contentType:({'.html':'text/html','.css':'text/css','.png':'image/png'})[extname(url.pathname)]||'text/plain'});}catch{return route.fulfill({status:404,body:''});}
});
async function take(key){for(let i=0;i<100&&!pending.has(key);i++)await page.waitForTimeout(20);assert.ok(pending.has(key),key);const r=pending.get(key);pending.delete(key);return r;}
async function theme(){await page.addStyleTag({path:resolve(root,'theme.css')});await page.evaluate(()=>document.documentElement.dataset.theme='dark');}
try{
 await page.goto('http://operations.test/job-workspace.html');await page.locator('#detail:not([hidden])').waitFor();await theme();
 hold=true;await page.locator('[data-job-id=a]').click();const a=await take('a');await page.locator('[data-job-id=b]').click();const b=await take('b');await b.fulfill({json:{job:job('b')}});await a.fulfill({json:{job:job('a')}});await page.waitForTimeout(80);assert.match(await page.locator('#job-title').innerText(),/Acme/);hold=false;
 await page.locator('[data-tab=expenses]').click();await page.locator('#job-expense-form input[name=description]').fill('Synthetic expense');
 await page.locator('#job-expense-form').evaluate(f=>{f.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));f.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));});
 const exp=await take('expense');assert.equal(expenseCount,1);await exp.fulfill({status:500,json:{message:'Fixture failure'}});await page.waitForFunction(()=>!document.querySelector('#job-expense-form').inert);assert.equal(await page.locator('[name=description]').inputValue(),'Synthetic expense');
 await page.locator('[data-tab=project]').click();await page.locator('#project-form').dispatchEvent('submit');const project=await take('project');await page.locator('[data-job-id=a]').click();await page.waitForFunction(()=>document.querySelector('#job-title').textContent.includes('Northwind'));await project.fulfill({json:{job:job('b')}});await page.waitForTimeout(80);assert.match(await page.locator('#job-title').innerText(),/Northwind/);
 await page.locator('[data-tab=overview]').click();
 await mkdir(resolve(root,'tmp/operations-ui'),{recursive:true});
 for(const width of [390,900,1440,2560]){await page.setViewportSize({width,height:1000});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),`job overflow ${width}`);await page.screenshot({path:resolve(root,`tmp/operations-ui/jobs-${width}.png`),fullPage:true});}
 console.log('PASS: job response ordering, duplicate expense prevention, failure recovery, project isolation, four viewport widths');
 await page.goto('http://operations.test/finance.html');await page.locator('#payment-target option[value="invoice:i"]').waitFor({state:'attached'});await theme();
 await page.locator('[data-view=payments]').click();await page.locator('#payment-target').selectOption('invoice:i');await page.evaluate(()=>render());assert.equal(await page.locator('#payment-target').inputValue(),'invoice:i');
 await page.evaluate(()=>document.querySelector('#add-group').click());assert.equal(await page.locator('[data-group-name]').count(),2);
 for(const width of [390,900,1440,2560]){await page.setViewportSize({width,height:1000});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),`finance overflow ${width}`);await page.screenshot({path:resolve(root,`tmp/operations-ui/finance-${width}.png`),fullPage:true});}
 assert.deepEqual(errors,[]);console.log('PASS: Finance selections survive refresh, group creation without randomUUID, four viewport widths, no runtime errors');
}finally{await browser.close();}

import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';
import vm from 'node:vm';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {StructuredStore} from '../database.mjs';
const root=mkdtempSync(join(tmpdir(),'huber-billing-test-'));
let store;
try {
  store=new StructuredStore(join(root,'test.sqlite'),root);
  const invoices=join(root,'invoices.txt'),finance=join(root,'finance.json');
  store.write(invoices,'[{"id":"one","status":"Sent"}]');
  store.write(finance,'{"payments":[]}');
  assert.throws(()=>store.withTransaction(()=>{
    store.write(invoices,'[{"id":"one","status":"Paid"}]');
    store.write(finance,'{"payments":[{"amount":100}]}');
    throw new Error('Simulated write failure');
  }),/Simulated/);
  assert.equal(JSON.parse(store.read(invoices))[0].status,'Sent');
  assert.equal(JSON.parse(store.read(finance)).payments.length,0);
  store.withTransaction(()=>{
    store.write(invoices,'[{"id":"one","status":"Paid"}]');
    store.write(finance,'{"payments":[{"amount":100}]}');
  });
  store.close();
  store=new StructuredStore(join(root,'test.sqlite'),root);
  assert.equal(JSON.parse(store.read(invoices))[0].status,'Paid');
  assert.equal(JSON.parse(store.read(finance)).payments[0].amount,100);
  assert.ok(store.integrityCheck());
  const source=readFileSync(new URL('../server.mjs',import.meta.url),'utf8');
  const extract=name=>{const start=source.indexOf(`function ${name}(`);return source.slice(start,source.indexOf('\n}',start)+2);};
  const context=vm.createContext({structuredStore:store});
  vm.runInContext(extract('billingTransaction'),context);
  let sent=false;
  const response={writeHead(){sent=true;},end(){}};
  assert.throws(()=>context.billingTransaction(response,buffered=>{
    store.write(finance,'{"payments":[]}');
    buffered.writeHead(200,{});buffered.end('ok');
    throw new Error('Commit interrupted');
  }),/Commit interrupted/);
  assert.equal(sent,false);
  assert.equal(JSON.parse(store.read(finance)).payments.length,1);
  context.billingTransaction(response,buffered=>{
    store.write(finance,'{"payments":[]}');
    buffered.writeHead(409,{});buffered.end('rejected');
  });
  assert.equal(JSON.parse(store.read(finance)).payments.length,1);
  const corrupt=vm.createContext({existsSync:()=>true,readFileSync:()=>'{invalid',ticketsPath:'tickets',invoicesPath:'invoices',financePath:'finance',bankPath:'bank'});
  vm.runInContext(['readTickets','readInvoices','readFinance','readBankData'].map(extract).join('\n'),corrupt);
  for(const name of ['readTickets','readInvoices','readFinance','readBankData']) assert.throws(()=>corrupt[name](),/Cannot read/);
  console.log('PASS: multi-record rollback, cache invalidation, commit, reopen and SQLite integrity.');
  console.log('PASS: failed transaction never sends success; rejected writes roll back; corrupt billing stores fail closed.');
}finally{store?.close();rmSync(root,{recursive:true,force:true});}

# Direct LAN routing

The dashboard can test a local server address at login and use Cloudflare when
the local address is unavailable.

Add these values to the Ubuntu website `.env` file:

```env
PUBLIC_BASE_URL=https://www.huberitps.com
LAN_BASE_URL=https://lan.huberitps.com
LAN_ROUTE_TIMEOUT_MS=1200
```

`LAN_BASE_URL` must reach the same `server.mjs` instance and expose port 3000
through a local HTTPS reverse proxy. Configure local DNS on the router so
`lan.huberitps.com` resolves to the Ubuntu server's private IP only while on the
company network. The certificate must be trusted by employee devices.

After changing `.env`, restart `server.mjs`.

## Plain IP addresses

The installed desktop dashboard can use a private HTTP address such as
`http://192.168.1.50:3000`. Set `LAN_BASE_URL` to that address on the server, or
launch a custom desktop build with `HUBER_DASHBOARD_LAN_URL` set to it. Normal browsers and PWAs opened from an HTTPS site
will block that downgrade, so they need the HTTPS LAN hostname above. Split DNS
for `www.huberitps.com` is another option and requires no redirect at all.

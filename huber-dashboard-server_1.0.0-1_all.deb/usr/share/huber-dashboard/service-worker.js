const CACHE_NAME = "huber-apps-v31";
const APP_SHELL = [
  "/login.html",
  "/servicelogin.html",
  "/service-dashboard.html",
  "/account.html?return=service",
  "/service-app.webmanifest",
  "/dashboard-app.webmanifest",
  "/theme.css",
  "/theme.js",
  "/professional-ui.js",
  "/professional-ui.css",
  "/motion.js",
  "/network-route.js",
  "/modal-dismiss.js",
  "/assets/logo.png",
  "/assets/service-app-192.png",
  "/assets/service-app-512.png"
];
const SHELL_PATHS = new Set(APP_SHELL.map((path) => new URL(path, self.location.origin).pathname));

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => Promise.all(APP_SHELL.map(async (path) => {
    const response = await fetch(path);
    // Protected shells may redirect to login during an unauthenticated install.
    if (response.ok && !response.redirected) await cache.put(path, response);
  }))));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => /^huber-apps-v\d+$/.test(key) && key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== self.location.origin || !SHELL_PATHS.has(url.pathname)) return;
  const cacheKey = APP_SHELL.find((path) => new URL(path, self.location.origin).pathname === url.pathname);
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    try {
      const response = await fetch(event.request);
      if (response.ok && !response.redirected) {
        event.waitUntil(cache.put(cacheKey, response.clone()).catch(() => {}));
      }
      return response;
    } catch {
      return await cache.match(cacheKey) || Response.error();
    }
  })());
});

self.addEventListener("push", (event) => {
  let data = {};
  try { data = event.data?.json() || {}; } catch {}
  event.waitUntil(self.registration.showNotification(data.title || "Service ticket update", {
    body: data.body || "Open the employee service app for details.",
    icon: "/assets/service-app-192.png",
    badge: "/assets/service-app-192.png",
    tag: data.ticketId ? `ticket-${data.ticketId}` : "service-update",
    data: { url: data.url || "/service-dashboard.html" }
  }));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  let target = new URL("/service-dashboard.html", self.location.origin);
  try {
    const requested = new URL(event.notification.data?.url || target.href, self.location.origin);
    if (requested.origin === self.location.origin) target = requested;
  } catch {}
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(async (clients) => {
      const existing = clients.find((client) => new URL(client.url).origin === self.location.origin);
      if (existing) {
        const navigated = await existing.navigate(target.href);
        return (navigated || existing).focus();
      }
      return self.clients.openWindow(target.href);
    })
  );
});

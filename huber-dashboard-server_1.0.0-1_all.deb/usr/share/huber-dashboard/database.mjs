import { DatabaseSync } from "node:sqlite";
import { copyFileSync, existsSync, readFileSync } from "node:fs";
import { join, relative } from "node:path";

export class StructuredStore {
  constructor(databasePath, rootPath) {
    this.databasePath = databasePath;
    this.rootPath = rootPath;
    this.database = new DatabaseSync(databasePath);
    this.readCache = new Map();
    this.dataVersion = null;
    this.dataVersionStatement = this.database.prepare("PRAGMA data_version");
    this.database.exec(`
      PRAGMA journal_mode = WAL;
      PRAGMA synchronous = FULL;
      PRAGMA foreign_keys = ON;
      PRAGMA busy_timeout = 5000;

      CREATE TABLE IF NOT EXISTS app_store (
        store_key TEXT PRIMARY KEY,
        content TEXT NOT NULL,
        updated_at TEXT NOT NULL
      ) STRICT;

      CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        applied_at TEXT NOT NULL,
        description TEXT NOT NULL
      ) STRICT;

      CREATE TABLE IF NOT EXISTS store_collections (
        store_key TEXT PRIMARY KEY,
        format TEXT NOT NULL CHECK (format IN ('json-array', 'json-object', 'text-lines')),
        trailing_newline INTEGER NOT NULL DEFAULT 0 CHECK (trailing_newline IN (0, 1)),
        updated_at TEXT NOT NULL
      ) STRICT;

      CREATE TABLE IF NOT EXISTS store_records (
        store_key TEXT NOT NULL,
        ordinal INTEGER NOT NULL,
        record_key TEXT NOT NULL,
        content TEXT NOT NULL,
        PRIMARY KEY (store_key, ordinal),
        FOREIGN KEY (store_key) REFERENCES store_collections(store_key) ON DELETE CASCADE
      ) STRICT;

      CREATE INDEX IF NOT EXISTS store_records_lookup
      ON store_records(store_key, record_key);
    `);
    this.readStatement = this.database.prepare(
      "SELECT content FROM app_store WHERE store_key = ?"
    );
    this.hasStatement = this.database.prepare(
      "SELECT 1 AS found FROM app_store WHERE store_key = ?"
    );
    this.infoStatement = this.database.prepare(
      "SELECT length(content) AS size, updated_at AS updatedAt FROM app_store WHERE store_key = ?"
    );
    this.writeStatement = this.database.prepare(`
      INSERT INTO app_store (store_key, content, updated_at)
      VALUES (?, ?, ?)
      ON CONFLICT(store_key) DO UPDATE SET
        content = excluded.content,
        updated_at = excluded.updated_at
    `);
    this.deleteStatement = this.database.prepare(
      "DELETE FROM app_store WHERE store_key = ?"
    );
    this.collectionStatement = this.database.prepare(`
      SELECT format, trailing_newline AS trailingNewline, updated_at AS updatedAt
      FROM store_collections WHERE store_key = ?
    `);
    this.collectionRecordsStatement = this.database.prepare(`
      SELECT ordinal, record_key AS recordKey, content
      FROM store_records WHERE store_key = ? ORDER BY ordinal
    `);
    this.collectionInfoStatement = this.database.prepare(`
      SELECT COALESCE(SUM(length(r.content)), 0) AS size, c.updated_at AS updatedAt,
             COUNT(r.ordinal) AS records, c.format AS format
      FROM store_collections c
      LEFT JOIN store_records r ON r.store_key = c.store_key
      WHERE c.store_key = ?
      GROUP BY c.store_key
    `);
    this.collectionUpsertStatement = this.database.prepare(`
      INSERT INTO store_collections (store_key, format, trailing_newline, updated_at)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(store_key) DO UPDATE SET
        format = excluded.format,
        trailing_newline = excluded.trailing_newline,
        updated_at = excluded.updated_at
    `);
    this.recordInsertStatement = this.database.prepare(`
      INSERT INTO store_records (store_key, ordinal, record_key, content)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(store_key, ordinal) DO UPDATE SET
        record_key = excluded.record_key,
        content = excluded.content
      WHERE record_key <> excluded.record_key OR content <> excluded.content
    `);
    this.recordsTrimStatement = this.database.prepare(
      "DELETE FROM store_records WHERE store_key = ? AND ordinal >= ?"
    );
    this.collectionDeleteStatement = this.database.prepare(
      "DELETE FROM store_collections WHERE store_key = ?"
    );
    this.allBlobStoresStatement = this.database.prepare(
      "SELECT store_key AS storeKey, content FROM app_store ORDER BY store_key"
    );
    this.migratedStores = this.migrateBlobStores();
  }

  key(filePath) {
    return relative(this.rootPath, filePath).replaceAll("\\", "/");
  }

  has(filePath) {
    const key = this.key(filePath);
    return Boolean(this.collectionStatement.get(key) || this.hasStatement.get(key));
  }

  read(filePath) {
    // Timestamps can collide; SQLite tracks commits from other connections.
    const dataVersion = this.dataVersionStatement.get().data_version;
    if (dataVersion !== this.dataVersion) {
      this.readCache.clear();
      this.dataVersion = dataVersion;
    }
    const key = this.key(filePath);
    const collection = this.collectionStatement.get(key);
    const updatedAt = collection?.updatedAt || this.infoStatement.get(key)?.updatedAt;
    const cached = this.readCache.get(key);
    if (cached && cached.updatedAt === updatedAt) return cached.content;
    if (!collection) {
      const content = this.readStatement.get(key)?.content;
      if (content !== undefined) this.readCache.set(key, { content, updatedAt });
      return content;
    }
    const records = this.collectionRecordsStatement.all(key);
    let content;
    if (collection.format === "json-array") {
      content = JSON.stringify(records.map((record) => JSON.parse(record.content)), null, 2);
    } else if (collection.format === "json-object") {
      content = JSON.stringify(Object.fromEntries(records.map((record) =>
        [record.recordKey, JSON.parse(record.content)])), null, 2);
    } else {
      content = records.map((record) => record.content).join("\n");
      content += collection.trailingNewline && records.length ? "\n" : "";
    }
    this.readCache.set(key, { content, updatedAt });
    return content;
  }

  info(filePath) {
    const key = this.key(filePath);
    return this.collectionInfoStatement.get(key) || this.infoStatement.get(key);
  }

  write(filePath, content) {
    const key = this.key(filePath);
    const source = String(content);
    const collection = this.parseCollection(key, source);
    const updatedAt = new Date().toISOString();
    if (!collection) {
      this.withSavepoint(() => {
        this.collectionDeleteStatement.run(key);
        this.writeStatement.run(key, source, updatedAt);
      });
      this.readCache.set(key, { content: source, updatedAt });
      return;
    }
    this.withSavepoint(() => {
      this.deleteStatement.run(key);
      this.collectionUpsertStatement.run(
        key,
        collection.format,
        collection.trailingNewline ? 1 : 0,
        updatedAt
      );
      collection.records.forEach((record, ordinal) => {
        this.recordInsertStatement.run(key, ordinal, record.key, record.content);
      });
      this.recordsTrimStatement.run(key, collection.records.length);
    });
    this.readCache.set(key, { content: source, updatedAt });
  }

  delete(filePath) {
    const key = this.key(filePath);
    this.withSavepoint(() => {
      this.collectionDeleteStatement.run(key);
      this.deleteStatement.run(key);
    });
    this.readCache.delete(key);
  }

  parseCollection(storeKey, source) {
    const trimmed = source.trim();
    if (trimmed) {
      try {
        const value = JSON.parse(trimmed);
        if (Array.isArray(value)) {
          return {
            format: "json-array",
            trailingNewline: false,
            records: value.map((record, index) => ({
              key: this.recordKey(record, index),
              content: JSON.stringify(record)
            }))
          };
        }
        if (value && typeof value === "object") {
          return {
            format: "json-object",
            trailingNewline: false,
            records: Object.entries(value).map(([recordKey, record]) => ({
              key: recordKey,
              content: JSON.stringify(record)
            }))
          };
        }
      } catch {
        // Non-JSON structured stores such as users.txt are handled below.
      }
    }
    if (storeKey.endsWith(".txt")) {
      const trailingNewline = /\r?\n$/.test(source);
      const lines = source.split(/\r?\n/);
      if (trailingNewline) lines.pop();
      return {
        format: "text-lines",
        trailingNewline,
        records: lines.map((line, index) => ({
          key: line.split("|", 1)[0] || String(index),
          content: line
        }))
      };
    }
    return null;
  }

  recordKey(record, index) {
    if (record && typeof record === "object" && !Array.isArray(record)) {
      for (const field of ["id", "username", "uid", "tokenHash", "path", "key", "name"]) {
        const value = record[field];
        if (["string", "number"].includes(typeof value) && String(value)) return String(value);
      }
    }
    return String(index);
  }

  withSavepoint(callback) {
    this.database.exec("SAVEPOINT structured_store_write");
    try {
      const result = callback();
      this.database.exec("RELEASE SAVEPOINT structured_store_write");
      return result;
    } catch (error) {
      this.database.exec("ROLLBACK TO SAVEPOINT structured_store_write");
      this.database.exec("RELEASE SAVEPOINT structured_store_write");
      this.readCache.clear();
      throw error;
    }
  }

  withTransaction(callback) {
    // Acquire the writer lock before reading balances or allocating numbers.
    this.database.exec("BEGIN IMMEDIATE");
    this.readCache.clear();
    try {
      const result = callback();
      if (result?.then) throw new Error("Database transactions must be synchronous.");
      this.database.exec("COMMIT");
      return result;
    } catch (error) {
      this.database.exec("ROLLBACK");
      this.readCache.clear();
      throw error;
    }
  }

  migrateBlobStores() {
    const legacyStores = this.allBlobStoresStatement.all();
    const migrationApplied = Boolean(this.database.prepare(
      "SELECT 1 AS found FROM schema_migrations WHERE version = 2"
    ).get());
    if (legacyStores.length && !migrationApplied) {
      const backupPath = `${this.databasePath}.pre-record-migration`;
      if (!existsSync(backupPath)) {
        this.database.exec("PRAGMA wal_checkpoint(TRUNCATE)");
        copyFileSync(this.databasePath, backupPath);
      }
    }
    let migrated = 0;
    for (const store of legacyStores) {
      if (!this.parseCollection(store.storeKey, store.content)) continue;
      this.write(join(this.rootPath, store.storeKey), store.content);
      migrated += 1;
    }
    this.database.prepare(`
      INSERT OR IGNORE INTO schema_migrations (version, applied_at, description)
      VALUES (2, ?, ?)
    `).run(new Date().toISOString(), "Split structured stores into individually indexed SQLite records");
    return migrated;
  }

  importLegacy(filePaths) {
    const pending = filePaths.filter((filePath) =>
      !this.has(filePath) && existsSync(filePath)
    );
    if (!pending.length) return 0;

    this.database.exec("BEGIN IMMEDIATE");
    try {
      for (const filePath of pending) {
        this.write(filePath, readFileSync(filePath, "utf8"));
      }
      this.database.prepare(`
        INSERT OR IGNORE INTO schema_migrations (version, applied_at, description)
        VALUES (1, ?, ?)
      `).run(new Date().toISOString(), "Imported legacy JSON and text stores");
      this.database.exec("COMMIT");
      return pending.length;
    } catch (error) {
      this.database.exec("ROLLBACK");
      this.readCache.clear();
      throw error;
    }
  }

  checkpoint() {
    this.database.exec("PRAGMA wal_checkpoint(TRUNCATE)");
  }

  integrityCheck() {
    return this.database.prepare("PRAGMA integrity_check").all()
      .every((row) => Object.values(row).includes("ok"));
  }

  stats() {
    const collections = this.database.prepare("SELECT COUNT(*) AS count FROM store_collections").get()?.count || 0;
    const records = this.database.prepare("SELECT COUNT(*) AS count FROM store_records").get()?.count || 0;
    const legacyBlobs = this.database.prepare("SELECT COUNT(*) AS count FROM app_store").get()?.count || 0;
    return { collections: Number(collections), records: Number(records), legacyBlobs: Number(legacyBlobs) };
  }

  close() {
    this.readCache.clear();
    this.database.close();
  }
}

# Dashboard PWA Toolkit

The project is staying as a PWA. Native Mac and iOS wrapper work has been removed from the active setup.

## 1. Browser Testing

Run a quick live-site PWA smoke test:

```bash
npm run test:pwa
```

If `npm` is not on the Mac path, use:

```bash
/Users/christian/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node tools/pwa-smoke-test.mjs
```

To test a local or staging server:

```bash
PWA_BASE_URL=http://localhost:3000 npm run test:pwa
```

The smoke test checks the public site, login pages, PWA manifests, and service worker.

## 2. Spreadsheet Exports

Useful CSV exports already in the dashboard:

- Payroll export for Zoho Payroll from the Payroll dashboard.
- Tax summary CSV from Tax Center.
- Reports page print/export workflow for service tickets and employee hours.

Good next spreadsheet upgrades:

- Inventory CSV export.
- Catalog CSV import/export.
- Service ticket CSV report.
- Employee hours weekly CSV grouped by employee.

## 3. PDF And Documents

Useful PDF output already in the dashboard:

- Estimate/quote PDF.
- Service ticket completion report PDF.
- Tax summary PDF.
- Pay stub PDF.
- Receipt/document upload and inline PDF viewing.

Good next PDF upgrades:

- Invoice PDF download button instead of print-only.
- Customer service history PDF.
- Weekly operations PDF summary.
- Employee timecard PDF.

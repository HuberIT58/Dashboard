import {
  chmodSync,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync
} from "node:fs";
import { basename, dirname, join, resolve } from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";

const root = fileURLToPath(new URL(".", import.meta.url));
const dataPath = join(root, ".data");
const statusPath = join(dataPath, "last-backup.json");
const backupPath = resolve(process.env.BACKUP_PATH || "/var/backups/huber-it");
const documentsPath = resolve(process.env.DOCUMENTS_PATH || join(dataPath, "documents"));
const retentionWeeks = Math.max(1, Number(process.env.BACKUP_RETENTION_WEEKS) || 12);
const prefix = "huber-it-backup-";
const databasePath = join(dataPath, "huber-it.sqlite");

mkdirSync(dataPath, { recursive: true, mode: 0o700 });
mkdirSync(backupPath, { recursive: true, mode: 0o700 });

const startedAt = new Date();
const stamp = startedAt.toISOString().replace(/[:.]/g, "-");
const archiveName = `${prefix}${stamp}.tar.gz`;
const temporaryPath = join(backupPath, `.${archiveName}.tmp`);
const archivePath = join(backupPath, archiveName);

try {
  if (existsSync(databasePath)) {
    const database = new DatabaseSync(databasePath);
    try {
      database.exec("PRAGMA wal_checkpoint(TRUNCATE)");
    } finally {
      database.close();
    }
  }
  const rootItems = [
    ".data",
    ".env",
    "server.mjs",
    "package.json",
    "package-lock.json",
    "pnpm-lock.yaml",
    ...readdirSync(root).filter((name) => name.endsWith(".txt"))
  ].filter((name, index, items) =>
    items.indexOf(name) === index && existsSync(join(root, name))
  );

  const tarArguments = ["-czf", temporaryPath, "-C", root, ...rootItems];
  const defaultDocumentsPath = resolve(join(dataPath, "documents"));
  if (documentsPath !== defaultDocumentsPath && existsSync(documentsPath)) {
    tarArguments.push("-C", dirname(documentsPath), basename(documentsPath));
  }

  const result = spawnSync("tar", tarArguments, { encoding: "utf8" });
  if (result.status !== 0) {
    throw new Error(result.stderr.trim() || `tar exited with status ${result.status}`);
  }

  renameSync(temporaryPath, archivePath);
  chmodSync(archivePath, 0o600);

  const cutoff = Date.now() - retentionWeeks * 7 * 24 * 60 * 60 * 1000;
  let removed = 0;
  for (const name of readdirSync(backupPath)) {
    if (!name.startsWith(prefix) || !name.endsWith(".tar.gz")) continue;
    const filePath = join(backupPath, name);
    if (filePath === archivePath || statSync(filePath).mtimeMs >= cutoff) continue;
    rmSync(filePath);
    removed += 1;
  }

  const status = {
    configured: true,
    lastSuccess: new Date().toISOString(),
    archive: archiveName,
    size: statSync(archivePath).size,
    backupPath,
    retentionWeeks,
    removed,
    message: "Weekly backup completed successfully."
  };
  writeFileSync(statusPath, JSON.stringify(status, null, 2), { mode: 0o600 });
  console.log(`Backup completed: ${archivePath}`);
} catch (error) {
  if (existsSync(temporaryPath)) rmSync(temporaryPath, { force: true });
  let previousSuccess = "";
  if (existsSync(statusPath)) {
    try {
      previousSuccess = JSON.parse(readFileSync(statusPath, "utf8")).lastSuccess || "";
    } catch {
      previousSuccess = "";
    }
  }
  writeFileSync(statusPath, JSON.stringify({
    configured: true,
    lastSuccess: previousSuccess,
    lastAttempt: new Date().toISOString(),
    backupPath,
    retentionWeeks,
    message: `Backup failed: ${error.message}`
  }, null, 2), { mode: 0o600 });
  console.error(error);
  process.exitCode = 1;
}

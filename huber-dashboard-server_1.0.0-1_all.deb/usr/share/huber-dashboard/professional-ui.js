(function () {
  "use strict";
  if (window.HuberProfessional) return;
  if (!["service-tickets.html", "customers.html", "employee-records.html", "inventory.html", "dispatch.html", "finance.html", "invoices.html"].includes(location.pathname.split("/").pop())) return;
  const dirty = new Set();
  let pending = 0, preferences = {}, preferenceKey = "", status, timer;
  const persist = () => { if (preferenceKey) try { localStorage.setItem(preferenceKey, JSON.stringify(preferences)); } catch {} };
  function notify(message, failure = false) {
    if (!status) return;
    (document.querySelector("dialog[open]") || document.body).append(status);
    clearTimeout(timer); status.hidden = false; status.dataset.failure = String(failure); status.textContent = message;
    if (!failure && !pending) timer = setTimeout(() => { status.hidden = true; }, 4500);
  }
  function canLeave() {
    if (pending) { notify("A save is in progress. Please wait.", true); return false; }
    return !dirty.size || confirm("Discard unsaved changes?");
  }
  window.HuberProfessional = { canLeave, notify };
  const originalFetch = window.fetch.bind(window);
  const writes = new Set(["/api/tickets", "/api/customers", "/api/employees", "/api/inventory", "/api/dispatch"]);
  // Observe writes without retrying them or intercepting authentication requests.
  window.fetch = async (input, options) => {
    const method = String(options?.method || (input instanceof Request ? input.method : "GET")).toUpperCase();
    const url = new URL(input instanceof Request ? input.url : input, location.href);
    if (url.origin !== location.origin || !writes.has(url.pathname) || !["POST", "PUT", "PATCH", "DELETE"].includes(method)) return originalFetch(input, options);
    pending++; notify("Saving to server...");
    let message = "Save not confirmed. Check your connection and the server record before retrying.", failure = true;
    try {
      const response = await originalFetch(input, options);
      const body = await response.clone().json().catch(() => null);
      failure = !(response.ok && body?.ok === true);
      message = failure ? (body?.message || message) : (method === "DELETE" ? "Deleted from server." : "Saved to server.");
      return response;
    } finally { pending--; notify(pending ? `Saving ${pending} pending requests...` : message, failure); }
  };
  function start() {
    const link = document.createElement("link"); link.rel = "stylesheet"; link.href = "/professional-ui.css"; document.head.append(link);
    document.body.classList.add("professional-workspace");
    status = document.createElement("div"); status.className = "professional-save-status"; status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite"); status.hidden = true; document.body.append(status);
    document.querySelectorAll("dialog").forEach(dialog => {
      for (const type of ["input", "change"]) dialog.addEventListener(type, event => { if (event.target.closest("form")) dirty.add(dialog); });
      dialog.addEventListener("close", () => { dirty.delete(dialog); if (dialog.contains(status)) document.body.append(status); });
      const blockClose = () => pending || (dirty.has(dialog) && !confirm("Discard unsaved changes?"));
      dialog.addEventListener("cancel", event => { if (blockClose()) event.preventDefault(); });
      dialog.addEventListener("click", event => {
        const button = event.target.closest("button");
        if (button && /close|cancel/i.test(`${button.id} ${button.className} ${button.getAttribute("aria-label") || ""} ${button.textContent}`) && blockClose()) { event.preventDefault(); event.stopImmediatePropagation(); }
      }, true);
    });
    window.addEventListener("beforeunload", event => { if (dirty.size || pending) { event.preventDefault(); event.returnValue = ""; } });
    document.addEventListener("keydown", event => {
      if (!(event.metaKey || event.ctrlKey) || event.key.toLowerCase() !== "s") return;
      const form = document.querySelector("dialog[open] form");
      if (!form) return;
      event.preventDefault(); if (!pending && form.getAttribute("aria-busy") !== "true") form.requestSubmit();
    });
    originalFetch("/auth-status", { cache: "no-store" }).then(r => r.ok ? r.json() : null).then(user => {
      if (!user?.authenticated || !user.username) return;
      preferenceKey = `huber-workspace-v1:${user.username}:${location.pathname}`;
      try { preferences = JSON.parse(localStorage.getItem(preferenceKey)) || {}; } catch {}
      if (typeof preferences !== "object" || Array.isArray(preferences)) preferences = {};
      installTables();
      document.querySelectorAll('main .toolbar input[type="search"], main .toolbar input.search, main .toolbar select, main .filters select').forEach(control => {
        if (!control.id) return;
        const key = `filter:${control.id}`, type = control.tagName === "SELECT" ? "change" : "input";
        if (typeof preferences[key] === "string" && (!control.options || [...control.options].some(o => o.value === preferences[key]))) { control.value = preferences[key]; control.dispatchEvent(new Event(type, { bubbles: true })); }
        control.addEventListener(type, () => { preferences[key] = control.value; persist(); });
      });
    }).catch(() => {});
  }
  function installTables() {
    document.querySelectorAll("main table").forEach((table, tableIndex) => {
      const headers = [...(table.tHead?.rows[0]?.cells || [])];
      if (headers.length < 2 || headers.some(h => h.colSpan > 1)) return;
      const key = `table:${table.id || tableIndex}`;
      const settings = preferences[key] && typeof preferences[key] === "object" ? preferences[key] : {};
      preferences[key] = settings; table.classList.add("professional-table");
      const appSortButtons = [...table.querySelectorAll("thead button[data-sort]")];
      if (settings.appSort) {
        const button = appSortButtons.find(b => b.dataset.sort === settings.appSort.key);
        if (button) {
          if (button.dataset.direction !== settings.appSort.direction) button.click();
          if (button.dataset.direction !== settings.appSort.direction) button.click();
        }
      }
      for (const button of appSortButtons) button.addEventListener("click", () => queueMicrotask(() => {
        settings.appSort = { key: button.dataset.sort, direction: button.dataset.direction }; persist();
      }));
      const details = document.createElement("details"); details.className = "professional-table-options";
      const summary = document.createElement("summary"); summary.textContent = "Table options"; details.append(summary);
      const density = document.createElement("select"); density.setAttribute("aria-label", "Table density");
      for (const value of ["Comfortable", "Compact"]) { const option = document.createElement("option"); option.value = value; option.textContent = value; density.append(option); }
      density.value = settings.density === "Compact" ? "Compact" : "Comfortable";
      const applyDensity = () => { table.dataset.density = density.value; settings.density = density.value; persist(); };
      density.addEventListener("change", applyDensity); applyDensity(); details.append(density);
      headers.forEach((header, index) => {
        const label = document.createElement("label"); label.textContent = header.textContent.trim();
        const range = document.createElement("input"); range.type = "range"; range.min = "90"; range.max = "500"; range.step = "10"; range.setAttribute("aria-label", `${label.textContent} column width`);
        range.value = String(Math.min(500, Math.max(90, Number(settings[index]) || header.getBoundingClientRect().width || 160)));
        const applyWidth = () => { header.style.width = `${range.value}px`; header.style.minWidth = `${range.value}px`; settings[index] = Number(range.value); persist(); };
        range.addEventListener("input", applyWidth); if (settings[index]) applyWidth(); label.append(range); details.append(label);
        if (header.querySelector("button, input, select") || /actions/i.test(label.textContent)) return;
        const button = document.createElement("button"); button.type = "button"; button.textContent = header.textContent.trim(); button.className = "professional-sort"; header.replaceChildren(button);
        button.addEventListener("click", () => { settings.sort = { index, descending: settings.sort?.index === index ? !settings.sort.descending : false }; sortRows(); persist(); });
      });
      function sortRows() {
        if (!settings.sort || !table.tBodies[0]) return;
        const { index, descending } = settings.sort;
        if (!Number.isInteger(index) || !headers[index]?.querySelector(".professional-sort")) return;
        const rows = [...table.tBodies[0].rows];
        if (rows.some(r => r.cells.length !== headers.length || [...r.cells].some(c => c.colSpan > 1))) return;
        const sorted = [...rows].sort((a, b) => a.cells[index].textContent.trim().localeCompare(b.cells[index].textContent.trim(), undefined, { numeric: true }) * (descending ? -1 : 1));
        headers.forEach((h, i) => i === index ? h.setAttribute("aria-sort", descending ? "descending" : "ascending") : h.removeAttribute("aria-sort"));
        if (sorted.some((row, i) => row !== rows[i])) table.tBodies[0].append(...sorted);
      }
      sortRows(); if (table.tBodies[0]) new MutationObserver(sortRows).observe(table.tBodies[0], { childList: true });
      const reset = document.createElement("button"); reset.type = "button"; reset.textContent = "Reset table";
      reset.addEventListener("click", () => { if (canLeave()) { delete preferences[key]; persist(); location.reload(); } }); details.append(reset);
      (table.closest(".table-wrap") || table).before(details);
    });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true }); else start();
})();

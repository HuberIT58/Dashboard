# Dashboard Audit

Date: 2026-09-07

## Scope

GPT-6 Astra reviewed the main dashboard backend and shared dashboard/login UI in two delegated passes. A third integration pass reviewed customer, finance and service-ticket workflows and verified the combined changes.

All 59 top-level HTML pages (60 inline scripts) and all eight top-level JavaScript files passed syntax checks. This is broad static coverage, not a claim that every workflow in every app has been exercised. Behavioral tests use synthetic records and intercepted browser requests, or temporary SQLite fixtures. The production server, actual accounts, business records, email and external integrations were not accessed.

The separate Ubuntu desktop shell, network tester and standalone desktop application projects were not changed. No release archives, installers, product version changes or published updates were created. The service-worker cache revision changed so deployed browsers can pick up the corrected cached shell.

## Fixed

### Access and Data Integrity

- Static-file authorization now checks the decoded, normalized path used for disk access. Encoded paths cannot bypass protected-page checks or expose the private data directory.
- Required two-factor enrollment can load its account setup page instead of redirecting back to itself.
- Existing sessions refresh user permissions and reject deleted users.
- Concurrent first-account setup cannot replace an owner created by another request.
- Account edits, avatar uploads, time-clock actions, customer changes and Document Maker saves/deletes re-read collections after asynchronous request parsing, preserving other requests' committed changes.
- JSON body decoding preserves multibyte UTF-8 across chunks and rejects aborted requests.
- SQLite read caches invalidate after external commits and failed transactions.

### Dashboard and Shared UI

- Login coalesces repeated submissions, focuses the two-factor field and avoids duplicate LAN-route probes.
- Routing configuration requests time out rather than indefinitely blocking login.
- Search ignores superseded responses and rejects unsafe or attribute-breaking result links.
- The companion search modal contains keyboard focus, makes the background inert and restores focus when closed.
- Backdrop dismissal respects the actual active dialog rather than its order in the document.
- Theme checks batch changed subtrees instead of repeatedly scanning the whole page; blocked browser storage no longer prevents initialization.
- Shared metric animations batch changes and respect changes to reduced-motion preferences.
- Dashboard/search and service login were checked at 320, 390 and 1440 pixels; service login permits browser zoom.
- Record Payment opens the finance Payments view.
- Offline shell caching includes routing/dialog scripts, uses stable keys across query versions, avoids caching login redirects as protected pages and preserves unrelated caches. API responses remain outside this cache.

### Feature Apps

- Customer history and live refreshes cannot replace the active customer with a late response from a previously opened record.
- Customer identifiers are escaped for HTML attributes as well as text.
- Finance payment, expense and allocation forms prevent repeated submissions while saving and restore controls after failures.
- Finance date defaults use the user's local date instead of UTC.
- Saving an invoice-linked payment re-enables the description field for the next custom payment.
- Receipt dialogs show a loading state immediately, isolate responses by record, and report upload/delete failures while restoring controls.
- Ticket saves update the local list only after persistence succeeds. Retries retain the same ticket ID, repeated submissions are blocked, and save failures leave the form usable.
- Live ticket refreshes do not reopen a detail dialog the user closed or replace another ticket's details; refresh failures are handled.

## Verification

- `tools/dashboard-backend-regression.mjs`: 21 isolated backend regression tests.
- `tools/dashboard-ui-audit.mjs`: 14 shared-UI, routing and offline-cache checks, including headless Chrome interactions and viewport assertions.
- `tools/dashboard-app-audit.mjs`: all-page/all-script syntax scan plus customer, finance, receipt and ticket regression workflows in headless Chrome. No uncaught page errors in those workflows.

Run with a supported Node.js version. Browser suites require Playwright and a browser installation; Playwright may also be resolved with `NODE_PATH` or, for the feature-app suite, `PLAYWRIGHT_MODULE`.

```sh
node --test tools/dashboard-backend-regression.mjs
CHROME_CHANNEL=chrome node tools/dashboard-ui-audit.mjs
BROWSER_CHANNEL=chrome node tools/dashboard-app-audit.mjs
```

## Remaining Work

- Main-dashboard session verification still retries at a fixed interval without a request timeout. A stalled connection needs explicit retry/offline feedback and backoff.
- Main-dashboard logout still needs a clear failure state if the server cannot confirm logout. It should not falsely claim that a remote session was revoked.
- The requested login intro remains intact, including its minimum display time. Shortening it is an optional product decision, not part of this audit.
- Before deployment, run a staging acceptance pass with representative permissions, multi-user edits, actual LAN/public routing and the desktop wrappers. The isolated tests do not validate real Cloudflare, mail, push, device authentication or production integration behavior.

These focused fixes do not replace an exhaustive security audit or production end-to-end testing.

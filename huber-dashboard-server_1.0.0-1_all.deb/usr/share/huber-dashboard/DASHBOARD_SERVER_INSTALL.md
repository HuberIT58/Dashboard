# Dashboard Server for Ubuntu

Use the `huber-dashboard-server_1.0.0-1_all.deb` file in `Updates` on a new
Ubuntu amd64 or arm64 server. Transfer that one file to the server, then run:

```bash
sudo apt install ./huber-dashboard-server_1.0.0-1_all.deb
```

The installer needs Internet access once to download and verify Node.js 24 and
install the dashboard's npm dependencies. It creates the `huber-dashboard`
system user and service, listens on port 3000, and starts at boot. The Node.js
runtime is private to this app; the system Node.js installation is untouched.

Open `http://SERVER-IP:3000/login.html` from a browser on the same network.
The first visit lets you create the administrator account. Use the username
`Huber58` so owner-only features, including Website Updater, are available.
Choose a unique password of at least 12 characters. The installer sets
the detected LAN address in `/usr/share/huber-dashboard/.env`; review this file
if your server has multiple network interfaces. After changing it, run
`sudo systemctl restart huber-dashboard`.

Check the service with `systemctl status huber-dashboard` or view logs with
`journalctl -u huber-dashboard -n 100 --no-pager`. If Ubuntu's firewall is
enabled, allow TCP port 3000 on the intended private network. Configure HTTPS
before publishing the dashboard to the Internet.

Application files live in `/usr/share/huber-dashboard`. Its `.env`, `.data`
(including the SQLite database), and user records survive package upgrades.
Existing installations can still use the in-dashboard Website Updater; they do
not need this server installer. To rebuild the installer from the current site,
double-click `Create Dashboard Server Installer.command` on the Mac.

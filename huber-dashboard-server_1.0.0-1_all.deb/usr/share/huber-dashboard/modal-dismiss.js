(() => {
  function isOutside(element, event) {
    const rect = element.getBoundingClientRect();
    return event.clientX < rect.left
      || event.clientX > rect.right
      || event.clientY < rect.top
      || event.clientY > rect.bottom;
  }

  function dismissDialog(dialog) {
    const cancelEvent = new Event("cancel", { cancelable: true });
    if (dialog.dispatchEvent(cancelEvent) && dialog.open) dialog.close("cancel");
  }

  document.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || event.isPrimary === false) return;
    // A modal backdrop targets its owning dialog, regardless of DOM order.
    const dialog = event.target instanceof Element && event.target.matches("dialog[open]")
      ? event.target : null;
    if (!dialog || !isOutside(dialog, event)) return;

    event.preventDefault();
    dismissDialog(dialog);
  }, true);
})();

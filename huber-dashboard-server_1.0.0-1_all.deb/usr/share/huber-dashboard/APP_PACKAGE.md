# Dashboard App Package

Dashboard apps are installed from the owner-only App Store at `/install.html`.

## Package structure

```text
example-app.zip
├── app.json
├── index.html
├── app.css
├── app.js
└── icon.png
```

`app.json` must be at the ZIP root or inside one top-level folder:

```json
{
  "id": "example-app",
  "name": "Example App",
  "version": "1.0.0",
  "description": "A company dashboard tool.",
  "entry": "index.html",
  "icon": "icon.png",
  "access": "all",
  "permission": ""
}
```

## Manifest fields

- `id`: Required unique ID using lowercase letters, numbers, and hyphens.
- `name`: Required dashboard tile and app name.
- `version`: Required package version, such as `1.0.0`.
- `description`: Optional dashboard tile description.
- `entry`: Required HTML entry file. Defaults to `index.html`.
- `icon`: Optional image used by the App Store.
- `access`: `all` for signed-in users or `owner` for Huber58 only.
- `permission`: Optional existing dashboard permission. Leave blank when no additional permission is needed.

Installing a package with an existing `id` updates that app in place.

## Theme integration

The server automatically loads `/theme.css`, `/theme.js`, `/motion.js`, and
`/modal-dismiss.js` into installed HTML pages. Apps should use ordinary semantic
controls and the shared variables:

```css
body {
  background: var(--page, #f3f6f7);
  color: var(--ink, #182026);
}

.panel {
  border: 1px solid var(--line, #cad4d9);
  background: var(--panel, #fff);
}

button.primary {
  background: var(--accent, #087f8c);
}
```

Use `.panel` for app surfaces and standard `input`, `select`, `textarea`, and
`button` elements so the global light and dark theme guards apply.

## Limits and security

- ZIP upload limit: 50 MB.
- Expanded package limit: 100 MB.
- Maximum entries: 500.
- Server files, executables, symbolic links, hidden files, and path traversal
  entries are rejected.
- Installed files live in `.data/installed-apps` and are included in server
  backups while remaining untouched by website ZIP updates.

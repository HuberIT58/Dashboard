# Huber Email Desktop App

Huber Email is a dedicated desktop client for the existing server-backed mailbox. It uses the same employee login, two-factor authentication, email permission, folders, signatures, and cached mail as the website.

On supported Macs, Email automatically requests Touch ID when its shared login session has expired. Open Dashboard 0.3.3 or newer once first to provision the macOS-encrypted shared credential. Cancelling Touch ID leaves the normal login page available.

## Build on macOS

Double-click `Create Email App.command`, or run:

```sh
cd /Users/christian/Documents/Website/email-desktop
pnpm install
pnpm run build:mac
```

The reusable installer is created at `/Users/christian/Documents/Website/Updates/Huber-Email.dmg`.

## Publish

Open Website Updater, choose `Huber Email` under **Publish Installer Application**, choose the DMG, enter the version, and publish it. Huber App Installer will then offer the Email app.

The Ubuntu website update must be installed as well so login can return directly to Email and the old dashboard Email tile is removed.

# Weekly Server Backups

The backup runs every Friday at 12:00 AM using the Ubuntu server's local time.
If the server is off at that time, systemd runs the missed backup after startup.

## Install

Upload `backup.mjs` and the `deployment` folder with the website, then run:

```bash
sudo mkdir -p /var/backups/huber-it
sudo chmod 700 /var/backups/huber-it

sudo cp /var/www/html/deployment/huber-backup.service /etc/systemd/system/
sudo cp /var/www/html/deployment/huber-backup.timer /etc/systemd/system/

sudo systemctl daemon-reload
sudo systemctl enable --now huber-backup.timer
```

Confirm the schedule:

```bash
systemctl list-timers huber-backup.timer
```

Run one backup immediately:

```bash
sudo systemctl start huber-backup.service
sudo systemctl status huber-backup.service
sudo ls -lh /var/backups/huber-it
```

## Enable Diagnostics Buttons

`Backup Now` and `Restore Last Backup` run as the same Linux user that runs
`server.mjs`. Find that user:

```bash
ps -eo user,cmd | grep '[n]ode server.mjs'
```

Replace `WEBSITE_USER` below with the username shown by that command:

```bash
sudo chown -R WEBSITE_USER:WEBSITE_USER /var/backups/huber-it
sudo chmod 700 /var/backups/huber-it
sudo chown -R WEBSITE_USER:WEBSITE_USER /var/www/html/.data
```

Run the scheduled backup service as that same user:

```bash
sudo systemctl edit huber-backup.service
```

Add:

```ini
[Service]
User=WEBSITE_USER
Group=WEBSITE_USER
```

Then reload it:

```bash
sudo systemctl daemon-reload
sudo systemctl restart huber-backup.timer
```

After using `Restore Last Backup`, restart the website service before anyone
continues entering data.

## Optional Settings

Create `/etc/default/huber-backup`:

```bash
BACKUP_PATH=/var/backups/huber-it
BACKUP_RETENTION_WEEKS=12
```

If documents are stored outside the website folder, also add:

```bash
DOCUMENTS_PATH=/path/to/documents
```

## Restore

Stop the website before restoring:

```bash
sudo systemctl stop huber-website
sudo tar -xzf /var/backups/huber-it/huber-it-backup-DATE.tar.gz -C /var/www/html
sudo systemctl start huber-website
```

Replace `huber-website` with the actual service name used to run `server.mjs`.
Review the archive contents before restoring:

```bash
sudo tar -tzf /var/backups/huber-it/huber-it-backup-DATE.tar.gz
```

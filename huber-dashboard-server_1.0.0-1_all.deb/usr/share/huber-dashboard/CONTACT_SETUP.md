# Contact Form Setup

This site now includes a small Node server that serves the website and handles contact form submissions at `/contact`.

## Ubuntu Setup

1. Install Node.js on the Ubuntu server.

2. In the website folder, install dependencies:

```sh
npm install
```

3. Create a `.env` file from `.env.example`:

```sh
cp .env.example .env
```

4. Edit `.env` with your Zoho email settings:

```sh
PORT=3000
CONTACT_TO=christian.huber@huberitps.com
ZOHO_USER=christian.huber@huberitps.com
ZOHO_APP_PASSWORD=your-zoho-app-password
ZOHO_SMTP_HOST=smtppro.zoho.com
ZOHO_SMTP_PORT=465
ZOHO_SMTP_SECURE=true
ZOHO_POP_HOST=poppro.zoho.com
ZOHO_POP_PORT=995
ZOHO_POP_SECURE=true
ZOHO_FROM_NAME=Huber I.T. Professionals
```

Use a Zoho app password, not your normal mailbox password.

5. Start the website:

```sh
npm start
```

6. Point Cloudflare Tunnel to:

```text
http://localhost:3000
```

The contact form will submit in the background and show a confirmation when the message is sent.

## Important

Do not upload or share the `.env` file publicly. It contains the private Zoho app password.

import { createServer } from "node:http";
import { appendFileSync, cpSync, readFileSync as fsReadFileSync, existsSync as fsExistsSync, writeFileSync as fsWriteFileSync, mkdirSync, mkdtempSync, readdirSync, renameSync, rmSync, statSync, lstatSync, statfsSync, createReadStream, createWriteStream, unlinkSync } from "node:fs";
import { basename, dirname, extname, join, normalize, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { cpus, freemem, hostname, loadavg, platform, release, totalmem, tmpdir, uptime as systemUptime } from "node:os";
import { spawn } from "node:child_process";
import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, randomUUID, scryptSync, timingSafeEqual } from "node:crypto";
import { gzipSync } from "node:zlib";
import webpush from "web-push";
import PDFDocument from "pdfkit";
import { simpleParser } from "mailparser";
import nodemailer from "nodemailer";
import Pop3Command from "node-pop3";
import { StructuredStore } from "./database.mjs";

let structuredStore = null;
let structuredPaths = new Set();
let restartScheduled = false;
let diagnosticsCpuSnapshot = null;
const writeLegacyStructuredSnapshots = process.env.WRITE_LEGACY_DATA_SNAPSHOTS === "true";

function readFileSync(filePath, options) {
  if (structuredStore && structuredPaths.has(resolve(filePath)) && structuredStore.has(filePath)) {
    const content = structuredStore.read(filePath);
    const encoding = typeof options === "string" ? options : options?.encoding;
    return encoding ? content : Buffer.from(content);
  }
  return fsReadFileSync(filePath, options);
}

function existsSync(filePath) {
  if (structuredStore && structuredPaths.has(resolve(filePath)) && structuredStore.has(filePath)) {
    return true;
  }
  return fsExistsSync(filePath);
}

function writeFileSync(filePath, data, options) {
  if (!structuredStore || !structuredPaths.has(resolve(filePath))) {
    return fsWriteFileSync(filePath, data, options);
  }
  const content = Buffer.isBuffer(data) ? data.toString("utf8") : String(data);
  if (typeof options?.flag === "string" && options.flag.includes("x")) {
    structuredStore.withSavepoint(() => {
      if (structuredStore.has(filePath) || fsExistsSync(filePath)) {
        const error = new Error(`File already exists: ${filePath}`);
        error.code = "EEXIST";
        throw error;
      }
      structuredStore.write(filePath, content);
    });
  } else {
    structuredStore.write(filePath, content);
  }
  if (!writeLegacyStructuredSnapshots) return undefined;
  try {
    return fsWriteFileSync(filePath, data, options);
  } catch (error) {
    console.warn(`Database write succeeded, but rollback snapshot failed for ${filePath}: ${error.message}`);
    return undefined;
  }
}

const root = fileURLToPath(new URL(".", import.meta.url));

loadLocalEnv();

const storageSettingsRuntimePath = join(root, ".data", "storage-settings-runtime.json");
function readRuntimeStorageSettings() {
  try {
    const value = JSON.parse(fsReadFileSync(storageSettingsRuntimePath, "utf8"));
    return value && typeof value === "object" ? value : {};
  } catch {
    return {};
  }
}
const runtimeStorageSettings = readRuntimeStorageSettings();
const managedStorageRoot = resolve(
  process.env.FILE_STORAGE_ROOT || runtimeStorageSettings.storageRoot || join(root, ".data")
);

const port = Number(process.env.PORT || 3000);
const publicBaseUrl = normalizeConfiguredBaseUrl(process.env.PUBLIC_BASE_URL || "https://www.huberitps.com");
const lanBaseUrl = normalizeConfiguredBaseUrl(process.env.LAN_BASE_URL || "");
const lanRouteProbeTimeoutMs = Math.min(3000, Math.max(500, Number(process.env.LAN_ROUTE_TIMEOUT_MS || 1200)));
const usersPath = join(root, "users.txt");
const ticketsPath = join(root, "tickets.txt");
const employeesPath = join(root, "employees.txt");
const timePath = join(root, "time-records.txt");
const scheduleEventsPath = join(root, "schedule-events.txt");
const rolesPath = join(root, "roles.txt");
const inventoryPath = join(root, "inventory.txt");
const catalogPath = join(root, "catalog.txt");
const itemCategoriesPath = join(root, ".data", "item-categories.json");
const nonChargeableReasonsPath = join(root, ".data", "non-chargeable-reasons.json");
const notificationsPath = join(root, "notifications.txt");
const invoicesPath = join(root, "invoices.txt");
const invoiceChargesPath = join(root, ".data", "invoice-charges.json");
const invoicePaymentInstructionsPath = join(root, ".data", "invoice-payment-instructions.json");
const financePath = join(root, ".data", "finance.json");
const billsPath = join(root, ".data", "bills.json");
const bankPath = join(root, ".data", "bank.json");
const bankRulesPath = join(root, ".data", "bank-rules.json");
const estimatesPath = join(root, ".data", "estimates.json");
const bidsPath = join(root, ".data", "bids.json");
const badgesPath = join(root, ".data", "badges.json");
const mailDraftsPath = join(root, ".data", "mail-drafts.json");
const mailAccountsPath = join(root, ".data", "mail-accounts.json");
const mailStatePath = join(root, ".data", "mail-state.json");
const mailEncryptionKeyPath = join(root, ".data", "mail-encryption.key");
const mailUploadsPath = join(managedStorageRoot, "mail-uploads");
const mailCachePath = join(managedStorageRoot, "mail-cache");
const estimateTemplatesPath = join(root, ".data", "estimate-text-templates.json");
const estimateMaterialRulesPath = join(root, ".data", "estimate-material-rules.json");
const estimateLineItemsPath = join(root, ".data", "estimate-line-items.json");
const stripeEventsPath = join(root, ".data", "stripe-events.json");
const zohoPaymentSessionsPath = join(root, ".data", "zoho-payment-sessions.json");
const zohoPaymentEventsPath = join(root, ".data", "zoho-payment-events.json");
const securityEventsPath = join(root, ".data", "security-events.json");
const receiptsPath = join(root, ".data", "receipts.json");
const receiptFilesPath = join(managedStorageRoot, "receipts");
const portalAccessPath = join(root, ".data", "customer-portal-access.json");
const customerSessionsPath = join(root, ".data", "customer-sessions.json");
const pushSubscriptionsPath = join(root, ".data", "push-subscriptions.json");
const pushConfigPath = join(root, ".data", "push-config.json");
const sessionsPath = join(root, ".data", "sessions.json");
const offlineMutationsPath = join(root, ".data", "offline-mutations.json");
const activityPath = join(root, ".data", "activity.json");
const ticketSignaturesPath = join(root, ".data", "ticket-signatures");
const alertDismissalsPath = join(root, ".data", "alert-dismissals.json");
const availabilityPath = join(root, ".data", "availability.json");
const pushFailuresPath = join(root, ".data", "push-failures.json");
const customersPath = join(root, ".data", "customers.json");
const customerCommunicationsPath = join(root, ".data", "customer-communications.json");
const warrantiesPath = join(root, ".data", "warranties.json");
const taxesPath = join(root, ".data", "taxes.json");
const payrollPath = join(root, ".data", "payroll.json");
const approvalsPath = join(root, ".data", "approvals.json");
const approvalPoliciesPath = join(root, ".data", "approval-policies.json");
const ptoSettingsPath = join(root, ".data", "pto-settings.json");
const dashboardLayoutsPath = join(root, ".data", "dashboard-layouts.json");
const accessTemplatesPath = join(root, ".data", "access-templates.json");
const userThemesPath = join(root, ".data", "user-themes.json");
const announcementsPath = join(root, ".data", "announcements.json");
const ticketEscalationPath = join(root, ".data", "ticket-escalation.json");
const assetsPath = join(root, ".data", "assets.json");
const presentationsPath = join(root, ".data", "presentations.json");
const spreadsheetsPath = join(root, ".data", "spreadsheets.json");
const floorPlansPath = join(root, ".data", "floor-plans.json");
const companyDocumentsPath = join(root, ".data", "company-documents.json");
const trainingVideosPath = join(root, ".data", "training-videos.json");
const jobExpensesPath = join(root, ".data", "job-expenses.json");
const trustedTwoFactorPath = join(root, ".data", "trusted-2fa-devices.json");
const passwordVaultPath = join(root, ".data", "password-vault.json");
const installedAppsPath = join(root, ".data", "installed-apps.json");
const installedAppFilesPath = join(managedStorageRoot, "installed-apps");
const desktopInstallerCatalogPath = join(root, ".data", "desktop-installer-catalog.json");
const desktopInstallerPackagesPath = join(managedStorageRoot, "desktop-installer-packages");
const desktopInstallerUploadsPath = join(root, ".data", "desktop-installer-uploads");
const networkTesterUpdatesPath = join(managedStorageRoot, "network-tester-updates");
const networkTesterUploadsPath = join(root, ".data", "network-tester-update-uploads");
const unifiPath = join(root, ".data", "unifi.json");
const databasePath = join(root, ".data", "huber-it.sqlite");
const ticketAttachmentsPath = join(managedStorageRoot, "ticket-attachments");
const accountAvatarsPath = join(root, ".data", "account-avatars");
const employeeAvatarsPath = join(root, ".data", "employee-avatars");
const presentationImagesPath = join(managedStorageRoot, "presentation-images");
const badgePhotosPath = join(managedStorageRoot, "badge-photos");
const documentsPath = resolve(process.env.DOCUMENTS_PATH || join(managedStorageRoot, "documents"));
const sessions = new Map();
const loginAttempts = new Map();
const eventClients = new Map();
let backupOperationRunning = false;
const sessionCutoffHour = 7;
const trustedTwoFactorLifetime = 3 * 24 * 60 * 60 * 1000;
const twoFactorEnrollmentGrace = 14 * 24 * 60 * 60 * 1000;
const allPermissions = [
  "employee-records",
  "service-tickets",
  "employee-time",
  "time-adjust",
  "schedule",
  "dispatch",
  "route-planning",
  "documents",
  "office-suite",
  "spreadsheets",
  "document-maker",
  "presentations",
  "design-center",
  "field-toolkit",
  "inventory",
  "inventory-scanner",
  "catalog",
  "invoicing",
  "estimates",
  "bids",
  "badge-maker",
  "email",
  "finance",
  "bills",
  "banking",
  "profit-loss",
  "customers",
  "job-workspace",
  "warranties",
  "taxes",
  "customer-portal",
  "availability",
  "reports",
  "payroll",
  "approvals",
  "announcements",
  "command-center",
  "unifi",
  "security"
];

mkdirSync(documentsPath, { recursive: true, mode: 0o700 });
mkdirSync(ticketAttachmentsPath, { recursive: true, mode: 0o700 });
mkdirSync(ticketSignaturesPath, { recursive: true, mode: 0o700 });
mkdirSync(receiptFilesPath, { recursive: true, mode: 0o700 });
mkdirSync(accountAvatarsPath, { recursive: true, mode: 0o700 });
mkdirSync(employeeAvatarsPath, { recursive: true, mode: 0o700 });
mkdirSync(presentationImagesPath, { recursive: true, mode: 0o700 });
mkdirSync(badgePhotosPath, { recursive: true, mode: 0o700 });
mkdirSync(mailUploadsPath, { recursive: true, mode: 0o700 });
mkdirSync(mailCachePath, { recursive: true, mode: 0o700 });
mkdirSync(installedAppFilesPath, { recursive: true, mode: 0o700 });
mkdirSync(join(root, ".data"), { recursive: true, mode: 0o700 });

structuredPaths = new Set([
  usersPath,
  ticketsPath,
  employeesPath,
  timePath,
  scheduleEventsPath,
  rolesPath,
  inventoryPath,
  catalogPath,
  itemCategoriesPath,
  nonChargeableReasonsPath,
  notificationsPath,
  invoicesPath,
  invoiceChargesPath,
  invoicePaymentInstructionsPath,
  financePath,
  billsPath,
  bankPath,
  bankRulesPath,
  estimatesPath,
  bidsPath,
  badgesPath,
  mailDraftsPath,
  mailAccountsPath,
  mailStatePath,
  estimateTemplatesPath,
  estimateMaterialRulesPath,
  estimateLineItemsPath,
  stripeEventsPath,
  zohoPaymentSessionsPath,
  zohoPaymentEventsPath,
  securityEventsPath,
  receiptsPath,
  portalAccessPath,
  customerSessionsPath,
  pushSubscriptionsPath,
  pushConfigPath,
  sessionsPath,
  offlineMutationsPath,
  activityPath,
  alertDismissalsPath,
  availabilityPath,
  pushFailuresPath,
  customersPath,
  customerCommunicationsPath,
  warrantiesPath,
  taxesPath,
  payrollPath,
  approvalsPath,
  approvalPoliciesPath,
  ptoSettingsPath,
  dashboardLayoutsPath,
  accessTemplatesPath,
  userThemesPath,
  announcementsPath,
  ticketEscalationPath,
  assetsPath,
  presentationsPath,
  spreadsheetsPath,
  floorPlansPath,
  companyDocumentsPath,
  trainingVideosPath,
  jobExpensesPath,
  trustedTwoFactorPath,
  passwordVaultPath,
  installedAppsPath
  ,unifiPath
].map((filePath) => resolve(filePath)));
structuredStore = new StructuredStore(databasePath, root);
if (structuredStore.migratedStores) {
  console.info(`Migrated ${structuredStore.migratedStores} structured data store(s) into indexed SQLite records.`);
}
const importedLegacyStores = structuredStore.importLegacy([...structuredPaths]);
if (importedLegacyStores) {
  console.info(`Imported ${importedLegacyStores} legacy data stores into SQLite.`);
}
migrateUserCreatedDates();
ensureAdminEmployeeRecord();
seedInitialTrainingVideo();
migrateEstimateStatuses();
runRetentionCleanup();
cleanupMailUploads();

function reopenStructuredStore() {
  structuredStore = new StructuredStore(databasePath, root);
  structuredStore.importLegacy([...structuredPaths]);
}

function runRetentionCleanup() {
  const policies = [
    [notificationsPath, 180, "createdAt"],
    [activityPath, 730, "createdAt"],
    [securityEventsPath, 365, "createdAt"],
    [approvalsPath, 730, "createdAt"],
    [pushFailuresPath, 90, "createdAt"],
    [offlineMutationsPath, 30, "createdAt"]
  ];
  for (const [filePath, days, dateField] of policies) {
    if (!existsSync(filePath)) continue;
    try {
      const records = JSON.parse(readFileSync(filePath, "utf8"));
      if (!Array.isArray(records)) continue;
      const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
      const retained = records.filter((record) => {
        const timestamp = new Date(record[dateField] || 0).getTime();
        return !Number.isFinite(timestamp) || timestamp >= cutoff;
      });
      if (retained.length !== records.length) {
        writeFileSync(filePath, JSON.stringify(retained, null, 2), { mode: 0o600 });
      }
    } catch (error) {
      console.warn(`Retention cleanup skipped ${filePath}: ${error.message}`);
    }
  }
  const trusted = readTrustedTwoFactorDevices().filter((record) =>
    Number(record.expiresAt || 0) > Date.now()
  );
  writeFileSync(trustedTwoFactorPath, JSON.stringify(trusted, null, 2), { mode: 0o600 });
}

const pushConfig = loadPushConfig();
loadSessions();
webpush.setVapidDetails(
  process.env.VAPID_SUBJECT || "mailto:christian.huber@huberitps.com",
  pushConfig.publicKey,
  pushConfig.privateKey
);

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".ico": "image/x-icon",
  ".svg": "image/svg+xml",
  ".json": "application/json; charset=utf-8",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".mp4": "video/mp4",
  ".webm": "video/webm",
  ".ogg": "video/ogg",
  ".webmanifest": "application/manifest+json"
};

const server = createServer(async (request, response) => {
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader("X-Frame-Options", "SAMEORIGIN");
  response.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  response.setHeader("Permissions-Policy", "geolocation=(), microphone=()");

  try {
    if (request.method === "GET" && request.url === "/api/network-route") {
      const connectionRoute = request.headers["cf-ray"] || request.headers["cf-connecting-ip"]
        ? "cloudflare"
        : "local";
      sendJson(response, 200, {
        publicBaseUrl,
        lanBaseUrl,
        probeTimeoutMs: lanRouteProbeTimeoutMs,
        connectionRoute
      });
      return;
    }
    if (request.method === "OPTIONS" && request.url === "/api/lan-health") {
      response.writeHead(204, lanHealthCorsHeaders(request));
      response.end();
      return;
    }
    if ((request.method === "GET" || request.method === "HEAD") && request.url === "/api/lan-health") {
      for (const [name, value] of Object.entries(lanHealthCorsHeaders(request))) {
        response.setHeader(name, value);
      }
      if (request.method === "HEAD") {
        response.writeHead(204, { "Cache-Control": "no-store" });
        response.end();
      } else {
        sendJson(response, 200, { ok: true, directRouteAvailable: true });
      }
      return;
    }
    if (request.method === "GET" && request.url === "/desktop-updates/latest-mac-arm64.json") {
      serveDesktopUpdateManifest(response);
      return;
    }
    if (request.method === "GET" && request.url === "/desktop-updates/Huber-Dashboard-mac-arm64.zip") {
      serveDesktopUpdateBundle(request, response);
      return;
    }
    if (request.method === "GET" && request.url === "/app-installer/catalog.json") {
      serveDesktopInstallerCatalog(response);
      return;
    }
    if ((request.method === "GET" || request.method === "HEAD") && request.url.startsWith("/app-installer/packages/")) {
      serveDesktopInstallerPackage(request, response);
      return;
    }
    if (request.method === "GET" && request.url === "/network-tester/update.json") {
      serveNetworkTesterUpdateManifest(response);
      return;
    }
    if ((request.method === "GET" || request.method === "HEAD") && request.url.startsWith("/network-tester/packages/")) {
      serveNetworkTesterUpdatePackage(request, response);
      return;
    }
    if (request.method === "GET" && request.url === "/auth-status") {
      const session = getSession(request);
      const user = session ? readUsers().find((record) => record.username === session.username) : null;
      const employee = session ? readEmployees().find((record) =>
        `${record.firstName || ""} ${record.lastName || ""}`.trim().toLowerCase() ===
        String(session.employeeName || "").trim().toLowerCase()
      ) : null;
      sendJson(response, 200, {
        authenticated: Boolean(session),
        username: session?.username || "",
        employeeName: session?.employeeName || "",
        role: session?.role || "",
        position: employee?.jobTitle || session?.role || "",
        permissions: effectivePermissions(session),
        avatarUrl: user?.avatarPath ? `/api/account-avatar?v=${encodeURIComponent(user.avatarUpdatedAt || "")}` : "",
        zohoPortalUrl: employee?.zohoPortalUrl || "",
        twoFactorSetupRequired: Boolean(session?.twoFactorEnrollmentRequired),
        setupRequired: readUsers().length === 0
      });
      return;
    }

    if (request.method === "POST" && request.url === "/setup") {
      await handleSetup(request, response);
      return;
    }

    if (request.method === "POST" && request.url === "/login") {
      await handleLogin(request, response);
      return;
    }

    const enrollmentSession = getSession(request);
    if (enrollmentSession?.twoFactorEnrollmentRequired &&
        request.url.startsWith("/api/") &&
        request.url !== "/api/account" &&
        request.url !== "/api/theme") {
      sendJson(response, 428, {
        ok: false,
        twoFactorSetupRequired: true,
        message: "Set up two-factor authentication to continue."
      });
      return;
    }

    if (request.url === "/api/account") {
      await handleAccount(request, response);
      return;
    }

    if (request.url.startsWith("/api/account-avatar")) {
      await handleAccountAvatar(request, response);
      return;
    }

    if (request.url === "/api/admin-password") {
      await handleAdminPassword(request, response);
      return;
    }

    if (request.method === "POST" && request.url === "/logout") {
      handleLogout(request, response);
      return;
    }

    if (request.method === "POST" && request.url === "/employee-user") {
      await handleEmployeeUser(request, response);
      return;
    }

    if (request.url === "/api/user-access") {
      await handleUserAccess(request, response);
      return;
    }

    if (request.url === "/api/access-templates") {
      await handleAccessTemplates(request, response);
      return;
    }

    if (request.url === "/api/contacts") {
      await handleContacts(request, response);
      return;
    }

    if (request.url.startsWith("/api/contact-avatar")) {
      await handleContactAvatar(request, response);
      return;
    }

    if (request.url === "/api/roles") {
      await handleRoles(request, response);
      return;
    }

    if (request.url === "/api/inventory") {
      await handleInventory(request, response);
      return;
    }

    if (request.url === "/api/assets") {
      await handleAssets(request, response);
      return;
    }

    if (request.url === "/api/password-vault") {
      await handlePasswordVault(request, response);
      return;
    }

    if (request.url === "/api/bids") {
      await handleBids(request, response);
      return;
    }

    if (request.url.startsWith("/api/badges")) {
      await handleBadges(request, response);
      return;
    }

    if (request.url.startsWith("/api/mail")) {
      await handleMail(request, response);
      return;
    }

    if (request.url === "/api/catalog") {
      await handleCatalog(request, response);
      return;
    }

    if (request.url === "/api/catalog-link-preview") {
      await handleCatalogLinkPreview(request, response);
      return;
    }

    if (request.url === "/api/item-categories") {
      await handleItemCategories(request, response);
      return;
    }

    if (request.url === "/api/customers" || request.url.startsWith("/api/customers?")) {
      await handleCustomers(request, response);
      return;
    }

    if (request.url.startsWith("/api/customer-communications")) {
      await handleCustomerCommunications(request, response);
      return;
    }

    if (request.url.startsWith("/api/job-workspace")) {
      await handleJobWorkspace(request, response);
      return;
    }

    if (request.url.startsWith("/api/job-expenses")) {
      await handleJobExpenses(request, response);
      return;
    }

    if (request.url === "/api/warranties") {
      await handleWarranties(request, response);
      return;
    }

    if (request.url.startsWith("/api/taxes")) {
      await handleTaxes(request, response);
      return;
    }

    if (request.url.startsWith("/api/customer-history")) {
      handleCustomerHistory(request, response);
      return;
    }

    if (request.url.startsWith("/api/estimates")) {
      await handleEstimates(request, response);
      return;
    }

    if (request.url === "/api/estimate-templates") {
      await handleEstimateTemplates(request, response);
      return;
    }

    if (request.url === "/api/estimate-line-items") {
      await handleEstimateLineItems(request, response);
      return;
    }

    if (request.url === "/api/estimate-material-rules") {
      await handleEstimateMaterialRules(request, response);
      return;
    }

    if (request.url.startsWith("/api/payroll")) {
      await handlePayroll(request, response);
      return;
    }

    if (request.url.startsWith("/api/security-center")) {
      await handleSecurityCenter(request, response);
      return;
    }

    if (request.url.startsWith("/api/ticket-messages")) {
      await handleTicketMessages(request, response);
      return;
    }

    if (request.method === "GET" && request.url.startsWith("/api/completion-report")) {
      handleCompletionReport(request, response);
      return;
    }

    if (request.method === "POST" && request.url === "/api/ticket-items") {
      await handleTicketItems(request, response);
      return;
    }

    if (request.url.startsWith("/api/ticket-attachments")) {
      await handleTicketAttachments(request, response);
      return;
    }

    if (request.url === "/api/notifications") {
      await handleNotifications(request, response);
      return;
    }

    if (request.url === "/api/push/public-key") {
      handlePushPublicKey(request, response);
      return;
    }

    if (request.url === "/api/push/subscription") {
      await handlePushSubscription(request, response);
      return;
    }

    if (request.url === "/api/push/devices") {
      await handlePushDevices(request, response);
      return;
    }

    if (request.method === "GET" && request.url === "/api/dashboard-summary") {
      handleDashboardSummary(request, response);
      return;
    }

    if (request.url.startsWith("/api/dispatch")) {
      await handleDispatch(request, response);
      return;
    }

    if (request.url.startsWith("/api/unifi")) {
      await handleUnifi(request, response);
      return;
    }

    if (request.url.startsWith("/api/activity")) {
      await handleActivity(request, response);
      return;
    }
    if (request.method === "GET" && request.url.startsWith("/api/global-search")) {
      handleGlobalSearch(request, response);
      return;
    }
    if (request.method === "POST" && request.url === "/api/local-assistant") {
      await handleLocalAssistant(request, response);
      return;
    }
    if (request.url === "/api/operations-center" || request.url.startsWith("/api/operations-center?")) {
      await handleOperationsCenter(request, response);
      return;
    }
    if (request.url === "/api/approvals") {
      await handleApprovals(request, response);
      return;
    }

    if (request.url === "/api/alerts") {
      await handleAlerts(request, response);
      return;
    }

    if (request.url === "/api/availability") {
      await handleAvailability(request, response);
      return;
    }

    if (request.url === "/api/pto-settings") {
      await handlePtoSettings(request, response);
      return;
    }

    if (request.url === "/api/dashboard-layout") {
      await handleDashboardLayout(request, response);
      return;
    }
    if (request.url.startsWith("/api/announcements")) {
      await handleAnnouncements(request, response);
      return;
    }
    if (request.url === "/api/ticket-escalation") {
      await handleTicketEscalation(request, response);
      return;
    }

    if (request.url === "/api/theme") {
      await handleTheme(request, response);
      return;
    }

    if (request.method === "GET" && request.url === "/api/diagnostics/live") {
      handleLiveDiagnostics(request, response);
      return;
    }

    if (request.method === "GET" && request.url === "/api/diagnostics") {
      handleDiagnostics(request, response);
      return;
    }

    if (request.url === "/api/backup-control") {
      await handleBackupControl(request, response);
      return;
    }

    if (request.url === "/api/site-update") {
      await handleSiteUpdate(request, response);
      return;
    }

    if (request.url === "/api/desktop-update") {
      await handleDesktopUpdate(request, response);
      return;
    }

    if (request.url.startsWith("/api/desktop-installer-publish")) {
      await handleDesktopInstallerPublish(request, response);
      return;
    }

    if (request.url.startsWith("/api/network-tester-update-publish")) {
      await handleNetworkTesterUpdatePublish(request, response);
      return;
    }

    if (request.url === "/api/app-store" || request.url.startsWith("/api/app-store?")) {
      await handleAppStore(request, response);
      return;
    }

    if (request.url === "/api/wipe-data") {
      await handleWipeData(request, response);
      return;
    }

    if (request.url.startsWith("/api/ticket-signature")) {
      handleTicketSignature(request, response);
      return;
    }

    if (request.method === "GET" && request.url === "/api/service-events") {
      handleServiceEvents(request, response);
      return;
    }

    if (request.url === "/api/invoices" || request.url.startsWith("/api/invoices?")) {
      await handleInvoices(request, response);
      return;
    }

    if (request.url === "/api/invoice-charges") {
      await handleInvoiceCharges(request, response);
      return;
    }

    if (request.url === "/api/invoice-payment-instructions") {
      await handleInvoicePaymentInstructions(request, response);
      return;
    }

    if (request.url === "/api/finance") {
      await handleFinance(request, response);
      return;
    }

    if (request.url === "/api/bills") {
      await handleBills(request, response);
      return;
    }

    if (request.url === "/api/bank") {
      await handleBanking(request, response);
      return;
    }

    if (request.url === "/api/bank-rules") {
      await handleBankRules(request, response);
      return;
    }

    if (request.url.startsWith("/api/pnl")) {
      handleProfitLoss(request, response);
      return;
    }

    if (request.url.startsWith("/api/receipts")) {
      await handleReceipts(request, response);
      return;
    }

    if (request.url === "/api/customer-portal-admin") {
      await handleCustomerPortalAdmin(request, response);
      return;
    }

    if (request.url === "/api/customer-portal-login" ||
        request.url === "/api/customer-portal-data" ||
        request.url === "/api/customer-portal-logout" ||
        request.url === "/api/customer-portal-checkout") {
      await handleCustomerPortal(request, response);
      return;
    }

    if (request.url === "/api/zoho-payments-webhook") {
      await handleZohoPaymentsWebhook(request, response);
      return;
    }

    if (request.url === "/api/tickets") {
      await handleTickets(request, response);
      return;
    }

    if (request.url === "/api/non-chargeable-reasons") {
      await handleNonChargeableReasons(request, response);
      return;
    }

    if (request.method === "POST" && request.url === "/api/ticket-hours") {
      await handleTicketHours(request, response);
      return;
    }

    if (request.url === "/api/employees") {
      await handleEmployees(request, response);
      return;
    }

    if (request.url.startsWith("/api/employee-avatar")) {
      await handleEmployeeAvatar(request, response);
      return;
    }

    if (request.url === "/api/time") {
      await handleTime(request, response);
      return;
    }

    if (request.url.startsWith("/api/service-timesheet")) {
      await handleServiceTimesheet(request, response);
      return;
    }

    if (request.method === "POST" && request.url === "/api/time-adjust") {
      await handleTimeAdjustment(request, response);
      return;
    }

    if (request.method === "GET" && request.url === "/api/admin-time") {
      handleAdminTime(request, response);
      return;
    }

    if (request.url === "/api/schedule-events") {
      await handleScheduleEvents(request, response);
      return;
    }

    if (request.url.startsWith("/api/documents")) {
      await handleDocuments(request, response);
      return;
    }

    if (request.url.startsWith("/api/presentations")) {
      await handlePresentations(request, response);
      return;
    }

    if (request.url.startsWith("/api/spreadsheets")) {
      await handleSpreadsheets(request, response);
      return;
    }

    if (request.url.startsWith("/api/floor-plans")) {
      await handleFloorPlans(request, response);
      return;
    }

    if (request.url.startsWith("/api/company-documents")) {
      await handleCompanyDocuments(request, response);
      return;
    }

    if (request.url.startsWith("/api/training-videos")) {
      await handleTrainingVideos(request, response);
      return;
    }

    if (request.method === "GET" || request.method === "HEAD") {
      serveStatic(request, response);
      return;
    }

    sendJson(response, 405, { ok: false, message: "Method not allowed." });
  } catch (error) {
    console.error(error);
    if (!response.headersSent) {
      sendJson(response, 500, { ok: false, message: "Server error." });
    } else if (!response.writableEnded) {
      response.end();
    }
  }
});

server.listen(port, () => {
  console.log(`Huber I.T. site running at http://localhost:${port}`);
  setTimeout(() => runTicketEscalations().catch((error) =>
    console.error("Ticket escalation check failed:", error.message)), 5000);
  setInterval(() => runTicketEscalations().catch((error) =>
    console.error("Ticket escalation check failed:", error.message)), 5 * 60 * 1000);
});

function serveStatic(request, response) {
  const url = new URL(request.url, `http://${request.headers.host}`);
  let requestedPath;
  try {
    requestedPath = url.pathname === "/" ? "/index.html" : decodeURIComponent(url.pathname);
  } catch {
    response.writeHead(400, { "Content-Type": "text/plain; charset=utf-8" });
    response.end("Invalid path");
    return;
  }
  const safePath = normalize(requestedPath).replace(/^(\.\.[/\\])+/, "");
  // Authorize the same decoded, normalized path that will be read from disk.
  const pathname = extname(safePath).toLowerCase() === ".html" ? safePath.toLowerCase() : safePath;
  const filePath = join(root, safePath);
  const publicExtensions = new Set([".html", ".css", ".js", ".json", ".png", ".jpg", ".jpeg", ".webp", ".gif", ".ico", ".svg", ".woff", ".woff2", ".ttf", ".mp4", ".webm", ".ogg", ".webmanifest"]);

  if (pathname === "/version.txt") {
    const versionPath = join(root, "version.txt");
    if (!existsSync(versionPath)) {
      response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      response.end("Not found");
      return;
    }
    response.writeHead(200, {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store"
    });
    response.end(readFileSync(versionPath, "utf8"));
    return;
  }

  const session = getSession(request);
  if (pathname === "/apps" || pathname.startsWith("/apps/")) {
    serveInstalledApp(request, response, url, session);
    return;
  }
  const adminPages = new Set([
    "/employee-records.html",
    "/service-tickets.html",
    "/employee-time.html",
    "/schedule.html",
    "/dispatch.html",
    "/route-planning.html",
    "/unifi.html",
    "/documents.html",
    "/office-suite.html",
    "/spreadsheet.html",
    "/document-maker.html",
    "/presentations.html",
    "/design-center.html",
    "/field-toolkit.html",
    "/password-vault.html",
    "/inventory.html",
    "/inventory-scanner.html",
    "/catalog.html",
    "/catalog-import.html",
    "/invoices.html",
    "/finance.html",
    "/bills.html",
    "/banking.html",
    "/profit-loss.html",
    "/customer-access.html",
    "/estimates.html",
    "/bids.html",
    "/badge-maker.html",
    "/labels.html",
    "/email.html",
    "/payroll.html",
    "/reports.html"
    ,"/announcements.html"
    ,"/command-center.html"
    ,"/availability.html"
    ,"/customers.html"
    ,"/job-workspace.html"
    ,"/warranties.html"
    ,"/taxes.html"
    ,"/approvals.html"
  ]);
  const protectedPages = new Set([...adminPages, "/dashboard.html", "/service-dashboard.html", "/contacts.html", "/install.html"]);
  protectedPages.add("/account.html");
  protectedPages.add("/operations-center.html");
  const pagePermissions = {
    "/employee-records.html": "employee-records",
    "/service-tickets.html": "service-tickets",
    "/employee-time.html": "employee-time",
    "/schedule.html": "schedule",
    "/dispatch.html": "dispatch",
    "/route-planning.html": "route-planning",
    "/unifi.html": "unifi",
    "/documents.html": "documents",
    "/office-suite.html": "office-suite",
    "/spreadsheet.html": "office-suite",
    "/document-maker.html": "document-maker",
    "/presentations.html": "presentations",
    "/design-center.html": "design-center",
    "/field-toolkit.html": "field-toolkit",
    "/inventory.html": "inventory",
    "/inventory-scanner.html": "inventory-scanner",
    "/catalog.html": "catalog",
    "/catalog-import.html": "catalog",
    "/invoices.html": "invoicing",
    "/finance.html": "finance",
    "/bills.html": "bills",
    "/banking.html": "banking",
    "/profit-loss.html": "profit-loss",
    "/customer-access.html": "customer-portal",
    "/estimates.html": "estimates",
    "/bids.html": "bids",
    "/badge-maker.html": "badge-maker",
    "/labels.html": "badge-maker",
    "/email.html": "email",
    "/payroll.html": "payroll",
    "/reports.html": "reports"
    ,"/announcements.html": "announcements"
    ,"/command-center.html": "command-center"
    ,"/availability.html": "availability"
    ,"/customers.html": "customers"
    ,"/job-workspace.html": "job-workspace"
    ,"/warranties.html": "warranties"
    ,"/taxes.html": "taxes"
    ,"/approvals.html": "approvals"
  };

  if (protectedPages.has(pathname) && !session) {
    const loginPage = pathname === "/service-dashboard.html"
      ? "/servicelogin.html"
      : "/login.html";
    response.writeHead(302, {
      "Location": loginPage,
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  const twoFactorRestrictedPages = new Set([
    ...protectedPages,
    "/settings.html",
    "/activity.html",
    "/diagnostics.html",
    "/update.html",
    "/assets.html",
    "/password-vault.html",
    "/security.html",
    "/operations-center.html"
  ]);
  twoFactorRestrictedPages.delete("/account.html");
  if (session?.twoFactorEnrollmentRequired && twoFactorRestrictedPages.has(pathname)) {
    const returnTarget = pathname === "/service-dashboard.html" ? "service"
      : pathname === "/email.html" ? "email"
      : pathname === "/office-suite.html" ? "office"
      : pathname === "/design-center.html" ? "design"
      : "dashboard";
    response.writeHead(302, {
      "Location": `/account.html?two-factor=required&return=${returnTarget}`,
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  if (pathname === "/settings.html" && (!session || session.username !== "Huber58")) {
    response.writeHead(302, {
      "Location": session ? "/dashboard.html" : "/login.html",
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  if (pathname === "/activity.html" && (!session || session.username !== "Huber58")) {
    response.writeHead(302, {
      "Location": session ? "/dashboard.html" : "/login.html",
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  if (pathname === "/diagnostics.html" && (!session || session.username !== "Huber58")) {
    response.writeHead(302, {
      "Location": session ? "/dashboard.html" : "/login.html",
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  if (pathname === "/update.html" && (!session || session.username !== "Huber58")) {
    response.writeHead(302, {
      "Location": session ? "/dashboard.html" : "/login.html",
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  if (pathname === "/operations-center.html" && (!session || session.username !== "Huber58")) {
    response.writeHead(302, {
      "Location": session ? "/dashboard.html" : "/login.html",
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  if (pathname === "/install.html" && (!session || session.username !== "Huber58")) {
    response.writeHead(302, {
      "Location": session ? "/dashboard.html" : "/login.html",
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  if (pathname === "/assets.html" && (!session || session.username !== "Huber58")) {
    response.writeHead(302, {
      "Location": session ? "/dashboard.html" : "/login.html",
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  if (pathname === "/password-vault.html" && (!session || session.username !== "Huber58")) {
    response.writeHead(302, {
      "Location": session ? "/dashboard.html" : "/login.html",
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  if (pathname === "/security.html" && !hasPermission(session, "security")) {
    response.writeHead(302, {
      "Location": session ? "/dashboard.html" : "/login.html",
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  const requiredPagePermission = pagePermissions[pathname];
  const officeSuiteLegacyPage = ["/document-maker.html", "/presentations.html"].includes(pathname);
  if (adminPages.has(pathname) &&
      !hasPermission(session, requiredPagePermission) &&
      !(officeSuiteLegacyPage && hasPermission(session, "office-suite"))) {
    response.writeHead(302, {
      "Location": "/dashboard.html",
      "Cache-Control": "no-store, private",
      "CDN-Cache-Control": "no-store",
      "Cloudflare-CDN-Cache-Control": "no-store",
      "Vary": "Cookie"
    });
    response.end();
    return;
  }

  if (safePath.toLowerCase().split(/[\\/\\\\]/).includes(".data") ||
      !filePath.startsWith(root) ||
      !publicExtensions.has(extname(filePath).toLowerCase()) ||
      !existsSync(filePath)) {
    response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    response.end("Not found");
    return;
  }

  const extension = extname(filePath).toLowerCase();
  if ([".mp4", ".webm", ".ogg"].includes(extension)) {
    const size = statSync(filePath).size;
    const range = String(request.headers.range || "").match(/^bytes=(\d*)-(\d*)$/);
    let start = range?.[1] ? Number(range[1]) : 0;
    let end = range?.[2] ? Number(range[2]) : size - 1;
    if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end < start || start >= size) {
      response.writeHead(416, { "Content-Range": `bytes */${size}` });
      response.end();
      return;
    }
    end = Math.min(end, size - 1);
    const partial = Boolean(range);
    response.writeHead(partial ? 206 : 200, {
      "Content-Type": mimeTypes[extension],
      "Content-Length": end - start + 1,
      "Accept-Ranges": "bytes",
      ...(partial ? { "Content-Range": `bytes ${start}-${end}/${size}` } : {}),
      "Cache-Control": "private, no-store"
    });
    if (request.method === "HEAD") response.end();
    else createReadStream(filePath, { start, end }).pipe(response);
    return;
  }

  const headers = {
    "Content-Type": mimeTypes[extname(filePath).toLowerCase()] || "application/octet-stream"
  };
  if (pathname === "/theme.css" ||
      pathname === "/theme.js" ||
      pathname === "/motion.js" ||
      pathname === "/service-worker.js" ||
      pathname === "/dashboard.html" ||
      pathname === "/contacts.html" ||
      pathname === "/employee-records.html" ||
      pathname === "/service-tickets.html" ||
      pathname === "/employee-time.html" ||
      pathname === "/schedule.html" ||
      pathname === "/dispatch.html" ||
      pathname === "/route-planning.html" ||
      pathname === "/unifi.html" ||
      pathname === "/documents.html" ||
      pathname === "/office-suite.html" ||
      pathname === "/spreadsheet.html" ||
      pathname === "/document-maker.html" ||
      pathname === "/presentations.html" ||
      pathname === "/inventory.html" ||
      pathname === "/inventory-scanner.html" ||
      pathname === "/catalog.html" ||
      pathname === "/catalog-import.html" ||
      pathname === "/customers.html" ||
      pathname === "/job-workspace.html" ||
      pathname === "/warranties.html" ||
      pathname === "/taxes.html" ||
      pathname === "/approvals.html" ||
      pathname === "/invoices.html" ||
      pathname === "/finance.html" ||
      pathname === "/bills.html" ||
      pathname === "/banking.html" ||
      pathname === "/profit-loss.html" ||
      pathname === "/customer-access.html" ||
      pathname === "/customer-portal.html" ||
      pathname === "/estimates.html" ||
      pathname === "/bids.html" ||
      pathname === "/badge-maker.html" ||
      pathname === "/labels.html" ||
      pathname === "/email.html" ||
      pathname === "/payroll.html" ||
      pathname === "/security.html" ||
      pathname === "/reports.html" ||
      pathname === "/announcements.html" ||
      pathname === "/command-center.html" ||
      pathname === "/field-toolkit.html" ||
      pathname === "/password-vault.html" ||
      pathname === "/settings.html" ||
      pathname === "/activity.html" ||
      pathname === "/account.html" ||
      pathname === "/diagnostics.html" ||
      pathname === "/operations-center.html" ||
      pathname === "/update.html" ||
      pathname === "/install.html" ||
      pathname === "/service-dashboard.html" ||
      pathname === "/servicelogin.html" ||
      pathname === "/login.html") {
    headers["Cache-Control"] = "no-store";
    headers["CDN-Cache-Control"] = "no-store";
    headers["Cloudflare-CDN-Cache-Control"] = "no-store";
  }
  response.writeHead(200, headers);

  if (request.method === "HEAD") {
    response.end();
    return;
  }

  let content = readFileSync(filePath);
  const themedPages = new Set([
    ...adminPages,
    "/dashboard.html",
    "/contacts.html",
    "/settings.html",
    "/activity.html",
    "/account.html",
    "/diagnostics.html",
    "/operations-center.html",
    "/update.html",
    "/install.html",
    "/security.html",
    "/service-dashboard.html",
    "/login.html",
    "/servicelogin.html",
    "/customer-portal.html"
  ]);
  if (extname(filePath).toLowerCase() === ".html" && themedPages.has(pathname)) {
    const html = content.toString("utf8");
    const themeAssets = `
      <script>
        (function(){var t=localStorage.getItem("huber-account-theme")||"system";var e=t==="system"?(matchMedia("(prefers-color-scheme: dark)").matches?"midnight":"professional"):t==="dark"?"midnight":t==="light"?"professional":t;var d=["midnight","ember","steel"].includes(e);document.documentElement.dataset.theme=d?"dark":"light";document.documentElement.dataset.themeStyle=e;document.documentElement.dataset.themeChoice=t;}());
      </script>
      <link rel="stylesheet" href="/theme.css">
      <script src="/theme.js" defer></script>
      <script src="/motion.js" defer></script>
    `;
    content = html.replace("</head>", `${themeAssets}</head>`);
  }
  response.end(content);
}

async function handleSetup(request, response) {
  if (readUsers().length > 0) {
    sendJson(response, 409, { ok: false, message: "Owner account is already configured." });
    return;
  }

  const payload = await readJsonBody(request);
  if (readUsers().length > 0) {
    sendJson(response, 409, { ok: false, message: "Owner account is already configured." });
    return;
  }
  const username = String(payload.username || "").trim();
  const password = String(payload.password || "");

  if (!validUsername(username) || password.length < 12) {
    sendJson(response, 400, {
      ok: false,
      message: "Use a username with 3-40 letters or numbers and a password of at least 12 characters."
    });
    return;
  }

  const salt = randomBytes(16).toString("hex");
  const hash = hashPassword(password, salt);
  const createdAt = new Date().toISOString();

  try {
    writeFileSync(usersPath, `${username}|${salt}|${hash}|Admin|${username}||||${createdAt}\n`, {
      mode: 0o600,
      flag: "wx"
    });
  } catch {
    sendJson(response, 409, { ok: false, message: "Owner account is already configured." });
    return;
  }

  createSession(request, response, {
    username,
    role: "Admin",
    employeeName: username,
    permissions: [...allPermissions],
    createdAt
  });
}

async function handleLogin(request, response) {
  const ip = request.headers["cf-connecting-ip"] || request.socket.remoteAddress || "unknown";
  const attempt = loginAttempts.get(ip);

  if (attempt && attempt.blockedUntil > Date.now()) {
    sendJson(response, 429, { ok: false, message: "Too many attempts. Please wait 15 minutes." });
    return;
  }

  const payload = await readJsonBody(request);
  const username = String(payload.username || "").trim();
  const password = String(payload.password || "");
  const user = readUsers().find((record) => record.username === username);
  const valid = user && verifyPassword(password, user.salt, user.hash);

  if (!valid) {
    const failures = (attempt?.failures || 0) + 1;
    loginAttempts.set(ip, {
      failures,
      blockedUntil: failures >= 5 ? Date.now() + 15 * 60 * 1000 : 0
    });
    logSecurityEvent("login.failed", `Failed login for ${username || "unknown user"}.`, {
      username,
      ip,
      userAgent: request.headers["user-agent"] || ""
    });
    sendJson(response, 401, { ok: false, message: "Incorrect username or password." });
    return;
  }

  let trustedTwoFactorCookie = "";
  if (user.totpSecret && !isTrustedTwoFactorDevice(request, user.username)) {
    const code = String(payload.twoFactorCode || "").replace(/\s/g, "").toUpperCase();
    if (!code) {
      sendJson(response, 202, { ok: false, twoFactorRequired: true });
      return;
    }
    if (!verifyTotp(user.totpSecret, code) && !consumeRecoveryCode(user, code)) {
      sendJson(response, 401, {
        ok: false,
        twoFactorRequired: true,
        message: "Incorrect authentication or recovery code."
      });
      return;
    }
    trustedTwoFactorCookie = createTrustedTwoFactorDevice(request, user.username);
  }

  loginAttempts.delete(ip);
  logSecurityEvent("login.succeeded", `Successful login for ${user.username}.`, {
    username: user.username,
    ip,
    userAgent: request.headers["user-agent"] || ""
  });
  createSession(request, response, user, trustedTwoFactorCookie);
}

function handleLogout(request, response) {
  for (const token of getCookieValues(request, "huber_session")) {
    sessions.delete(hashSessionToken(token));
  }
  persistSessions();
  response.writeHead(200, {
    "Content-Type": "application/json; charset=utf-8",
    "Set-Cookie": "huber_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"
  });
  response.end(JSON.stringify({ ok: true }));
}

function createSession(request, response, user, additionalCookie = "") {
  const token = randomBytes(32).toString("hex");
  const enrollment = twoFactorEnrollmentStatus(user);
  const issuedAt = Date.now();
  sessions.set(hashSessionToken(token), {
    username: user.username,
    role: user.role || "Employee",
    employeeName: user.employeeName || user.username,
    permissions: user.permissions || [],
    twoFactorEnrollmentRequired: enrollment.required,
    issuedAt,
    expiresAt: nextSessionCutoff(issuedAt)
  });
  persistSessions();
  const secure = isSecureRequest(request);
  const expiresAt = nextSessionCutoff(issuedAt);
  const maxAge = Math.max(1, Math.floor((expiresAt - issuedAt) / 1000));
  const cookie = [
    `huber_session=${token}`,
    "HttpOnly",
    "SameSite=Strict",
    "Path=/",
    `Max-Age=${maxAge}`,
    `Expires=${new Date(expiresAt).toUTCString()}`,
    secure ? "Secure" : ""
  ].filter(Boolean).join("; ");

  response.writeHead(200, {
    "Content-Type": "application/json; charset=utf-8",
    "Set-Cookie": additionalCookie ? [cookie, additionalCookie] : cookie,
    "Cache-Control": "no-store"
  });
  response.end(JSON.stringify({
    ok: true,
    role: user.role || "Employee",
    twoFactorSetupRequired: enrollment.required
  }));
}

function getSession(request) {
  for (const token of getCookieValues(request, "huber_session")) {
    const tokenHash = hashSessionToken(token);
    let session = sessions.get(tokenHash);
    if (!session) session = restoreSessionFromStore(tokenHash);
    if (!session) continue;
    if (session.expiresAt <= Date.now()) {
      sessions.delete(tokenHash);
      persistSessions();
      continue;
    }
    const user = readUsers().find((record) => record.username === session.username);
    if (!user) {
      sessions.delete(tokenHash);
      persistSessions();
      continue;
    }
    session.role = user.role || "Employee";
    session.employeeName = user.employeeName || user.username;
    session.permissions = user.permissions || [];
    session.twoFactorEnrollmentRequired = twoFactorEnrollmentStatus(user).required;
    return session;
  }
  return null;
}

function restoreSessionFromStore(tokenHash) {
  if (!existsSync(sessionsPath)) return null;
  try {
    const saved = JSON.parse(readFileSync(sessionsPath, "utf8"));
    const session = saved[tokenHash];
    if (!session?.username || session.expiresAt <= Date.now()) return null;
    sessions.set(tokenHash, session);
    return session;
  } catch {
    return null;
  }
}

function hashSessionToken(token) {
  return createHash("sha256").update(token).digest("hex");
}

function loadSessions() {
  if (!existsSync(sessionsPath)) return;
  try {
    const saved = JSON.parse(readFileSync(sessionsPath, "utf8"));
    const now = Date.now();
    for (const [tokenHash, session] of Object.entries(saved)) {
      if (!session?.username || session.expiresAt <= now) continue;
      session.issuedAt = Number(session.issuedAt) || now;
      session.expiresAt = Math.min(
        Number(session.expiresAt) || nextSessionCutoff(session.issuedAt),
        nextSessionCutoff(session.issuedAt)
      );
      if (session.expiresAt > now) sessions.set(tokenHash, session);
    }
    persistSessions();
  } catch {
    writeFileSync(sessionsPath, "{}\n", { mode: 0o600 });
  }
}

function timeZoneParts(timestamp, timeZone) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23"
  }).formatToParts(new Date(timestamp));
  return Object.fromEntries(parts
    .filter((part) => part.type !== "literal")
    .map((part) => [part.type, Number(part.value)]));
}

function timeZoneOffset(timestamp, timeZone) {
  const parts = timeZoneParts(timestamp, timeZone);
  const represented = Date.UTC(
    parts.year, parts.month - 1, parts.day,
    parts.hour, parts.minute, parts.second
  );
  return represented - Math.floor(timestamp / 1000) * 1000;
}

function localTimeToTimestamp(parts, timeZone) {
  const represented = Date.UTC(
    parts.year, parts.month - 1, parts.day,
    parts.hour, parts.minute || 0, parts.second || 0
  );
  let timestamp = represented;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    timestamp = represented - timeZoneOffset(timestamp, timeZone);
  }
  return timestamp;
}

function nextSessionCutoff(timestamp = Date.now()) {
  const timeZone = process.env.APP_TIME_ZONE || "America/Denver";
  const current = timeZoneParts(timestamp, timeZone);
  const date = new Date(Date.UTC(current.year, current.month - 1, current.day));
  if (current.hour >= sessionCutoffHour) date.setUTCDate(date.getUTCDate() + 1);
  return localTimeToTimestamp({
    year: date.getUTCFullYear(),
    month: date.getUTCMonth() + 1,
    day: date.getUTCDate(),
    hour: sessionCutoffHour,
    minute: 0,
    second: 0
  }, timeZone);
}

function persistSessions() {
  const active = {};
  for (const [tokenHash, session] of sessions) {
    if (session.expiresAt > Date.now()) active[tokenHash] = session;
    else sessions.delete(tokenHash);
  }
  writeFileSync(sessionsPath, `${JSON.stringify(active, null, 2)}\n`, { mode: 0o600 });
}

function readOfflineMutations() {
  if (!existsSync(offlineMutationsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(offlineMutationsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function completedMutation(session, id) {
  if (!id) return null;
  return readOfflineMutations().find((record) =>
    record.id === id && record.username === session.username
  )?.result || null;
}

function rememberMutation(session, id, result) {
  if (!id) return;
  const cutoff = Date.now() - 45 * 24 * 60 * 60 * 1000;
  const records = readOfflineMutations().filter((record) =>
    new Date(record.createdAt).getTime() >= cutoff &&
    !(record.id === id && record.username === session.username)
  );
  records.push({
    id,
    username: session.username,
    result,
    createdAt: new Date().toISOString()
  });
  writeFileSync(offlineMutationsPath, JSON.stringify(records.slice(-5000), null, 2), { mode: 0o600 });
}

function getCookie(request, name) {
  return getCookieValues(request, name)[0] || "";
}

function getCookieValues(request, name) {
  return String(request.headers.cookie || "").split(";")
    .map((cookie) => cookie.trim())
    .filter((cookie) => cookie.startsWith(`${name}=`))
    .map((cookie) => cookie.slice(name.length + 1))
    .filter(Boolean);
}

function isSecureRequest(request) {
  return request.headers["x-forwarded-proto"] === "https" ||
    request.headers["cf-visitor"]?.includes("\"scheme\":\"https\"");
}

function readTrustedTwoFactorDevices() {
  if (!existsSync(trustedTwoFactorPath)) return [];
  try {
    const now = Date.now();
    const records = JSON.parse(readFileSync(trustedTwoFactorPath, "utf8"));
    return Array.isArray(records)
      ? records.filter((record) =>
          /^[a-f0-9]{64}$/.test(record.tokenHash) && record.username && record.expiresAt > now
        )
      : [];
  } catch {
    return [];
  }
}

function writeTrustedTwoFactorDevices(records) {
  writeFileSync(trustedTwoFactorPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function isTrustedTwoFactorDevice(request, username) {
  const token = getCookie(request, "huber_2fa_trusted");
  if (!token) return false;
  const records = readTrustedTwoFactorDevices();
  writeTrustedTwoFactorDevices(records);
  const tokenHash = createHash("sha256").update(token).digest("hex");
  return records.some((record) =>
    record.username === username &&
    timingSafeEqual(Buffer.from(record.tokenHash, "hex"), Buffer.from(tokenHash, "hex"))
  );
}

function createTrustedTwoFactorDevice(request, username) {
  const token = randomBytes(32).toString("hex");
  const records = readTrustedTwoFactorDevices();
  records.push({
    username,
    tokenHash: createHash("sha256").update(token).digest("hex"),
    createdAt: new Date().toISOString(),
    expiresAt: Date.now() + trustedTwoFactorLifetime
  });
  writeTrustedTwoFactorDevices(records);
  return [
    `huber_2fa_trusted=${token}`,
    "HttpOnly",
    "SameSite=Strict",
    "Path=/",
    `Max-Age=${trustedTwoFactorLifetime / 1000}`,
    isSecureRequest(request) ? "Secure" : ""
  ].filter(Boolean).join("; ");
}

function invalidateTrustedTwoFactorDevices(username) {
  writeTrustedTwoFactorDevices(
    readTrustedTwoFactorDevices().filter((record) => record.username !== username)
  );
}

async function handleAccount(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  let users = readUsers();
  let user = users.find((record) => record.username === session.username);
  if (!user) {
    sendJson(response, 404, { ok: false, message: "Account not found." });
    return;
  }
  if (request.method === "GET") {
    const enrollment = twoFactorEnrollmentStatus(user);
    const employee = readEmployees().find((record) =>
      `${record.firstName || ""} ${record.lastName || ""}`.trim().toLowerCase() ===
      String(user.employeeName || "").trim().toLowerCase()
    );
    sendJson(response, 200, {
      ok: true,
      username: user.username,
      employeeName: user.employeeName,
      role: user.role,
      position: employee?.jobTitle || user.role,
      avatarUrl: user.avatarPath ? `/api/account-avatar?v=${encodeURIComponent(user.avatarUpdatedAt || "")}` : "",
      twoFactorEnabled: Boolean(user.totpSecret),
      twoFactorSetupRequired: enrollment.required,
      twoFactorRequiredAt: enrollment.requiredAt,
      twoFactorDaysRemaining: enrollment.daysRemaining,
      twoFactorCanDisable: !enrollment.deadlinePassed,
      twoFactorEnrollmentExempt: enrollment.exempt
    });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }

  const payload = await readJsonBody(request);
  users = readUsers();
  user = users.find((record) => record.username === session.username);
  if (!user) {
    sendJson(response, 404, { ok: false, message: "Account not found." });
    return;
  }
  const action = String(payload.action || "");
  if (action === "change-password") {
    if (!verifyPassword(String(payload.currentPassword || ""), user.salt, user.hash) ||
        String(payload.newPassword || "").length < 12) {
      sendJson(response, 400, {
        ok: false,
        message: "Enter your current password and a new password of at least 12 characters."
      });
      return;
    }
    user.salt = randomBytes(16).toString("hex");
    user.hash = hashPassword(String(payload.newPassword), user.salt);
    writeUsers(users);
    invalidateUserSessions(user.username, request);
    invalidateTrustedTwoFactorDevices(user.username);
    logActivity(session, "account.password-changed", "Changed account password.");
    sendJson(response, 200, { ok: true });
    return;
  }

  if (action === "begin-2fa") {
    if (!verifyPassword(String(payload.currentPassword || ""), user.salt, user.hash)) {
      sendJson(response, 403, { ok: false, message: "Current password is incorrect." });
      return;
    }
    const secret = base32Encode(randomBytes(20));
    session.pendingTotpSecret = secret;
    persistSessions();
    sendJson(response, 200, {
      ok: true,
      secret,
      account: user.username,
      issuer: "Huber I.T. Professionals",
      uri: `otpauth://totp/${encodeURIComponent(`Huber I.T. Professionals:${user.username}`)}?secret=${secret}&issuer=${encodeURIComponent("Huber I.T. Professionals")}`
    });
    return;
  }

  if (action === "enable-2fa") {
    if (!session.pendingTotpSecret ||
        !verifyTotp(session.pendingTotpSecret, String(payload.code || ""))) {
      sendJson(response, 400, { ok: false, message: "Enter the current six-digit authenticator code." });
      return;
    }
    const recoveryCodes = Array.from({ length: 8 }, () =>
      `${randomBytes(3).toString("hex")}-${randomBytes(3).toString("hex")}`.toUpperCase()
    );
    user.totpSecret = session.pendingTotpSecret;
    user.recoveryHashes = recoveryCodes.map(hashRecoveryCode);
    delete session.pendingTotpSecret;
    session.twoFactorEnrollmentRequired = false;
    writeUsers(users);
    persistSessions();
    invalidateTrustedTwoFactorDevices(user.username);
    logActivity(session, "account.2fa-enabled", "Enabled two-factor authentication.");
    sendJson(response, 200, { ok: true, recoveryCodes });
    return;
  }

  if (action === "disable-2fa") {
    if (twoFactorEnrollmentStatus(user).deadlinePassed) {
      sendJson(response, 403, {
        ok: false,
        message: "Two-factor authentication is required for this account and cannot be disabled."
      });
      return;
    }
    const passwordValid = verifyPassword(String(payload.currentPassword || ""), user.salt, user.hash);
    const code = String(payload.code || "").replace(/\s/g, "").toUpperCase();
    if (!passwordValid || (!verifyTotp(user.totpSecret, code) &&
        !user.recoveryHashes.includes(hashRecoveryCode(code)))) {
      sendJson(response, 403, { ok: false, message: "Password or authentication code is incorrect." });
      return;
    }
    user.totpSecret = "";
    user.recoveryHashes = [];
    writeUsers(users);
    invalidateTrustedTwoFactorDevices(user.username);
    logActivity(session, "account.2fa-disabled", "Disabled two-factor authentication.");
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 400, { ok: false, message: "Unknown account action." });
}

async function handleAccountAvatar(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  let users = readUsers();
  let user = users.find((record) => record.username === session.username);
  if (!user) {
    sendJson(response, 404, { ok: false, message: "Account not found." });
    return;
  }

  if (request.method === "GET") {
    if (!user.avatarPath || !existsSync(user.avatarPath)) {
      response.writeHead(404, { "Cache-Control": "no-store" });
      response.end("No account picture.");
      return;
    }
    const extension = extname(user.avatarPath).toLowerCase();
    response.writeHead(200, {
      "Content-Type": mimeTypes[extension] || "image/jpeg",
      "Cache-Control": "no-store, private",
      "Vary": "Cookie"
    });
    createReadStream(user.avatarPath).pipe(response);
    return;
  }

  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }

  const payload = await readJsonBody(request);
  users = readUsers();
  user = users.find((record) => record.username === session.username);
  if (!user) {
    sendJson(response, 404, { ok: false, message: "Account not found." });
    return;
  }
  let saved;
  try {
    saved = saveImageDataUrl(
      payload.image,
      accountAvatarsPath,
      createHash("sha256").update(user.username).digest("hex").slice(0, 18)
    );
  } catch (error) {
    sendJson(response, 400, { ok: false, message: error.message });
    return;
  }
  const filePath = saved.filePath;
  user.avatarPath = filePath;
  user.avatarUpdatedAt = new Date().toISOString();
  writeUsers(users);
  logActivity(session, "account.avatar-updated", "Updated account picture.");
  sendJson(response, 200, {
    ok: true,
    avatarUrl: `/api/account-avatar?v=${encodeURIComponent(user.avatarUpdatedAt)}`
  });
}

function saveImageDataUrl(dataUrl, directory, baseName) {
  const match = String(dataUrl || "").match(/^data:image\/(png|jpeg|jpg|webp);base64,([a-z0-9+/=]+)$/i);
  if (!match) throw new Error("Upload a PNG, JPG, or WebP image.");
  const extension = match[1].toLowerCase() === "jpeg" ? "jpg" : match[1].toLowerCase();
  const image = Buffer.from(match[2], "base64");
  if (!image.length || image.length > 800_000) throw new Error("Choose a smaller picture.");
  const safeBaseName = String(baseName || randomBytes(8).toString("hex")).replace(/[^a-z0-9_-]/gi, "").slice(0, 80);
  const filePath = join(directory, `${safeBaseName || randomBytes(8).toString("hex")}.${extension}`);
  writeFileSync(filePath, image, { mode: 0o600 });
  return { filePath, extension };
}

async function handleAdminPassword(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can reset passwords." });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const payload = await readJsonBody(request);
  const username = String(payload.username || "");
  const password = String(payload.newPassword || "");
  const users = readUsers();
  const user = users.find((record) => record.username === username);
  if (!user || password.length < 12) {
    sendJson(response, 400, { ok: false, message: "Select a user and enter at least 12 characters." });
    return;
  }
  user.salt = randomBytes(16).toString("hex");
  user.hash = hashPassword(password, user.salt);
  if (payload.clearTwoFactor) {
    user.totpSecret = "";
    user.recoveryHashes = [];
  }
  writeUsers(users);
  invalidateUserSessions(username, username === session.username ? request : null);
  invalidateTrustedTwoFactorDevices(username);
  logActivity(session, "account.password-reset",
    `Reset ${user.employeeName || username}'s password${payload.clearTwoFactor ? " and two-factor authentication" : ""}.`);
  sendJson(response, 200, { ok: true });
}

function invalidateUserSessions(username, keepRequest = null) {
  const keepHash = keepRequest
    ? hashSessionToken(getCookie(keepRequest, "huber_session"))
    : "";
  for (const [tokenHash, activeSession] of sessions) {
    if (activeSession.username === username && tokenHash !== keepHash) sessions.delete(tokenHash);
  }
  persistSessions();
}

function readUsers() {
  if (!existsSync(usersPath)) return [];
  return readFileSync(usersPath, "utf8")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith("#"))
    .map((line) => {
      const [
        username,
        salt,
        hash,
        role = "Admin",
        employeeName = username,
        permissionText,
        totpSecret = "",
        recoveryText = "",
        createdAt = "",
        avatarPath = "",
        avatarUpdatedAt = ""
      ] = line.split("|");
      const permissions = permissionText === undefined
        ? role.toLowerCase() === "admin" ? [...allPermissions] : []
        : permissionText.split(",").filter((permission) => allPermissions.includes(permission));
      return {
        username,
        salt,
        hash,
        role: username === "Huber58" ? "Admin" : role,
        employeeName,
        permissions: username === "Huber58" ? [...allPermissions] : permissions,
        totpSecret,
        recoveryHashes: recoveryText ? recoveryText.split(";").filter(Boolean) : [],
        createdAt,
        avatarPath,
        avatarUpdatedAt
      };
    })
    .filter((user) => user.username && user.salt && user.hash);
}

function migrateUserCreatedDates() {
  if (!existsSync(usersPath)) return;
  const users = readUsers();
  let changed = false;
  const now = new Date().toISOString();
  for (const user of users) {
    if (user.createdAt && !Number.isNaN(new Date(user.createdAt).getTime())) continue;
    user.createdAt = now;
    changed = true;
  }
  if (changed) writeUsers(users);
}

function ensureAdminEmployeeRecord() {
  const adminEmployee = {
    id: "huber58-christian-huber",
    firstName: "Christian",
    lastName: "Huber",
    jobTitle: "Owner",
    hireDate: "2026-07-08",
    wage: "0",
    payType: "Hourly",
    status: "Active",
    phone: "",
    email: "christian.huber@huberitps.com",
    notes: "Permanent owner employee record attached to the Huber58 administrator account."
  };
  const employees = readEmployees();
  const existingIndex = employees.findIndex((employee) =>
    employee.id === adminEmployee.id ||
    `${employee.firstName || ""} ${employee.lastName || ""}`.trim().toLowerCase() === "christian huber"
  );
  if (existingIndex >= 0) {
    employees[existingIndex] = {
      ...adminEmployee,
      ...employees[existingIndex],
      id: adminEmployee.id,
      jobTitle: "Owner",
      status: "Active"
    };
  } else {
    employees.unshift(adminEmployee);
  }
  writeEmployees(employees);

  const users = readUsers();
  const admin = users.find((user) => user.username === "Huber58");
  if (admin && admin.employeeName !== "Christian Huber") {
    admin.employeeName = "Christian Huber";
    writeUsers(users);
  }
}

function twoFactorEnrollmentStatus(user) {
  const exempt = user?.username === "Huber58" &&
    String(process.env.REQUIRE_ADMIN_2FA || "true").toLowerCase() !== "true";
  const createdAt = new Date(user?.createdAt || 0).getTime();
  const requiredAt = Number.isFinite(createdAt)
    ? createdAt + twoFactorEnrollmentGrace
    : Date.now() + twoFactorEnrollmentGrace;
  const deadlinePassed = !exempt && Date.now() >= requiredAt;
  const required = Boolean(user && !user.totpSecret && deadlinePassed);
  return {
    required,
    deadlinePassed,
    exempt,
    requiredAt: new Date(requiredAt).toISOString(),
    daysRemaining: required
      ? 0
      : Math.max(0, Math.ceil((requiredAt - Date.now()) / (24 * 60 * 60 * 1000)))
  };
}

async function handleEmployeeUser(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can create user accounts." });
    return;
  }

  const payload = await readJsonBody(request);
  const username = String(payload.username || "").trim();
  const password = String(payload.password || "");
  const employeeName = String(payload.employeeName || "").trim();
  const roleName = String(payload.role || "Employee").trim();
  const role = readRoles().find((record) => record.name === roleName);

  if (!validUsername(username) || password.length < 12 || !employeeName || !role ||
      roleName === "Admin") {
    sendJson(response, 400, {
      ok: false,
      message: "Employee login requires a valid role, username, and password of at least 12 characters."
    });
    return;
  }

  const users = readUsers();
  if (users.some((user) => user.username === username)) {
    sendJson(response, 409, { ok: false, message: "That username already exists." });
    return;
  }

  const salt = randomBytes(16).toString("hex");
  users.push({
    username,
    salt,
    hash: hashPassword(password, salt),
    role: role.name,
    employeeName,
    permissions: [],
    createdAt: new Date().toISOString()
  });
  writeUsers(users);
  logActivity(session, "user.created", `Created login for ${employeeName}.`);
  sendJson(response, 200, { ok: true });
}

async function handleUserAccess(request, response) {
  const session = getSession(request);
  if (request.method === "GET") {
    if (!hasPermission(session, "employee-records")) {
      sendJson(response, 403, { ok: false, message: "Employee Records access required." });
      return;
    }
    const employees = readEmployees();
    const users = readUsers().map((user) => ({
      username: session.username === "Huber58" ? user.username : "",
      employeeName: user.employeeName,
      role: user.role,
      position: employees.find((employee) =>
        `${employee.firstName || ""} ${employee.lastName || ""}`.trim().toLowerCase() ===
        String(user.employeeName || "").trim().toLowerCase()
      )?.jobTitle || user.role,
      permissions: session.username === "Huber58" ? user.permissions || [] : []
    }));
    sendJson(response, 200, { ok: true, users });
    return;
  }

  if (request.method === "POST") {
    if (!session || session.username !== "Huber58") {
      sendJson(response, 403, { ok: false, message: "Only Huber58 can manage access." });
      return;
    }
    const payload = await readJsonBody(request);
    const employeeName = String(payload.employeeName || "").trim();
    const permissions = Array.isArray(payload.permissions)
      ? payload.permissions.filter((permission) => allPermissions.includes(permission))
      : [];
    const users = readUsers();
    const user = users.find((record) => record.employeeName === employeeName);
    if (!user) {
      sendJson(response, 404, {
        ok: false,
        message: "Create a user account for this employee before assigning access."
      });
      return;
    }
    if (user.username === "Huber58") {
      sendJson(response, 400, { ok: false, message: "Huber58 always has full access." });
      return;
    }
    user.permissions = permissions;
    writeUsers(users);
    for (const activeSession of sessions.values()) {
      if (activeSession.username === user.username) activeSession.permissions = permissions;
    }
    persistSessions();
    logActivity(session, "access.updated", `Updated dashboard access for ${employeeName}.`);
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function defaultAccessTemplates() {
  return [
    {
      id: "office-staff",
      name: "Office Staff",
      permissions: ["service-tickets", "job-workspace", "customers", "warranties", "schedule", "documents", "office-suite", "spreadsheets", "design-center", "field-toolkit", "inventory", "catalog", "estimates", "bids", "badge-maker", "email"]
    },
    {
      id: "field-technician",
      name: "Field Technician",
      permissions: ["service-tickets", "customers", "warranties", "schedule", "route-planning", "availability", "documents", "field-toolkit", "inventory-scanner"]
    },
    {
      id: "finance-team",
      name: "Finance Team",
      permissions: ["invoicing", "estimates", "finance", "bills", "banking", "profit-loss", "reports", "payroll"]
    },
    {
      id: "operations-manager",
      name: "Operations Manager",
      permissions: ["employee-records", "service-tickets", "job-workspace", "customers", "warranties", "employee-time", "schedule", "dispatch", "route-planning", "availability", "documents", "office-suite", "spreadsheets", "design-center", "field-toolkit", "inventory", "inventory-scanner", "catalog", "invoicing", "estimates", "bids", "badge-maker", "email", "approvals", "reports", "announcements", "command-center", "unifi"]
    }
  ];
}

function readAccessTemplates() {
  if (!existsSync(accessTemplatesPath)) return defaultAccessTemplates();
  try {
    const templates = JSON.parse(readFileSync(accessTemplatesPath, "utf8"));
    return Array.isArray(templates) ? templates : defaultAccessTemplates();
  } catch {
    return defaultAccessTemplates();
  }
}

async function handleAccessTemplates(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can manage access templates." });
    return;
  }
  const templates = readAccessTemplates();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, templates });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const name = String(payload.name || "").trim().slice(0, 50);
    const permissions = Array.isArray(payload.permissions)
      ? [...new Set(payload.permissions.filter((permission) => allPermissions.includes(permission)))]
      : [];
    if (!name || !permissions.length) {
      sendJson(response, 400, { ok: false, message: "Enter a template name and select at least one permission." });
      return;
    }
    const existing = templates.find((template) => template.id === payload.id);
    const duplicate = templates.find((template) =>
      template.id !== existing?.id && template.name.toLowerCase() === name.toLowerCase()
    );
    if (duplicate) {
      sendJson(response, 409, { ok: false, message: "An access template with that name already exists." });
      return;
    }
    const template = {
      id: existing?.id || randomBytes(10).toString("hex"),
      name,
      permissions,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    const index = templates.findIndex((item) => item.id === template.id);
    if (index >= 0) templates[index] = template;
    else templates.push(template);
    writeFileSync(accessTemplatesPath, JSON.stringify(templates, null, 2), { mode: 0o600 });
    logActivity(session, "access-template.saved", `Saved access template ${template.name}.`);
    sendJson(response, 200, { ok: true, template, templates });
    return;
  }
  if (request.method === "DELETE") {
    const existing = templates.find((template) => template.id === payload.id);
    if (!existing) {
      sendJson(response, 404, { ok: false, message: "Access template not found." });
      return;
    }
    const remaining = templates.filter((template) => template.id !== payload.id);
    writeFileSync(accessTemplatesPath, JSON.stringify(remaining, null, 2), { mode: 0o600 });
    logActivity(session, "access-template.deleted", `Deleted access template ${existing.name}.`);
    sendJson(response, 200, { ok: true, templates: remaining });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

async function handleRoles(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can manage roles." });
    return;
  }

  const roles = readRoles();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, roles });
    return;
  }

  const payload = await readJsonBody(request);
  const name = String(payload.name || "").trim();

  if (request.method === "POST") {
    if (!/^[a-zA-Z][a-zA-Z0-9 ._-]{1,29}$/.test(name) || name === "Admin") {
      sendJson(response, 400, { ok: false, message: "Enter a valid custom role name." });
      return;
    }
    const role = { name };
    const index = roles.findIndex((record) => record.name === name);
    if (index >= 0) roles[index] = role;
    else roles.push(role);
    writeRoles(roles);
    logActivity(session, "role.saved", `Saved the ${name} role.`);
    sendJson(response, 200, { ok: true, role });
    return;
  }

  if (request.method === "DELETE") {
    if (name === "Admin" || name === "Employee") {
      sendJson(response, 400, { ok: false, message: "Built-in roles cannot be deleted." });
      return;
    }
    if (readUsers().some((user) => user.role === name)) {
      sendJson(response, 409, { ok: false, message: "This role is assigned to a user." });
      return;
    }
    writeRoles(roles.filter((role) => role.name !== name));
    logActivity(session, "role.deleted", `Deleted the ${name} role.`);
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readRoles() {
  const builtIn = [
    { name: "Admin" },
    { name: "Employee" }
  ];
  if (!existsSync(rolesPath)) return builtIn;
  try {
    const custom = JSON.parse(readFileSync(rolesPath, "utf8")) || [];
    return [
      ...builtIn,
      ...custom
        .filter((role) => role.name !== "Admin" && role.name !== "Employee")
        .map((role) => ({ name: role.name }))
    ];
  } catch {
    return builtIn;
  }
}

function writeRoles(roles) {
  const custom = roles
    .filter((role) => role.name !== "Admin" && role.name !== "Employee")
    .map((role) => ({ name: role.name }));
  writeFileSync(rolesPath, JSON.stringify(custom, null, 2), { mode: 0o600 });
}

function billingTransaction(response, operation) {
  let status, headers, body;
  const buffered = {
    req: response.req,
    writeHead(code, values) { status = code; headers = values; },
    end(value) { body = value; }
  };
  const rollback = new Error("Request rejected");
  try {
    structuredStore.withTransaction(() => {
      operation(buffered);
      if (status >= 400) throw rollback;
    });
  } catch (error) {
    if (error !== rollback) throw error;
  }
  response.writeHead(status, headers);
  response.end(body);
}

async function handleTickets(request, response) {
  const payload = request.method === "GET" ? null : await readJsonBody(request);
  return billingTransaction(response, buffered => handleTicketsParsed(request, buffered, payload));
}

function handleTicketsParsed(request, response, payload) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }

  if (request.method === "GET") {
    const tickets = readTickets();
    const canViewAll = hasPermission(session, "service-tickets") ||
      hasPermission(session, "schedule") ||
      hasPermission(session, "reports");
    const visibleTickets = canViewAll
      ? tickets
      : tickets.filter((ticket) =>
          ticketMatchesEmployee(ticket, session)
        );
    sendJson(response, 200, { ok: true, tickets: visibleTickets });
    return;
  }

  if (!hasPermission(session, "service-tickets")) {
    sendJson(response, 403, { ok: false, message: "Service Ticket access required." });
    return;
  }

  const tickets = readTickets();

  if (request.method === "POST") {
    const ticket = payload.ticket;
    const isOffice = ticket?.isOffice === true;
    const nonChargeable = ticket?.ticketType !== "Contract" && ticket?.nonChargeable === true;
    const nonChargeableReason = String(ticket?.nonChargeableReason || "").trim().slice(0, 80);
    const officeTitle = String(ticket?.officeTitle || "").trim().slice(0, 160);
    if (!ticket?.id || !ticket?.description ||
        (nonChargeable && !nonChargeableReason) ||
        (isOffice ? (!officeTitle || !validDateOnly(ticket.scheduledDate) || ticket.ticketType === "Contract") : !ticket?.customer)) {
      sendJson(response, 400, { ok: false, message: "Ticket information is incomplete." });
      return;
    }
    ticket.isOffice = isOffice;
    ticket.nonChargeable = nonChargeable;
    ticket.nonChargeableReason = nonChargeable ? nonChargeableReason : "";
    ticket.phases = ticket?.ticketType === "Contract"
      ? (Array.isArray(ticket.phases) ? ticket.phases : []).slice(0, 50).map((phase) => ({
          id: String(phase?.id || randomBytes(8).toString("hex")).slice(0, 80),
          name: String(phase?.name || "").trim().slice(0, 120),
          status: ["Not Started", "In Progress", "Complete", "On Hold"].includes(phase?.status)
            ? phase.status : "Not Started",
          startDate: validDateOnly(phase?.startDate) ? phase.startDate : "",
          endDate: validDateOnly(phase?.endDate) ? phase.endDate : "",
          notes: String(phase?.notes || "").trim().slice(0, 500)
        })).filter((phase) => phase.name)
      : [];
    if (ticket.phases.some((phase) =>
      phase.startDate && phase.endDate && phase.startDate > phase.endDate
    )) {
      sendJson(response, 400, {
        ok: false,
        message: "A contract phase end date cannot be before its start date."
      });
      return;
    }
    const assignees = normalizedTicketAssignees(ticket);
    const activeEmployeeNames = new Set(readEmployees()
      .filter((employee) => employee.status !== "Inactive")
      .map((employee) => `${employee.firstName || ""} ${employee.lastName || ""}`.trim()));
    if (assignees.some((name) => !activeEmployeeNames.has(name))) {
      sendJson(response, 400, { ok: false, message: "Choose active employees for this ticket." });
      return;
    }
    setTicketAssignees(ticket, assignees);
    ticket.officeTitle = isOffice ? officeTitle : "";
    if (isOffice) {
      ticket.customerId = "";
      ticket.customer = officeTitle;
      ticket.company = "";
      ticket.phone = "";
      ticket.email = "";
      ticket.address = "";
      ticket.serviceType = "Office";
    }
    const index = tickets.findIndex((record) => record.id === ticket.id);
    const previous = index >= 0 ? tickets[index] : null;
    if (!previous || Boolean(previous.nonChargeable) !== nonChargeable) {
      ticket.number = tickets
        .filter((record) => record.id !== ticket.id &&
          (nonChargeable
            ? record.ticketType !== "Contract" && record.nonChargeable
            : !record.nonChargeable || record.ticketType === "Contract"))
        .reduce((highest, record) => Math.max(highest, Number(record.number) || 0), 0) + 1;
    } else ticket.number = previous.number;
    const previousSnapshot = previous ? structuredClone(previous) : null;
    if (!Array.isArray(ticket.reassignmentFlags) && Array.isArray(previous?.reassignmentFlags)) {
      ticket.reassignmentFlags = structuredClone(previous.reassignmentFlags);
      setTicketAssignees(ticket, assignees);
    }
    ticket.createdAt = previous?.createdAt || ticket.createdAt || new Date().toISOString();
    ticket.updatedAt = new Date().toISOString();
    ticket.updatedBy = session.username;
    if (index >= 0) tickets[index] = ticket;
    else tickets.push(ticket);
    writeTickets(tickets);
    logActivity(session, index >= 0 ? "ticket.updated" : "ticket.created",
      `${index >= 0 ? "Updated" : "Created"} ${ticketLabel(ticket)} for ${isOffice ? `office: ${officeTitle}` : ticket.customer}.`, {
        undo: { collection: "tickets", recordId: ticket.id, before: previousSnapshot, after: structuredClone(ticket) }
      });
    createTicketNotification(previous, ticket);
    broadcastAllServiceEvent("tickets-updated", { ticketId: ticket.id });
    sendJson(response, 200, {
      ok: true,
      ticket,
      warnings: availabilityWarningsForTicket(ticket)
    });
    return;
  }

  if (request.method === "DELETE") {
    const removed = tickets.find((ticket) => ticket.id === payload.id);
    if (readInvoices().some(invoice => invoice.ticketId === payload.id) ||
        readFinance().payments.some(payment => payment.contractTicketId === payload.id)) {
      sendJson(response, 409, { ok: false, message: "This ticket has billing records and cannot be deleted. Keep it closed to preserve its history." });
      return;
    }
    writeTickets(tickets.filter((ticket) => ticket.id !== payload.id));
    if (removed) logActivity(session, "ticket.deleted", `Deleted ${ticketLabel(removed)} for ${removed.customer}.`, {
      undo: { collection: "tickets", recordId: removed.id, before: structuredClone(removed), after: null }
    });
    broadcastAllServiceEvent("tickets-updated", { ticketId: payload.id });
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

const defaultNonChargeableReasons = [
  "Warranty",
  "Callback / Correction",
  "Courtesy Service",
  "Manufacturer Support"
];

async function handleNonChargeableReasons(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "service-tickets")) {
    sendJson(response, session ? 403 : 401, {
      ok: false,
      message: session ? "Service Ticket access required." : "Please sign in."
    });
    return;
  }
  const reasons = readNonChargeableReasons();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, reasons });
    return;
  }
  if (request.method === "POST") {
    const payload = await readJsonBody(request);
    const reason = String(payload.reason || "").trim().slice(0, 80);
    if (!reason) {
      sendJson(response, 400, { ok: false, message: "Enter a reason." });
      return;
    }
    if (!reasons.some((item) => item.toLowerCase() === reason.toLowerCase())) {
      reasons.push(reason);
      reasons.sort((a, b) => a.localeCompare(b));
      writeFileSync(nonChargeableReasonsPath, JSON.stringify(reasons, null, 2), { mode: 0o600 });
      logActivity(session, "ticket.reason.created", `Created non-chargeable service reason ${reason}.`);
    }
    sendJson(response, 200, { ok: true, reasons });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readNonChargeableReasons() {
  let saved = [];
  try {
    saved = JSON.parse(readFileSync(nonChargeableReasonsPath, "utf8"));
  } catch {
    saved = [];
  }
  const seen = new Set();
  return [...defaultNonChargeableReasons, ...(Array.isArray(saved) ? saved : [])]
    .map((reason) => String(reason || "").trim().slice(0, 80))
    .filter((reason) => reason && !seen.has(reason.toLowerCase()) && seen.add(reason.toLowerCase()))
    .sort((a, b) => a.localeCompare(b));
}

async function handleDispatch(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "dispatch")) {
    sendJson(response, session ? 403 : 401, {
      ok: false,
      message: session ? "Dispatch access required." : "Please sign in."
    });
    return;
  }

  if (request.method === "GET") {
    const url = new URL(request.url, `http://${request.headers.host}`);
    const requestedStart = String(url.searchParams.get("week") || "");
    const today = new Date(`${businessToday()}T12:00:00`);
    const monday = new Date(today);
    monday.setDate(today.getDate() - ((today.getDay() + 6) % 7));
    const weekStart = /^\d{4}-\d{2}-\d{2}$/.test(requestedStart)
      ? requestedStart
      : monday.toISOString().slice(0, 10);
    const end = new Date(`${weekStart}T12:00:00`);
    end.setDate(end.getDate() + 6);
    const weekEnd = end.toISOString().slice(0, 10);
    sendJson(response, 200, {
      ok: true,
      weekStart,
      weekEnd,
      employees: readEmployees()
        .filter((employee) => employee.status !== "Inactive")
        .map((employee) => ({
          id: employee.id,
          name: `${employee.firstName || ""} ${employee.lastName || ""}`.trim()
        }))
        .filter((employee) => employee.name)
        .sort((a, b) => a.name.localeCompare(b.name)),
      tickets: readTickets().filter((ticket) => ticket.status !== "Closed"),
      availability: readAvailability().filter((record) =>
        record.status === "Approved" &&
        record.startDate <= weekEnd &&
        record.endDate >= weekStart
      )
    });
    return;
  }

  if (request.method === "POST") {
    const payload = await readJsonBody(request);
    const assignedToMany = Array.isArray(payload.assignedToMany)
      ? payload.assignedToMany.map((name) => String(name || "").trim()).filter(Boolean)
      : [String(payload.assignedTo || "").trim()].filter(Boolean);
    const scheduledDate = String(payload.scheduledDate || "");
    if (!payload.id || (scheduledDate && !/^\d{4}-\d{2}-\d{2}$/.test(scheduledDate))) {
      sendJson(response, 400, { ok: false, message: "Ticket and scheduled date are required." });
      return;
    }
    const activeNames = new Set(readEmployees()
      .filter((employee) => employee.status !== "Inactive")
      .map((employee) => `${employee.firstName || ""} ${employee.lastName || ""}`.trim()));
    if (assignedToMany.some((name) => !activeNames.has(name))) {
      sendJson(response, 400, { ok: false, message: "Choose an active employee." });
      return;
    }
    const tickets = readTickets();
    const ticket = tickets.find((record) => record.id === payload.id);
    if (!ticket || ticket.status === "Closed") {
      sendJson(response, 404, { ok: false, message: "Open ticket not found." });
      return;
    }
    const previous = structuredClone(ticket);
    setTicketAssignees(ticket, assignedToMany);
    ticket.scheduledDate = scheduledDate;
    writeTickets(tickets);
    logActivity(session, "ticket.dispatched",
      `Dispatched ${ticketLabel(ticket)} to ${ticket.assignedTo || "Unassigned"}${scheduledDate ? ` on ${scheduledDate}` : " without a date"}.`);
    createTicketNotification(previous, ticket);
    broadcastAllServiceEvent("tickets-updated", { ticketId: ticket.id });
    broadcastAllServiceEvent("dashboard-updated", { area: "dispatch" });
    sendJson(response, 200, {
      ok: true,
      ticket,
      warnings: availabilityWarningsForTicket(ticket)
    });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

async function handleTicketHours(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }

  const payload = await readJsonBody(request);
  const completed = completedMutation(session, payload.clientMutationId);
  if (completed) {
    sendJson(response, 200, completed);
    return;
  }
  const tickets = readTickets();
  const ticket = tickets.find((record) => record.id === payload.id);

  if (!ticket) {
    sendJson(response, 404, { ok: false, message: "Ticket not found." });
    return;
  }

  if (!hasPermission(session, "service-tickets") && !ticketMatchesEmployee(ticket, session)) {
    sendJson(response, 403, { ok: false, message: "This ticket is not assigned to you." });
    return;
  }

  const rawHours = String(payload.hoursUsed ?? "").trim();
  const hours = rawHours ? Number(rawHours) : 0;
  if (!Number.isFinite(hours) || hours < 0) {
    sendJson(response, 400, { ok: false, message: "Enter valid hours of zero or greater." });
    return;
  }

  const allowedStatuses = ["In Progress", "Closed", "Incomplete Remove", "Multi Day"];
  if (!allowedStatuses.includes(payload.status)) {
    sendJson(response, 400, { ok: false, message: "Choose a valid ticket status." });
    return;
  }
  if (ticket.status === "Open" && hours <= 0 && ["In Progress", "Closed"].includes(payload.status)) {
    sendJson(response, 400, { ok: false, message: "Log the first hours before progressing or closing this ticket." });
    return;
  }

  const currentAssignee = ticketAssigneeForSession(ticket, session);
  if (!currentAssignee) {
    sendJson(response, 403, { ok: false, message: "This ticket is not assigned to your employee record." });
    return;
  }
  const employeeStatus = payload.status;
  const otherAssignees = ticketAssignees(ticket).filter((name) =>
    name.toLowerCase() !== currentAssignee.toLowerCase());
  if (employeeStatus === "Closed" && otherAssignees.length) {
    const permitted = new Set(["Multi Day", "Closed", "Incomplete Remove"]);
    const blockers = otherAssignees.filter((name) =>
      !permitted.has(ticketAssigneeProgress(ticket, name)?.status));
    if (blockers.length) {
      sendJson(response, 409, {
        ok: false,
        message: `This ticket cannot be closed yet. Waiting for ${blockers.join(", ")} to select Multi Day, Closed, or Incomplete Remove.`,
        blockers
      });
      return;
    }
  }

  setTicketAssigneeProgress(ticket, currentAssignee, session, employeeStatus);
  const allAssignmentsResolved = ticketAssignees(ticket).every((name) =>
    ticketAssigneeProgress(ticket, name)?.status === "Closed");
  const effectiveStatus = allAssignmentsResolved ? "Closed" : "In Progress";

  const resolution = String(payload.resolution || "").trim();
  if (!resolution) {
    sendJson(response, 400, { ok: false, message: "Please describe the work completed." });
    return;
  }

  let newReassignmentFlag = null;
  if (employeeStatus === "Incomplete Remove") {
    if (!Array.isArray(ticket.reassignmentFlags)) ticket.reassignmentFlags = [];
    const employeeKey = currentAssignee.toLowerCase();
    const existingFlag = ticket.reassignmentFlags.find((entry) =>
      String(entry.employeeName || "").trim().toLowerCase() === employeeKey);
    const now = new Date().toISOString();
    const nextFlag = {
      id: existingFlag?.id || randomBytes(12).toString("hex"),
      employeeName: currentAssignee,
      username: session.username,
      reason: resolution,
      createdAt: existingFlag?.createdAt || now,
      updatedAt: now
    };
    if (existingFlag) Object.assign(existingFlag, nextFlag);
    else {
      ticket.reassignmentFlags.push(nextFlag);
      newReassignmentFlag = nextFlag;
    }
  }

  if (effectiveStatus === "Closed") {
    const signatureData = String(payload.signatureData || "");
    if (!ticket.isOffice && !signatureData && !ticket.signature) {
      sendJson(response, 400, { ok: false, message: "Customer signature is required to close the ticket." });
      return;
    }
    if (!ticket.isOffice && signatureData) {
      const match = signatureData.match(/^data:image\/png;base64,([a-zA-Z0-9+/=]+)$/);
      const image = match ? Buffer.from(match[1], "base64") : null;
      if (!image?.length || image.length > 1_000_000) {
        sendJson(response, 400, { ok: false, message: "Invalid customer signature." });
        return;
      }
      const storedName = `${ticket.id}-${randomBytes(8).toString("hex")}.png`;
      writeFileSync(join(ticketSignaturesPath, storedName), image, { mode: 0o600 });
      ticket.signature = {
        storedName,
        signedAt: new Date().toISOString(),
        signedBy: String(payload.signedBy || ticket.customer).trim() || ticket.customer,
        employeeName: session.employeeName || session.username
      };
    }
  }

  if (!Array.isArray(ticket.workLogs)) {
    ticket.workLogs = [];
    ticket.legacyHours = Number(ticket.hoursUsed) || 0;
  }
  ticket.workLogs.push({
    id: randomBytes(12).toString("hex"),
    username: session.username,
    employeeName: session.employeeName || session.username,
    hours,
    status: employeeStatus,
    resolution,
    loggedAt: new Date().toISOString()
  });
  const loggedHours = ticket.workLogs.reduce((total, entry) =>
    total + (Number(entry.hours) || 0), 0);
  ticket.hoursUsed = String((Number(ticket.legacyHours) || 0) + loggedHours);
  ticket.status = effectiveStatus;
  ticket.resolution = resolution;
  ticket.updatedAt = new Date().toISOString();
  ticket.updatedBy = session.username;
  writeTickets(tickets);
  if (newReassignmentFlag) {
    notifyOfficeOfReassignment(ticket, newReassignmentFlag, session.username);
  }
  if (effectiveStatus === "Closed" && ticket.sourceEstimateId) {
    const estimates = readEstimates();
    const estimate = estimates.find((record) => record.id === ticket.sourceEstimateId);
    if (estimate && !["Done", "Paid"].includes(estimate.status)) {
      estimate.status = "Done";
      estimate.updatedAt = new Date().toISOString();
      estimate.updatedBy = session.username;
      writeEstimates(estimates);
      logActivity(session, "workflow.estimate-completed",
        `Marked estimate Q-${String(estimate.number).padStart(4, "0")} Done when ${ticketLabel(ticket)} closed.`);
    }
  }
  logActivity(session, "ticket.work",
    `Logged ${hours} hours on ${ticketLabel(ticket)} (${employeeStatus}; office status ${effectiveStatus}).`);
  broadcastAllServiceEvent("tickets-updated", { ticketId: ticket.id });
  broadcastAllServiceEvent("dashboard-updated", { area: "service-tickets", ticketId: ticket.id });
  const result = {
    ok: true,
    hoursUsed: ticket.hoursUsed,
    status: ticket.status,
    employeeStatus,
    assigneeProgress: ticket.assigneeProgress,
    resolution: ticket.resolution,
    workLog: ticket.workLogs[ticket.workLogs.length - 1]
  };
  rememberMutation(session, payload.clientMutationId, result);
  sendJson(response, 200, result);
}

function ticketAssignees(ticket) {
  const source = Array.isArray(ticket?.assignedToMany) && ticket.assignedToMany.length
    ? ticket.assignedToMany
    : String(ticket?.assignedTo || "").split(",");
  return [...new Set(source.map((name) => String(name || "").trim()).filter(Boolean))];
}

function ticketAssigneeForSession(ticket, session) {
  const employeeName = String(session?.employeeName || "").trim().toLowerCase();
  const username = String(session?.username || "").trim().toLowerCase();
  return ticketAssignees(ticket).find((name) => {
    const assigned = name.toLowerCase();
    return assigned === employeeName || assigned.split(/\s+/)[0] === username;
  }) || "";
}

function ticketAssigneeProgress(ticket, employeeName) {
  const key = String(employeeName || "").trim().toLowerCase();
  return (Array.isArray(ticket?.assigneeProgress) ? ticket.assigneeProgress : [])
    .find((entry) => String(entry.employeeName || "").trim().toLowerCase() === key);
}

function setTicketAssigneeProgress(ticket, employeeName, session, status) {
  if (!Array.isArray(ticket.assigneeProgress)) ticket.assigneeProgress = [];
  const key = String(employeeName || "").trim().toLowerCase();
  const entry = ticket.assigneeProgress.find((record) =>
    String(record.employeeName || "").trim().toLowerCase() === key);
  const next = {
    employeeName,
    username: session.username,
    status,
    updatedAt: new Date().toISOString()
  };
  if (entry) Object.assign(entry, next);
  else ticket.assigneeProgress.push(next);
  return next;
}

function normalizedTicketAssignees(ticket) {
  if (Array.isArray(ticket?.assignedToMany)) return ticketAssignees(ticket);
  return ticketAssignees({ assignedToMany: [ticket?.assignedTo] });
}

function setTicketAssignees(ticket, names) {
  const unique = [...new Set((Array.isArray(names) ? names : [names])
    .map((name) => String(name || "").trim()).filter(Boolean))];
  ticket.assignedToMany = unique;
  ticket.assignedTo = unique.join(", ");
  const active = new Set(unique.map((name) => name.toLowerCase()));
  ticket.assigneeProgress = (Array.isArray(ticket.assigneeProgress) ? ticket.assigneeProgress : [])
    .filter((entry) => active.has(String(entry.employeeName || "").trim().toLowerCase()));
  ticket.reassignmentFlags = (Array.isArray(ticket.reassignmentFlags) ? ticket.reassignmentFlags : [])
    .filter((entry) => active.has(String(entry.employeeName || "").trim().toLowerCase()));
  return unique;
}

function ticketMatchesEmployee(ticket, session) {
  const employeeName = String(session.employeeName || "").trim().toLowerCase();
  const username = String(session.username || "").trim().toLowerCase();
  return ticketAssignees(ticket).some((name) => {
    const assigned = name.toLowerCase();
    return assigned === employeeName || assigned.split(/\s+/)[0] === username;
  });
}

function readTickets() {
  if (!existsSync(ticketsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(ticketsPath, "utf8"));
    if (!Array.isArray(records)) throw new Error("Expected ticket records array");
    return records;
  } catch (error) {
    throw new Error(`Cannot read tickets: ${error.message}`);
  }
}

function writeTickets(tickets) {
  writeFileSync(ticketsPath, JSON.stringify(tickets, null, 2), { mode: 0o600 });
}

function readUnifiData() {
  const defaults = {
    settings: { autoTickets: false },
    mappings: {},
    cache: {
      hosts: [], sites: [], devices: [], ispMetrics: [],
      networkDevices: {}, clients: {}, protect: {}, access: {},
      connectorStatus: {}, syncedAt: ""
    },
    activeOutages: []
  };
  if (!existsSync(unifiPath)) return defaults;
  try {
    const saved = JSON.parse(readFileSync(unifiPath, "utf8"));
    return {
      settings: { ...defaults.settings, ...(saved.settings || {}) },
      mappings: saved.mappings && typeof saved.mappings === "object" ? saved.mappings : {},
      cache: { ...defaults.cache, ...(saved.cache || {}) },
      activeOutages: Array.isArray(saved.activeOutages) ? saved.activeOutages : []
    };
  } catch {
    return defaults;
  }
}

function writeUnifiData(data) {
  writeFileSync(unifiPath, JSON.stringify(data, null, 2), { mode: 0o600 });
}

async function fetchUnifiCollection(pathname, paginate = true) {
  const key = String(process.env.UNIFI_API_KEY || "").trim();
  if (!key) throw new Error("UNIFI_API_KEY is not configured on this server.");
  const records = [];
  let nextToken = "";
  for (let page = 0; page < (paginate ? 20 : 1); page += 1) {
    const url = new URL(pathname, "https://api.ui.com/v1/");
    if (paginate) {
      url.searchParams.set("pageSize", "200");
      if (nextToken) url.searchParams.set("nextToken", nextToken);
    }
    const response = await fetch(url, {
      headers: { "X-API-Key": key, "Accept": "application/json" },
      signal: AbortSignal.timeout(20000)
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      const retry = response.headers.get("retry-after");
      throw new Error(`${result.message || `UniFi API returned ${response.status}`}${retry ? ` Retry after ${retry} seconds.` : ""}`);
    }
    records.push(...(Array.isArray(result.data) ? result.data : result.data ? [result.data] : []));
    nextToken = String(result.nextToken || "");
    if (!nextToken) break;
  }
  return records;
}

async function fetchUnifiConnector(hostId, applicationPath) {
  const key = String(process.env.UNIFI_API_KEY || "").trim();
  if (!key) throw new Error("UNIFI_API_KEY is not configured on this server.");
  const url = new URL(
    `https://api.ui.com/v1/connector/consoles/${encodeURIComponent(hostId)}/proxy/${applicationPath}`
  );
  const response = await fetch(url, {
    headers: { "X-API-Key": key, "Accept": "application/json" },
    signal: AbortSignal.timeout(25000)
  });
  const result = await response.json().catch(() => null);
  if (!response.ok) throw new Error(result?.message || `Connector returned ${response.status}.`);
  if (Array.isArray(result)) return result;
  if (Array.isArray(result?.data)) return result.data;
  return result ? [result] : [];
}

async function pipeUnifiSnapshot(response, hostId, cameraId) {
  const data = readUnifiData();
  const known = data.cache.protect?.[hostId]?.cameras?.some((camera) =>
    String(camera.id) === cameraId
  );
  if (!known) {
    sendJson(response, 404, { ok: false, message: "Camera not found." });
    return;
  }
  const key = String(process.env.UNIFI_API_KEY || "").trim();
  const url = new URL(
    `https://api.ui.com/v1/connector/consoles/${encodeURIComponent(hostId)}/proxy/protect/integration/v1/cameras/${encodeURIComponent(cameraId)}/snapshot`
  );
  const upstream = await fetch(url, {
    headers: { "X-API-Key": key, "Accept": "image/jpeg" },
    signal: AbortSignal.timeout(25000)
  });
  if (!upstream.ok) {
    sendJson(response, upstream.status, { ok: false, message: "Unable to retrieve camera snapshot." });
    return;
  }
  const image = Buffer.from(await upstream.arrayBuffer());
  response.writeHead(200, {
    "Content-Type": upstream.headers.get("content-type") || "image/jpeg",
    "Content-Length": image.length,
    "Cache-Control": "private, no-store",
    "X-Content-Type-Options": "nosniff"
  });
  response.end(image);
}

function unifiSiteName(site) {
  return String(site?.meta?.desc || site?.meta?.name || site?.name || site?.siteId || "UniFi Site");
}

function unifiOfflineCount(site) {
  const counts = site?.statistics?.counts || {};
  return Math.max(0, Number(counts.offlineDevice) || (
    (Number(counts.offlineGatewayDevice) || 0) +
    (Number(counts.offlineWifiDevice) || 0) +
    (Number(counts.offlineWiredDevice) || 0)
  ));
}

function createUnifiOutageTickets(data, session) {
  const currentOutages = new Set();
  const previousOutages = new Map((data.activeOutages || []).map((record) =>
    typeof record === "string" ? [record, { siteId: record, ticketId: "" }] : [record.siteId, record]
  ));
  const nextOutages = [];
  const tickets = readTickets();
  let changed = false;
  for (const site of data.cache.sites || []) {
    const siteId = String(site.siteId || "");
    const offline = unifiOfflineCount(site);
    if (!siteId || offline <= 0) continue;
    currentOutages.add(siteId);
    if (previousOutages.has(siteId)) {
      nextOutages.push(previousOutages.get(siteId));
      continue;
    }
    if (!data.settings.autoTickets) continue;
    const customer = readCustomers().find((record) => record.id === data.mappings[siteId]);
    if (!customer) continue;
    const ticket = {
      id: randomBytes(12).toString("hex"),
      number: tickets.reduce((max, ticket) => Math.max(max, Number(ticket.number) || 0), 0) + 1,
      ticketType: "Service",
      customerId: customer.id,
      customer: customer.name,
      company: customer.company || "",
      email: customer.email || "",
      phone: customer.phone || "",
      address: customer.address || "",
      description: `UniFi alert: ${offline} device${offline === 1 ? "" : "s"} offline at ${unifiSiteName(site)}.`,
      serviceType: "UniFi Monitoring",
      status: "Open",
      priority: "High",
      assignedTo: "",
      scheduledDate: "",
      scheduledTime: "",
      workNotes: `Automatically created from UniFi Site Manager for site ${siteId}.`,
      unifiSiteId: siteId,
      createdAt: new Date().toISOString(),
      createdBy: session.username
    };
    tickets.push(ticket);
    nextOutages.push({ siteId, ticketId: ticket.id, openedAt: ticket.createdAt });
    changed = true;
  }
  for (const [siteId, outage] of previousOutages) {
    if (currentOutages.has(siteId) || !outage.ticketId) continue;
    const ticket = tickets.find((record) => record.id === outage.ticketId);
    if (!ticket) continue;
    const recoveredAt = new Date().toISOString();
    ticket.workNotes = `${ticket.workNotes || ""}\nUniFi recovery detected ${recoveredAt}. Devices are reporting online again.`.trim();
    ticket.internalMessages = Array.isArray(ticket.internalMessages) ? ticket.internalMessages : [];
    ticket.internalMessages.push({
      id: randomBytes(12).toString("hex"),
      employeeName: "UniFi Monitor",
      username: "system",
      message: "UniFi reports this site has recovered and affected devices are online.",
      fromOffice: true,
      createdAt: recoveredAt
    });
    changed = true;
  }
  data.activeOutages = nextOutages;
  if (changed) {
    writeTickets(tickets);
    broadcastAllServiceEvent("tickets-updated");
  }
}

async function enrichUnifiCache(hosts, sites) {
  const networkDevices = {};
  const clients = {};
  const protect = {};
  const access = {};
  const connectorStatus = {};
  const sitesByHost = Map.groupBy(sites, (site) => String(site.hostId || ""));
  for (const [hostId, managedSites] of sitesByHost) {
    if (!hostId) continue;
    let localSites = [];
    try {
      localSites = await fetchUnifiConnector(
        hostId, "network/integration/v1/sites?offset=0&limit=500"
      );
    } catch (error) {
      for (const site of managedSites) {
        connectorStatus[String(site.siteId || hostId)] = {
          ok: false,
          message: error.message || "The Network connector is unavailable."
        };
      }
      continue;
    }
    for (const site of managedSites) {
      const siteId = String(site.siteId || "");
      if (!siteId) continue;
      const siteName = unifiSiteName(site).trim().toLowerCase();
      const localSite = localSites.find((record) =>
        String(record.id || "") === siteId ||
        String(record.internalReference || "") === siteId
      ) || localSites.find((record) =>
        siteName && String(record.name || "").trim().toLowerCase() === siteName
      ) || (managedSites.length === 1 && localSites.length === 1 ? localSites[0] : null);
      if (!localSite?.id) {
        connectorStatus[siteId] = {
          ok: false,
          message: "The Site Manager site could not be matched to a local Network site."
        };
        continue;
      }
      const networkBase =
        `network/integration/v1/sites/${encodeURIComponent(localSite.id)}`;
      const [deviceResult, clientResult] = await Promise.allSettled([
        fetchUnifiConnector(hostId, `${networkBase}/devices?offset=0&limit=500`),
        fetchUnifiConnector(hostId, `${networkBase}/clients?offset=0&limit=500`)
      ]);
      networkDevices[siteId] = deviceResult.status === "fulfilled" ? deviceResult.value : [];
      clients[siteId] = clientResult.status === "fulfilled" ? clientResult.value : [];
      const errors = [deviceResult, clientResult]
        .filter((result) => result.status === "rejected")
        .map((result) => result.reason?.message || "Connector request failed.");
      connectorStatus[siteId] = errors.length
        ? { ok: false, message: errors.join(" ") }
        : { ok: true, localSiteId: String(localSite.id) };
    }
  }
  for (const host of hosts) {
    const hostId = String(host.id || host.hostId || "");
    if (!hostId) continue;
    const [cameras, sensors, nvrs, accessDevices, doors] = await Promise.all([
      fetchUnifiConnector(hostId, "protect/integration/v1/cameras").catch(() => []),
      fetchUnifiConnector(hostId, "protect/integration/v1/sensors").catch(() => []),
      fetchUnifiConnector(hostId, "protect/integration/v1/nvrs").catch(() => []),
      fetchUnifiConnector(hostId, "access/integration/v1/devices").catch(() => []),
      fetchUnifiConnector(hostId, "access/integration/v1/doors").catch(() => [])
    ]);
    protect[hostId] = { cameras, sensors, nvrs };
    access[hostId] = { devices: accessDevices, doors };
  }
  return { networkDevices, clients, protect, access, connectorStatus };
}

function syncUnifiEquipment(siteId, data, session) {
  const customer = readCustomers().find((record) => record.id === data.mappings[siteId]);
  if (!customer) throw new Error("Link this UniFi site to a customer first.");
  const site = data.cache.sites.find((record) => String(record.siteId) === siteId);
  if (!site) throw new Error("UniFi site not found.");
  const devices = data.cache.networkDevices?.[siteId] || [];
  const warranties = readWarranties();
  let created = 0;
  let updated = 0;
  for (const device of devices) {
    const serial = String(device.macAddress || device.mac || device.id || "").trim();
    if (!serial) continue;
    const existing = warranties.find((record) =>
      record.unifiDeviceId === device.id ||
      String(record.serialNumber || "").toLowerCase() === serial.toLowerCase()
    );
    const record = {
      ...(existing || {}),
      id: existing?.id || randomBytes(12).toString("hex"),
      customerId: customer.id,
      customerName: customer.name,
      productName: String(device.name || device.model || "UniFi Device"),
      manufacturer: "Ubiquiti",
      model: String(device.model || ""),
      equipmentStatus: "Installed",
      serialNumber: serial,
      installDate: String(device.adoptedAt || data.cache.syncedAt || new Date().toISOString()).slice(0, 10),
      expiresAt: existing?.expiresAt || "",
      location: customer.primaryAddress || customer.address || unifiSiteName(site),
      notes: `Synced from UniFi. IP: ${device.ipAddress || "Not reported"}. Firmware: ${device.firmwareVersion || "Not reported"}.`,
      unifiSiteId: siteId,
      unifiDeviceId: String(device.id || ""),
      unifiFirmwareVersion: String(device.firmwareVersion || ""),
      createdAt: existing?.createdAt || new Date().toISOString(),
      createdBy: existing?.createdBy || session.username,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    if (existing) {
      warranties[warranties.indexOf(existing)] = record;
      updated += 1;
    } else {
      warranties.push(record);
      created += 1;
    }
  }
  writeWarranties(warranties);
  broadcastAllServiceEvent("dashboard-updated", { area: "warranties" });
  return { created, updated };
}

function sendUnifiMaintenanceReport(response, site, data) {
  const siteId = String(site.siteId || "");
  const devices = data.cache.networkDevices?.[siteId] || [];
  const clients = data.cache.clients?.[siteId] || [];
  const metrics = (data.cache.ispMetrics || []).find((record) =>
    String(record.siteId) === siteId
  );
  const host = data.cache.hosts.find((record) =>
    String(record.id || record.hostId) === String(site.hostId)
  );
  const doc = new PDFDocument({
    size: "LETTER",
    margin: 48,
    info: { Title: `${unifiSiteName(site)} UniFi Maintenance Report` }
  });
  const safeName = unifiSiteName(site).replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").toLowerCase();
  response.writeHead(200, {
    "Content-Type": "application/pdf",
    "Content-Disposition": `attachment; filename="unifi-${safeName || "site"}-report.pdf"`,
    "Cache-Control": "no-store"
  });
  doc.pipe(response);
  doc.fontSize(18).fillColor("#182026").text("UniFi Maintenance Report");
  doc.fontSize(10).fillColor("#526068").text(
    `${unifiSiteName(site)} · Generated ${new Date().toLocaleString("en-US")}`
  );
  doc.moveDown().fillColor("#182026");
  reportField(doc, "Site ID", siteId);
  reportField(doc, "ISP", site.statistics?.ispInfo?.name || "Not reported");
  reportField(doc, "WAN uptime", `${Number(site.statistics?.percentages?.wanUptime || 0).toFixed(2)}%`);
  reportField(doc, "Devices", String(devices.length || site.statistics?.counts?.totalDevice || 0));
  reportField(doc, "Offline devices", String(unifiOfflineCount(site)));
  reportField(doc, "Connected clients", String(clients.length));
  reportField(doc, "Console backup", host?.latestBackupTime || "Not reported");
  doc.moveDown().fontSize(13).text("Equipment").moveDown(0.4);
  if (!devices.length) doc.fontSize(9).fillColor("#526068").text("Detailed device data was not available.");
  for (const device of devices) {
    if (doc.y > 700) doc.addPage();
    doc.fontSize(10).fillColor("#182026").text(
      `${device.name || "UniFi Device"} · ${device.model || "Unknown model"} · ${device.state || "Unknown"}`
    );
    doc.fontSize(8).fillColor("#526068").text(
      `${device.macAddress || "No MAC"} · Firmware ${device.firmwareVersion || "not reported"}` +
      `${device.firmwareUpdatable ? " · Update available" : ""}`
    );
    doc.moveDown(0.35);
  }
  doc.moveDown().fontSize(13).fillColor("#182026").text("ISP History").moveDown(0.4);
  const periods = metrics?.periods || [];
  if (!periods.length) doc.fontSize(9).fillColor("#526068").text("ISP history was not available.");
  for (const period of periods.slice(-12)) {
    const wan = period?.data?.wan || {};
    doc.fontSize(8).fillColor("#526068").text(
      `${period.metricTime || "Unknown time"} · Uptime ${wan.uptime ?? "--"}% · ` +
      `Latency ${wan.avgLatency ?? "--"} ms · Packet loss ${wan.packetLoss ?? "--"}%`
    );
  }
  doc.end();
}

async function handleUnifi(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "unifi")) {
    sendJson(response, session ? 403 : 401, {
      ok: false,
      message: session ? "UniFi access required." : "Please sign in."
    });
    return;
  }
  const url = new URL(request.url, publicOrigin(request));
  const data = readUnifiData();
  if (request.method === "GET") {
    if (url.pathname === "/api/unifi/snapshot") {
      await pipeUnifiSnapshot(
        response,
        String(url.searchParams.get("hostId") || ""),
        String(url.searchParams.get("cameraId") || "")
      );
      return;
    }
    if (url.pathname === "/api/unifi/report") {
      const site = data.cache.sites.find((record) =>
        String(record.siteId) === String(url.searchParams.get("siteId") || "")
      );
      if (!site) {
        sendJson(response, 404, { ok: false, message: "UniFi site not found." });
        return;
      }
      sendUnifiMaintenanceReport(response, site, data);
      logActivity(session, "unifi.report", `Generated a maintenance report for ${unifiSiteName(site)}.`);
      return;
    }
    sendJson(response, 200, {
      ok: true,
      configured: Boolean(String(process.env.UNIFI_API_KEY || "").trim()),
      settings: data.settings,
      mappings: data.mappings,
      cache: data.cache,
      customers: readCustomers().map((customer) => ({ id: customer.id, name: customer.name }))
    });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const payload = await readJsonBody(request);
  if (payload.action === "sync") {
    try {
      const [hosts, sites, devices, ispMetrics] = await Promise.all([
        fetchUnifiCollection("hosts"),
        fetchUnifiCollection("sites"),
        fetchUnifiCollection("devices"),
        fetchUnifiCollection("isp-metrics/5m?duration=24h", false).catch(() => [])
      ]);
      const detail = await enrichUnifiCache(hosts, sites);
      data.cache = {
        hosts, sites, devices, ispMetrics, ...detail, syncedAt: new Date().toISOString()
      };
      createUnifiOutageTickets(data, session);
      writeUnifiData(data);
      logActivity(session, "unifi.synced",
        `Synced ${sites.length} UniFi sites and ${devices.length} device records.`);
      broadcastAllServiceEvent("dashboard-updated", { area: "unifi" });
      sendJson(response, 200, { ok: true, cache: data.cache });
    } catch (error) {
      sendJson(response, 502, { ok: false, message: error.message || "Unable to sync UniFi." });
    }
    return;
  }
  if (payload.action === "settings") {
    data.settings.autoTickets = Boolean(payload.autoTickets);
    writeUnifiData(data);
    logActivity(session, "unifi.settings",
      `${data.settings.autoTickets ? "Enabled" : "Disabled"} automatic UniFi outage tickets.`);
    sendJson(response, 200, { ok: true, settings: data.settings });
    return;
  }
  if (payload.action === "map-site") {
    const siteId = String(payload.siteId || "");
    const customerId = String(payload.customerId || "");
    if (!data.cache.sites.some((site) => String(site.siteId) === siteId) ||
        (customerId && !readCustomers().some((customer) => customer.id === customerId))) {
      sendJson(response, 400, { ok: false, message: "Choose a valid site and customer." });
      return;
    }
    if (customerId) data.mappings[siteId] = customerId;
    else delete data.mappings[siteId];
    writeUnifiData(data);
    sendJson(response, 200, { ok: true, mappings: data.mappings });
    return;
  }
  if (payload.action === "sync-equipment") {
    try {
      const result = syncUnifiEquipment(String(payload.siteId || ""), data, session);
      logActivity(session, "unifi.equipment",
        `Synchronized UniFi equipment: ${result.created} created, ${result.updated} updated.`);
      sendJson(response, 200, { ok: true, ...result });
    } catch (error) {
      sendJson(response, 400, { ok: false, message: error.message });
    }
    return;
  }
  sendJson(response, 400, { ok: false, message: "Unknown UniFi action." });
}

async function handleNotifications(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }

  const notifications = readNotifications();
  if (request.method === "GET") {
    const own = notifications
      .filter((notification) => notification.username === session.username)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    sendJson(response, 200, { ok: true, notifications: own });
    return;
  }

  if (request.method === "POST") {
    const payload = await readJsonBody(request);
    for (const notification of notifications) {
      if (notification.username !== session.username) continue;
      if (payload.all || notification.id === payload.id) notification.read = true;
    }
    writeNotifications(notifications);
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function createTicketNotification(previous, ticket) {
  const currentNames = ticketAssignees(ticket);
  const previousNames = ticketAssignees(previous);
  if (!currentNames.length && !previousNames.length) return;
  const currentKeys = new Set(currentNames.map((name) => name.toLowerCase()));
  const previousKeys = new Set(previousNames.map((name) => name.toLowerCase()));
  const assignmentChanged = currentNames.length !== previousNames.length ||
    currentNames.some((name) => !previousKeys.has(name.toLowerCase()));
  const scheduleChanged = previous &&
    (previous.scheduledDate !== ticket.scheduledDate ||
     previous.scheduledTime !== ticket.scheduledTime);
  const detailsChanged = previous &&
    (previous.status !== ticket.status ||
     previous.description !== ticket.description ||
     previous.priority !== ticket.priority ||
     JSON.stringify(previous.phases || []) !== JSON.stringify(ticket.phases || []));
  if (!assignmentChanged && !scheduleChanged && !detailsChanged) return;

  const users = readUsers();
  const userForName = (name) => {
    const assigned = name.toLowerCase();
    return users.find((user) =>
      String(user.employeeName || "").toLowerCase() === assigned ||
      assigned.split(/\s+/)[0] === String(user.username || "").toLowerCase());
  };
  const number = ticketLabel(ticket);
  const notifications = readNotifications();
  previousNames.filter((name) => !currentKeys.has(name.toLowerCase())).forEach((name) => {
    const recipient = userForName(name);
    if (!recipient) return;
    const notification = {
      id: randomBytes(12).toString("hex"),
      username: recipient.username,
      ticketId: ticket.id,
      title: `${ticket.ticketType === "Contract" ? "Contract" : "Service"} ticket removed`,
      message: `${number} for ${ticket.customer} was removed from your assignments.`,
      createdAt: new Date().toISOString(),
      read: false
    };
    notifications.push(notification);
    broadcastServiceEvent(recipient.username, "ticket-updated", { ticketId: ticket.id });
    void sendPushNotification(recipient.username, notification).catch((error) => {
      console.error("Unable to prepare ticket removal notification:", error.message);
    });
  });

  const schedule = ticket.scheduledDate
    ? ` Scheduled for ${ticket.scheduledDate}${ticket.scheduledTime ? ` at ${ticket.scheduledTime}` : ""}.`
    : "";
  for (const name of currentNames) {
    const recipient = userForName(name);
    if (!recipient) continue;
    const newlyAssigned = !previousKeys.has(name.toLowerCase());
    const title = newlyAssigned
      ? `New ${ticket.ticketType === "Contract" ? "contract" : "service"} ticket assigned`
      : scheduleChanged ? "Ticket schedule updated" : "Ticket updated";
    const notification = {
      id: randomBytes(12).toString("hex"), username: recipient.username, ticketId: ticket.id,
      title, message: `${number} for ${ticket.customer}.${schedule}`,
      createdAt: new Date().toISOString(), read: false
    };
    notifications.push(notification);
    broadcastServiceEvent(recipient.username, "ticket-updated", { ticketId: ticket.id });
    void sendPushNotification(recipient.username, notification).catch((error) => {
      console.error("Unable to prepare push notification:", error.message);
    });
  }
  writeNotifications(notifications.slice(-2000));
}

function notifyOfficeOfReassignment(ticket, flag, actorUsername) {
  const notifications = readNotifications();
  const number = ticketLabel(ticket);
  for (const user of readUsers()) {
    if (user.username === actorUsername || !hasPermission(user, "service-tickets")) continue;
    const notification = {
      id: randomBytes(12).toString("hex"),
      username: user.username,
      ticketId: ticket.id,
      title: "Ticket needs reassignment",
      message: `${number}: ${flag.employeeName} requested removal. ${flag.reason}`.slice(0, 500),
      createdAt: new Date().toISOString(),
      read: false
    };
    notifications.push(notification);
    broadcastServiceEvent(user.username, "ticket-updated", { ticketId: ticket.id });
    void sendPushNotification(user.username, notification).catch((error) => {
      console.error("Unable to prepare reassignment notification:", error.message);
    });
  }
  writeNotifications(notifications.slice(-2000));
}

function readNotifications() {
  if (!existsSync(notificationsPath)) return [];
  try {
    return JSON.parse(readFileSync(notificationsPath, "utf8")) || [];
  } catch {
    return [];
  }
}

function writeNotifications(notifications) {
  writeFileSync(notificationsPath, JSON.stringify(notifications, null, 2), { mode: 0o600 });
}

function loadPushConfig() {
  if (existsSync(pushConfigPath)) {
    try {
      const saved = JSON.parse(readFileSync(pushConfigPath, "utf8"));
      if (saved.publicKey && saved.privateKey) return saved;
    } catch {
      // Replace an unreadable key file below.
    }
  }
  const generated = webpush.generateVAPIDKeys();
  writeFileSync(pushConfigPath, JSON.stringify(generated, null, 2), { mode: 0o600 });
  return generated;
}

function readPushSubscriptions() {
  if (!existsSync(pushSubscriptionsPath)) return [];
  try {
    const saved = JSON.parse(readFileSync(pushSubscriptionsPath, "utf8"));
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function writePushSubscriptions(subscriptions) {
  writeFileSync(pushSubscriptionsPath, JSON.stringify(subscriptions, null, 2), { mode: 0o600 });
}

function handlePushPublicKey(request, response) {
  if (!getSession(request)) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  sendJson(response, 200, { ok: true, publicKey: pushConfig.publicKey });
}

async function handlePushSubscription(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }

  const subscriptions = readPushSubscriptions();
  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      subscribed: subscriptions.some((record) => record.username === session.username)
    });
    return;
  }

  if (request.method === "POST") {
    const payload = await readJsonBody(request);
    const subscription = payload.subscription;
    if (!subscription?.endpoint || !subscription?.keys?.p256dh || !subscription?.keys?.auth) {
      sendJson(response, 400, { ok: false, message: "Invalid notification subscription." });
      return;
    }
    const filtered = subscriptions.filter((record) => record.subscription.endpoint !== subscription.endpoint);
    filtered.push({
      id: randomBytes(12).toString("hex"),
      username: session.username,
      subscription,
      createdAt: new Date().toISOString()
    });
    writePushSubscriptions(filtered);
    sendJson(response, 200, { ok: true });
    return;
  }

  if (request.method === "DELETE") {
    const payload = await readJsonBody(request);
    writePushSubscriptions(subscriptions.filter((record) =>
      record.username !== session.username ||
      (payload.endpoint && record.subscription.endpoint !== payload.endpoint)
    ));
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

async function handlePushDevices(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can manage notification devices." });
    return;
  }
  const subscriptions = readPushSubscriptions();
  if (request.method === "GET") {
    const users = readUsers();
    const devices = subscriptions.map((record) => {
      const user = users.find((candidate) => candidate.username === record.username);
      let provider = "Push service";
      try {
        provider = new URL(record.subscription.endpoint).hostname;
      } catch {
        // Keep the generic provider label.
      }
      return {
        id: record.id,
        username: record.username,
        employeeName: user?.employeeName || record.username,
        provider,
        createdAt: record.createdAt
      };
    });
    sendJson(response, 200, { ok: true, devices });
    return;
  }
  if (request.method === "DELETE") {
    const payload = await readJsonBody(request);
    const exists = subscriptions.some((record) => record.id === payload.id);
    if (!exists) {
      sendJson(response, 404, { ok: false, message: "Notification device not found." });
      return;
    }
    writePushSubscriptions(subscriptions.filter((record) => record.id !== payload.id));
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

async function sendPushNotification(username, notification) {
  const records = readPushSubscriptions().filter((record) => record.username === username);
  if (!records.length) return;
  const expired = new Set();
  const payload = JSON.stringify({
    title: notification.title,
    body: notification.message,
    ticketId: notification.ticketId,
    url: notification.url ||
      `/service-dashboard.html?ticket=${encodeURIComponent(notification.ticketId)}`
  });

  await Promise.all(records.map(async (record) => {
    try {
      await webpush.sendNotification(record.subscription, payload);
    } catch (error) {
      if (error.statusCode === 404 || error.statusCode === 410) {
        expired.add(record.subscription.endpoint);
      } else {
        console.error("Unable to send push notification:", error.message);
        recordPushFailure(username, error);
      }
    }
  }));

  if (expired.size) {
    writePushSubscriptions(readPushSubscriptions().filter((record) =>
      !expired.has(record.subscription.endpoint)
    ));
  }
}

function handleServiceEvents(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  response.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no"
  });
  response.write(`event: connected\ndata: ${JSON.stringify({ ok: true })}\n\n`);
  const id = randomBytes(12).toString("hex");
  eventClients.set(id, { username: session.username, response });
  const keepAlive = setInterval(() => response.write(": keep-alive\n\n"), 25000);
  request.on("close", () => {
    clearInterval(keepAlive);
    eventClients.delete(id);
  });
}

function broadcastServiceEvent(username, event, data = {}) {
  for (const client of eventClients.values()) {
    if (client.username !== username) continue;
    client.response.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  }
}

function broadcastAllServiceEvent(event, data = {}) {
  for (const client of eventClients.values()) {
    client.response.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  }
}

function recordPushFailure(username, error) {
  let failures = [];
  if (existsSync(pushFailuresPath)) {
    try {
      failures = JSON.parse(readFileSync(pushFailuresPath, "utf8")) || [];
    } catch {
      failures = [];
    }
  }
  failures.push({
    id: randomBytes(12).toString("hex"),
    username,
    statusCode: Number(error.statusCode) || 0,
    message: String(error.message || "Push delivery failed").slice(0, 300),
    createdAt: new Date().toISOString()
  });
  writeFileSync(pushFailuresPath, JSON.stringify(failures.slice(-500), null, 2), { mode: 0o600 });
}

function writeUsers(users) {
  const contents = users.map((user) =>
    [
      user.username,
      user.salt,
      user.hash,
      user.role,
      user.employeeName,
      (user.permissions || []).join(","),
      user.totpSecret || "",
      (user.recoveryHashes || []).join(";"),
      user.createdAt || new Date().toISOString(),
      user.avatarPath || "",
      user.avatarUpdatedAt || ""
    ].join("|")
  ).join("\n");
  writeFileSync(usersPath, `${contents}\n`, { mode: 0o600 });
}

async function handleEmployees(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "employee-records")) {
    sendJson(response, 403, { ok: false, message: "Employee Records access required." });
    return;
  }

  const employees = readEmployees();

  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, employees: employees.map(publicEmployeeRecord) });
    return;
  }

  const payload = await readJsonBody(request);

  if (request.method === "POST") {
    const employee = payload.employee;
    if (!employee?.id || !employee?.firstName || !employee?.lastName || !employee?.jobTitle) {
      sendJson(response, 400, { ok: false, message: "Employee information is incomplete." });
      return;
    }
    const index = employees.findIndex((record) => record.id === employee.id);
    const previous = index >= 0 ? employees[index] : null;
    if (previous) {
      employee.photoPath = previous.photoPath || "";
      employee.photoUpdatedAt = previous.photoUpdatedAt || "";
    }
    if (employee.photoDataUrl) {
      try {
        const saved = saveImageDataUrl(employee.photoDataUrl, employeeAvatarsPath, employee.id);
        employee.photoPath = saved.filePath;
        employee.photoUpdatedAt = new Date().toISOString();
      } catch (error) {
        sendJson(response, 400, { ok: false, message: error.message });
        return;
      }
    }
    delete employee.photoDataUrl;
    delete employee.photoUrl;
    employee.zohoEmployeeId = String(employee.zohoEmployeeId || "").trim().slice(0, 80);
    employee.zohoPortalUrl = /^https:\/\/[^\s]+$/i.test(String(employee.zohoPortalUrl || "").trim())
      ? String(employee.zohoPortalUrl).trim().slice(0, 500) : "";
    if (index >= 0) employees[index] = employee;
    else employees.push(employee);
    writeEmployees(employees);
    const changed = previous ? [
      previous.wage !== employee.wage && "wage",
      previous.payType !== employee.payType && "pay type",
      previous.status !== employee.status && "status",
      previous.jobTitle !== employee.jobTitle && "job title",
      previous.zohoEmployeeId !== employee.zohoEmployeeId && "Zoho employee ID"
      ,previous.zohoPortalUrl !== employee.zohoPortalUrl && "Zoho portal URL"
    ].filter(Boolean) : [];
    logActivity(session, index >= 0 ? "employee.updated" : "employee.created",
      `${index >= 0 ? "Updated" : "Created"} employee ${employee.firstName} ${employee.lastName}` +
      `${changed.length ? ` (${changed.join(", ")})` : ""}.`);
    sendJson(response, 200, { ok: true, employee: publicEmployeeRecord(employee) });
    return;
  }

  if (request.method === "DELETE") {
    const removed = employees.find((employee) => employee.id === payload.id);
    if (removed?.id === "huber58-christian-huber") {
      sendJson(response, 403, { ok: false, message: "The primary admin employee record cannot be deleted." });
      return;
    }
    writeEmployees(employees.filter((employee) => employee.id !== payload.id));
    if (removed) logActivity(session, "employee.deleted", `Deleted employee ${removed.firstName} ${removed.lastName}.`);
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readEmployees() {
  if (!existsSync(employeesPath)) return [];
  try {
    return JSON.parse(readFileSync(employeesPath, "utf8")) || [];
  } catch {
    return [];
  }
}

function writeEmployees(employees) {
  writeFileSync(employeesPath, JSON.stringify(employees, null, 2), { mode: 0o600 });
}

function publicEmployeeRecord(employee) {
  const { photoPath, ...publicRecord } = employee;
  return {
    ...publicRecord,
    photoUrl: employee.photoPath
      ? `/api/employee-avatar?id=${encodeURIComponent(employee.id)}&v=${encodeURIComponent(employee.photoUpdatedAt || "")}`
      : ""
  };
}

async function handleEmployeeAvatar(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "employee-records")) {
    sendJson(response, 403, { ok: false, message: "Employee Records access required." });
    return;
  }
  if (request.method !== "GET") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const url = new URL(request.url, `http://${request.headers.host}`);
  const employee = readEmployees().find((record) => record.id === url.searchParams.get("id"));
  if (!employee?.photoPath || !existsSync(employee.photoPath)) {
    response.writeHead(404, { "Cache-Control": "no-store" });
    response.end("No employee picture.");
    return;
  }
  const extension = extname(employee.photoPath).toLowerCase();
  response.writeHead(200, {
    "Content-Type": mimeTypes[extension] || "image/jpeg",
    "Cache-Control": "no-store, private",
    "Vary": "Cookie"
  });
  createReadStream(employee.photoPath).pipe(response);
}

async function handleContacts(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  if (request.method !== "GET") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }

  const users = readUsers();
  const contacts = readEmployees()
    .filter((employee) => employee.status !== "Inactive")
    .map((employee) => {
      const name = `${employee.firstName || ""} ${employee.lastName || ""}`.trim();
      const linkedUser = users.find((user) =>
        String(user.employeeName || "").trim().toLowerCase() === name.toLowerCase()
      );
      return {
        id: employee.id,
        name,
        email: String(employee.email || "").trim(),
        phone: String(employee.phone || "").trim(),
        position: String(employee.jobTitle || "").trim(),
        avatarUrl: employee.photoPath || linkedUser?.avatarPath
          ? `/api/contact-avatar?id=${encodeURIComponent(employee.id)}&v=${encodeURIComponent(employee.photoUpdatedAt || linkedUser?.avatarUpdatedAt || "")}`
          : ""
      };
    })
    .filter((contact) => contact.name)
    .sort((a, b) => a.name.localeCompare(b.name));

  sendJson(response, 200, { ok: true, contacts });
}

async function handleContactAvatar(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  if (request.method !== "GET") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }

  const url = new URL(request.url, `http://${request.headers.host}`);
  const employee = readEmployees().find((record) => record.id === url.searchParams.get("id"));
  if (!employee) {
    response.writeHead(404, { "Cache-Control": "no-store" });
    response.end("Contact not found.");
    return;
  }
  const employeeName = `${employee.firstName || ""} ${employee.lastName || ""}`.trim().toLowerCase();
  const user = readUsers().find((record) =>
    String(record.employeeName || "").trim().toLowerCase() === employeeName
  );
  const avatarPath = employee.photoPath || user?.avatarPath || "";
  if (!avatarPath || !existsSync(avatarPath)) {
    response.writeHead(404, { "Cache-Control": "no-store" });
    response.end("No contact picture.");
    return;
  }
  const extension = extname(avatarPath).toLowerCase();
  response.writeHead(200, {
    "Content-Type": mimeTypes[extension] || "image/jpeg",
    "Cache-Control": "no-store, private",
    "Vary": "Cookie"
  });
  createReadStream(avatarPath).pipe(response);
}

async function handleTime(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }

  let records = readTimeRecords();
  const employeeName = session.employeeName || session.username;
  const employeeRecords = records
    .filter((record) => record.username === session.username)
    .sort((a, b) => new Date(b.clockIn) - new Date(a.clockIn));

  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      employeeName,
      active: employeeRecords.find((record) => !record.clockOut) || null,
      records: employeeRecords
    });
    return;
  }

  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }

  const payload = await readJsonBody(request);
  const completed = completedMutation(session, payload.clientMutationId);
  if (completed) {
    sendJson(response, 200, completed);
    return;
  }
  records = readTimeRecords();
  const activeIndex = records.findIndex((record) =>
    record.username === session.username && !record.clockOut
  );

  if (payload.action === "clock-in") {
    if (activeIndex >= 0) {
      sendJson(response, 409, { ok: false, message: "You are already clocked in." });
      return;
    }
    records.push({
      id: randomBytes(16).toString("hex"),
      username: session.username,
      employeeName,
      clockIn: new Date().toISOString(),
      clockOut: null
    });
  } else if (payload.action === "clock-out") {
    if (activeIndex < 0) {
      sendJson(response, 409, { ok: false, message: "You are not currently clocked in." });
      return;
    }
    records[activeIndex].clockOut = new Date().toISOString();
    const laborRate = employeeLaborRate(employeeName);
    const hours = (new Date(records[activeIndex].clockOut) -
      new Date(records[activeIndex].clockIn)) / 3600000;
    records[activeIndex].laborRate = roundMoney(laborRate);
    records[activeIndex].laborCost = roundMoney(Math.max(0, hours) * laborRate);
  } else {
    sendJson(response, 400, { ok: false, message: "Unknown time-clock action." });
    return;
  }

  writeTimeRecords(records);
  const result = { ok: true };
  rememberMutation(session, payload.clientMutationId, result);
  broadcastServiceEvent(session.username, "time-updated");
  broadcastAllServiceEvent("dashboard-updated", { area: "time" });
  sendJson(response, 200, result);
}

async function handleServiceTimesheet(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }

  const url = new URL(request.url, `http://${request.headers.host}`);
  const requestedWeek = request.method === "GET"
    ? url.searchParams.get("week")
    : null;

  if (request.method === "GET") {
    const timesheet = serviceTimesheetForWeek(session, requestedWeek);
    sendJson(response, 200, { ok: true, ...timesheet });
    return;
  }

  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }

  const payload = await readJsonBody(request);
  const completed = completedMutation(session, payload.clientMutationId);
  if (completed) {
    sendJson(response, 200, completed);
    return;
  }
  const signature = String(payload.signature || "").trim().slice(0, 160);
  if (!signature) {
    sendJson(response, 400, { ok: false, message: "Enter your name to sign the timesheet." });
    return;
  }

  const weekStart = serviceTimesheetWeekStart(payload.weekStart);
  const weekEnd = serviceTimesheetWeekEnd(weekStart);
  const tickets = readTickets();
  const records = readTimeRecords();
  const submittedAt = new Date().toISOString();
  const timesheetId = randomBytes(12).toString("hex");
  const employeeName = session.employeeName || session.username;
  const laborRate = roundMoney(employeeLaborRate(employeeName));
  const submittedEntries = [];

  for (const ticket of tickets) {
    if (!ticketMatchesEmployee(ticket, session) && !hasPermission(session, "service-tickets")) continue;
    if (!Array.isArray(ticket.workLogs)) continue;
    for (const log of ticket.workLogs) {
      if (log.username !== session.username || log.timesheetSubmittedAt) continue;
      const logDate = String(log.loggedAt || "").slice(0, 10);
      if (logDate < weekStart || logDate > weekEnd) continue;
      const hours = Math.max(0, Number(log.hours) || 0);
      if (!hours) continue;
      const clockIn = serviceTimesheetClockIn(logDate);
      const clockOut = new Date(clockIn.getTime() + hours * 3600000);
      const timeRecord = {
        id: randomBytes(16).toString("hex"),
        username: session.username,
        employeeName,
        clockIn: clockIn.toISOString(),
        clockOut: clockOut.toISOString(),
        laborRate,
        laborCost: roundMoney(hours * laborRate),
        source: "ticket-timesheet",
        ticketId: ticket.id,
        ticketNumber: ticket.number,
        ticketType: ticket.ticketType || "Service",
        nonChargeable: Boolean(ticket.nonChargeable),
        customer: ticket.customer || "",
        serviceType: ticket.serviceType || "",
        workLogId: log.id,
        timesheetId,
        timesheetWeekStart: weekStart,
        signedAt: submittedAt,
        signedBy: signature,
        notes: log.resolution || ""
      };
      records.push(timeRecord);
      log.timesheetSubmittedAt = submittedAt;
      log.timesheetId = timesheetId;
      log.timeRecordId = timeRecord.id;
      submittedEntries.push({
        date: logDate,
        ticketId: ticket.id,
        ticketNumber: ticketLabel(ticket),
        customer: ticket.customer || "",
        serviceType: ticket.serviceType || "",
        hours
      });
    }
  }

  if (!submittedEntries.length) {
    sendJson(response, 400, { ok: false, message: "There are no unsubmitted ticket hours for this week." });
    return;
  }

  writeTickets(tickets);
  writeTimeRecords(records);
  logActivity(session, "timesheet.submitted",
    `Submitted ${roundMoney(submittedEntries.reduce((sum, entry) => sum + entry.hours, 0))} ticket hours for ${weekStart} through ${weekEnd}.`);
  broadcastServiceEvent(session.username, "time-updated");
  broadcastAllServiceEvent("dashboard-updated", { area: "time" });
  broadcastAllServiceEvent("tickets-updated", {});

  const result = {
    ok: true,
    timesheetId,
    submittedAt,
    entries: submittedEntries,
    ...serviceTimesheetForWeek(session, weekStart, tickets)
  };
  rememberMutation(session, payload.clientMutationId, result);
  sendJson(response, 200, result);
}

function serviceTimesheetForWeek(session, requestedWeek, ticketSource = null) {
  const weekStart = serviceTimesheetWeekStart(requestedWeek);
  const weekEnd = serviceTimesheetWeekEnd(weekStart);
  const tickets = ticketSource || readTickets();
  const entries = [];
  for (const ticket of tickets) {
    if (!ticketMatchesEmployee(ticket, session) && !hasPermission(session, "service-tickets")) continue;
    for (const log of Array.isArray(ticket.workLogs) ? ticket.workLogs : []) {
      if (log.username !== session.username) continue;
      const date = String(log.loggedAt || "").slice(0, 10);
      if (date < weekStart || date > weekEnd) continue;
      entries.push({
        id: log.id,
        date,
        ticketId: ticket.id,
        ticketNumber: ticketLabel(ticket),
        customer: ticket.customer || "",
        serviceType: ticket.serviceType || "",
        status: log.status || ticket.status || "",
        resolution: log.resolution || "",
        hours: roundMoney(Number(log.hours) || 0),
        submitted: Boolean(log.timesheetSubmittedAt),
        submittedAt: log.timesheetSubmittedAt || "",
        timesheetId: log.timesheetId || ""
      });
    }
  }
  entries.sort((a, b) =>
    a.date.localeCompare(b.date) || a.ticketNumber.localeCompare(b.ticketNumber)
  );
  return {
    weekStart,
    weekEnd,
    entries,
    totalHours: roundMoney(entries.reduce((sum, entry) => sum + Number(entry.hours || 0), 0)),
    unsubmittedHours: roundMoney(entries.filter((entry) => !entry.submitted)
      .reduce((sum, entry) => sum + Number(entry.hours || 0), 0))
  };
}

function serviceTimesheetWeekStart(value) {
  const today = new Date(`${businessToday()}T12:00:00`);
  const base = /^\d{4}-\d{2}-\d{2}$/.test(String(value || ""))
    ? new Date(`${value}T12:00:00`)
    : today;
  base.setDate(base.getDate() - ((base.getDay() + 6) % 7));
  return base.toISOString().slice(0, 10);
}

function serviceTimesheetWeekEnd(weekStart) {
  const end = new Date(`${weekStart}T12:00:00`);
  end.setDate(end.getDate() + 6);
  return end.toISOString().slice(0, 10);
}

function serviceTimesheetClockIn(date) {
  return new Date(`${date}T08:00:00`);
}

function readTimeRecords() {
  if (!existsSync(timePath)) return [];
  try {
    return JSON.parse(readFileSync(timePath, "utf8")) || [];
  } catch {
    return [];
  }
}

function writeTimeRecords(records) {
  writeFileSync(timePath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

async function handleTimeAdjustment(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "time-adjust")) {
    sendJson(response, 403, { ok: false, message: "Time adjustment access required." });
    return;
  }

  const payload = await readJsonBody(request);
  const records = readTimeRecords();
  const record = records.find((entry) => entry.id === payload.id);
  const clockIn = new Date(payload.clockIn);
  const clockOut = payload.clockOut ? new Date(payload.clockOut) : null;
  const note = String(payload.note || "").trim();

  if (!record || Number.isNaN(clockIn.getTime()) ||
      (clockOut && (Number.isNaN(clockOut.getTime()) || clockOut < clockIn)) ||
      !note) {
    sendJson(response, 400, {
      ok: false,
      message: "Enter valid times and an adjustment note."
    });
    return;
  }

  if (readApprovalPolicies().requireTimeAdjustments && !hasPermission(session, "approvals")) {
    const approval = createApprovalRequest(session, "time-adjustment", {
      id: payload.id,
      clockIn: clockIn.toISOString(),
      clockOut: clockOut ? clockOut.toISOString() : null,
      note
    }, `Adjust ${record.employeeName || record.username}'s time entry`);
    sendJson(response, 202, {
      ok: true,
      approvalPending: true,
      approval,
      message: "Time adjustment submitted for approval."
    });
    return;
  }

  record.clockIn = clockIn.toISOString();
  record.clockOut = clockOut ? clockOut.toISOString() : null;
  if (clockOut) {
    const laborRate = Number.isFinite(Number(record.laborRate))
      ? Number(record.laborRate) : employeeLaborRate(record.employeeName);
    record.laborRate = roundMoney(laborRate);
    record.laborCost = roundMoney((clockOut - clockIn) / 3600000 * laborRate);
  } else {
    delete record.laborCost;
  }
  record.adjustedBy = session.username;
  record.adjustedAt = new Date().toISOString();
  record.adjustmentNote = note;
  writeTimeRecords(records);
  logActivity(session, "time.adjusted", `Adjusted ${record.employeeName || record.username}'s time entry.`);
  broadcastServiceEvent(record.username, "time-updated");
  sendJson(response, 200, { ok: true, record });
}

function handleAdminTime(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "employee-time") && !hasPermission(session, "reports")) {
    sendJson(response, 403, { ok: false, message: "Employee Time access required." });
    return;
  }

  sendJson(response, 200, {
    ok: true,
    employees: readEmployees(),
    records: readTimeRecords(),
    ticketWorkLogs: readTickets().flatMap((ticket) =>
      (ticket.workLogs || []).map((entry) => ({
        ...entry,
        ticketId: ticket.id,
        ticketNumber: ticket.number,
        ticketType: ticket.ticketType || "Service",
        customer: ticket.customer
      }))
    )
  });
}

async function handleScheduleEvents(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }

  const events = readScheduleEvents();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, events });
    return;
  }

  if (!hasPermission(session, "schedule")) {
    sendJson(response, 403, { ok: false, message: "Schedule access required." });
    return;
  }

  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const event = payload.event;
    if (!event?.title || !/^\d{4}-\d{2}-\d{2}$/.test(event.date || "")) {
      sendJson(response, 400, { ok: false, message: "Event title and date are required." });
      return;
    }
    const record = {
      id: event.id || randomBytes(12).toString("hex"),
      title: String(event.title).trim(),
      date: event.date,
      type: String(event.type || "Company Event"),
      notes: String(event.notes || "").trim(),
      createdBy: session.username
    };
    const index = events.findIndex((item) => item.id === record.id);
    if (index >= 0) events[index] = record;
    else events.push(record);
    writeScheduleEvents(events);
    logActivity(session, index >= 0 ? "schedule.updated" : "schedule.created",
      `${index >= 0 ? "Updated" : "Created"} schedule event ${record.title} on ${record.date}.`);
    broadcastAllServiceEvent("schedule-updated", { eventId: record.id });
    sendJson(response, 200, { ok: true, event: record });
    return;
  }

  if (request.method === "DELETE") {
    const removed = events.find((event) => event.id === payload.id);
    writeScheduleEvents(events.filter((event) => event.id !== payload.id));
    if (removed) logActivity(session, "schedule.deleted",
      `Deleted schedule event ${removed.title} from ${removed.date}.`);
    broadcastAllServiceEvent("schedule-updated", { eventId: payload.id });
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

async function handleAvailability(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  const records = readAvailability();
  const canManage = hasPermission(session, "availability");
  if (request.method === "GET") {
    const visibleRecords = canManage
      ? records.sort((a, b) => a.startDate.localeCompare(b.startDate))
      : records.filter((record) => record.username === session.username)
        .sort((a, b) => b.startDate.localeCompare(a.startDate));
    sendJson(response, 200, {
      ok: true,
      canManage,
      pto: ptoSummary(session.username),
      requests: visibleRecords.map((record) => ({
        ...record,
        ptoBalance: ptoSummary(record.username).balance
      }))
    });
    return;
  }

  const payload = await readJsonBody(request);
  if (request.method === "POST" && payload.action === "review") {
    if (!canManage || !["Approved", "Denied"].includes(payload.status)) {
      sendJson(response, 403, { ok: false, message: "Schedule access is required." });
      return;
    }
    const record = records.find((item) => item.id === payload.id);
    if (!record) {
      sendJson(response, 404, { ok: false, message: "Availability request not found." });
      return;
    }
    if (payload.status === "Approved" && record.type === "PTO") {
      const balance = ptoSummary(record.username, record.id).balance;
      if (Number(record.hoursRequested) > balance + 0.001) {
        sendJson(response, 409, {
          ok: false,
          message: `${record.employeeName} has ${balance.toFixed(2)} PTO hours available, less than the ${Number(record.hoursRequested).toFixed(2)} requested.`
        });
        return;
      }
    }
    record.status = payload.status;
    record.reviewedBy = session.username;
    record.reviewedAt = new Date().toISOString();
    record.reviewNote = String(payload.note || "").trim();
    writeAvailability(records);
    logActivity(session, "availability.reviewed",
      `${payload.status} ${record.employeeName}'s availability request for ${record.startDate} to ${record.endDate}.`);
    broadcastServiceEvent(record.username, "availability-updated", { requestId: record.id });
    broadcastAllServiceEvent("schedule-updated", { availabilityId: record.id });
    broadcastAllServiceEvent("availability-requests-updated", { requestId: record.id });
    sendJson(response, 200, { ok: true, request: record });
    return;
  }

  if (request.method === "POST") {
    const startDate = String(payload.startDate || "");
    const endDate = String(payload.endDate || "");
    const type = ["PTO", "Unpaid Time Off", "Vacation", "Unavailable", "Appointment", "Other"].includes(payload.type)
      ? payload.type : "Unavailable";
    const hoursRequested = Math.round(Number(payload.hoursRequested) * 100) / 100;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) ||
        !/^\d{4}-\d{2}-\d{2}$/.test(endDate) || endDate < startDate ||
        !Number.isFinite(hoursRequested) || hoursRequested <= 0) {
      sendJson(response, 400, { ok: false, message: "Enter valid dates and requested hours." });
      return;
    }
    if (type === "PTO" && hoursRequested > ptoSummary(session.username).balance + 0.001) {
      sendJson(response, 409, {
        ok: false,
        message: `You have ${ptoSummary(session.username).balance.toFixed(2)} PTO hours available.`
      });
      return;
    }
    const record = {
      id: randomBytes(12).toString("hex"),
      username: session.username,
      employeeName: session.employeeName || session.username,
      startDate,
      endDate,
      type,
      hoursRequested,
      reason: String(payload.reason || "").trim(),
      status: "Pending",
      createdAt: new Date().toISOString()
    };
    records.push(record);
    writeAvailability(records);
    logActivity(session, "availability.requested",
      `Requested ${type.toLowerCase()} time from ${startDate} to ${endDate}.`);
    broadcastServiceEvent(session.username, "availability-updated", { requestId: record.id });
    broadcastAllServiceEvent("availability-requests-updated", { requestId: record.id });
    sendJson(response, 200, { ok: true, request: record });
    return;
  }

  if (request.method === "DELETE") {
    const record = records.find((item) => item.id === payload.id);
    if (!record || (!canManage && (record.username !== session.username || record.status !== "Pending"))) {
      sendJson(response, 403, { ok: false, message: "This request cannot be deleted." });
      return;
    }
    writeAvailability(records.filter((item) => item.id !== record.id));
    logActivity(session, "availability.deleted",
      `Deleted ${record.employeeName}'s availability request for ${record.startDate} to ${record.endDate}.`);
    broadcastServiceEvent(record.username, "availability-updated", { requestId: record.id });
    broadcastAllServiceEvent("schedule-updated", { availabilityId: record.id });
    broadcastAllServiceEvent("availability-requests-updated", { requestId: record.id });
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readAvailability() {
  if (!existsSync(availabilityPath)) return [];
  try {
    const records = JSON.parse(readFileSync(availabilityPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeAvailability(records) {
  writeFileSync(availabilityPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function defaultPtoSettings() {
  return {
    newHireToTwo: 3,
    twoToFive: 4,
    fivePlus: 5
  };
}

function readPtoSettings() {
  const defaults = defaultPtoSettings();
  if (!existsSync(ptoSettingsPath)) return defaults;
  try {
    const settings = JSON.parse(readFileSync(ptoSettingsPath, "utf8"));
    const legacyRate = Number.isFinite(Number(settings.hoursPer40))
      ? Number(settings.hoursPer40) : null;
    return {
      newHireToTwo: Number.isFinite(Number(settings.newHireToTwo))
        ? Number(settings.newHireToTwo) : legacyRate ?? defaults.newHireToTwo,
      twoToFive: Number.isFinite(Number(settings.twoToFive))
        ? Number(settings.twoToFive) : legacyRate ?? defaults.twoToFive,
      fivePlus: Number.isFinite(Number(settings.fivePlus))
        ? Number(settings.fivePlus) : legacyRate ?? defaults.fivePlus,
      updatedAt: settings.updatedAt || "",
      updatedBy: settings.updatedBy || ""
    };
  } catch {
    return defaults;
  }
}

function ptoRateForUser(username) {
  const settings = readPtoSettings();
  const user = readUsers().find((record) => record.username === username);
  const employeeName = String(user?.employeeName || username).trim().toLowerCase();
  const employee = readEmployees().find((record) =>
    `${record.firstName || ""} ${record.lastName || ""}`.trim().toLowerCase() === employeeName
  );
  const hireDate = employee?.hireDate ? new Date(`${employee.hireDate}T12:00:00`) : null;
  if (!hireDate || Number.isNaN(hireDate.getTime())) {
    return { rate: settings.newHireToTwo, tier: "New hire - 2 years" };
  }
  const years = (Date.now() - hireDate.getTime()) / (365.2425 * 24 * 60 * 60 * 1000);
  if (years >= 5) return { rate: settings.fivePlus, tier: "5+ years" };
  if (years >= 2) return { rate: settings.twoToFive, tier: "2 - 5 years" };
  return { rate: settings.newHireToTwo, tier: "New hire - 2 years" };
}

function ptoSummary(username, excludeRequestId = "") {
  const tier = ptoRateForUser(username);
  const rate = tier.rate;
  const workedHours = readTimeRecords()
    .filter((record) => record.username === username && record.clockOut)
    .reduce((total, record) =>
      total + Math.max(0, (new Date(record.clockOut) - new Date(record.clockIn)) / 3600000), 0
    );
  const accrued = workedHours / 40 * rate;
  const used = readAvailability()
    .filter((record) =>
      record.id !== excludeRequestId &&
      record.username === username &&
      record.type === "PTO" &&
      record.status === "Approved"
    )
    .reduce((total, record) => total + (Number(record.hoursRequested) || 0), 0);
  return {
    rate,
    tier: tier.tier,
    workedHours: Math.round(workedHours * 100) / 100,
    accrued: Math.round(accrued * 100) / 100,
    used: Math.round(used * 100) / 100,
    balance: Math.round(Math.max(0, accrued - used) * 100) / 100
  };
}

async function handlePtoSettings(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can manage PTO accrual." });
    return;
  }
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, settings: readPtoSettings() });
    return;
  }
  if (request.method === "POST") {
    const payload = await readJsonBody(request);
    const settings = {
      newHireToTwo: Math.round(Number(payload.newHireToTwo) * 100) / 100,
      twoToFive: Math.round(Number(payload.twoToFive) * 100) / 100,
      fivePlus: Math.round(Number(payload.fivePlus) * 100) / 100,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    if ([settings.newHireToTwo, settings.twoToFive, settings.fivePlus].some((value) =>
      !Number.isFinite(value) || value < 0 || value > 40
    )) {
      sendJson(response, 400, { ok: false, message: "Enter accrual amounts between 0 and 40 hours." });
      return;
    }
    writeFileSync(ptoSettingsPath, JSON.stringify(settings, null, 2), { mode: 0o600 });
    logActivity(session, "pto.settings",
      `Updated PTO accrual tiers: ${settings.newHireToTwo}, ${settings.twoToFive}, ${settings.fivePlus} hours per 40.`);
    broadcastAllServiceEvent("pto-updated");
    sendJson(response, 200, { ok: true, settings });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

async function handleDashboardLayout(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  const dashboardTileCatalog = [
    { id: "employee-records", name: "Employee Records", category: "People" },
    { id: "contacts", name: "Contacts", category: "People" },
    { id: "employee-time", name: "Employee Time", category: "People" },
    { id: "availability", name: "Employee Availability", category: "People" },
    { id: "payroll", name: "Payroll Hours", category: "People" },
    { id: "service-tickets", name: "Service Tickets", category: "Operations" },
    { id: "job-workspace", name: "Job Workspace", category: "Operations" },
    { id: "customers", name: "Customers", category: "Operations" },
    { id: "warranties", name: "Equipment Registry", category: "Operations" },
    { id: "schedule", name: "Schedule", category: "Operations" },
    { id: "dispatch", name: "Dispatch", category: "Operations" },
    { id: "route-planning", name: "Route Planning", category: "Operations" },
    { id: "unifi", name: "UniFi Operations", category: "Operations" },
    { id: "command-center", name: "Command Center", category: "Operations" },
    { id: "announcements", name: "Announcements & Operations", category: "Operations" },
    { id: "documents", name: "File Browser", category: "Company Tools" },
    { id: "design-center", name: "Design Center", category: "Company Tools" },
    { id: "field-toolkit", name: "Field Toolkit", category: "Company Tools" },
    { id: "password-vault", name: "Password Vault", category: "Company Tools" },
    { id: "inventory", name: "Inventory", category: "Company Tools" },
    { id: "inventory-scanner", name: "Inventory Scanner", category: "Company Tools" },
    { id: "catalog", name: "Catalog", category: "Company Tools" },
    { id: "catalog-import", name: "Catalog Import", category: "Company Tools" },
    { id: "bids", name: "Bids", category: "Company Tools" },
    { id: "badge-maker", name: "Labels & Badges", category: "Company Tools" },
    { id: "invoicing", name: "Invoicing", category: "Finance" },
    { id: "finance", name: "Finance", category: "Finance" },
    { id: "taxes", name: "Tax Center", category: "Finance" },
    { id: "bills", name: "Bills & Loans", category: "Finance" },
    { id: "banking", name: "Banking", category: "Finance" },
    { id: "profit-loss", name: "Profit & Loss", category: "Finance" },
    { id: "customer-portal", name: "Customer Portal", category: "Finance" },
    { id: "estimates", name: "Estimates & Quotes", category: "Finance" },
    { id: "approvals", name: "Approvals", category: "Administration" },
    { id: "reports", name: "Reports", category: "Administration" },
    { id: "install-apps", name: "App Store", category: "Administration" },
    { id: "operations-center", name: "Operations Center", category: "Administration" },
    { id: "diagnostics", name: "Server Diagnostics", category: "Administration" },
    { id: "site-update", name: "Website Updater", category: "Administration" },
    { id: "security", name: "Security Center", category: "Administration" }
    ,{ id: "recent-activity", name: "Recent Activity", category: "Dashboard Sections" }
  ];
  dashboardTileCatalog.push(...readInstalledApps().map((app) => ({
    id: `app-${app.id}`,
    name: app.name,
    category: "Installed Apps"
  })));
  const allowedItems = new Set(dashboardTileCatalog.map((item) => item.id));
  const layouts = readDashboardLayouts();
  const hiddenItems = Array.isArray(layouts.__dashboardTiles?.hiddenItems)
    ? layouts.__dashboardTiles.hiddenItems.filter((id) => allowedItems.has(id))
    : [];
  const saved = layouts[session.username] || {
    folders: [], assignments: {}, favorites: [], density: "comfortable", tileNames: {}
  };
  const profileState = saved.profiles
    ? saved
    : { activeProfile: "Default", profiles: { Default: saved } };
  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      layout: profileState.profiles[profileState.activeProfile] || {
        folders: [], assignments: {}, favorites: [], density: "comfortable", tileNames: {}
      },
      profiles: Object.keys(profileState.profiles),
      activeProfile: profileState.activeProfile,
      hiddenItems,
      availableItems: session.username === "Huber58" ? dashboardTileCatalog : undefined
    });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const payload = await readJsonBody(request);
  if (payload.action === "visibility") {
    if (session.username !== "Huber58") {
      sendJson(response, 403, { ok: false, message: "Only Huber58 can change dashboard tile visibility." });
      return;
    }
    const nextHiddenItems = Array.isArray(payload.hiddenItems)
      ? [...new Set(payload.hiddenItems.filter((id) => allowedItems.has(id)))]
      : [];
    layouts.__dashboardTiles = {
      hiddenItems: nextHiddenItems,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    writeFileSync(dashboardLayoutsPath, JSON.stringify(layouts, null, 2), { mode: 0o600 });
    logActivity(session, "dashboard.visibility", `Updated dashboard visibility; ${nextHiddenItems.length} tiles hidden.`);
    broadcastAllServiceEvent("dashboard-tiles-updated", { hiddenItems: nextHiddenItems });
    sendJson(response, 200, {
      ok: true,
      hiddenItems: nextHiddenItems,
      availableItems: dashboardTileCatalog
    });
    return;
  }
  if (payload.action === "switch") {
    const name = String(payload.name || "");
    if (!profileState.profiles[name]) {
      sendJson(response, 404, { ok: false, message: "Dashboard profile not found." });
      return;
    }
    profileState.activeProfile = name;
    layouts[session.username] = profileState;
    writeFileSync(dashboardLayoutsPath, JSON.stringify(layouts, null, 2), { mode: 0o600 });
    sendJson(response, 200, {
      ok: true, layout: profileState.profiles[name],
      profiles: Object.keys(profileState.profiles), activeProfile: name
    });
    return;
  }
  if (payload.action === "create") {
    const name = String(payload.name || "").trim().slice(0, 30);
    if (!name || profileState.profiles[name]) {
      sendJson(response, 409, { ok: false, message: "Enter a unique profile name." });
      return;
    }
    profileState.profiles[name] = structuredClone(
      profileState.profiles[profileState.activeProfile] || {
        folders: [], assignments: {}, favorites: [], density: "comfortable", tileNames: {}
      }
    );
    profileState.activeProfile = name;
    layouts[session.username] = profileState;
    writeFileSync(dashboardLayoutsPath, JSON.stringify(layouts, null, 2), { mode: 0o600 });
    sendJson(response, 200, {
      ok: true, layout: profileState.profiles[name],
      profiles: Object.keys(profileState.profiles), activeProfile: name
    });
    return;
  }
  if (payload.action === "delete") {
    const name = String(payload.name || "");
    if (name === "Default" || !profileState.profiles[name]) {
      sendJson(response, 400, { ok: false, message: "The Default profile cannot be deleted." });
      return;
    }
    delete profileState.profiles[name];
    profileState.activeProfile = "Default";
    layouts[session.username] = profileState;
    writeFileSync(dashboardLayoutsPath, JSON.stringify(layouts, null, 2), { mode: 0o600 });
    sendJson(response, 200, {
      ok: true, layout: profileState.profiles.Default,
      profiles: Object.keys(profileState.profiles), activeProfile: "Default"
    });
    return;
  }
  const seenFolders = new Set();
  const folders = Array.isArray(payload.folders)
    ? payload.folders.slice(0, 20).map((folder) => ({
        id: String(folder.id || "").trim(),
        name: String(folder.name || "").trim().slice(0, 40)
      })).filter((folder) =>
        /^[a-zA-Z0-9_-]{1,60}$/.test(folder.id) &&
        folder.name &&
        folder.name.toLowerCase() !== "ui" &&
        !seenFolders.has(folder.id) &&
        seenFolders.add(folder.id)
      )
    : [];
  const folderIds = new Set(folders.map((folder) => folder.id));
  const assignments = {};
  if (payload.assignments && typeof payload.assignments === "object") {
    for (const [itemId, folderId] of Object.entries(payload.assignments)) {
      if (allowedItems.has(itemId) && folderIds.has(folderId)) assignments[itemId] = folderId;
    }
  }
  const favorites = Array.isArray(payload.favorites)
    ? [...new Set(payload.favorites.filter((itemId) => allowedItems.has(itemId)))].slice(0, 12)
    : [];
  const density = payload.density === "compact" ? "compact" : "comfortable";
  const tileNames = {};
  if (payload.tileNames && typeof payload.tileNames === "object") {
    const validFolderIds = new Set(["system-ui", ...folderIds]);
    for (const [key, value] of Object.entries(payload.tileNames).slice(0, 80)) {
      const name = String(value || "").trim().slice(0, 40);
      const toolId = key.startsWith("tool:") ? key.slice(5) : "";
      const folderId = key.startsWith("folder:") ? key.slice(7) : "";
      if (name && ((toolId && allowedItems.has(toolId)) ||
          (folderId && validFolderIds.has(folderId)))) tileNames[key] = name;
    }
  }
  profileState.profiles[profileState.activeProfile] = {
    folders, assignments, favorites, density, tileNames
  };
  layouts[session.username] = profileState;
  writeFileSync(dashboardLayoutsPath, JSON.stringify(layouts, null, 2), { mode: 0o600 });
  logActivity(session, "dashboard.organized", "Updated personal dashboard folders.");
  sendJson(response, 200, {
    ok: true,
    layout: profileState.profiles[profileState.activeProfile],
    profiles: Object.keys(profileState.profiles),
    activeProfile: profileState.activeProfile
  });
}

function readAnnouncements() {
  if (!existsSync(announcementsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(announcementsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

async function handleAnnouncements(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  const records = readAnnouncements();
  const canManage = hasPermission(session, "announcements");
  if (request.method === "GET") {
    const url = new URL(request.url, publicOrigin(request));
    const surface = url.searchParams.get("surface") === "service" ? "Service" : "Office";
    const managing = canManage && url.searchParams.get("manage") === "1";
    const today = businessToday();
    const visible = managing ? records : records.filter((record) =>
      record.active !== false &&
      (!record.startsAt || record.startsAt <= today) &&
      (!record.endsAt || record.endsAt >= today) &&
      ["Everyone", surface].includes(record.audience)
    );
    sendJson(response, 200, { ok: true, announcements: visible, canManage });
    return;
  }
  if (!canManage) {
    sendJson(response, 403, { ok: false, message: "Announcement access required." });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const title = String(payload.title || "").trim().slice(0, 100);
    const message = String(payload.message || "").trim().slice(0, 2000);
    const audience = ["Everyone", "Office", "Service"].includes(payload.audience)
      ? payload.audience : "Everyone";
    if (!title || !message) {
      sendJson(response, 400, { ok: false, message: "Enter a title and announcement." });
      return;
    }
    const existing = records.find((record) => record.id === payload.id);
    const record = {
      id: existing?.id || randomBytes(12).toString("hex"),
      title,
      message,
      audience,
      priority: ["Normal", "Important"].includes(payload.priority) ? payload.priority : "Normal",
      startsAt: validDateOnly(payload.startsAt),
      endsAt: validDateOnly(payload.endsAt),
      active: payload.active !== false,
      createdAt: existing?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    const index = records.findIndex((item) => item.id === record.id);
    if (index >= 0) records[index] = record;
    else records.push(record);
    writeFileSync(announcementsPath, JSON.stringify(records, null, 2), { mode: 0o600 });
    logActivity(session, "announcement.saved", `Saved announcement ${record.title}.`);
    broadcastAllServiceEvent("announcements-updated");
    sendJson(response, 200, { ok: true, announcement: record });
    return;
  }
  if (request.method === "DELETE") {
    writeFileSync(announcementsPath,
      JSON.stringify(records.filter((record) => record.id !== payload.id), null, 2),
      { mode: 0o600 });
    logActivity(session, "announcement.deleted", "Deleted a company announcement.");
    broadcastAllServiceEvent("announcements-updated");
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readTicketEscalation() {
  if (!existsSync(ticketEscalationPath)) {
    return { urgentMinutes: 60, highMinutes: 240, enabled: true, notified: {} };
  }
  try {
    const saved = JSON.parse(readFileSync(ticketEscalationPath, "utf8"));
    return {
      urgentMinutes: Math.max(5, Number(saved.urgentMinutes) || 60),
      highMinutes: Math.max(5, Number(saved.highMinutes) || 240),
      enabled: saved.enabled !== false,
      notified: saved.notified && typeof saved.notified === "object" ? saved.notified : {}
    };
  } catch {
    return { urgentMinutes: 60, highMinutes: 240, enabled: true, notified: {} };
  }
}

async function runTicketEscalations() {
  const settings = readTicketEscalation();
  if (!settings.enabled) return;
  const tickets = readTickets();
  let ticketDatesChanged = false;
  for (const ticket of tickets) {
    if (ticket.createdAt) continue;
    ticket.createdAt = new Date().toISOString();
    ticket.updatedAt = ticket.updatedAt || ticket.createdAt;
    ticketDatesChanged = true;
  }
  if (ticketDatesChanged) writeTickets(tickets);
  const openIds = new Set(tickets.filter((ticket) => ticket.status === "Open").map((ticket) => ticket.id));
  for (const id of Object.keys(settings.notified)) {
    if (!openIds.has(id)) delete settings.notified[id];
  }
  const managers = readUsers().filter((user) =>
    user.username === "Huber58" || user.role === "Admin"
  );
  const notifications = readNotifications();
  let changed = false;
  for (const ticket of tickets.filter((record) =>
    record.status === "Open" && ["High", "Urgent"].includes(record.priority)
  )) {
    const threshold = ticket.priority === "Urgent"
      ? settings.urgentMinutes : settings.highMinutes;
    const ruleKey = `${ticket.priority}:${threshold}`;
    const ageMinutes = (Date.now() -
      new Date(ticket.updatedAt || ticket.createdAt || Date.now()).getTime()) / 60000;
    if (ageMinutes < threshold || settings.notified[ticket.id] === ruleKey) continue;
    for (const manager of managers) {
      const notification = {
        id: randomBytes(12).toString("hex"),
        username: manager.username,
        ticketId: ticket.id,
        title: `${ticket.priority} ticket escalation`,
        message: `${ticketLabel(ticket)} for ${ticket.customer} has remained open beyond ${threshold} minutes.`,
        url: "/service-tickets.html",
        createdAt: new Date().toISOString(),
        read: false
      };
      notifications.push(notification);
      void sendPushNotification(manager.username, notification).catch(() => {});
    }
    settings.notified[ticket.id] = ruleKey;
    changed = true;
  }
  if (!changed) return;
  writeNotifications(notifications.slice(-2000));
  writeFileSync(ticketEscalationPath, JSON.stringify(settings, null, 2), { mode: 0o600 });
  broadcastAllServiceEvent("dashboard-updated", { area: "escalation" });
}

async function handleTicketEscalation(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "announcements")) {
    sendJson(response, session ? 403 : 401, {
      ok: false, message: session ? "Operations settings access required." : "Please sign in."
    });
    return;
  }
  const settings = readTicketEscalation();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, settings });
    return;
  }
  if (request.method === "POST") {
    const payload = await readJsonBody(request);
    settings.enabled = payload.enabled !== false;
    settings.urgentMinutes = Math.min(10080, Math.max(5, Number(payload.urgentMinutes) || 60));
    settings.highMinutes = Math.min(10080, Math.max(5, Number(payload.highMinutes) || 240));
    writeFileSync(ticketEscalationPath, JSON.stringify(settings, null, 2), { mode: 0o600 });
    logActivity(session, "ticket.escalation", "Updated ticket escalation rules.");
    broadcastAllServiceEvent("dashboard-updated", { area: "escalation" });
    sendJson(response, 200, { ok: true, settings });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readDashboardLayouts() {
  if (!existsSync(dashboardLayoutsPath)) return {};
  try {
    const layouts = JSON.parse(readFileSync(dashboardLayoutsPath, "utf8"));
    return layouts && typeof layouts === "object" && !Array.isArray(layouts) ? layouts : {};
  } catch {
    return {};
  }
}

async function handleTheme(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  const themes = readUserThemes();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, theme: themes[session.username] || "system" });
    return;
  }
  if (request.method === "POST") {
    const payload = await readJsonBody(request);
    const theme = String(payload.theme || "");
    if (!["professional", "midnight", "contrast", "modern", "coastal", "ember", "orchard", "steel", "light", "dark", "system"].includes(theme)) {
      sendJson(response, 400, { ok: false, message: "Choose a valid appearance theme." });
      return;
    }
    themes[session.username] = theme;
    writeFileSync(userThemesPath, JSON.stringify(themes, null, 2), { mode: 0o600 });
    logActivity(session, "account.theme", `Changed account theme to ${theme}.`);
    sendJson(response, 200, { ok: true, theme });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readUserThemes() {
  if (!existsSync(userThemesPath)) return {};
  try {
    const themes = JSON.parse(readFileSync(userThemesPath, "utf8"));
    return themes && typeof themes === "object" && !Array.isArray(themes) ? themes : {};
  } catch {
    return {};
  }
}

function availabilityWarningsForTicket(ticket) {
  if (!ticketAssignees(ticket).length || !ticket.scheduledDate) return [];
  const employees = new Set(ticketAssignees(ticket).map((name) => name.toLowerCase()));
  return readAvailability()
    .filter((record) =>
      record.status === "Approved" &&
      employees.has(record.employeeName.trim().toLowerCase()) &&
      ticket.scheduledDate >= record.startDate &&
      ticket.scheduledDate <= record.endDate
    )
    .map((record) =>
      `${record.employeeName} is ${record.type.toLowerCase()} from ${record.startDate} through ${record.endDate}.`
    );
}

async function handleItemCategories(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "catalog") && !hasPermission(session, "inventory")) {
    sendJson(response, 403, { ok: false, message: "Catalog or Inventory access required." });
    return;
  }

  const categories = readItemCategories();
  const knownNames = new Set(categories.map((category) => category.name.toLowerCase()));
  for (const name of [...readCatalog(), ...readInventory()].map((item) => String(item.category || "").trim())) {
    if (!name || knownNames.has(name.toLowerCase())) continue;
    knownNames.add(name.toLowerCase());
    categories.push({ id: randomBytes(8).toString("hex"), name });
  }
  categories.sort((a, b) => a.name.localeCompare(b.name));

  if (request.method === "GET") {
    writeItemCategories(categories);
    sendJson(response, 200, { ok: true, categories });
    return;
  }

  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const name = String(payload.name || "").trim().slice(0, 60);
    if (!name) {
      sendJson(response, 400, { ok: false, message: "Enter a category name." });
      return;
    }
    if (categories.some((category) => category.name.toLowerCase() === name.toLowerCase())) {
      sendJson(response, 409, { ok: false, message: "That category already exists." });
      return;
    }
    const category = { id: randomBytes(8).toString("hex"), name };
    categories.push(category);
    categories.sort((a, b) => a.name.localeCompare(b.name));
    writeItemCategories(categories);
    logActivity(session, "category.created", `Created item category ${name}.`);
    sendJson(response, 200, { ok: true, category, categories });
    return;
  }

  if (request.method === "DELETE") {
    const category = categories.find((record) => record.id === payload.id);
    if (!category) {
      sendJson(response, 404, { ok: false, message: "Category not found." });
      return;
    }
    const inUse = [...readCatalog(), ...readInventory()].some((item) =>
      String(item.category || "").toLowerCase() === category.name.toLowerCase()
    );
    if (inUse) {
      sendJson(response, 409, {
        ok: false,
        message: "Move items out of this category before deleting it."
      });
      return;
    }
    const remaining = categories.filter((record) => record.id !== category.id);
    writeItemCategories(remaining);
    logActivity(session, "category.deleted", `Deleted item category ${category.name}.`);
    sendJson(response, 200, { ok: true, categories: remaining });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readItemCategories() {
  if (!existsSync(itemCategoriesPath)) return [];
  try {
    const categories = JSON.parse(readFileSync(itemCategoriesPath, "utf8"));
    return Array.isArray(categories)
      ? categories.filter((category) => category?.id && category?.name)
      : [];
  } catch {
    return [];
  }
}

function writeItemCategories(categories) {
  writeFileSync(itemCategoriesPath, JSON.stringify(categories, null, 2), { mode: 0o600 });
}

function readScheduleEvents() {
  if (!existsSync(scheduleEventsPath)) return [];
  try {
    return JSON.parse(readFileSync(scheduleEventsPath, "utf8")) || [];
  } catch {
    return [];
  }
}

function writeScheduleEvents(events) {
  writeFileSync(scheduleEventsPath, JSON.stringify(events, null, 2), { mode: 0o600 });
}

async function handleInventory(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "inventory")) {
    sendJson(response, 403, { ok: false, message: "Inventory access required." });
    return;
  }

  const items = readInventory();
  if (request.method === "GET") {
    const catalogItems = readCatalog();
    let changed = false;
    const syncedItems = items.map((item) => {
      const catalogItem = catalogItems.find((record) => record.id === item.catalogItemId);
      if (!catalogItem) return item;
      const variation = item.catalogVariationId
        ? (catalogItem.variations || []).find((record) => record.id === item.catalogVariationId)
        : null;
      const synced = {
        ...item,
        name: catalogItem.name,
        sku: catalogItem.sku,
        category: catalogItem.category || "",
        unitCost: variation
          ? roundMoney(Number(catalogItem.unitCost || 0) + Number(variation.priceAdjustment || 0))
          : item.catalogVariationId ? item.unitCost : catalogItem.unitCost,
        variationName: variation?.name || item.variationName || "Standard",
        priceAdjustment: variation?.priceAdjustment ?? item.priceAdjustment ?? 0
      };
      if (JSON.stringify(synced) !== JSON.stringify(item)) changed = true;
      return synced;
    });
    if (changed) writeInventory(syncedItems);
    sendJson(response, 200, { ok: true, items: syncedItems, catalogItems });
    return;
  }

  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const item = payload.item;
    const existing = items.find((record) => record.id === item?.id);
    const catalogItem = readCatalog().find((record) =>
      record.id === item?.catalogItemId &&
      (record.active || existing?.catalogItemId === record.id)
    );
    const catalogVariationId = String(item?.catalogVariationId || "");
    const catalogVariation = catalogVariationId
      ? (catalogItem?.variations || []).find((record) => record.id === catalogVariationId)
      : null;
    const preservedVariation = existing?.catalogVariationId === catalogVariationId
      ? {
          id: existing.catalogVariationId,
          name: existing.variationName,
          priceAdjustment: existing.priceAdjustment
        }
      : null;
    const selectedVariation = catalogVariation || preservedVariation;
    if (!catalogItem && (!existing || existing.catalogItemId || !item?.name || !item?.sku)) {
      sendJson(response, 400, { ok: false, message: "Select an active catalog item." });
      return;
    }
    if (catalogItem && catalogVariationId && !selectedVariation) {
      sendJson(response, 400, { ok: false, message: "Select a valid catalog variation." });
      return;
    }
    if (catalogItem && items.some((record) =>
      record.catalogItemId === catalogItem.id &&
      String(record.catalogVariationId || "") === catalogVariationId &&
      record.id !== item.id
    )) {
      sendJson(response, 409, { ok: false, message: "That catalog item and variation are already in inventory." });
      return;
    }
    const itemName = catalogItem?.name || item.name;
    const itemSku = catalogItem?.sku || item.sku;
    const duplicate = items.find((record) =>
      record.sku.toLowerCase() === String(itemSku).trim().toLowerCase() &&
      record.id !== item.id
    );
    if (duplicate) {
      sendJson(response, 409, { ok: false, message: "That SKU is already in use." });
      return;
    }
    const baseCost = Math.max(0, Number(catalogItem?.unitCost ?? item.unitCost) || 0);
    const unitCost = roundMoney(baseCost + Number(selectedVariation?.priceAdjustment || 0));
    const variationNames = new Set();
    const variations = [];
    const sourceVariations = catalogItem ? [] : item.variations;
    for (const variation of (Array.isArray(sourceVariations) ? sourceVariations : []).slice(0, 50)) {
      const name = String(variation.name || "").trim().slice(0, 100);
      const priceAdjustment = roundMoney(Number(variation.priceAdjustment) || 0);
      const normalizedName = name.toLowerCase();
      if (!name || variationNames.has(normalizedName) || unitCost + priceAdjustment < 0) {
        sendJson(response, 400, {
          ok: false,
          message: "Each variation needs a unique name and a final price of zero or more."
        });
        return;
      }
      variationNames.add(normalizedName);
      variations.push({
        id: String(variation.id || randomBytes(8).toString("hex")),
        name,
        priceAdjustment
      });
    }
    const record = {
      id: item.id || randomBytes(12).toString("hex"),
      catalogItemId: catalogItem?.id || existing?.catalogItemId || "",
      catalogVariationId: catalogItem ? catalogVariationId : existing?.catalogVariationId || "",
      variationName: catalogItem
        ? selectedVariation?.name || "Standard"
        : existing?.variationName || "",
      priceAdjustment: catalogItem
        ? Number(selectedVariation?.priceAdjustment || 0)
        : Number(existing?.priceAdjustment || 0),
      name: String(itemName).trim(),
      sku: String(itemSku).trim(),
      category: String(catalogItem?.category ?? item.category ?? "").trim(),
      quantity: Math.max(0, Number(item.quantity) || 0),
      reorderLevel: Math.max(0, Number(item.reorderLevel) || 0),
      location: String(item.location || "").trim(),
      unitCost,
      variations,
      notes: String(item.notes || "").trim(),
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    const index = items.findIndex((existing) => existing.id === record.id);
    if (index >= 0) items[index] = record;
    else items.push(record);
    writeInventory(items);
    logActivity(session, index >= 0 ? "inventory.updated" : "inventory.created",
      `${index >= 0 ? "Updated" : "Created"} inventory item ${record.name} (${record.sku}).`);
    broadcastAllServiceEvent("dashboard-updated", { area: "inventory" });
    sendJson(response, 200, { ok: true, item: record });
    return;
  }

  if (request.method === "DELETE") {
    const removed = items.find((item) => item.id === payload.id);
    writeInventory(items.filter((item) => item.id !== payload.id));
    if (removed) logActivity(session, "inventory.deleted", `Deleted inventory item ${removed.name} (${removed.sku}).`);
    broadcastAllServiceEvent("dashboard-updated", { area: "inventory" });
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readInventory() {
  if (!existsSync(inventoryPath)) return [];
  try {
    return JSON.parse(readFileSync(inventoryPath, "utf8")) || [];
  } catch {
    return [];
  }
}

function writeInventory(items) {
  writeFileSync(inventoryPath, JSON.stringify(items, null, 2), { mode: 0o600 });
}

function readAssets() {
  if (!existsSync(assetsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(assetsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeAssets(records) {
  writeFileSync(assetsPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function createAssetId(records) {
  let assetId;
  do {
    assetId = `HITP-${randomBytes(4).toString("hex").toUpperCase()}`;
  } while (records.some((record) => record.assetId === assetId));
  return assetId;
}

function readPasswordVaultEnvelope() {
  if (!existsSync(passwordVaultPath)) return null;
  try {
    const envelope = JSON.parse(readFileSync(passwordVaultPath, "utf8"));
    return validPasswordVaultEnvelope(envelope) ? envelope : null;
  } catch {
    return null;
  }
}

function validPasswordVaultEnvelope(envelope) {
  if (!envelope || typeof envelope !== "object" || Array.isArray(envelope)) return false;
  if (envelope.version !== 1 || envelope.kdf !== "PBKDF2-SHA256" ||
      envelope.cipher !== "AES-256-GCM") return false;
  if (!Number.isInteger(envelope.iterations) ||
      envelope.iterations < 100_000 || envelope.iterations > 1_500_000) return false;
  const base64 = /^[A-Za-z0-9+/]+={0,2}$/;
  if (![envelope.salt, envelope.iv, envelope.ciphertext].every((value) =>
    typeof value === "string" && base64.test(value))) return false;
  try {
    return Buffer.from(envelope.salt, "base64").length === 16 &&
      Buffer.from(envelope.iv, "base64").length === 12 &&
      Buffer.from(envelope.ciphertext, "base64").length >= 17 &&
      Buffer.from(envelope.ciphertext, "base64").length <= 750_000;
  } catch {
    return false;
  }
}

async function handlePasswordVault(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Owner access required." });
    return;
  }

  if (request.method === "GET") {
    const vault = readPasswordVaultEnvelope();
    sendJson(response, 200, { ok: true, configured: Boolean(vault), vault });
    return;
  }

  const payload = await readJsonBody(request);
  if (request.method === "PUT") {
    const envelope = payload.vault;
    if (!validPasswordVaultEnvelope(envelope)) {
      sendJson(response, 400, {
        ok: false,
        message: "The encrypted vault package is invalid."
      });
      return;
    }
    const saved = {
      version: 1,
      kdf: "PBKDF2-SHA256",
      cipher: "AES-256-GCM",
      iterations: envelope.iterations,
      salt: envelope.salt,
      iv: envelope.iv,
      ciphertext: envelope.ciphertext,
      updatedAt: new Date().toISOString()
    };
    writeFileSync(passwordVaultPath, JSON.stringify(saved, null, 2), { mode: 0o600 });
    logActivity(session, "password-vault.updated", "Updated the encrypted owner password vault.");
    sendJson(response, 200, { ok: true, updatedAt: saved.updatedAt });
    return;
  }

  if (request.method === "DELETE") {
    const user = readUsers().find((record) => record.username === session.username);
    if (!user || !verifyPassword(String(payload.accountPassword || ""), user.salt, user.hash)) {
      sendJson(response, 403, { ok: false, message: "Your account password is incorrect." });
      return;
    }
    structuredStore.delete(passwordVaultPath);
    if (fsExistsSync(passwordVaultPath)) unlinkSync(passwordVaultPath);
    logActivity(session, "password-vault.reset", "Reset the encrypted owner password vault.");
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

async function handleAssets(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Admin access required." });
    return;
  }
  const records = readAssets();
  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      assets: [...records].sort((a, b) =>
        String(b.updatedAt || b.createdAt).localeCompare(String(a.updatedAt || a.createdAt))
      )
    });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const productName = String(payload.productName || "").trim().slice(0, 120);
    const description = String(payload.description || "").trim().slice(0, 600);
    const serialNumber = String(payload.serialNumber || "").trim().slice(0, 120);
    const assignedTo = String(payload.assignedTo || "").trim().slice(0, 120);
    const requestedAssignedDate = String(payload.assignedDate || "").trim();
    const existing = records.find((record) => record.id === payload.id);
    if (!productName || !serialNumber) {
      sendJson(response, 400, { ok: false, message: "Enter a product name and serial number." });
      return;
    }
    if (records.some((record) => record.id !== existing?.id &&
        String(record.serialNumber).toLowerCase() === serialNumber.toLowerCase())) {
      sendJson(response, 409, { ok: false, message: "An asset with that serial number already exists." });
      return;
    }
    const now = new Date().toISOString();
    const assignedDate = assignedTo
      ? validDateOnly(requestedAssignedDate)
        ? requestedAssignedDate
        : existing?.assignedTo === assignedTo && validDateOnly(existing?.assignedDate)
          ? existing.assignedDate
          : businessToday()
      : "";
    const asset = {
      id: existing?.id || randomBytes(12).toString("hex"),
      assetId: existing?.assetId || createAssetId(records),
      productName,
      description,
      serialNumber,
      assignedTo,
      assignedDate,
      createdAt: existing?.createdAt || now,
      createdBy: existing?.createdBy || session.username,
      updatedAt: now,
      updatedBy: session.username
    };
    const index = records.findIndex((record) => record.id === asset.id);
    if (index >= 0) records[index] = asset;
    else records.push(asset);
    writeAssets(records);
    logActivity(session, index >= 0 ? "asset.updated" : "asset.created",
      `${index >= 0 ? "Updated" : "Created"} asset ${asset.assetId} for ${asset.productName}` +
      `${asset.assignedTo ? `, assigned to ${asset.assignedTo}` : ""}.`);
    sendJson(response, 200, { ok: true, asset });
    return;
  }
  if (request.method === "DELETE") {
    const asset = records.find((record) => record.id === payload.id);
    if (!asset) {
      sendJson(response, 404, { ok: false, message: "Asset not found." });
      return;
    }
    writeAssets(records.filter((record) => record.id !== asset.id));
    logActivity(session, "asset.deleted", `Deleted asset ${asset.assetId} for ${asset.productName}.`);
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readBids() {
  if (!existsSync(bidsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(bidsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeBids(records) {
  writeFileSync(bidsPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function cleanBidLine(line) {
  return {
    id: /^[a-f0-9]{24}$/.test(String(line?.id || ""))
      ? line.id : randomBytes(12).toString("hex"),
    category: String(line?.category || "Other").trim().slice(0, 60) || "Other",
    name: String(line?.name || "").trim().slice(0, 140),
    quantity: roundMoney(Math.max(0, Number(line?.quantity) || 0)),
    materialCost: roundMoney(Math.max(0, Number(line?.materialCost) || 0)),
    laborHours: roundMoney(Math.max(0, Number(line?.laborHours) || 0)),
    additionalPrice: roundMoney(Math.max(0, Number(line?.additionalPrice) || 0)),
    notes: String(line?.notes || "").trim().slice(0, 300)
  };
}

async function handleBids(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "bids")) {
    sendJson(response, 403, { ok: false, message: "Bids access required." });
    return;
  }
  const records = readBids();
  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      bids: [...records].sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)))
    });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const existing = records.find((record) => record.id === payload.id);
    const projectName = String(payload.projectName || "").trim().slice(0, 140);
    const customer = String(payload.customer || "").trim().slice(0, 140);
    if (!projectName || !customer) {
      sendJson(response, 400, { ok: false, message: "Enter a project name and customer." });
      return;
    }
    const lines = (Array.isArray(payload.lines) ? payload.lines : [])
      .slice(0, 250).map(cleanBidLine).filter((line) => line.name && line.quantity > 0);
    if (!lines.length) {
      sendJson(response, 400, { ok: false, message: "Add at least one bid item." });
      return;
    }
    const now = new Date().toISOString();
    const bid = {
      id: existing?.id || randomBytes(12).toString("hex"),
      number: existing?.number || records.reduce((highest, record) =>
        Math.max(highest, Number(record.number) || 0), 0) + 1,
      projectName,
      customer,
      address: String(payload.address || "").trim().slice(0, 300),
      status: ["Draft", "Presented", "Won", "Lost"].includes(payload.status)
        ? payload.status : "Draft",
      materialMargin: Math.min(90, roundMoney(Math.max(0, Number(payload.materialMargin) || 0))),
      laborRate: roundMoney(Math.max(0, Number(payload.laborRate) || 0)),
      projectCharge: roundMoney(Math.max(0, Number(payload.projectCharge) || 0)),
      contingencyPercent: Math.min(50, roundMoney(Math.max(0, Number(payload.contingencyPercent) || 0))),
      taxPercent: Math.min(30, roundMoney(Math.max(0, Number(payload.taxPercent) || 0))),
      notes: String(payload.notes || "").trim().slice(0, 2000),
      lines,
      createdAt: existing?.createdAt || now,
      createdBy: existing?.createdBy || session.username,
      updatedAt: now,
      updatedBy: session.username
    };
    const index = records.findIndex((record) => record.id === bid.id);
    if (index >= 0) records[index] = bid;
    else records.push(bid);
    writeBids(records);
    logActivity(session, index >= 0 ? "bid.updated" : "bid.created",
      `${index >= 0 ? "Updated" : "Created"} bid B-${String(bid.number).padStart(4, "0")} for ${bid.customer}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "bids" });
    sendJson(response, 200, { ok: true, bid });
    return;
  }
  if (request.method === "DELETE") {
    const bid = records.find((record) => record.id === payload.id);
    if (!bid) {
      sendJson(response, 404, { ok: false, message: "Bid not found." });
      return;
    }
    writeBids(records.filter((record) => record.id !== bid.id));
    logActivity(session, "bid.deleted",
      `Deleted bid B-${String(bid.number).padStart(4, "0")} for ${bid.customer}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "bids" });
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readBadges() {
  if (!existsSync(badgesPath)) return [];
  try {
    const records = JSON.parse(readFileSync(badgesPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeBadges(records) {
  writeFileSync(badgesPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

async function handleBadges(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "badge-maker")) {
    sendJson(response, 403, { ok: false, message: "Badge Maker access required." });
    return;
  }
  const url = new URL(request.url, `http://${request.headers.host || "localhost"}`);
  const records = readBadges();
  if (url.pathname === "/api/badges/photo" && request.method === "GET") {
    const badge = records.find((record) => record.id === url.searchParams.get("id"));
    const filePath = badge?.photoStoredName && resolve(badgePhotosPath, badge.photoStoredName);
    if (!badge || !filePath || !filePath.startsWith(`${badgePhotosPath}${sep}`) || !existsSync(filePath)) {
      sendJson(response, 404, { ok: false, message: "Badge photo not found." });
      return;
    }
    response.writeHead(200, {
      "Content-Type": badge.photoContentType || "image/jpeg",
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff"
    });
    createReadStream(filePath).pipe(response);
    return;
  }
  if (url.pathname === "/api/badges/photo" && request.method === "POST") {
    const badge = records.find((record) => record.id === url.searchParams.get("id"));
    const contentType = String(request.headers["content-type"] || "").toLowerCase();
    const extensions = { "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp" };
    if (!badge || !extensions[contentType]) {
      sendJson(response, badge ? 400 : 404, {
        ok: false,
        message: badge ? "Upload a JPG, PNG, or WebP photo." : "Save the badge before uploading its photo."
      });
      return;
    }
    const body = await readBinaryBody(request, 8 * 1024 * 1024);
    if (!body.length) {
      sendJson(response, 400, { ok: false, message: "Choose a photo to upload." });
      return;
    }
    if (badge.photoStoredName) {
      const previousPath = resolve(badgePhotosPath, badge.photoStoredName);
      if (previousPath.startsWith(`${badgePhotosPath}${sep}`)) rmSync(previousPath, { force: true });
    }
    const storedName = `${badge.id}-${randomBytes(5).toString("hex")}${extensions[contentType]}`;
    writeFileSync(join(badgePhotosPath, storedName), body, { mode: 0o600, flag: "wx" });
    badge.photoStoredName = storedName;
    badge.photoContentType = contentType;
    badge.photoUpdatedAt = new Date().toISOString();
    badge.updatedAt = badge.photoUpdatedAt;
    badge.updatedBy = session.username;
    writeBadges(records);
    sendJson(response, 200, {
      ok: true,
      badge,
      photoUrl: `/api/badges/photo?id=${encodeURIComponent(badge.id)}&v=${encodeURIComponent(badge.photoUpdatedAt)}`
    });
    return;
  }
  if (url.pathname !== "/api/badges") {
    sendJson(response, 404, { ok: false, message: "Not found." });
    return;
  }
  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      badges: [...records].sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)))
        .map((badge) => ({
          ...badge,
          orientation: "portrait",
          photoUrl: badge.photoStoredName
            ? `/api/badges/photo?id=${encodeURIComponent(badge.id)}&v=${encodeURIComponent(badge.photoUpdatedAt || "")}` : ""
        }))
    });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const existing = records.find((record) => record.id === payload.id);
    const name = String(payload.name || "").trim().slice(0, 120);
    const position = String(payload.position || "").trim().slice(0, 120);
    if (!name || !position) {
      sendJson(response, 400, { ok: false, message: "Enter the badge holder's name and position." });
      return;
    }
    const now = new Date().toISOString();
    const badge = {
      id: existing?.id || randomBytes(12).toString("hex"),
      name,
      position,
      format: ["CR79", "CR80", "CR100"].includes(payload.format) ? payload.format : "CR80",
      orientation: "portrait",
      photoStoredName: existing?.photoStoredName || "",
      photoContentType: existing?.photoContentType || "",
      photoUpdatedAt: existing?.photoUpdatedAt || "",
      createdAt: existing?.createdAt || now,
      createdBy: existing?.createdBy || session.username,
      updatedAt: now,
      updatedBy: session.username
    };
    const index = records.findIndex((record) => record.id === badge.id);
    if (index >= 0) records[index] = badge;
    else records.push(badge);
    writeBadges(records);
    logActivity(session, index >= 0 ? "badge.updated" : "badge.created",
      `${index >= 0 ? "Updated" : "Created"} ${badge.format} badge for ${badge.name}.`);
    sendJson(response, 200, {
      ok: true,
      badge: {
        ...badge,
        photoUrl: badge.photoStoredName
          ? `/api/badges/photo?id=${encodeURIComponent(badge.id)}&v=${encodeURIComponent(badge.photoUpdatedAt || "")}` : ""
      }
    });
    return;
  }
  if (request.method === "DELETE") {
    const badge = records.find((record) => record.id === payload.id);
    if (!badge) {
      sendJson(response, 404, { ok: false, message: "Badge not found." });
      return;
    }
    if (badge.photoStoredName) {
      const filePath = resolve(badgePhotosPath, badge.photoStoredName);
      if (filePath.startsWith(`${badgePhotosPath}${sep}`)) rmSync(filePath, { force: true });
    }
    writeBadges(records.filter((record) => record.id !== badge.id));
    logActivity(session, "badge.deleted", `Deleted badge for ${badge.name}.`);
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readMailAccounts() {
  if (!existsSync(mailAccountsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(mailAccountsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeMailAccounts(records) {
  writeFileSync(mailAccountsPath, `${JSON.stringify(records, null, 2)}\n`, { mode: 0o600 });
}

function mailEncryptionKey() {
  if (!fsExistsSync(mailEncryptionKeyPath)) {
    fsWriteFileSync(mailEncryptionKeyPath, randomBytes(32), { mode: 0o600, flag: "wx" });
  }
  const key = fsReadFileSync(mailEncryptionKeyPath);
  if (key.length !== 32) throw new Error("MAIL_KEY_INVALID");
  return key;
}

function encryptMailPassword(password, username) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", mailEncryptionKey(), iv);
  cipher.setAAD(Buffer.from(String(username)));
  const ciphertext = Buffer.concat([cipher.update(String(password), "utf8"), cipher.final()]);
  return { iv: iv.toString("base64"), tag: cipher.getAuthTag().toString("base64"), data: ciphertext.toString("base64") };
}

function decryptMailPassword(encrypted, username) {
  const decipher = createDecipheriv("aes-256-gcm", mailEncryptionKey(), Buffer.from(encrypted.iv, "base64"));
  decipher.setAAD(Buffer.from(String(username)));
  decipher.setAuthTag(Buffer.from(encrypted.tag, "base64"));
  return Buffer.concat([decipher.update(Buffer.from(encrypted.data, "base64")), decipher.final()]).toString("utf8");
}

function mailConfiguration(session) {
  const account = readMailAccounts().find((record) => record.username === session?.username);
  if (!account?.encryptedPassword || !account.email) return { configured: false };
  try {
    const provider = "zoho-pop";
    return {
      configured: true,
      user: String(account.email).trim(),
      password: decryptMailPassword(account.encryptedPassword, session.username),
      fromName: String(account.fromName || session.employeeName || session.username).trim(),
      signature: {
        enabled: account.signature?.enabled !== false,
        name: String(account.signature?.name || account.fromName || session.employeeName || session.username).slice(0, 120),
        title: String(account.signature?.title || "Huber I.T. Professional").slice(0, 120),
        phone: String(account.signature?.phone || "605-787-0103").slice(0, 40)
      },
      provider,
      pop: {
        host: "poppro.zoho.com",
        port: 995,
        secure: true
      },
      smtp: {
        host: provider === "zoho" ? "smtppro.zoho.com" : String(account.smtp?.host || "").trim(),
        port: Number(account.smtp?.port || 465),
        secure: account.smtp?.secure !== false
      }
    };
  } catch {
    return { configured: false, unreadable: true };
  }
}

function publicMailConfiguration(config) {
  if (!config.configured) return null;
  return {
    email: config.user,
    fromName: config.fromName,
    signature: config.signature,
    provider: config.provider,
    protocol: "POP3",
    popHost: config.pop.host,
    popPort: config.pop.port,
    popSecure: config.pop.secure,
    smtpHost: config.smtp.host,
    smtpPort: config.smtp.port,
    smtpSecure: config.smtp.secure
  };
}

async function verifyMailConfiguration(config) {
  const client = new Pop3Command({
    host: config.pop.host, port: config.pop.port, tls: config.pop.secure,
    user: config.user, password: config.password, timeout: 30000
  });
  try { await client.UIDL(); } finally { try { await client.QUIT(); } catch {} }
  const transport = nodemailer.createTransport({
    host: config.smtp.host, port: config.smtp.port, secure: config.smtp.secure,
    auth: { user: config.user, pass: config.password },
    connectionTimeout: 15000, greetingTimeout: 15000, socketTimeout: 30000
  });
  await transport.verify();
  transport.close();
}

async function withMailbox(session, callback) {
  const config = mailConfiguration(session);
  if (!config.configured) throw new Error("MAIL_NOT_CONFIGURED");
  const client = new Pop3Command({
    host: config.pop.host, port: config.pop.port, tls: config.pop.secure,
    user: config.user, password: config.password, timeout: 30000
  });
  try {
    return await callback(client, config);
  } finally {
    try { await client.QUIT(); } catch {}
  }
}

function sanitizeEmailHtml(value) {
  return String(value || "")
    .replace(/<(script|iframe|object|embed|form|meta|link|base)[\s\S]*?<\/\1\s*>/gi, "")
    .replace(/<(script|iframe|object|embed|form|meta|link|base)\b[^>]*\/?>/gi, "")
    .replace(/\son[a-z]+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "")
    .replace(/(href|src)\s*=\s*(["'])\s*javascript:[\s\S]*?\2/gi, '$1="#"');
}

function adaptiveEmailHtml(fragment) {
  if (!fragment) return "";
  return `<!doctype html>
<html>
<head>
  <meta name="color-scheme" content="light dark">
  <meta name="supported-color-schemes" content="light dark">
  <style>
    :root { color-scheme: light dark; supported-color-schemes: light dark; }
    body, .huber-email-shell { background-color: #ffffff !important; color: #182026 !important; }
    .huber-email-signature { background-color: transparent !important; }
    @media (prefers-color-scheme: dark) {
      body, .huber-email-shell { background-color: #2c2c2e !important; color: #f5f5f7 !important; }
      .huber-signature-primary { color: #f5f5f7 !important; }
      .huber-signature-secondary { color: #c7c7cc !important; }
      .huber-signature-accent { color: #5ee7ed !important; }
      a { color: #70d7ff !important; }
    }
  </style>
</head>
<body style="margin:0;padding:0;background-color:#ffffff;color:#182026;font-family:Arial,Helvetica,sans-serif">
  <div class="huber-email-shell" style="padding:20px;background-color:#ffffff;color:#182026">${fragment}</div>
</body>
</html>`;
}

function readMailDrafts() {
  if (!existsSync(mailDraftsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(mailDraftsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeMailDrafts(records) {
  writeFileSync(mailDraftsPath, JSON.stringify(records.slice(-1000), null, 2), { mode: 0o600 });
}

function readMailState() {
  if (!existsSync(mailStatePath)) return [];
  try {
    const records = JSON.parse(readFileSync(mailStatePath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function mailStateFor(username) {
  const record = readMailState().find((item) => item.username === username);
  return {
    seen: new Set(Array.isArray(record?.seen) ? record.seen.map(String) : []),
    flagged: new Set(Array.isArray(record?.flagged) ? record.flagged.map(String) : []),
    folders: Array.isArray(record?.folders) ? record.folders
      .filter((folder) => folder?.id && folder?.name)
      .map((folder) => ({ id: String(folder.id), name: String(folder.name).slice(0, 80), createdAt: String(folder.createdAt || "") })) : [],
    assignments: record?.assignments && typeof record.assignments === "object" && !Array.isArray(record.assignments)
      ? Object.fromEntries(Object.entries(record.assignments).map(([uid, folderId]) => [String(uid), String(folderId)])) : {}
  };
}

function writeUserMailState(username, state) {
  const records = readMailState();
  const record = {
    username,
    seen: [...state.seen].slice(-10000),
    flagged: [...state.flagged].slice(-10000),
    folders: (state.folders || []).slice(0, 200),
    assignments: state.assignments || {},
    updatedAt: new Date().toISOString()
  };
  const index = records.findIndex((item) => item.username === username);
  if (index >= 0) records[index] = record; else records.push(record);
  writeFileSync(mailStatePath, `${JSON.stringify(records, null, 2)}\n`, { mode: 0o600 });
}

function localMailFolderId(folderPath) {
  const value = String(folderPath || "");
  return value.startsWith("LOCAL:") ? value.slice(6) : "";
}

function mailCacheFile(username, uid) {
  const userHash = createHash("sha256").update(String(username)).digest("hex").slice(0, 32);
  const uidHash = createHash("sha256").update(String(uid)).digest("hex");
  const directory = join(mailCachePath, userHash);
  mkdirSync(directory, { recursive: true, mode: 0o700 });
  return join(directory, `${uidHash}.bin`);
}

function writeCachedMail(username, uid, source) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", mailEncryptionKey(), iv);
  cipher.setAAD(Buffer.from(`${username}\0${uid}`));
  const encrypted = Buffer.concat([cipher.update(Buffer.isBuffer(source) ? source : Buffer.from(String(source))), cipher.final()]);
  fsWriteFileSync(mailCacheFile(username, uid), Buffer.concat([iv, cipher.getAuthTag(), encrypted]), { mode: 0o600 });
}

function readCachedMail(username, uid) {
  const filePath = mailCacheFile(username, uid);
  if (!fsExistsSync(filePath)) throw new Error("MESSAGE_NOT_FOUND");
  const stored = fsReadFileSync(filePath);
  if (stored.length < 29) throw new Error("MESSAGE_NOT_FOUND");
  const decipher = createDecipheriv("aes-256-gcm", mailEncryptionKey(), stored.subarray(0, 12));
  decipher.setAAD(Buffer.from(`${username}\0${uid}`));
  decipher.setAuthTag(stored.subarray(12, 28));
  return Buffer.concat([decipher.update(stored.subarray(28)), decipher.final()]);
}

function removeCachedMail(username, uid) {
  rmSync(mailCacheFile(username, uid), { force: true });
}

const MAIL_INDEX_CACHE_UID = "__huber_inbox_index_v1__";
const MAIL_INDEX_MAX_PAGES = 25;
const MAIL_INDEX_FRESH_MS = 60 * 1000;

function readMailIndexCache(username) {
  try {
    const value = JSON.parse(readCachedMail(username, MAIL_INDEX_CACHE_UID).toString("utf8"));
    if (!value || !Array.isArray(value.entries) || !value.pages || typeof value.pages !== "object") return null;
    return value;
  } catch {
    return null;
  }
}

function writeMailIndexCache(username, value) {
  const pages = Object.fromEntries(Object.entries(value.pages || {}).slice(-MAIL_INDEX_MAX_PAGES));
  writeCachedMail(username, MAIL_INDEX_CACHE_UID, JSON.stringify({ ...value, pages }));
}

function removeFromMailIndexCache(username, uid) {
  const cache = readMailIndexCache(username);
  if (!cache) return;
  cache.entries = cache.entries.filter((entry) => String(entry.uid) !== String(uid));
  cache.pages = Object.fromEntries(Object.entries(cache.pages).map(([page, records]) => [
    page,
    Array.isArray(records) ? records.filter((record) => String(record.uid) !== String(uid)) : []
  ]));
  cache.updatedAt = new Date().toISOString();
  writeMailIndexCache(username, cache);
}

function cachedInboxEntries(cache, localState) {
  return (cache?.entries || []).filter((entry) => !localState.assignments[String(entry.uid)]);
}

function decorateMailSummary(record, localState) {
  const uid = String(record.uid);
  return { ...record, uid, seen: localState.seen.has(uid), flagged: localState.flagged.has(uid) };
}

function cachedInboxResult(cache, page, limit, query, localState) {
  const records = Array.isArray(cache?.pages?.[String(page)]) ? cache.pages[String(page)] : null;
  if (!records) return null;
  const messages = records
    .filter((record) => !localState.assignments[String(record.uid)])
    .map((record) => decorateMailSummary(record, localState))
    .filter((record) => !query || [record.subject, ...(record.from || []).map((item) => `${item.name} ${item.address}`)]
      .join(" ").toLowerCase().includes(query))
    .sort((a, b) => new Date(b.date) - new Date(a.date));
  const total = cachedInboxEntries(cache, localState).length;
  return { messages, total, page, pages: Math.max(1, Math.ceil(total / limit)) };
}

async function refreshMailIndexPage(session, page, limit) {
  return withMailbox(session, async (client) => {
    const localState = mailStateFor(session.username);
    const remoteEntries = await client.UIDL();
    const entries = remoteEntries.map(([messageNumber, uid]) => ({ messageNumber: Number(messageNumber), uid: String(uid) }));
    const filteredEntries = entries.filter((entry) => !localState.assignments[entry.uid]);
    const sizes = new Map((await client.LIST()).map((entry) => [String(entry[0]), Number(entry[1] || 0)]));
    const end = Math.max(0, filteredEntries.length - ((page - 1) * limit));
    const start = Math.max(0, end - limit);
    const pageEntries = filteredEntries.slice(start, end).reverse();
    const messages = [];
    for (const entry of pageEntries) {
      const parsed = await simpleParser(await client.TOP(entry.messageNumber, 0));
      messages.push(mailSummary(parsed, entry.uid, localState, sizes.get(String(entry.messageNumber)) || 0));
    }
    messages.sort((a, b) => new Date(b.date) - new Date(a.date));
    const previous = readMailIndexCache(session.username);
    const remoteSignature = createHash("sha256").update(entries.map((entry) => entry.uid).join("\n")).digest("hex");
    const pages = previous?.remoteSignature === remoteSignature ? { ...previous.pages } : {};
    pages[String(page)] = messages;
    const updatedAt = new Date().toISOString();
    const cache = { updatedAt, remoteSignature, entries, pages };
    writeMailIndexCache(session.username, cache);
    return { messages, total: filteredEntries.length, page, pages: Math.max(1, Math.ceil(filteredEntries.length / limit)), updatedAt };
  });
}

function mailSummary(parsed, uid, localState, size = 0) {
  return {
    uid: String(uid), subject: String(parsed.subject || "(No subject)"),
    from: parsed.from?.value || [], to: parsed.to?.value || [],
    date: parsed.date || "", messageId: String(parsed.messageId || ""),
    seen: localState.seen.has(String(uid)), flagged: localState.flagged.has(String(uid)),
    answered: false, size: Number(size || 0)
  };
}

async function popMessageNumber(client, uid) {
  const entries = await client.UIDL();
  const match = entries.find((entry) => String(entry[1]) === String(uid));
  if (!match) throw new Error("MESSAGE_NOT_FOUND");
  return Number(match[0]);
}

function safeMailFilename(value) {
  return String(value || "attachment")
    .replace(/[\x00-\x1f\x7f/\\:*?"<>|]/g, "_")
    .trim().slice(0, 160) || "attachment";
}

function mailUploadPaths(token) {
  if (!/^[a-f0-9]{32}$/.test(token)) return null;
  const binary = resolve(mailUploadsPath, `${token}.bin`);
  const metadata = resolve(mailUploadsPath, `${token}.json`);
  if (!binary.startsWith(`${mailUploadsPath}${sep}`) || !metadata.startsWith(`${mailUploadsPath}${sep}`)) return null;
  return { binary, metadata };
}

function cleanupMailUploads() {
  const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
  for (const name of readdirSync(mailUploadsPath).filter((entry) => entry.endsWith(".json"))) {
    const paths = mailUploadPaths(name.slice(0, -5));
    if (!paths) continue;
    try {
      const metadata = JSON.parse(readFileSync(paths.metadata, "utf8"));
      if (new Date(metadata.createdAt || 0).getTime() >= cutoff) continue;
    } catch {}
    rmSync(paths.metadata, { force: true });
    rmSync(paths.binary, { force: true });
  }
}

function readMailUpload(token, session) {
  const paths = mailUploadPaths(token);
  if (!paths || !existsSync(paths.binary) || !existsSync(paths.metadata)) return null;
  try {
    const metadata = JSON.parse(readFileSync(paths.metadata, "utf8"));
    return metadata.username === session.username ? { ...metadata, ...paths } : null;
  } catch {
    return null;
  }
}

function removeMailUpload(upload) {
  if (!upload) return;
  rmSync(upload.binary, { force: true });
  rmSync(upload.metadata, { force: true });
}

function mailFailureMessage(error) {
  const text = String(error?.message || "").toLowerCase();
  if (error?.authenticationFailed || error?.code === "EAUTH" || String(error?.command || "").startsWith("PASS") ||
      text.includes("auth") || text.includes("credentials") || text.includes("login")) {
    return "Zoho rejected the mailbox sign-in. Check the email address and Zoho app password.";
  }
  if (error?.message === "MAIL_NOT_CONFIGURED") {
    return "Connect your email account to continue.";
  }
  if (error?.message === "MAIL_KEY_INVALID") {
    return "The server could not unlock this email account. Disconnect it and connect it again.";
  }
  return "Unable to connect to this mailbox right now.";
}

async function handleMail(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "email")) {
    sendJson(response, session ? 403 : 401, { ok: false, message: session ? "Email access required." : "Please sign in." });
    return;
  }
  const url = new URL(request.url, `http://${request.headers.host || "localhost"}`);
  const action = url.pathname.slice("/api/mail/".length) || "status";
  const config = mailConfiguration(session);

  if (action === "status" && request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      configured: config.configured,
      account: config.configured ? config.user : "",
      settings: publicMailConfiguration(config),
      unreadable: Boolean(config.unreadable)
    });
    return;
  }

  if (action === "setup" && request.method === "POST") {
    try {
      const payload = await readJsonBody(request);
      const email = String(payload.email || "").trim().toLowerCase();
      const fromName = String(payload.fromName || session.employeeName || session.username).trim().slice(0, 120);
      const previous = mailConfiguration(session);
      const password = String(payload.password || "") || (previous.configured ? previous.password : "");
      const signature = {
        enabled: payload.signature?.enabled !== false,
        name: String(payload.signature?.name || fromName).trim().slice(0, 120),
        title: String(payload.signature?.title || "Huber I.T. Professional").trim().slice(0, 120),
        phone: String(payload.signature?.phone || "605-787-0103").trim().slice(0, 40)
      };
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
        sendJson(response, 400, { ok: false, message: "Enter a valid email address." });
        return;
      }
      if (!password || password.length > 500) {
        sendJson(response, 400, { ok: false, message: "Enter your Zoho app password." });
        return;
      }
      const candidate = {
        configured: true, user: email, password, fromName, signature, provider: "zoho-pop",
        pop: { host: "poppro.zoho.com", port: 995, secure: true },
        smtp: { host: "smtppro.zoho.com", port: 465, secure: true }
      };
      await verifyMailConfiguration(candidate);
      const accounts = readMailAccounts();
      const record = {
        username: session.username, email, fromName, signature, provider: "zoho-pop",
        pop: candidate.pop, smtp: candidate.smtp,
        encryptedPassword: encryptMailPassword(password, session.username),
        updatedAt: new Date().toISOString()
      };
      const index = accounts.findIndex((account) => account.username === session.username);
      if (index >= 0) accounts[index] = record; else accounts.push(record);
      writeMailAccounts(accounts);
      logActivity(session, "email.connected", `Connected email account ${email}.`);
      sendJson(response, 200, { ok: true, configured: true, account: email, settings: publicMailConfiguration(candidate) });
    } catch (error) {
      console.warn(`Email setup failed for ${session.username}: ${error?.code || error?.responseStatus || error?.message || "unknown error"}`);
      sendJson(response, 502, { ok: false, message: mailFailureMessage(error) });
    }
    return;
  }

  if (action === "setup" && request.method === "DELETE") {
    const accounts = readMailAccounts();
    writeMailAccounts(accounts.filter((account) => account.username !== session.username));
    logActivity(session, "email.disconnected", "Disconnected personal email account.");
    sendJson(response, 200, { ok: true });
    return;
  }

  if (!config.configured) {
    sendJson(response, 503, { ok: false, configured: false, message: mailFailureMessage(new Error("MAIL_NOT_CONFIGURED")) });
    return;
  }

  if (action === "upload" && request.method === "POST") {
    try {
      const name = safeMailFilename(decodeURIComponent(String(request.headers["x-file-name"] || "attachment")));
      const contentType = String(request.headers["content-type"] || "application/octet-stream").slice(0, 120);
      const body = await readBinaryBody(request, 10 * 1024 * 1024);
      if (!body.length) throw new Error("Choose a file to attach.");
      const token = randomBytes(16).toString("hex");
      const paths = mailUploadPaths(token);
      const metadata = { token, username: session.username, name, contentType, size: body.length, createdAt: new Date().toISOString() };
      writeFileSync(paths.binary, body, { mode: 0o600, flag: "wx" });
      writeFileSync(paths.metadata, JSON.stringify(metadata), { mode: 0o600, flag: "wx" });
      sendJson(response, 200, { ok: true, attachment: metadata });
    } catch (error) {
      sendJson(response, 400, { ok: false, message: error.message || "Unable to attach file." });
    }
    return;
  }

  if (action === "drafts") {
    const drafts = readMailDrafts();
    if (request.method === "GET") {
      sendJson(response, 200, { ok: true, drafts: drafts.filter((draft) => draft.username === session.username).sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt))) });
      return;
    }
    const payload = await readJsonBody(request);
    if (request.method === "POST") {
      const existing = drafts.find((draft) => draft.id === payload.id && draft.username === session.username);
      const now = new Date().toISOString();
      const draft = {
        id: existing?.id || randomBytes(12).toString("hex"), username: session.username,
        to: String(payload.to || "").slice(0, 1000), cc: String(payload.cc || "").slice(0, 1000),
        bcc: String(payload.bcc || "").slice(0, 1000), subject: String(payload.subject || "").slice(0, 300),
        body: String(payload.body || "").slice(0, 100000),
        bodyHtml: sanitizeEmailHtml(String(payload.bodyHtml || "").slice(0, 200000)),
        attachments: Array.isArray(payload.attachments) ? payload.attachments.slice(0, 20) : [],
        createdAt: existing?.createdAt || now, updatedAt: now
      };
      const index = drafts.findIndex((record) => record.id === draft.id);
      if (index >= 0) drafts[index] = draft; else drafts.push(draft);
      writeMailDrafts(drafts);
      sendJson(response, 200, { ok: true, draft });
      return;
    }
    if (request.method === "DELETE") {
      const removed = drafts.find((draft) => draft.id === payload.id && draft.username === session.username);
      writeMailDrafts(drafts.filter((draft) => !(draft.id === payload.id && draft.username === session.username)));
      for (const token of removed?.attachments || []) removeMailUpload(readMailUpload(String(token), session));
      sendJson(response, 200, { ok: true });
      return;
    }
  }

  if (action === "send" && request.method === "POST") {
    try {
      const payload = await readJsonBody(request);
      const to = String(payload.to || "").trim();
      const subject = String(payload.subject || "").trim().slice(0, 300);
      const body = String(payload.body || "").slice(0, 100000);
      const bodyHtml = sanitizeEmailHtml(String(payload.bodyHtml || "").slice(0, 200000));
      const sentHtml = adaptiveEmailHtml(bodyHtml);
      if (!to || !subject || !body) {
        sendJson(response, 400, { ok: false, message: "Enter recipients, a subject, and a message." });
        return;
      }
      const uploads = (Array.isArray(payload.attachments) ? payload.attachments : [])
        .slice(0, 20).map((token) => readMailUpload(String(token), session)).filter(Boolean);
      const transport = nodemailer.createTransport({
        host: config.smtp.host, port: config.smtp.port, secure: config.smtp.secure,
        auth: { user: config.user, pass: config.password }
      });
      const info = await transport.sendMail({
        from: { name: config.fromName, address: config.user }, to,
        cc: String(payload.cc || "").trim() || undefined,
        bcc: String(payload.bcc || "").trim() || undefined,
        subject, text: body, html: sentHtml || undefined,
        inReplyTo: String(payload.inReplyTo || "").trim() || undefined,
        references: String(payload.references || "").trim() || undefined,
        attachments: uploads.map((upload) => ({ filename: upload.name, path: upload.binary, contentType: upload.contentType }))
      });
      uploads.forEach(removeMailUpload);
      if (payload.draftId) {
        writeMailDrafts(readMailDrafts().filter((draft) => !(draft.id === payload.draftId && draft.username === session.username)));
      }
      logActivity(session, "email.sent", `Sent email “${subject}”.`);
      sendJson(response, 200, { ok: true, messageId: info.messageId || "" });
    } catch (error) {
      sendJson(response, 502, { ok: false, message: mailFailureMessage(error) });
    }
    return;
  }

  try {
    if (action === "folders" && request.method === "GET") {
      const localState = mailStateFor(session.username);
      const cachedIndex = readMailIndexCache(session.username);
      const buildFolders = (uids) => {
        const inboxUids = uids.filter((uid) => !localState.assignments[String(uid)]);
        return [{
          path: "INBOX", name: "Inbox", specialUse: "\\Inbox",
          messages: inboxUids.length,
          unseen: inboxUids.filter((uid) => !localState.seen.has(String(uid))).length
        }, ...localState.folders.map((folder) => {
          const uids = Object.entries(localState.assignments).filter(([, folderId]) => folderId === folder.id).map(([uid]) => uid);
          return { path: `LOCAL:${folder.id}`, name: folder.name, specialUse: "", local: true, messages: uids.length, unseen: uids.filter((uid) => !localState.seen.has(uid)).length };
        })];
      };
      if (cachedIndex) {
        sendJson(response, 200, { ok: true, account: config.user, folders: buildFolders(cachedIndex.entries.map((entry) => entry.uid)), cached: true, cachedAt: cachedIndex.updatedAt });
        return;
      }
      const uids = await withMailbox(session, async (client) => (await client.UIDL()).map((entry) => String(entry[1])));
      sendJson(response, 200, { ok: true, account: config.user, folders: buildFolders(uids), cached: false });
      return;
    }

    if (action === "local-folders" && ["POST", "PATCH", "DELETE"].includes(request.method)) {
      const payload = await readJsonBody(request);
      const localState = mailStateFor(session.username);
      if (request.method === "POST") {
        const name = String(payload.name || "").trim().slice(0, 80);
        if (!name) { sendJson(response, 400, { ok: false, message: "Enter a folder name." }); return; }
        if (localState.folders.some((folder) => folder.name.toLowerCase() === name.toLowerCase())) {
          sendJson(response, 409, { ok: false, message: "A folder with that name already exists." }); return;
        }
        const folder = { id: randomBytes(10).toString("hex"), name, createdAt: new Date().toISOString() };
        localState.folders.push(folder);
        writeUserMailState(session.username, localState);
        sendJson(response, 200, { ok: true, folder: { ...folder, path: `LOCAL:${folder.id}` } });
        return;
      }
      const id = String(payload.id || "");
      const folder = localState.folders.find((item) => item.id === id);
      if (!folder) throw new Error("MAILBOX_NOT_FOUND");
      if (request.method === "PATCH") {
        const name = String(payload.name || "").trim().slice(0, 80);
        if (!name) { sendJson(response, 400, { ok: false, message: "Enter a folder name." }); return; }
        if (localState.folders.some((item) => item.id !== id && item.name.toLowerCase() === name.toLowerCase())) {
          sendJson(response, 409, { ok: false, message: "A folder with that name already exists." }); return;
        }
        folder.name = name;
      } else {
        if (Object.values(localState.assignments).includes(id)) {
          sendJson(response, 409, { ok: false, message: "Move or delete the messages in this folder before deleting it." }); return;
        }
        localState.folders = localState.folders.filter((item) => item.id !== id);
      }
      writeUserMailState(session.username, localState);
      sendJson(response, 200, { ok: true });
      return;
    }

    if (action === "move" && request.method === "POST") {
      const payload = await readJsonBody(request);
      const uid = String(payload.uid || "");
      const targetPath = String(payload.targetFolder || "INBOX");
      const targetId = localMailFolderId(targetPath);
      const localState = mailStateFor(session.username);
      if (!uid) throw new Error("MESSAGE_NOT_FOUND");
      if (targetPath !== "INBOX" && !localState.folders.some((folder) => folder.id === targetId)) throw new Error("MAILBOX_NOT_FOUND");
      if (targetPath === "INBOX") {
        await withMailbox(session, async (client) => popMessageNumber(client, uid));
        delete localState.assignments[uid];
        removeCachedMail(session.username, uid);
      } else {
        const cacheFile = mailCacheFile(session.username, uid);
        if (!fsExistsSync(cacheFile)) {
          const raw = await withMailbox(session, async (client) => client.RETR(await popMessageNumber(client, uid)));
          writeCachedMail(session.username, uid, raw);
        }
        localState.assignments[uid] = targetId;
      }
      writeUserMailState(session.username, localState);
      sendJson(response, 200, { ok: true });
      return;
    }

    const folderPath = String(url.searchParams.get("folder") || "INBOX");
    const localFolderId = localMailFolderId(folderPath);
    const folderState = mailStateFor(session.username);
    if (folderPath !== "INBOX" && !folderState.folders.some((folder) => folder.id === localFolderId)) throw new Error("MAILBOX_NOT_FOUND");
    if (action === "messages" && request.method === "GET") {
      const page = Math.max(1, Number(url.searchParams.get("page") || 1));
      const limit = 40;
      const query = String(url.searchParams.get("query") || "").trim().toLowerCase();
      if (localFolderId) {
        const allMessages = [];
        for (const [uid, folderId] of Object.entries(folderState.assignments)) {
          if (folderId !== localFolderId) continue;
          try {
            const raw = readCachedMail(session.username, uid);
            const parsed = await simpleParser(raw);
            const record = mailSummary(parsed, uid, folderState, raw.length);
            if (!query || [record.subject, ...record.from.map((item) => `${item.name} ${item.address}`)].join(" ").toLowerCase().includes(query)) allMessages.push(record);
          } catch {}
        }
        allMessages.sort((a, b) => new Date(b.date) - new Date(a.date));
        const start = (page - 1) * limit;
        sendJson(response, 200, { ok: true, folder: folderPath, messages: allMessages.slice(start, start + limit), total: allMessages.length, page, pages: Math.max(1, Math.ceil(allMessages.length / limit)) });
        return;
      }
      const forceRefresh = url.searchParams.get("refresh") === "1";
      const cachedIndex = readMailIndexCache(session.username);
      const cachedResult = !forceRefresh && cachedInboxResult(cachedIndex, page, limit, query, folderState);
      if (cachedResult) {
        const cacheAge = Math.max(0, Date.now() - new Date(cachedIndex.updatedAt || 0).getTime());
        sendJson(response, 200, { ok: true, folder: folderPath, ...cachedResult, cached: true, cachedAt: cachedIndex.updatedAt, refreshRecommended: cacheAge >= MAIL_INDEX_FRESH_MS });
        return;
      }
      const freshResult = await refreshMailIndexPage(session, page, limit);
      const messages = freshResult.messages
        .map((record) => decorateMailSummary(record, mailStateFor(session.username)))
        .filter((record) => !query || [record.subject, ...(record.from || []).map((item) => `${item.name} ${item.address}`)]
          .join(" ").toLowerCase().includes(query));
      sendJson(response, 200, { ok: true, folder: folderPath, ...freshResult, messages, cached: false, cachedAt: freshResult.updatedAt, refreshRecommended: false });
      return;
    }

    const uid = String(url.searchParams.get("uid") || "");
    if (action === "message" && request.method === "GET") {
      if (!uid) throw new Error("MESSAGE_NOT_FOUND");
      const detail = await (async () => {
        const parsed = localFolderId ? await simpleParser(readCachedMail(session.username, uid)) : await withMailbox(session, async (client) => simpleParser(await client.RETR(await popMessageNumber(client, uid))));
        const localState = mailStateFor(session.username);
        if (url.searchParams.get("peek") !== "1") {
          localState.seen.add(uid);
          writeUserMailState(session.username, localState);
        }
        return {
          uid, subject: String(parsed.subject || "(No subject)"),
          from: parsed.from?.value || [], to: parsed.to?.value || [],
          cc: parsed.cc?.value || [], date: parsed.date || "",
          messageId: String(parsed.messageId || ""),
          inReplyTo: String(parsed.inReplyTo || ""), references: Array.isArray(parsed.references) ? parsed.references.join(" ") : String(parsed.references || ""),
          text: String(parsed.text || ""), html: sanitizeEmailHtml(parsed.html || ""),
          flagged: localState.flagged.has(uid),
          attachments: (parsed.attachments || []).map((attachment, index) => ({
            index, filename: safeMailFilename(attachment.filename || `attachment-${index + 1}`),
            contentType: String(attachment.contentType || "application/octet-stream"), size: Number(attachment.size || attachment.content?.length || 0)
          }))
        };
      })();
      sendJson(response, 200, { ok: true, message: detail });
      return;
    }

    if (action === "attachment" && request.method === "GET") {
      const index = Number(url.searchParams.get("index"));
      const parsed = localFolderId ? await simpleParser(readCachedMail(session.username, uid)) : await withMailbox(session, async (client) => simpleParser(await client.RETR(await popMessageNumber(client, uid))));
      const attachment = parsed.attachments?.[index];
      if (!attachment) throw new Error("ATTACHMENT_NOT_FOUND");
      response.writeHead(200, {
        "Content-Type": attachment.contentType || "application/octet-stream",
        "Content-Disposition": `attachment; filename="${safeMailFilename(attachment.filename)}"`,
        "Content-Length": attachment.content.length,
        "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff"
      });
      response.end(attachment.content);
      return;
    }

    if (["read", "flag", "delete"].includes(action) && request.method === "POST") {
      const payload = await readJsonBody(request);
      const targetUid = String(payload.uid || "");
      if (!targetUid) throw new Error("MESSAGE_NOT_FOUND");
      const localState = mailStateFor(session.username);
      if (action === "read") {
        if (payload.value) localState.seen.add(targetUid); else localState.seen.delete(targetUid);
      } else if (action === "flag") {
        if (payload.value) localState.flagged.add(targetUid); else localState.flagged.delete(targetUid);
      } else {
        try { await withMailbox(session, async (client) => client.DELE(await popMessageNumber(client, targetUid))); }
        catch (error) { if (!localFolderId || error.message !== "MESSAGE_NOT_FOUND") throw error; }
        localState.seen.delete(targetUid);
        localState.flagged.delete(targetUid);
        delete localState.assignments[targetUid];
        removeCachedMail(session.username, targetUid);
        removeFromMailIndexCache(session.username, targetUid);
      }
      writeUserMailState(session.username, localState);
      sendJson(response, 200, { ok: true });
      return;
    }
    sendJson(response, 405, { ok: false, message: "Unsupported email action." });
  } catch (error) {
    const known = ["MAILBOX_NOT_FOUND", "MESSAGE_NOT_FOUND", "ATTACHMENT_NOT_FOUND"].includes(error.message);
    sendJson(response, known ? 404 : 502, { ok: false, message: known ? "The requested mailbox item was not found." : mailFailureMessage(error) });
  }
}

async function handleInvoices(request, response) {
  const payload = request.method === "GET" ? null : await readJsonBody(request);
  return billingTransaction(response, buffered => handleInvoicesParsed(request, buffered, payload));
}

function handleInvoicesParsed(request, response, payload) {
  const session = getSession(request);
  if (!hasPermission(session, "invoicing")) {
    sendJson(response, 403, { ok: false, message: "Invoicing access required." });
    return;
  }

  const invoices = readInvoices();
  const allServiceTickets = readTickets().filter((ticket) =>
    (ticket.ticketType || "Service") === "Service" && !ticket.isOffice
  );
  const serviceTickets = allServiceTickets.filter((ticket) => !ticket.nonChargeable);

  if (request.method === "GET") {
    const payments = readFinance().payments || [];
    const url = new URL(request.url, publicOrigin(request));
    const compactTickets = url.searchParams.get("compactTickets") === "1";
    const detailedInvoices = invoices.map((invoice) => {
      const invoicePayments = payments.filter((payment) => payment.invoiceId === invoice.id);
      const paidAmount = invoicePaidAmount(invoice, invoicePayments);
      return {
        ...invoice,
        status: invoicePaymentStatus(invoice, invoicePayments),
        payments: invoicePayments,
        paidAmount,
        balance: roundMoney(Math.max(0, Number(invoice.total || 0) - paidAmount))
      };
    });
    sendJson(response, 200, {
      ok: true,
      invoices: detailedInvoices,
      tickets: compactTickets
        ? serviceTickets.map((ticket) => ({
            id: ticket.id,
            number: ticket.number,
            customer: ticket.customer,
            hoursUsed: ticket.hoursUsed
          }))
        : serviceTickets,
      canDeleteInvoices: session.username === "Huber58"
    });
    return;
  }

  if (request.method === "POST") {
    const ticket = allServiceTickets.find((record) => record.id === payload.ticketId);
    if (!ticket) {
      sendJson(response, 400, { ok: false, message: "Select a valid service ticket." });
      return;
    }
    const existing = invoices.find((invoice) => invoice.id === payload.id);
    if (payload.id && !existing) {
      sendJson(response, 404, { ok: false, message: "Invoice no longer exists. Refresh before editing." });
      return;
    }
    const requestedStatus = ["Draft", "Sent", "Paid", "Void"].includes(payload.status)
      ? payload.status : "Draft";
    const issuingInvoice = ["Sent", "Paid"].includes(requestedStatus);
    const recordedTicketHours = Math.max(0, Number(ticket.hoursUsed) || 0);
    if (ticket.nonChargeable) {
      sendJson(response, 409, {
        ok: false,
        message: `${ticketLabel(ticket)} is non-chargeable and cannot be invoiced.`
      });
      return;
    }
    if (issuingInvoice && ticket.status !== "Closed") {
      sendJson(response, 409, {
        ok: false,
        message: "This invoice cannot be sent or marked paid until the service ticket is closed."
      });
      return;
    }
    if (readApprovalPolicies().requireInvoiceVoids &&
        existing && payload.status === "Void" && existing.status !== "Void" &&
        !hasPermission(session, "approvals")) {
      const approval = createApprovalRequest(session, "invoice-void", {
        invoiceId: existing.id
      }, `Void invoice #${existing.number} for ${existing.customer}`);
      sendJson(response, 202, {
        ok: true,
        approvalPending: true,
        approval,
        message: "Invoice void submitted for approval."
      });
      return;
    }
    if (invoices.some((invoice) =>
      invoice.ticketId === ticket.id && invoice.id !== payload.id && invoice.status !== "Void")) {
      sendJson(response, 409, { ok: false, message: "This service ticket already has an invoice." });
      return;
    }
    const laborHours = Math.max(0, Number(payload.laborHours) || 0);
    const laborRate = Math.max(0, Number(payload.laborRate) || 0);
    const customCharges = (Array.isArray(payload.customCharges) ? payload.customCharges : [])
      .slice(0, 100)
      .map((charge) => {
        const quantity = Math.max(0, Number(charge.quantity) || 0);
        const rate = Math.max(0, Number(charge.rate) || 0);
        return {
          name: String(charge.name || "").trim().slice(0, 120),
          quantity,
          rate: roundMoney(rate),
          total: roundMoney(quantity * rate)
        };
      })
      .filter((charge) => charge.name && charge.quantity > 0);
    if (!customCharges.length && Number(payload.additionalCharges) > 0) {
      customCharges.push({
        name: "Additional charges",
        quantity: 1,
        rate: roundMoney(Number(payload.additionalCharges)),
        total: roundMoney(Number(payload.additionalCharges))
      });
    }
    const taxRate = Math.max(0, Number(payload.taxRate) || 0);
    const materials = (ticket.usedItems || []).map((item) => ({
      name: `${item.name}${item.variationName ? ` - ${item.variationName}` : ""}`,
      sku: item.sku,
      quantity: Number(item.quantity) || 0,
      unitCost: Number(item.unitCost) || 0,
      total: roundMoney((Number(item.quantity) || 0) * (Number(item.unitCost) || 0))
    }));
    const materialTotal = roundMoney(materials.reduce((sum, item) => sum + item.total, 0));
    const laborTotal = roundMoney(laborHours * laborRate);
    const customChargeTotal = roundMoney(customCharges.reduce((sum, charge) => sum + charge.total, 0));
    const subtotal = roundMoney(materialTotal + laborTotal + customChargeTotal);
    const tax = roundMoney(subtotal * taxRate / 100);
    const nextNumber = invoices.reduce((highest, invoice) =>
      Math.max(highest, Number(invoice.number) || 0), 0) + 1;
    const invoice = {
      id: existing?.id || randomBytes(12).toString("hex"),
      number: existing?.number || nextNumber,
      ticketId: ticket.id,
      ticketNumber: ticket.number,
      customer: ticket.customer,
      company: ticket.company,
      email: ticket.email,
      phone: ticket.phone,
      address: ticket.address,
      laborHours,
      laborRate,
      laborTotal,
      materials,
      materialTotal,
      customCharges,
      customChargeTotal,
      additionalCharges: 0,
      taxRate,
      tax,
      subtotal,
      total: roundMoney(subtotal + tax),
      status: requestedStatus,
      issueDate: payload.issueDate || new Date().toISOString().slice(0, 10),
      dueDate: payload.dueDate || "",
      notes: String(payload.notes || "").trim(),
      paymentInstructions: String(
        Object.prototype.hasOwnProperty.call(payload, "paymentInstructions")
          ? payload.paymentInstructions
          : existing?.paymentInstructions || ""
      ).trim().slice(0, 1200),
      noHoursApprovedAt: existing?.noHoursApprovedAt || "",
      noHoursApprovedBy: existing?.noHoursApprovedBy || "",
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    const recordedPayments = (readFinance().payments || []).filter(payment => payment.invoiceId === invoice.id);
    const recordedPaid = invoicePaidAmount(invoice, recordedPayments);
    if (!Number.isFinite(invoice.total) || !Number.isFinite(laborHours) || !Number.isFinite(taxRate)) {
      sendJson(response, 400, { ok: false, message: "Invoice amounts must be finite numbers." });
      return;
    }
    if (recordedPaid > invoice.total + 0.001 ||
        (recordedPayments.length && ["Draft", "Void"].includes(requestedStatus))) {
      sendJson(response, 409, { ok: false, message: "This invoice has payments. Correct the payment records before reducing it below the paid amount, drafting, or voiding it." });
      return;
    }
    if (requestedStatus === "Paid" && recordedPaid < invoice.total - 0.001 && existing?.status !== "Paid") {
      sendJson(response, 409, { ok: false, message: "Record the payment in Finance before marking this invoice paid." });
      return;
    }
    if (["Sent", "Paid"].includes(requestedStatus)) invoice.status = invoicePaymentStatus(invoice, recordedPayments);
    if (issuingInvoice && recordedTicketHours <= 0 && session.username === "Huber58") {
      invoice.noHoursApprovedAt = new Date().toISOString();
      invoice.noHoursApprovedBy = session.username;
    }
    const index = invoices.findIndex((record) => record.id === invoice.id);
    const needsOwnerApproval = issuingInvoice && recordedTicketHours <= 0 &&
      session.username !== "Huber58" && !invoice.noHoursApprovedAt;
    if (needsOwnerApproval) {
      invoice.status = "Draft";
      if (index >= 0) invoices[index] = invoice;
      else invoices.push(invoice);
      writeInvoices(invoices);
      const pending = readApprovals().find((record) =>
        record.type === "invoice-no-hours" &&
        record.status === "Pending" &&
        record.payload.invoiceId === invoice.id &&
        record.payload.requestedStatus === requestedStatus
      );
      const approval = pending || createApprovalRequest(session, "invoice-no-hours", {
        invoiceId: invoice.id,
        requestedStatus
      }, `Send invoice #${invoice.number} for closed ticket ${ticketLabel(ticket)} with zero recorded hours`);
      sendJson(response, 202, {
        ok: true,
        approvalPending: true,
        approval,
        invoice,
        message: pending
          ? "Owner approval for this zero-hour invoice is already pending."
          : "The invoice was saved as a draft and submitted to the owner for approval because the closed ticket has zero recorded hours."
      });
      return;
    }
    if (index >= 0) invoices[index] = invoice;
    else invoices.push(invoice);
    writeInvoices(invoices);
    if (invoice.status === "Paid") {
      const estimates = readEstimates();
      let changed = false;
      for (const estimate of estimates) {
        if (estimate.invoiceId !== invoice.id || estimate.status === "Paid") continue;
        estimate.status = "Paid";
        estimate.updatedAt = new Date().toISOString();
        estimate.updatedBy = session.username;
        changed = true;
      }
      if (changed) writeEstimates(estimates);
    }
    logActivity(session, index >= 0 ? "invoice.updated" : "invoice.created",
      `${index >= 0 ? "Updated" : "Created"} invoice #${invoice.number} for ${invoice.customer} (${invoice.status}).`, {
        undo: { collection: "invoices", recordId: invoice.id, before: existing ? structuredClone(existing) : null, after: structuredClone(invoice) }
      });
    broadcastAllServiceEvent("dashboard-updated", { area: "invoices" });
    const payments = (readFinance().payments || []).filter((payment) =>
      payment.invoiceId === invoice.id
    );
    const paidAmount = invoicePaidAmount(invoice, payments);
    sendJson(response, 200, {
      ok: true,
      invoice: {
        ...invoice,
        payments,
        paidAmount,
        balance: roundMoney(Math.max(0, Number(invoice.total || 0) - paidAmount))
      }
    });
    return;
  }

  if (request.method === "DELETE") {
    if (session.username !== "Huber58") {
      sendJson(response, 403, { ok: false, message: "Only Huber58 can delete invoices." });
      return;
    }
    const invoice = invoices.find((record) => record.id === payload.id);
    if (!invoice) {
      sendJson(response, 404, { ok: false, message: "Invoice not found." });
      return;
    }
    const finance = readFinance();
    const linkedPayments = (finance.payments || []).filter((payment) => payment.invoiceId === invoice.id);
    if (linkedPayments.some((payment) => payment.stripeSessionId || payment.zohoPaymentId || payment.bankTransactionId)) {
      sendJson(response, 409, {
        ok: false,
        message: "This invoice has a processor or bank payment and cannot be deleted. Reverse or reconcile the payment at its source first."
      });
      return;
    }
    writeInvoices(invoices.filter((record) => record.id !== invoice.id));
    if (linkedPayments.length) {
      const linkedPaymentIds = new Set(linkedPayments.map((payment) => payment.id));
      finance.payments = finance.payments.filter((payment) => !linkedPaymentIds.has(payment.id));
      writeFinance(finance);
      const receipts = readReceipts();
      const retainedReceipts = [];
      for (const receipt of receipts) {
        if (receipt.entityType === "invoice-payment" && linkedPaymentIds.has(receipt.entityId)) {
          const filePath = resolve(receiptFilesPath, receipt.storedName);
          if (filePath.startsWith(`${receiptFilesPath}${sep}`)) rmSync(filePath, { force: true });
        } else {
          retainedReceipts.push(receipt);
        }
      }
      if (retainedReceipts.length !== receipts.length) writeReceipts(retainedReceipts);
    }
    const estimates = readEstimates();
    let clearedEstimateLinks = false;
    for (const estimate of estimates) {
      if (estimate.invoiceId === invoice.id) {
        estimate.invoiceId = "";
        clearedEstimateLinks = true;
      }
    }
    if (clearedEstimateLinks) writeEstimates(estimates);
    logActivity(session, "invoice.deleted",
      `Deleted invoice #${invoice.number} for ${invoice.customer}${linkedPayments.length ? ` and ${linkedPayments.length} linked payment record(s)` : ""}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "invoices" });
    broadcastAllServiceEvent("job-workspace-updated", { ticketId: invoice.ticketId });
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function invoicePaidAmount(invoice, payments = []) {
  return roundMoney(payments
    .filter((payment) => payment.invoiceId === invoice?.id)
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0));
}

function invoicePaymentStatus(invoice, payments = []) {
  if (["Draft", "Void"].includes(invoice.status)) return invoice.status;
  return invoicePaidAmount(invoice, payments) >= Number(invoice.total || 0) - 0.001 ? "Paid" : "Sent";
}

function readInvoices() {
  if (!existsSync(invoicesPath)) return [];
  try {
    const records = JSON.parse(readFileSync(invoicesPath, "utf8"));
    if (!Array.isArray(records)) throw new Error("Expected invoice records array");
    return records;
  } catch (error) {
    throw new Error(`Cannot read invoices: ${error.message}`);
  }
}

function writeInvoices(invoices) {
  writeFileSync(invoicesPath, JSON.stringify(invoices, null, 2), { mode: 0o600 });
}

async function handleInvoiceCharges(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "invoicing")) {
    sendJson(response, 403, { ok: false, message: "Invoicing access required." });
    return;
  }
  const charges = readInvoiceCharges();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, charges });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const name = String(payload.name || "").trim().slice(0, 120);
    const defaultRate = roundMoney(Math.max(0, Number(payload.defaultRate) || 0));
    if (!name) {
      sendJson(response, 400, { ok: false, message: "Enter a charge name." });
      return;
    }
    const existing = charges.find((charge) => charge.id === payload.id);
    const duplicate = charges.find((charge) =>
      charge.name.toLowerCase() === name.toLowerCase() && charge.id !== payload.id
    );
    if (duplicate) {
      sendJson(response, 409, { ok: false, message: "A saved charge with that name already exists." });
      return;
    }
    const charge = {
      id: existing?.id || randomBytes(12).toString("hex"),
      name,
      defaultRate,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    const index = charges.findIndex((record) => record.id === charge.id);
    if (index >= 0) charges[index] = charge;
    else charges.push(charge);
    writeInvoiceCharges(charges);
    logActivity(session, index >= 0 ? "invoice-charge.updated" : "invoice-charge.created",
      `${index >= 0 ? "Updated" : "Created"} invoice charge ${charge.name}.`);
    sendJson(response, 200, { ok: true, charge });
    return;
  }
  if (request.method === "DELETE") {
    const removed = charges.find((charge) => charge.id === payload.id);
    writeInvoiceCharges(charges.filter((charge) => charge.id !== payload.id));
    if (removed) {
      logActivity(session, "invoice-charge.deleted", `Deleted invoice charge ${removed.name}.`);
    }
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readInvoiceCharges() {
  if (!existsSync(invoiceChargesPath)) return [];
  try {
    const charges = JSON.parse(readFileSync(invoiceChargesPath, "utf8"));
    return Array.isArray(charges) ? charges : [];
  } catch {
    return [];
  }
}

function writeInvoiceCharges(charges) {
  writeFileSync(invoiceChargesPath, JSON.stringify(charges, null, 2), { mode: 0o600 });
}

async function handleInvoicePaymentInstructions(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "invoicing")) {
    sendJson(response, 403, { ok: false, message: "Invoicing access required." });
    return;
  }
  const instructions = readInvoicePaymentInstructions();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, instructions });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const name = String(payload.name || "").trim().slice(0, 120);
    const body = String(payload.body || "").trim().slice(0, 1200);
    if (!name || !body) {
      sendJson(response, 400, { ok: false, message: "Enter a name and payment instructions." });
      return;
    }
    const existing = instructions.find((instruction) => instruction.id === payload.id);
    const duplicate = instructions.find((instruction) =>
      instruction.name.toLowerCase() === name.toLowerCase() && instruction.id !== payload.id
    );
    if (duplicate) {
      sendJson(response, 409, { ok: false, message: "Saved payment instructions with that name already exist." });
      return;
    }
    const instruction = {
      id: existing?.id || randomBytes(12).toString("hex"),
      name,
      body,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    const index = instructions.findIndex((record) => record.id === instruction.id);
    if (index >= 0) instructions[index] = instruction;
    else instructions.push(instruction);
    writeInvoicePaymentInstructions(instructions);
    logActivity(session, index >= 0 ? "invoice-payment-instructions.updated" : "invoice-payment-instructions.created",
      `${index >= 0 ? "Updated" : "Created"} invoice payment instructions ${instruction.name}.`);
    sendJson(response, 200, { ok: true, instruction });
    return;
  }
  if (request.method === "DELETE") {
    const removed = instructions.find((instruction) => instruction.id === payload.id);
    writeInvoicePaymentInstructions(instructions.filter((instruction) => instruction.id !== payload.id));
    if (removed) {
      logActivity(session, "invoice-payment-instructions.deleted", `Deleted invoice payment instructions ${removed.name}.`);
    }
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readInvoicePaymentInstructions() {
  if (!existsSync(invoicePaymentInstructionsPath)) return [];
  try {
    const instructions = JSON.parse(readFileSync(invoicePaymentInstructionsPath, "utf8"));
    return Array.isArray(instructions) ? instructions : [];
  } catch {
    return [];
  }
}

function writeInvoicePaymentInstructions(instructions) {
  writeFileSync(invoicePaymentInstructionsPath, JSON.stringify(instructions, null, 2), { mode: 0o600 });
}

async function handleFinance(request, response) {
  const payload = request.method === "GET" ? null : await readJsonBody(request);
  return billingTransaction(response, buffered => handleFinanceParsed(request, buffered, payload));
}

function handleFinanceParsed(request, response, payload) {
  const session = getSession(request);
  if (!hasPermission(session, "finance")) {
    sendJson(response, 403, { ok: false, message: "Finance access required." });
    return;
  }
  const finance = readFinance();
  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      ...calculateFinance(finance),
      canDeleteExpenses: session.username === "Huber58"
    });
    return;
  }
  if (request.method !== "POST" && request.method !== "DELETE") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const action = String(payload.action || "");

  if (request.method === "POST" && action === "save-groups") {
    const existingGroupIds = new Set(finance.groups.map((group) => group.id));
    const groups = (Array.isArray(payload.groups) ? payload.groups : [])
      .slice(0, 30)
      .map((group) => ({
        id: existingGroupIds.has(String(group.id || "")) ||
            /^[a-f0-9]{24}$/.test(String(group.id || ""))
          ? group.id : randomBytes(12).toString("hex"),
        name: String(group.name || "").trim().slice(0, 80),
        percent: roundMoney(Math.max(0, Number(group.percent) || 0))
      }))
      .filter((group) => group.name);
    const totalPercent = groups.reduce((sum, group) => sum + group.percent, 0);
    const names = new Set(groups.map((group) => group.name.toLowerCase()));
    const retainedIds = new Set(groups.map((group) => group.id));
    const removedUsedGroup = finance.expenses.some((expense) => !retainedIds.has(expense.groupId));
    if (!groups.length || totalPercent > 100.001) {
      sendJson(response, 400, {
        ok: false,
        message: "Add at least one group and keep the combined allocation at or below 100%."
      });
      return;
    }
    if (names.size !== groups.length || removedUsedGroup) {
      sendJson(response, 400, {
        ok: false,
        message: removedUsedGroup
          ? "Move or delete expenses from a group before removing that group."
          : "Each allocation group needs a unique name."
      });
      return;
    }
    finance.groups = groups;
    finance.laborGroupId = groups.some((group) => group.id === payload.laborGroupId)
      ? payload.laborGroupId : "";
    writeFinance(finance);
    logActivity(session, "finance.groups-updated", "Updated financial allocation groups.");
    broadcastAllServiceEvent("dashboard-updated", { area: "finance" });
    sendJson(response, 200, { ok: true, ...calculateFinance(finance) });
    return;
  }

  if (request.method === "POST" && action === "add-payment") {
    const requestId = String(payload.requestId || "").trim();
    if (!/^[a-zA-Z0-9-]{16,80}$/.test(requestId)) {
      sendJson(response, 400, { ok: false, message: "Invalid payment request ID." });
      return;
    }
    const fingerprint = JSON.stringify([payload.invoiceId || "", payload.contractTicketId || "", Number(payload.amount), payload.date || "", payload.method || "", payload.reference || "", payload.description || "", payload.note || ""]);
    const requestKey = `${session.username}:${requestId}`;
    const previous = requestId && (finance.paymentRequests?.[requestKey] || finance.payments.find(payment => payment.requestId === requestId && payment.createdBy === session.username));
    if (previous) {
      if (previous.requestFingerprint !== fingerprint) {
        sendJson(response, 409, { ok: false, requestConflict: true, message: "Your earlier payment was already saved with different details. Check the payment list before submitting a new payment." });
        return;
      }
      sendJson(response, 200, { ok: true, replayed: true, ...calculateFinance(finance) });
      return;
    }
    const amount = roundMoney(Number(payload.amount));
    const invoiceId = String(payload.invoiceId || "");
    const invoice = invoiceId && readInvoices().find((record) => record.id === invoiceId);
    const invoiceTicket = invoice && readTickets().find((record) => record.id === invoice.ticketId);
    if (invoice && ["Draft", "Void"].includes(invoice.status)) {
      sendJson(response, 409, { ok: false, message: "Payments require an issued invoice, not a draft or void invoice." });
      return;
    }
    const contractTicketId = String(payload.contractTicketId || "");
    const contract = contractTicketId && contractPaymentSummaries(finance)
      .find((record) => record.id === contractTicketId);
    if (invoiceId && contractTicketId) {
      sendJson(response, 400, { ok: false, message: "Choose either an invoice or a contract ticket." });
      return;
    }
    if ((invoiceId && !invoice) || (contractTicketId && !contract)) {
      sendJson(response, 404, { ok: false, message: invoiceId ? "Invoice not found." : "Contract ticket not found." });
      return;
    }
    if (invoice && (invoiceTicket?.ticketType || "Service") === "Contract") {
      sendJson(response, 400, {
        ok: false,
        message: "Record this payment against the contract ticket, not an invoice."
      });
      return;
    }
    const description = invoice
      ? `Payment for INV-${String(invoice.number).padStart(4, "0")}`
      : contract
        ? `Payment for C-${String(contract.number).padStart(4, "0")}`
        : String(payload.description || "").trim().slice(0, 140);
    if (!Number.isFinite(amount) || !(amount > 0) || (!invoice && !contract && !description)) {
      sendJson(response, 400, { ok: false, message: "Enter a payment amount and description." });
      return;
    }
    if (invoice) {
      const alreadyPaid = invoicePaidAmount(invoice, finance.payments);
      const remaining = roundMoney(Math.max(0, Number(invoice.total || 0) - alreadyPaid));
      if (amount > remaining + 0.001) {
        sendJson(response, 400, {
          ok: false,
          message: `This payment is greater than the ${remaining.toFixed(2)} remaining balance.`
        });
        return;
      }
    }
    if (contract && amount > contract.balance + 0.001) {
      sendJson(response, 400, {
        ok: false,
        message: `This payment is greater than the ${contract.balance.toFixed(2)} remaining contract balance.`
      });
      return;
    }
    const payment = {
      id: randomBytes(12).toString("hex"),
      requestId,
      requestFingerprint: fingerprint,
      invoiceId: invoice?.id || "",
      contractTicketId: contract?.id || "",
      description,
      amount,
      date: validDateOnly(payload.date) || new Date().toISOString().slice(0, 10),
      method: ["ACH", "Bank Transfer", "Cash", "Check", "Credit Card", "Other"].includes(payload.method)
        ? payload.method : "Other",
      reference: String(payload.reference || "").trim().slice(0, 120),
      note: String(payload.note || "").trim().slice(0, 300),
      createdAt: new Date().toISOString(),
      createdBy: session.username
    };
    finance.payments.push(payment);
    if (requestId) {
      finance.paymentRequests ||= {};
      finance.paymentRequests[requestKey] = { requestFingerprint: fingerprint, paymentId: payment.id };
    }
    if (invoice) {
      const invoices = readInvoices();
      const editable = invoices.find((record) => record.id === invoice.id);
      const paid = finance.payments
        .filter((record) => record.invoiceId === invoice.id)
        .reduce((sum, record) => sum + Number(record.amount || 0), 0);
      if (editable && paid >= Number(editable.total || 0) - 0.001) {
        payment.markedInvoicePaid = editable.status !== "Paid";
        editable.status = "Paid";
        editable.updatedAt = new Date().toISOString();
        editable.updatedBy = session.username;
        writeInvoices(invoices);
      }
    }
    writeFinance(finance);
    logActivity(session, "finance.payment-added", `Recorded ${description} for $${amount.toFixed(2)}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "finance" });
    if (contract) {
      broadcastAllServiceEvent("job-workspace-updated", { ticketId: contract.id });
    }
    sendJson(response, 200, { ok: true, ...calculateFinance(finance) });
    return;
  }

  if (request.method === "POST" && action === "add-expense") {
    const amount = roundMoney(Number(payload.amount));
    const description = String(payload.description || "").trim().slice(0, 140);
    const groupId = String(payload.groupId || "");
    if (!(amount > 0) || !description || !finance.groups.some((group) => group.id === groupId)) {
      sendJson(response, 400, { ok: false, message: "Enter an expense and select its allocation group." });
      return;
    }
    if (amount >= readApprovalPolicies().expenseThreshold && !hasPermission(session, "approvals")) {
      const approval = createApprovalRequest(session, "expense", {
        groupId,
        description,
        employee: String(payload.employee || "").trim().slice(0, 100),
        amount,
        date: validDateOnly(payload.date) || businessToday(),
        note: String(payload.note || "").trim().slice(0, 300)
      }, `Record expense ${description} for $${amount.toFixed(2)}`);
      sendJson(response, 202, {
        ok: true,
        approvalPending: true,
        approval,
        message: "Expense submitted for approval.",
        ...calculateFinance(finance)
      });
      return;
    }
    const expense = {
      id: randomBytes(12).toString("hex"),
      groupId,
      description,
      employee: String(payload.employee || "").trim().slice(0, 100),
      amount,
      date: validDateOnly(payload.date) || new Date().toISOString().slice(0, 10),
      note: String(payload.note || "").trim().slice(0, 300),
      createdAt: new Date().toISOString(),
      createdBy: session.username
    };
    finance.expenses.push(expense);
    writeFinance(finance);
    logActivity(session, "finance.expense-added",
      `Recorded expense ${expense.description} for $${amount.toFixed(2)}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "finance" });
    sendJson(response, 200, { ok: true, ...calculateFinance(finance) });
    return;
  }

  if (request.method === "DELETE" && action === "delete-payment") {
    const payment = finance.payments.find((record) => record.id === payload.id);
    if (payment?.stripeSessionId || payment?.zohoPaymentId || payment?.bankTransactionId) {
      sendJson(response, 409, { ok: false, message: "Reverse this payment through its processor or bank reconciliation so the audit trail stays intact." });
      return;
    }
    finance.payments = finance.payments.filter((record) => record.id !== payload.id);
    if (payment?.invoiceId) {
      const invoices = readInvoices();
      const invoice = invoices.find((record) => record.id === payment.invoiceId);
      if (invoice) {
        invoice.status = invoicePaymentStatus(invoice, finance.payments);
        writeInvoices(invoices);
      }
    }
    writeFinance(finance);
    if (payment) logActivity(session, "finance.payment-deleted", `Deleted ${payment.description}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "finance" });
    if (payment?.contractTicketId) {
      broadcastAllServiceEvent("job-workspace-updated", { ticketId: payment.contractTicketId });
    }
    sendJson(response, 200, { ok: true, ...calculateFinance(finance) });
    return;
  }

  if (request.method === "DELETE" && action === "delete-expense") {
    if (session.username !== "Huber58") {
      sendJson(response, 403, { ok: false, message: "Only Huber58 can delete expenses." });
      return;
    }
    const expense = finance.expenses.find((record) => record.id === payload.id);
    finance.expenses = finance.expenses.filter((record) => record.id !== payload.id);
    writeFinance(finance);
    if (expense) logActivity(session, "finance.expense-deleted", `Deleted expense ${expense.description}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "finance" });
    sendJson(response, 200, { ok: true, ...calculateFinance(finance) });
    return;
  }

  sendJson(response, 400, { ok: false, message: "Unknown finance action." });
}

function validDateOnly(value) {
  const date = String(value || "");
  return /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : "";
}

function readFinance() {
  const defaults = {
    groups: [
      { id: "bonus-pool", name: "Bonus Pool", percent: 5 },
      { id: "employee-labor", name: "Employee Labor", percent: 35 },
      { id: "operating", name: "Operating", percent: 60 }
    ],
    laborGroupId: "employee-labor",
    payments: [],
    paymentRequests: {},
    expenses: []
  };
  if (!existsSync(financePath)) return defaults;
  try {
    const saved = JSON.parse(readFileSync(financePath, "utf8"));
    if (!saved || !Array.isArray(saved.payments) || !Array.isArray(saved.expenses) || !Array.isArray(saved.groups)) throw new Error("Invalid finance record structure");
    return {
      groups: Array.isArray(saved.groups) ? saved.groups : defaults.groups,
      laborGroupId: String(saved.laborGroupId || ""),
      payments: Array.isArray(saved.payments) ? saved.payments : [],
      paymentRequests: saved.paymentRequests && typeof saved.paymentRequests === "object" && !Array.isArray(saved.paymentRequests) ? saved.paymentRequests : {},
      expenses: Array.isArray(saved.expenses) ? saved.expenses : []
    };
  } catch (error) {
    throw new Error(`Cannot read finance records; writes are blocked until storage is repaired: ${error.message}`);
  }
}

function writeFinance(finance) {
  writeFileSync(financePath, JSON.stringify(finance, null, 2), { mode: 0o600 });
}

function contractPaymentSummaries(finance, customerId = "") {
  const estimates = readEstimates();
  const invoices = readInvoices();
  return readTickets()
    .filter((ticket) => (ticket.ticketType || "Service") === "Contract" &&
      (!customerId || ticket.customerId === customerId))
    .map((ticket) => {
      const estimate = estimates.find((record) =>
        record.ticketId === ticket.id || record.id === ticket.sourceEstimateId
      );
      const total = roundMoney(estimate?.total || 0);
      const legacyInvoiceIds = new Set(invoices
        .filter((invoice) => invoice.ticketId === ticket.id)
        .map((invoice) => invoice.id));
      const payments = finance.payments.filter((payment) =>
        payment.contractTicketId === ticket.id || legacyInvoiceIds.has(payment.invoiceId)
      );
      const paid = roundMoney(payments.reduce((sum, payment) =>
        sum + Number(payment.amount || 0), 0));
      return {
        id: ticket.id,
        number: ticket.number,
        customerId: ticket.customerId || "",
        customer: ticket.customer || "",
        description: ticket.description || ticket.serviceType || estimate?.title || "Contract",
        status: ticket.status || "Open",
        issueDate: String(ticket.createdAt || ticket.scheduledDate || "").slice(0, 10),
        dueDate: String(ticket.dueDate || "").slice(0, 10),
        estimateId: estimate?.id || "",
        total,
        paid,
        balance: roundMoney(Math.max(0, total - paid)),
        payments
      };
    })
    .filter((contract) => contract.total > 0)
    .sort((a, b) => Number(b.number || 0) - Number(a.number || 0));
}

function calculateFinance(finance) {
  const invoices = readInvoices();
  const contractTicketIds = new Set(readTickets()
    .filter((ticket) => (ticket.ticketType || "Service") === "Contract")
    .map((ticket) => ticket.id));
  const explicitInvoicePayments = new Map();
  for (const payment of finance.payments) {
    if (!payment.invoiceId) continue;
    explicitInvoicePayments.set(
      payment.invoiceId,
      (explicitInvoicePayments.get(payment.invoiceId) || 0) + Number(payment.amount || 0)
    );
  }
  let invoiceReceived = 0;
  let outstanding = 0;
  const invoiceBalances = invoices
    .filter((invoice) => invoice.status !== "Void" && invoice.status !== "Draft" &&
      !contractTicketIds.has(invoice.ticketId))
    .map((invoice) => {
      const paid = explicitInvoicePayments.get(invoice.id) || 0;
      const balance = roundMoney(Math.max(0, Number(invoice.total || 0) - paid));
      invoiceReceived += Math.min(Number(invoice.total || 0), paid);
      outstanding += balance;
      return {
        id: invoice.id,
        number: invoice.number,
        customer: invoice.customer,
        total: Number(invoice.total || 0),
        paid: roundMoney(paid),
        balance,
        status: invoicePaymentStatus(invoice, finance.payments)
      };
    });
  const contracts = contractPaymentSummaries(finance);
  const contractPaymentIds = new Set(contracts.flatMap((contract) =>
    contract.payments.map((payment) => payment.id)
  ));
  const contractReceived = roundMoney(contracts.reduce((sum, contract) =>
    sum + Math.min(contract.total, contract.paid), 0));
  outstanding += contracts.reduce((sum, contract) => sum + contract.balance, 0);
  const customReceived = finance.payments
    .filter((payment) => !payment.invoiceId && !payment.contractTicketId &&
      !contractPaymentIds.has(payment.id))
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  const received = roundMoney(invoiceReceived + contractReceived + customReceived);
  const labor = calculateLaborCost();
  const expenseTotal = roundMoney(finance.expenses.reduce(
    (sum, expense) => sum + Number(expense.amount || 0), 0
  ));
  const billData = billSummary(readBills());
  const billPaymentTotal = billData.summary.paymentTotal;
  const billTypeById = new Map(billData.bills.map((bill) => [bill.id, bill.type || "Bill"]));
  const groups = finance.groups.map((group) => {
    const allocated = roundMoney(received * Number(group.percent || 0) / 100);
    const expenses = roundMoney(finance.expenses
      .filter((expense) => expense.groupId === group.id)
      .reduce((sum, expense) => sum + Number(expense.amount || 0), 0));
    const laborCost = finance.laborGroupId === group.id ? labor.total : 0;
    return {
      ...group,
      allocated,
      expenses,
      laborCost,
      balance: roundMoney(allocated - expenses - laborCost)
    };
  });
  const allocatedPercent = roundMoney(finance.groups.reduce(
    (sum, group) => sum + Number(group.percent || 0), 0
  ));
  return {
    summary: {
      outstanding: roundMoney(outstanding),
      received,
      expenses: expenseTotal,
      labor: labor.total,
      billsDue: billData.summary.unpaid,
      overdueBills: billData.summary.overdue,
      overdueBillCount: billData.summary.overdueCount,
      billPayments: billPaymentTotal,
      netIncome: roundMoney(
        received - expenseTotal - labor.total - billPaymentTotal - billData.summary.unpaid
      ),
      unallocated: roundMoney(received * Math.max(0, 100 - allocatedPercent) / 100)
    },
    groups,
    laborGroupId: finance.laborGroupId,
    payments: [...finance.payments].sort((a, b) => b.date.localeCompare(a.date)),
    billPayments: billData.payments.map((payment) => ({
      ...payment,
      type: billTypeById.get(payment.billId) || "Bill"
    })),
    expenses: [...finance.expenses].sort((a, b) => b.date.localeCompare(a.date)),
    invoices: invoiceBalances,
    contracts,
    labor: labor.employees,
    employeeNames: readEmployees()
      .filter((employee) => employee.status !== "Inactive")
      .map((employee) => `${employee.firstName || ""} ${employee.lastName || ""}`.trim())
      .filter(Boolean)
      .sort()
  };
}

function calculateLaborCost() {
  const employees = readEmployees();
  const employeeByName = new Map(employees.map((employee) => [
    `${employee.firstName || ""} ${employee.lastName || ""}`.trim().toLowerCase(),
    employee
  ]));
  const totals = new Map();
  for (const record of readTimeRecords()) {
    if (!record.clockOut) continue;
    const start = new Date(record.clockIn);
    const end = new Date(record.clockOut);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end <= start) continue;
    const employee = employeeByName.get(String(record.employeeName || "").trim().toLowerCase());
    const hasSavedRate = Number.isFinite(Number(record.laborRate));
    if (!employee && !hasSavedRate) continue;
    const hours = (end - start) / 3600000;
    const rate = hasSavedRate
      ? Number(record.laborRate)
      : employee.payType === "Salary"
        ? Number(employee.wage || 0) / 2080
        : Number(employee.wage || 0);
    const current = totals.get(record.employeeName) || { hours: 0, cost: 0 };
    current.hours += hours;
    current.cost += hours * rate;
    totals.set(record.employeeName, current);
  }
  const employeesWithCosts = [...totals].map(([employeeName, values]) => ({
    employeeName,
    hours: Math.round(values.hours * 100) / 100,
    cost: roundMoney(values.cost)
  })).sort((a, b) => b.cost - a.cost);
  return {
    total: roundMoney(employeesWithCosts.reduce((sum, employee) => sum + employee.cost, 0)),
    employees: employeesWithCosts
  };
}

function employeeLaborRate(employeeName) {
  const employee = readEmployees().find((record) =>
    `${record.firstName || ""} ${record.lastName || ""}`.trim().toLowerCase() ===
    String(employeeName || "").trim().toLowerCase()
  );
  if (!employee) return 0;
  return employee.payType === "Salary"
    ? Number(employee.wage || 0) / 2080
    : Number(employee.wage || 0);
}

async function handleBills(request, response) {
  const payload = request.method === "GET" ? null : await readJsonBody(request);
  return billingTransaction(response, buffered => handleBillsParsed(request, buffered, payload));
}

function handleBillsParsed(request, response, payload) {
  const session = getSession(request);
  if (!hasPermission(session, "bills")) {
    sendJson(response, 403, { ok: false, message: "Finance access required." });
    return;
  }
  const bills = readBills();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, ...billSummary(bills) });
    return;
  }
  if (request.method !== "POST" && request.method !== "DELETE") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const action = String(payload.action || "");

  if (request.method === "POST" && action === "save") {
    const name = String(payload.name || "").trim().slice(0, 120);
    const type = payload.type === "Loan" ? "Loan" : "Bill";
    const existing = bills.find((bill) => bill.id === payload.id);
    const loanAmount = roundMoney(Number(payload.loanAmount));
    const monthlyPayment = roundMoney(Number(payload.monthlyPayment));
    const amount = type === "Loan"
      ? roundMoney(Math.min(monthlyPayment, loanAmount))
      : roundMoney(Number(payload.amount));
    const dueDate = validDateOnly(payload.dueDate);
    const frequency = type === "Loan"
      ? "Monthly"
      : ["Monthly", "Yearly"].includes(payload.frequency) ? payload.frequency : "";
    const paidOffLoan = type === "Loan" && loanAmount === 0 && existing?.status === "Paid Off";
    if (!name || (!(amount > 0) && !paidOffLoan) || !dueDate || !frequency ||
        (type === "Loan" && ((!(loanAmount > 0) && !paidOffLoan) || !(monthlyPayment > 0)))) {
      sendJson(response, 400, {
        ok: false,
        message: type === "Loan"
          ? "Enter a loan amount, monthly payment, and due date."
          : "Enter a name, amount, due date, and monthly or yearly frequency."
      });
      return;
    }
    const requestedStatus = paidOffLoan
      ? "Paid Off"
      : payload.status === "Paid" ? "Paid" : "Unpaid";
    const payments = Array.isArray(existing?.payments) ? existing.payments : [];
    const bill = {
      id: existing?.id || randomBytes(12).toString("hex"),
      name,
      type,
      amount,
      monthlyPayment: type === "Loan" ? monthlyPayment : 0,
      originalLoanAmount: type === "Loan"
        ? Math.max(Number(existing?.originalLoanAmount) || 0, loanAmount)
        : 0,
      remainingLoanAmount: type === "Loan" ? loanAmount : 0,
      frequency,
      dueDate,
      status: requestedStatus,
      note: String(payload.note || "").trim().slice(0, 500),
      payments,
      createdAt: existing?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    for (const payment of bill.payments) {
      if (!payment.billId) payment.billId = bill.id;
    }
    if (requestedStatus === "Paid" && existing?.status !== "Paid") {
      recordBillPayment(bill, session);
    } else if (requestedStatus === "Unpaid" && existing?.status === "Paid") {
      reverseCurrentBillPayment(bill);
    }
    const index = bills.findIndex((record) => record.id === bill.id);
    if (index >= 0) bills[index] = bill;
    else bills.push(bill);
    writeBills(bills);
    logActivity(session, index >= 0 ? "bill.updated" : "bill.created",
      `${index >= 0 ? "Updated" : "Created"} ${bill.type.toLowerCase()} ${bill.name}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "bills" });
    sendJson(response, 200, { ok: true, ...billSummary(bills), bill });
    return;
  }

  if (request.method === "POST" && action === "mark-paid") {
    const bill = bills.find((record) => record.id === payload.id);
    if (!bill) {
      sendJson(response, 404, { ok: false, message: "Bill not found." });
      return;
    }
    if (!["Paid", "Paid Off"].includes(bill.status)) {
      const payment = recordBillPayment(bill, session);
      bill.updatedAt = new Date().toISOString();
      bill.updatedBy = session.username;
      writeBills(bills);
      logActivity(session, "bill.paid", `Marked ${bill.name} paid for $${Number(payment.amount).toFixed(2)}.`);
      broadcastAllServiceEvent("dashboard-updated", { area: "bills" });
    }
    sendJson(response, 200, { ok: true, ...billSummary(bills), bill });
    return;
  }

  if (request.method === "POST" && action === "mark-unpaid") {
    const bill = bills.find((record) => record.id === payload.id);
    if (!bill) {
      sendJson(response, 404, { ok: false, message: "Bill not found." });
      return;
    }
    reverseCurrentBillPayment(bill);
    bill.status = Number(bill.remainingLoanAmount) <= 0 && bill.type === "Loan"
      ? "Paid Off" : "Unpaid";
    bill.updatedAt = new Date().toISOString();
    bill.updatedBy = session.username;
    writeBills(bills);
    logActivity(session, "bill.unpaid", `Marked ${bill.name} unpaid.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "bills" });
    sendJson(response, 200, { ok: true, ...billSummary(bills), bill });
    return;
  }

  if (request.method === "DELETE" && action === "delete") {
    const bill = bills.find((record) => record.id === payload.id);
    writeBills(bills.filter((record) => record.id !== payload.id));
    if (bill) logActivity(session, "bill.deleted", `Deleted ${bill.type.toLowerCase()} ${bill.name}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "bills" });
    sendJson(response, 200, { ok: true, ...billSummary(readBills()) });
    return;
  }

  sendJson(response, 400, { ok: false, message: "Unknown bill action." });
}

function createBillPayment(billId, name, amount, dueDate, session) {
  return {
    id: randomBytes(12).toString("hex"),
    billId,
    name,
    amount: roundMoney(amount),
    dueDate,
    paidAt: new Date().toISOString(),
    paidBy: session.username
  };
}

function recordBillPayment(bill, session, requestedAmount = null) {
  bill.payments = Array.isArray(bill.payments) ? bill.payments : [];
  const amount = bill.type === "Loan"
    ? roundMoney(Math.min(
        Number(requestedAmount ?? bill.monthlyPayment ?? bill.amount) || 0,
        Number(bill.remainingLoanAmount) || 0
      ))
    : roundMoney(Number(requestedAmount ?? bill.amount) || 0);
  const payment = createBillPayment(bill.id, bill.name, amount, bill.dueDate, session);
  if (bill.type === "Loan") {
    payment.principalApplied = amount;
    bill.remainingLoanAmount = roundMoney(
      Math.max(0, Number(bill.remainingLoanAmount || 0) - amount)
    );
    payment.remainingLoanBalance = bill.remainingLoanAmount;
    bill.amount = roundMoney(Math.min(
      Number(bill.monthlyPayment) || 0,
      Number(bill.remainingLoanAmount) || 0
    ));
    bill.status = bill.remainingLoanAmount <= 0 ? "Paid Off" : "Paid";
  } else {
    bill.status = "Paid";
  }
  bill.payments.push(payment);
  return payment;
}

function reverseCurrentBillPayment(bill) {
  bill.payments = Array.isArray(bill.payments) ? bill.payments : [];
  let index = -1;
  for (let cursor = bill.payments.length - 1; cursor >= 0; cursor -= 1) {
    if (bill.payments[cursor].dueDate === bill.dueDate) {
      index = cursor;
      break;
    }
  }
  if (index < 0 && bill.payments.length) index = bill.payments.length - 1;
  if (index < 0) return null;
  const [payment] = bill.payments.splice(index, 1);
  restoreLoanPrincipal(bill, payment);
  return payment;
}

function restoreLoanPrincipal(bill, payment) {
  if (bill.type !== "Loan" || !payment) return;
  bill.remainingLoanAmount = roundMoney(Math.min(
    Number(bill.originalLoanAmount) || Infinity,
    Number(bill.remainingLoanAmount || 0) +
      Number(payment.principalApplied ?? payment.amount ?? 0)
  ));
  bill.amount = roundMoney(Math.min(
    Number(bill.monthlyPayment) || 0,
    Number(bill.remainingLoanAmount) || 0
  ));
}

function readBills() {
  if (!existsSync(billsPath)) return [];
  try {
    const saved = JSON.parse(readFileSync(billsPath, "utf8"));
    if (!Array.isArray(saved)) return [];
    let changed = false;
    const today = businessToday();
    for (const bill of saved) {
      bill.payments = Array.isArray(bill.payments) ? bill.payments : [];
      if (bill.type === "Loan") {
        const legacyAmount = Math.max(0, Number(bill.amount) || 0);
        if (!Number.isFinite(Number(bill.monthlyPayment)) || Number(bill.monthlyPayment) <= 0) {
          bill.monthlyPayment = legacyAmount;
          changed = true;
        }
        if (!Number.isFinite(Number(bill.remainingLoanAmount))) {
          bill.remainingLoanAmount = Math.max(0, Number(bill.loanAmount) || legacyAmount);
          changed = true;
        }
        if (!Number.isFinite(Number(bill.originalLoanAmount))) {
          bill.originalLoanAmount = Math.max(
            Number(bill.remainingLoanAmount) || 0,
            Number(bill.loanAmount) || 0
          );
          changed = true;
        }
        const dueAmount = Math.min(
          Number(bill.monthlyPayment) || 0,
          Number(bill.remainingLoanAmount) || 0
        );
        if (bill.amount !== dueAmount) {
          bill.amount = roundMoney(dueAmount);
          changed = true;
        }
        if (Number(bill.remainingLoanAmount) <= 0 && bill.status !== "Paid Off") {
          bill.status = "Paid Off";
          changed = true;
        }
      }
      if (bill.status === "Paid" && validDateOnly(bill.dueDate) && bill.dueDate < today) {
        bill.dueDate = advanceBillDate(bill.dueDate, bill.frequency);
        bill.status = "Unpaid";
        changed = true;
      }
    }
    if (changed) writeBills(saved);
    return saved;
  } catch {
    return [];
  }
}

function writeBills(bills) {
  writeFileSync(billsPath, JSON.stringify(bills, null, 2), { mode: 0o600 });
}

function billSummary(bills) {
  const today = businessToday();
  const sorted = [...bills].sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  const unpaid = sorted.filter((bill) => !["Paid", "Paid Off"].includes(bill.status));
  const overdue = unpaid.filter((bill) => bill.dueDate < today);
  const payments = sorted.flatMap((bill) => bill.payments || [])
    .sort((a, b) => new Date(b.paidAt) - new Date(a.paidAt));
  return {
    bills: sorted.map((bill) => ({
      ...bill,
      overdue: !["Paid", "Paid Off"].includes(bill.status) && bill.dueDate < today
    })),
    payments,
    summary: {
      unpaid: roundMoney(unpaid.reduce((sum, bill) => sum + Number(bill.amount || 0), 0)),
      overdue: roundMoney(overdue.reduce((sum, bill) => sum + Number(bill.amount || 0), 0)),
      overdueCount: overdue.length,
      paid: roundMoney(sorted.filter((bill) => bill.status === "Paid")
        .reduce((sum, bill) => {
          const cyclePayment = [...(bill.payments || [])].reverse()
            .find((payment) => payment.dueDate === bill.dueDate);
          return sum + Number(cyclePayment?.amount ?? bill.amount ?? 0);
        }, 0)),
      loanBalance: roundMoney(sorted.filter((bill) => bill.type === "Loan")
        .reduce((sum, bill) => sum + Number(bill.remainingLoanAmount || 0), 0)),
      paymentTotal: roundMoney(payments.reduce(
        (sum, payment) => sum + Number(payment.amount || 0), 0
      ))
    }
  };
}

function businessToday() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: process.env.APP_TIME_ZONE || "America/Denver",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date());
}

function advanceBillDate(dateText, frequency) {
  const [year, month, day] = dateText.split("-").map(Number);
  const monthOffset = frequency === "Yearly" ? 12 : 1;
  const targetMonthIndex = month - 1 + monthOffset;
  const targetYear = year + Math.floor(targetMonthIndex / 12);
  const targetMonth = ((targetMonthIndex % 12) + 12) % 12;
  const lastDay = new Date(Date.UTC(targetYear, targetMonth + 1, 0)).getUTCDate();
  return `${targetYear}-${String(targetMonth + 1).padStart(2, "0")}-${
    String(Math.min(day, lastDay)).padStart(2, "0")
  }`;
}

async function handleBanking(request, response) {
  const upload = request.method === "POST" && request.headers["x-bank-statement"] === "1";
  const payload = request.method === "POST"
    ? upload ? await readBinaryBody(request, 15 * 1024 * 1024) : await readJsonBody(request)
    : null;
  return billingTransaction(response, buffered => handleBankingParsed(request, buffered, payload));
}

function handleBankingParsed(request, response, payload) {
  const session = getSession(request);
  if (!hasPermission(session, "banking")) {
    sendJson(response, 403, { ok: false, message: "Finance access required." });
    return;
  }
  const bank = readBankData();
  if (request.method === "GET") {
    sendJson(response, 200, bankingResponse(bank));
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }

  try {
    if (request.headers["x-bank-statement"] === "1") {
      const fileName = validDocumentName(decodeURIComponent(request.headers["x-file-name"] || ""));
      const extension = extname(fileName).toLowerCase();
      if (![".csv", ".ofx", ".qfx", ".qbo"].includes(extension)) {
        throw new Error("Choose a CSV, OFX, QFX, or QBO bank statement.");
      }
      const file = payload;
      const result = importBankStatement(bank, {
        fileName,
        extension,
        text: file.toString("utf8"),
        accountName: decodeURIComponent(request.headers["x-account-name"] || ""),
        endingBalance: decodeURIComponent(request.headers["x-ending-balance"] || ""),
        positiveMeans: request.headers["x-positive-means"] === "withdrawals" ? "withdrawals" : "deposits",
        username: session.username
      });
      writeBankData(bank);
      logActivity(session, "bank.statement-imported",
        `Imported ${result.added} transaction(s) from ${fileName}; skipped ${result.skipped} duplicate(s).`);
      broadcastAllServiceEvent("dashboard-updated", { area: "bank" });
      sendJson(response, 200, { ...bankingResponse(bank), importResult: result });
      return;
    }
    const action = String(payload.action || "");
    if (action === "reconcile") {
      const transaction = bank.transactions.find((item) => item.id === payload.transactionId);
      if (!transaction || transaction.reconciliation) {
        sendJson(response, 400, { ok: false, message: "Select an unreconciled bank transaction." });
        return;
      }
      const reconciliation = reconcileBankTransaction(transaction, payload, session);
      transaction.reconciliation = reconciliation;
      writeBankData(bank);
      logActivity(session, "bank.reconciled",
        `Reconciled ${transaction.name} for $${Math.abs(transaction.amount).toFixed(2)}.`);
      broadcastAllServiceEvent("dashboard-updated", { area: "bank" });
      sendJson(response, 200, bankingResponse(bank));
      return;
    }
    if (action === "unreconcile") {
      const transaction = bank.transactions.find((item) => item.id === payload.transactionId);
      if (!transaction?.reconciliation) {
        sendJson(response, 400, { ok: false, message: "Transaction is not reconciled." });
        return;
      }
      undoBankReconciliation(transaction.reconciliation);
      delete transaction.reconciliation;
      writeBankData(bank);
      broadcastAllServiceEvent("dashboard-updated", { area: "bank" });
      sendJson(response, 200, bankingResponse(bank));
      return;
    }
  } catch (error) {
    sendJson(response, 502, { ok: false, message: error.message || "Bank statement import failed." });
    return;
  }
  sendJson(response, 400, { ok: false, message: "Unknown banking action." });
}

function defaultBankData() {
  return {
    schemaVersion: 2,
    lastImportedAt: "",
    accounts: [],
    transactions: [],
    imports: []
  };
}

function readBankData() {
  if (!existsSync(bankPath)) return defaultBankData();
  try {
    const stored = JSON.parse(readFileSync(bankPath, "utf8"));
    if (!stored || !Array.isArray(stored.transactions) || !Array.isArray(stored.accounts)) throw new Error("Invalid bank record structure");
    const bank = {
      ...defaultBankData(),
      accounts: Array.isArray(stored.accounts) ? stored.accounts : [],
      transactions: Array.isArray(stored.transactions) ? stored.transactions : [],
      imports: Array.isArray(stored.imports) ? stored.imports : [],
      lastImportedAt: stored.lastImportedAt || stored.lastSyncedAt || ""
    };
    const legacyConnectorFields = [
      "accessToken",
      "itemId",
      "cursor",
      "environment",
      "connectedAt",
      "lastSyncedAt",
      "institution"
    ];
    if (legacyConnectorFields.some((key) => Object.prototype.hasOwnProperty.call(stored, key))) {
      writeBankData(bank);
    }
    return bank;
  } catch (error) {
    throw new Error(`Cannot read bank records: ${error.message}`);
  }
}

function writeBankData(bank) {
  writeFileSync(bankPath, JSON.stringify(bank, null, 2), { mode: 0o600 });
}

function parseDelimitedRows(text, delimiter) {
  const rows = [];
  let row = [];
  let value = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const character = text[index];
    if (quoted) {
      if (character === "\"" && text[index + 1] === "\"") {
        value += "\"";
        index += 1;
      } else if (character === "\"") {
        quoted = false;
      } else {
        value += character;
      }
    } else if (character === "\"") {
      quoted = true;
    } else if (character === delimiter) {
      row.push(value);
      value = "";
    } else if (character === "\n") {
      row.push(value.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      value = "";
    } else {
      value += character;
    }
  }
  if (value || row.length) {
    row.push(value.replace(/\r$/, ""));
    rows.push(row);
  }
  return rows.filter((fields) => fields.some((field) => String(field).trim()));
}

function normalizedStatementHeader(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

function statementColumn(headers, aliases) {
  const normalized = headers.map(normalizedStatementHeader);
  for (const alias of aliases) {
    const index = normalized.indexOf(normalizedStatementHeader(alias));
    if (index >= 0) return index;
  }
  return -1;
}

function statementMoney(value) {
  const text = String(value ?? "").trim();
  if (!text) return null;
  const negative = /^\(.*\)$/.test(text) || /^-/.test(text);
  const number = Number(text.replace(/[,$()+'" ]/g, ""));
  if (!Number.isFinite(number)) return null;
  return negative ? -Math.abs(number) : number;
}

function statementDate(value) {
  const text = String(value || "").trim();
  if (!text) return "";
  let match = text.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (match) return `${match[1]}-${match[2].padStart(2, "0")}-${match[3].padStart(2, "0")}`;
  match = text.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2}|\d{4})$/);
  if (match) {
    const year = match[3].length === 2 ? Number(match[3]) + (Number(match[3]) >= 70 ? 1900 : 2000) : match[3];
    return `${year}-${match[1].padStart(2, "0")}-${match[2].padStart(2, "0")}`;
  }
  const parsed = new Date(text);
  return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString().slice(0, 10);
}

function parseCsvStatement(text, positiveMeans) {
  const firstLine = String(text).split(/\r?\n/, 1)[0] || "";
  const delimiters = [",", "\t", ";"];
  const delimiter = delimiters.sort((a, b) =>
    firstLine.split(b).length - firstLine.split(a).length)[0];
  const rows = parseDelimitedRows(String(text).replace(/^\uFEFF/, ""), delimiter);
  if (rows.length < 2) throw new Error("The CSV statement has no transaction rows.");
  const headers = rows[0];
  const dateIndex = statementColumn(headers,
    ["date", "transaction date", "posting date", "posted date", "effective date"]);
  const descriptionIndex = statementColumn(headers,
    ["description", "transaction description", "name", "payee", "merchant", "details"]);
  const memoIndex = statementColumn(headers, ["memo", "notes", "additional description"]);
  const amountIndex = statementColumn(headers, ["amount", "transaction amount"]);
  const debitIndex = statementColumn(headers, ["debit", "withdrawal", "withdrawals", "charge"]);
  const creditIndex = statementColumn(headers, ["credit", "deposit", "deposits"]);
  const balanceIndex = statementColumn(headers, ["balance", "running balance"]);
  const idIndex = statementColumn(headers,
    ["transaction id", "id", "reference", "reference number", "check number", "fitid"]);
  if (dateIndex < 0 || (descriptionIndex < 0 && memoIndex < 0) ||
      (amountIndex < 0 && debitIndex < 0 && creditIndex < 0)) {
    throw new Error(
      "CSV columns were not recognized. Include Date, Description, and Amount, or separate Debit and Credit columns."
    );
  }
  const transactions = [];
  for (const row of rows.slice(1)) {
    const date = statementDate(row[dateIndex]);
    const name = String(row[descriptionIndex] || row[memoIndex] || "").trim();
    if (!date || !name) continue;
    let amount = null;
    if (debitIndex >= 0 || creditIndex >= 0) {
      const debit = statementMoney(row[debitIndex]);
      const credit = statementMoney(row[creditIndex]);
      if (debit !== null && debit !== 0) amount = Math.abs(debit);
      else if (credit !== null && credit !== 0) amount = -Math.abs(credit);
    } else {
      const rawAmount = statementMoney(row[amountIndex]);
      if (rawAmount !== null) amount = positiveMeans === "withdrawals" ? rawAmount : -rawAmount;
    }
    if (amount === null || !Number.isFinite(amount) || amount === 0) continue;
    transactions.push({
      date,
      name,
      originalName: String(row[memoIndex] || name).trim(),
      amount: roundMoney(amount),
      externalId: idIndex >= 0 ? String(row[idIndex] || "").trim() : "",
      balance: balanceIndex >= 0 ? statementMoney(row[balanceIndex]) : null
    });
  }
  if (!transactions.length) throw new Error("No valid transactions were found in the CSV statement.");
  const latestWithBalance = [...transactions]
    .filter((transaction) => transaction.balance !== null)
    .sort((a, b) => b.date.localeCompare(a.date))[0];
  return { transactions, endingBalance: latestWithBalance?.balance ?? null, accountNumber: "" };
}

function decodeStatementText(value) {
  return String(value || "")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, "\"")
    .replace(/&#39;/gi, "'");
}

function ofxValue(block, tag) {
  const match = String(block).match(new RegExp(`<${tag}>\\s*([^<\\r\\n]+)`, "i"));
  return decodeStatementText(match?.[1]?.trim() || "");
}

function parseOfxStatement(text) {
  const transactions = [];
  const blocks = String(text).match(/<STMTTRN>[\s\S]*?(?=<STMTTRN>|<\/BANKTRANLIST>|<\/CCBANKTRANLIST>|$)/gi) || [];
  for (const block of blocks) {
    const rawAmount = statementMoney(ofxValue(block, "TRNAMT"));
    const date = statementDate(ofxValue(block, "DTPOSTED").slice(0, 8)
      .replace(/^(\d{4})(\d{2})(\d{2})$/, "$1-$2-$3"));
    const name = ofxValue(block, "NAME") || ofxValue(block, "MEMO") || "Bank transaction";
    if (!date || rawAmount === null || rawAmount === 0) continue;
    transactions.push({
      date,
      name,
      originalName: ofxValue(block, "MEMO") || name,
      amount: roundMoney(-rawAmount),
      externalId: ofxValue(block, "FITID"),
      balance: null
    });
  }
  if (!transactions.length) throw new Error("No valid transactions were found in the OFX statement.");
  return {
    transactions,
    endingBalance: statementMoney(ofxValue(text, "BALAMT")),
    accountNumber: ofxValue(text, "ACCTID"),
    accountType: ofxValue(text, "ACCTTYPE")
  };
}

function bankStatementTransactionId(accountId, transaction, occurrence) {
  const source = transaction.externalId
    ? `external:${transaction.externalId}`
    : [
        transaction.date,
        transaction.amount.toFixed(2),
        transaction.name.toLowerCase().replace(/\s+/g, " ").trim(),
        occurrence
      ].join("|");
  return createHash("sha256").update(`${accountId}|${source}`).digest("hex").slice(0, 32);
}

function importBankStatement(bank, options) {
  const accountName = String(options.accountName || "").trim().slice(0, 120) || "Business Checking";
  const parsed = options.extension === ".csv"
    ? parseCsvStatement(options.text, options.positiveMeans)
    : parseOfxStatement(options.text);
  const accountMask = String(parsed.accountNumber || "").replace(/\D/g, "").slice(-4);
  const accountId = createHash("sha256")
    .update(`${accountName.toLowerCase()}|${accountMask}`)
    .digest("hex").slice(0, 24);
  const fingerprint = createHash("sha256").update(options.text).digest("hex");
  const previousImport = bank.imports.find((record) => record.fingerprint === fingerprint);
  if (previousImport) {
    return {
      added: 0,
      skipped: parsed.transactions.length,
      duplicateStatement: true,
      message: `This statement was already imported on ${new Date(previousImport.importedAt).toLocaleString()}.`
    };
  }

  const importId = randomBytes(12).toString("hex");
  const existingIds = new Set(bank.transactions.map((transaction) => transaction.id));
  const occurrences = new Map();
  const imported = [];
  let skipped = 0;
  for (const transaction of parsed.transactions) {
    const signature = `${transaction.date}|${transaction.amount.toFixed(2)}|${transaction.name.toLowerCase()}`;
    const occurrence = occurrences.get(signature) || 0;
    occurrences.set(signature, occurrence + 1);
    const id = bankStatementTransactionId(accountId, transaction, occurrence);
    if (existingIds.has(id)) {
      skipped += 1;
      continue;
    }
    existingIds.add(id);
    imported.push({
      id,
      accountId,
      importId,
      date: transaction.date,
      authorizedDate: "",
      name: transaction.name.slice(0, 240),
      originalName: transaction.originalName.slice(0, 500),
      amount: transaction.amount,
      pending: false,
      category: "",
      rule: matchBankRule(transaction.name, transaction.amount),
      reconciliation: null
    });
  }
  const suppliedBalance = statementMoney(options.endingBalance);
  const endingBalance = suppliedBalance ?? parsed.endingBalance;
  const account = bank.accounts.find((record) => record.id === accountId);
  const accountData = {
    id: accountId,
    name: accountName,
    officialName: accountName,
    type: "depository",
    subtype: parsed.accountType || "checking",
    mask: accountMask,
    current: endingBalance ?? account?.current ?? 0,
    available: endingBalance ?? account?.available ?? 0,
    lastStatementAt: new Date().toISOString()
  };
  if (account) Object.assign(account, accountData);
  else bank.accounts.push(accountData);
  bank.transactions.push(...imported);
  bank.transactions.sort((a, b) => b.date.localeCompare(a.date));
  const dates = parsed.transactions.map((transaction) => transaction.date).sort();
  const record = {
    id: importId,
    fingerprint,
    fileName: options.fileName,
    accountId,
    accountName,
    transactionCount: imported.length,
    skipped,
    fromDate: dates[0] || "",
    toDate: dates.at(-1) || "",
    importedAt: new Date().toISOString(),
    importedBy: options.username
  };
  bank.imports.unshift(record);
  bank.imports = bank.imports.slice(0, 100);
  bank.lastImportedAt = record.importedAt;
  return {
    added: imported.length,
    skipped,
    duplicateStatement: false,
    message: `Imported ${imported.length} transaction${imported.length === 1 ? "" : "s"} and skipped ${skipped} duplicate${skipped === 1 ? "" : "s"}.`
  };
}

function bankingResponse(bank) {
  const finance = readFinance();
  const calculated = calculateFinance(finance);
  const bills = readBills();
  return {
    ok: true,
    mode: "statement-import",
    lastImportedAt: bank.lastImportedAt,
    accounts: bank.accounts || [],
    transactions: bank.transactions || [],
    imports: bank.imports || [],
    targets: {
      invoices: calculated.invoices.filter((invoice) => invoice.balance > 0),
      bills: bills.filter((bill) => !["Paid", "Paid Off"].includes(bill.status)),
      groups: finance.groups
    }
  };
}

function readBankRules() {
  if (!existsSync(bankRulesPath)) return [];
  try {
    const rules = JSON.parse(readFileSync(bankRulesPath, "utf8"));
    return Array.isArray(rules) ? rules : [];
  } catch {
    return [];
  }
}

function writeBankRules(rules) {
  writeFileSync(bankRulesPath, JSON.stringify(rules, null, 2), { mode: 0o600 });
}

function matchBankRule(description, amount) {
  const text = String(description || "").toLowerCase();
  const direction = Number(amount) < 0 ? "Deposit" : "Withdrawal";
  const rule = readBankRules().find((item) =>
    item.enabled !== false &&
    (!item.direction || item.direction === "Any" || item.direction === direction) &&
    text.includes(String(item.contains || "").toLowerCase())
  );
  return rule ? { id: rule.id, name: rule.name, category: rule.category, groupId: rule.groupId || "" } : null;
}

async function handleBankRules(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "banking")) {
    sendJson(response, 403, { ok: false, message: "Finance access required." });
    return;
  }
  const rules = readBankRules();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, rules, groups: readFinance().groups });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const contains = String(payload.contains || "").trim().slice(0, 120);
    const category = String(payload.category || "").trim().slice(0, 80);
    if (!contains || !category) {
      sendJson(response, 400, { ok: false, message: "Rule text and category are required." });
      return;
    }
    const existing = rules.find((item) => item.id === payload.id);
    const rule = {
      id: existing?.id || randomBytes(12).toString("hex"),
      name: String(payload.name || contains).trim().slice(0, 80),
      contains,
      category,
      groupId: String(payload.groupId || ""),
      direction: ["Any", "Deposit", "Withdrawal"].includes(payload.direction) ? payload.direction : "Any",
      enabled: payload.enabled !== false,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    const index = rules.findIndex((item) => item.id === rule.id);
    if (index >= 0) rules[index] = rule;
    else rules.push(rule);
    writeBankRules(rules);
    const bank = readBankData();
    bank.transactions = bank.transactions.map((transaction) => ({
      ...transaction,
      rule: matchBankRule(transaction.name, transaction.amount)
    }));
    writeBankData(bank);
    logActivity(session, "bank-rule.saved", `Saved bank rule ${rule.name}.`);
    sendJson(response, 200, { ok: true, rule });
    return;
  }
  if (request.method === "DELETE") {
    writeBankRules(rules.filter((rule) => rule.id !== payload.id));
    logActivity(session, "bank-rule.deleted", "Deleted a bank categorization rule.");
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function reconcileBankTransaction(transaction, payload, session) {
  const type = String(payload.targetType || "");
  const amount = roundMoney(Math.abs(Number(transaction.amount) || 0));
  if (!(amount > 0)) throw new Error("Transaction amount is invalid.");
  if (type === "invoice") {
    if (transaction.amount >= 0) throw new Error("Only deposits can be matched to invoices.");
    const invoices = readInvoices();
    const invoice = invoices.find((record) => record.id === payload.targetId);
    if (!invoice) throw new Error("Invoice not found.");
    if (["Draft", "Void"].includes(invoice.status)) throw new Error("Only issued invoices can receive bank payments.");
    const finance = readFinance();
    const alreadyPaid = invoicePaidAmount(invoice, finance.payments);
    const remaining = roundMoney(Math.max(0, invoice.total - alreadyPaid));
    if (amount > remaining + 0.001) throw new Error(`Deposit exceeds the ${remaining.toFixed(2)} invoice balance. Split or correct the deposit before reconciling; no money was allocated.`);
    if (finance.payments.some(payment => payment.bankTransactionId === transaction.id)) throw new Error("This bank transaction already has a payment record.");
    const paymentAmount = amount;
    if (!(paymentAmount > 0)) throw new Error("Invoice has no remaining balance.");
    const payment = {
      id: randomBytes(12).toString("hex"),
      invoiceId: invoice.id,
      description: `Bank payment for INV-${String(invoice.number).padStart(4, "0")}`,
      amount: paymentAmount,
      date: transaction.date,
      method: "Bank Transfer",
      reference: transaction.name,
      bankTransactionId: transaction.id,
      note: "Reconciled from bank feed.",
      createdAt: new Date().toISOString(),
      createdBy: session.username
    };
    finance.payments.push(payment);
    writeFinance(finance);
    if (alreadyPaid + paymentAmount >= Number(invoice.total) - 0.001) {
      invoice.status = "Paid";
      writeInvoices(invoices);
    }
    return { type, targetId: invoice.id, recordId: payment.id, amount: paymentAmount };
  }
  if (type === "bill") {
    if (transaction.amount <= 0) throw new Error("Only withdrawals can be matched to bills.");
    const bills = readBills();
    const bill = bills.find((record) => record.id === payload.targetId);
    if (!bill) throw new Error("Bill not found.");
    if (bill.type === "Loan" && amount > Number(bill.remainingLoanAmount) + 0.001) {
      throw new Error("Withdrawal exceeds the remaining loan balance. Split or correct the withdrawal before reconciling; no money was allocated.");
    }
    if (bill.type === "Loan" && !(Number(bill.remainingLoanAmount) > 0)) {
      throw new Error("Loan has no remaining balance.");
    }
    const payment = recordBillPayment(bill, session, amount);
    payment.method = "Bank Transfer";
    payment.bankTransactionId = transaction.id;
    writeBills(bills);
    return { type, targetId: bill.id, recordId: payment.id, amount: payment.amount };
  }
  if (type === "expense") {
    if (transaction.amount <= 0) throw new Error("Only withdrawals can be recorded as expenses.");
    const finance = readFinance();
    const groupId = String(payload.groupId || "");
    if (!finance.groups.some((group) => group.id === groupId)) {
      throw new Error("Select an allocation group.");
    }
    const expense = {
      id: randomBytes(12).toString("hex"),
      groupId,
      description: String(payload.description || transaction.name).trim().slice(0, 140),
      employee: "",
      amount,
      date: transaction.date,
      method: "Bank Transaction",
      bankTransactionId: transaction.id,
      note: "Reconciled from bank feed.",
      createdAt: new Date().toISOString(),
      createdBy: session.username
    };
    finance.expenses.push(expense);
    writeFinance(finance);
    return { type, targetId: expense.id, recordId: expense.id, amount };
  }
  throw new Error("Choose an invoice, bill, or expense.");
}

function undoBankReconciliation(reconciliation) {
  if (reconciliation.type === "invoice") {
    const finance = readFinance();
    finance.payments = finance.payments.filter((record) => record.id !== reconciliation.recordId);
    writeFinance(finance);
    const invoices = readInvoices();
    const invoice = invoices.find((record) => record.id === reconciliation.targetId);
    if (invoice) {
      invoice.status = invoicePaymentStatus(invoice, finance.payments);
      writeInvoices(invoices);
    }
  } else if (reconciliation.type === "bill") {
    const bills = readBills();
    const bill = bills.find((record) => record.id === reconciliation.targetId);
    if (bill) {
      const payment = (bill.payments || []).find((record) => record.id === reconciliation.recordId);
      bill.payments = (bill.payments || []).filter((record) => record.id !== reconciliation.recordId);
      restoreLoanPrincipal(bill, payment);
      bill.status = bill.type === "Loan" && Number(bill.remainingLoanAmount) <= 0
        ? "Paid Off" : "Unpaid";
      writeBills(bills);
    }
  } else if (reconciliation.type === "expense") {
    const finance = readFinance();
    finance.expenses = finance.expenses.filter((record) => record.id !== reconciliation.recordId);
    writeFinance(finance);
  }
}

function handleProfitLoss(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "profit-loss")) {
    sendJson(response, 403, { ok: false, message: "Finance access required." });
    return;
  }
  if (request.method !== "GET") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const url = new URL(request.url, `http://${request.headers.host}`);
  const today = businessToday();
  const from = validDateOnly(url.searchParams.get("from")) || `${today.slice(0, 4)}-01-01`;
  const to = validDateOnly(url.searchParams.get("to")) || today;
  const finance = readFinance();
  const incomeRecords = finance.payments.filter((record) => record.date >= from && record.date <= to);
  const expenseRecords = finance.expenses.filter((record) => record.date >= from && record.date <= to);
  const billPayments = readBills().flatMap((bill) => bill.payments || [])
    .filter((record) => record.paidAt.slice(0, 10) >= from && record.paidAt.slice(0, 10) <= to);
  const laborRecords = [];
  for (const record of readTimeRecords()) {
    if (!record.clockOut || record.clockOut.slice(0, 10) < from || record.clockOut.slice(0, 10) > to) continue;
    const hours = Math.max(0, (new Date(record.clockOut) - new Date(record.clockIn)) / 3600000);
    const rate = Number.isFinite(Number(record.laborRate))
      ? Number(record.laborRate) : employeeLaborRate(record.employeeName);
    laborRecords.push({
      date: record.clockOut.slice(0, 10),
      employeeName: record.employeeName,
      amount: roundMoney(hours * rate)
    });
  }
  const sum = (records) => roundMoney(records.reduce(
    (total, record) => total + Number(record.amount || 0), 0
  ));
  const revenue = sum(incomeRecords);
  const expenses = sum(expenseRecords);
  const bills = sum(billPayments);
  const labor = sum(laborRecords);
  const months = new Map();
  const addMonth = (date, key, amount) => {
    const month = date.slice(0, 7);
    const row = months.get(month) || { month, revenue: 0, expenses: 0, labor: 0, bills: 0 };
    row[key] += Number(amount || 0);
    months.set(month, row);
  };
  incomeRecords.forEach((record) => addMonth(record.date, "revenue", record.amount));
  expenseRecords.forEach((record) => addMonth(record.date, "expenses", record.amount));
  laborRecords.forEach((record) => addMonth(record.date, "labor", record.amount));
  billPayments.forEach((record) => addMonth(record.paidAt.slice(0, 10), "bills", record.amount));
  const monthly = [...months.values()].sort((a, b) => a.month.localeCompare(b.month)).map((row) => ({
    ...row,
    revenue: roundMoney(row.revenue),
    expenses: roundMoney(row.expenses),
    labor: roundMoney(row.labor),
    bills: roundMoney(row.bills),
    net: roundMoney(row.revenue - row.expenses - row.labor - row.bills)
  }));
  sendJson(response, 200, {
    ok: true,
    from,
    to,
    summary: {
      revenue,
      expenses,
      labor,
      bills,
      net: roundMoney(revenue - expenses - labor - bills)
    },
    monthly,
    incomeRecords,
    expenseRecords,
    laborRecords,
    billPayments
  });
}

async function handleReceipts(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "finance") && !hasPermission(session, "taxes")) {
    sendJson(response, 403, { ok: false, message: "Finance or Tax Center access required." });
    return;
  }
  const url = new URL(request.url, `http://${request.headers.host}`);
  const receipts = readReceipts();
  const taxOnly = !hasPermission(session, "finance") && hasPermission(session, "taxes");
  if (request.method === "GET" && url.pathname === "/api/receipts") {
    const entityType = String(url.searchParams.get("entityType") || "");
    const entityId = String(url.searchParams.get("entityId") || "");
    if (taxOnly && entityType !== "tax-filing") {
      sendJson(response, 403, { ok: false, message: "Tax Center access only permits tax filing documents." });
      return;
    }
    sendJson(response, 200, {
      ok: true,
      receipts: receipts.filter((record) =>
        (!entityType || record.entityType === entityType) &&
        (!entityId || record.entityId === entityId)
      )
    });
    return;
  }
  if (request.method === "GET" && url.pathname === "/api/receipts/open") {
    const receipt = receipts.find((record) => record.id === url.searchParams.get("id"));
    if (taxOnly && receipt?.entityType !== "tax-filing") {
      sendJson(response, 403, { ok: false, message: "Tax Center access only permits tax filing documents." });
      return;
    }
    const filePath = receipt && resolve(receiptFilesPath, receipt.storedName);
    if (!receipt || !filePath.startsWith(`${receiptFilesPath}${sep}`) || !existsSync(filePath)) {
      sendJson(response, 404, { ok: false, message: "Receipt not found." });
      return;
    }
    response.writeHead(200, {
      "Content-Type": receipt.contentType,
      "Content-Length": statSync(filePath).size,
      "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(receipt.name)}`,
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "private, no-store"
    });
    createReadStream(filePath).pipe(response);
    return;
  }
  if (request.method === "POST" && url.pathname === "/api/receipts/upload") {
    const entityType = String(url.searchParams.get("entityType") || "");
    const entityId = String(url.searchParams.get("entityId") || "");
    const name = validDocumentName(decodeURIComponent(request.headers["x-file-name"] || ""));
    const extension = extname(name).toLowerCase();
    const types = {
      ".pdf": "application/pdf",
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".webp": "image/webp"
    };
    if ((taxOnly && entityType !== "tax-filing") ||
        !["expense", "invoice-payment", "bill-payment", "tax-filing"].includes(entityType) ||
        !entityId || !name || !types[extension]) {
      sendJson(response, 400, { ok: false, message: "Choose a PDF, PNG, JPG, or WebP receipt." });
      return;
    }
    const id = randomBytes(12).toString("hex");
    const storedName = `${id}${extension}`;
    const file = await readBinaryBody(request, 10 * 1024 * 1024);
    writeFileSync(join(receiptFilesPath, storedName), file, { mode: 0o600, flag: "wx" });
    const receipt = {
      id,
      entityType,
      entityId,
      name,
      storedName,
      contentType: types[extension],
      size: file.length,
      uploadedAt: new Date().toISOString(),
      uploadedBy: session.username
    };
    receipts.push(receipt);
    writeReceipts(receipts);
    logActivity(session, "receipt.uploaded", `Uploaded receipt ${name}.`);
    sendJson(response, 200, { ok: true, receipt });
    return;
  }
  if (request.method === "DELETE" && url.pathname === "/api/receipts") {
    const payload = await readJsonBody(request);
    const receipt = receipts.find((record) => record.id === payload.id);
    if (taxOnly && receipt?.entityType !== "tax-filing") {
      sendJson(response, 403, { ok: false, message: "Tax Center access only permits tax filing documents." });
      return;
    }
    if (receipt) {
      const filePath = resolve(receiptFilesPath, receipt.storedName);
      if (filePath.startsWith(`${receiptFilesPath}${sep}`)) rmSync(filePath, { force: true });
      writeReceipts(receipts.filter((record) => record.id !== receipt.id));
      logActivity(session, "receipt.deleted", `Deleted receipt ${receipt.name}.`);
    }
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readReceipts() {
  if (!existsSync(receiptsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(receiptsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeReceipts(receipts) {
  writeFileSync(receiptsPath, JSON.stringify(receipts, null, 2), { mode: 0o600 });
}

async function handleCustomerPortalAdmin(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "customer-portal")) {
    sendJson(response, 403, { ok: false, message: "Customer access management requires Service Tickets access." });
    return;
  }
  const access = readPortalAccess();
  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      customers: readCustomers().map((customer) => ({
        id: customer.id,
        name: customer.name,
        company: customer.company,
        email: customer.email,
        enabled: access.some((record) => record.customerId === customer.id && record.enabled),
        updatedAt: access.find((record) => record.customerId === customer.id)?.updatedAt || ""
      }))
    });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const payload = await readJsonBody(request);
  const customer = readCustomers().find((record) => record.id === payload.customerId);
  if (!customer) {
    sendJson(response, 404, { ok: false, message: "Customer not found." });
    return;
  }
  const currentIndex = access.findIndex((record) => record.customerId === customer.id);
  if (payload.action === "generate") {
    const code = Array.from({ length: 3 }, () => randomBytes(2).toString("hex").toUpperCase()).join("-");
    const salt = randomBytes(16).toString("hex");
    const record = {
      customerId: customer.id,
      salt,
      hash: hashPassword(code, salt),
      enabled: true,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    if (currentIndex >= 0) access[currentIndex] = record;
    else access.push(record);
    writePortalAccess(access);
    invalidateCustomerSessions(customer.id);
    logActivity(session, "portal.access-generated", `Generated portal access for ${customer.name}.`);
    sendJson(response, 200, {
      ok: true,
      code,
      customerId: customer.id,
      portalUrl: "/customer-portal.html"
    });
    return;
  }
  if (payload.action === "revoke") {
    if (currentIndex >= 0) access[currentIndex].enabled = false;
    writePortalAccess(access);
    invalidateCustomerSessions(customer.id);
    logActivity(session, "portal.access-revoked", `Revoked portal access for ${customer.name}.`);
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 400, { ok: false, message: "Unknown portal access action." });
}

async function handleCustomerPortal(request, response) {
  if (request.url === "/api/customer-portal-login") {
    if (request.method !== "POST") {
      sendJson(response, 405, { ok: false, message: "Method not allowed." });
      return;
    }
    const payload = await readJsonBody(request);
    const submittedCustomerId = String(payload.customerId || "").trim().toLowerCase();
    const record = readPortalAccess().find((item) =>
      String(item.customerId || "").toLowerCase() === submittedCustomerId && item.enabled
    );
    if (!record || !verifyPassword(String(payload.code || "").toUpperCase(), record.salt, record.hash)) {
      sendJson(response, 401, { ok: false, message: "Customer ID or access code is incorrect." });
      return;
    }
    const token = randomBytes(32).toString("hex");
    const sessions = readCustomerSessions().filter((item) => item.expiresAt > Date.now());
    sessions.push({
      tokenHash: createHash("sha256").update(token).digest("hex"),
      customerId: record.customerId,
      expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000
    });
    writeCustomerSessions(sessions);
    response.writeHead(200, {
      "Content-Type": "application/json; charset=utf-8",
      "Set-Cookie": [
        `huber_customer_portal=${token}`,
        "HttpOnly",
        "SameSite=Strict",
        "Path=/",
        "Max-Age=604800",
        isSecureRequest(request) ? "Secure" : ""
      ].filter(Boolean).join("; "),
      "Cache-Control": "no-store"
    });
    response.end(JSON.stringify({ ok: true }));
    return;
  }
  if (request.url === "/api/customer-portal-logout") {
    const token = getCookie(request, "huber_customer_portal");
    const tokenHash = createHash("sha256").update(token).digest("hex");
    writeCustomerSessions(readCustomerSessions().filter((item) => item.tokenHash !== tokenHash));
    response.writeHead(200, {
      "Content-Type": "application/json; charset=utf-8",
      "Set-Cookie": "huber_customer_portal=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"
    });
    response.end(JSON.stringify({ ok: true }));
    return;
  }
  const customerId = getCustomerPortalSession(request);
  if (!customerId) {
    sendJson(response, 401, { ok: false, message: "Please sign in to the customer portal." });
    return;
  }
  const customer = readCustomers().find((record) => record.id === customerId);
  if (!customer) {
    sendJson(response, 404, { ok: false, message: "Customer not found." });
    return;
  }
  if (request.url === "/api/customer-portal-checkout") {
    if (request.method !== "POST") {
      sendJson(response, 405, { ok: false, message: "Method not allowed." });
      return;
    }
    const payload = await readJsonBody(request);
    if (payload.action === "confirm") {
      try {
        const result = await confirmZohoPortalPayment(customer, payload);
        sendJson(response, 200, { ok: true, ...result });
      } catch (error) {
        sendJson(response, 400, { ok: false, message: error.message });
      }
      return;
    }
    if (payload.contractTicketId) {
      const finance = readFinance();
      const contract = contractPaymentSummaries(finance, customer.id)
        .find((record) => record.id === payload.contractTicketId);
      if (!contract || !(contract.balance > 0)) {
        sendJson(response, 404, { ok: false, message: "Open contract balance not found." });
        return;
      }
      try {
        const checkout = await createContractZohoPaymentSession(
          customer, contract, Number(payload.amount)
        );
        sendJson(response, 200, { ok: true, provider: "zoho", checkout });
      } catch (error) {
        sendJson(response, 502, { ok: false, message: error.message });
      }
      return;
    }
    const invoice = readInvoices().find((record) => record.id === payload.invoiceId);
    const ownedTickets = readTickets().filter((ticket) =>
      !ticket.isOffice && ticket.customerId === customer.id
    );
    const invoiceTicket = invoice && ownedTickets.find((ticket) => ticket.id === invoice.ticketId);
    if (!invoice || ["Draft", "Void"].includes(invoice.status) ||
        (invoiceTicket?.ticketType || "Service") === "Contract" ||
        !invoiceTicket) {
      sendJson(response, 404, { ok: false, message: "Invoice not found." });
      return;
    }
    try {
      const checkout = await createInvoiceZohoPaymentSession(customer, invoice);
      sendJson(response, 200, { ok: true, provider: "zoho", checkout });
    } catch (error) {
      sendJson(response, 502, { ok: false, message: error.message });
    }
    return;
  }
  const tickets = readTickets().filter((ticket) =>
    !ticket.isOffice && ticket.customerId === customer.id
  );
  const ticketIds = new Set(tickets.map((ticket) => ticket.id));
  const contractTicketIds = new Set(tickets
    .filter((ticket) => (ticket.ticketType || "Service") === "Contract")
    .map((ticket) => ticket.id));
  const finance = readFinance();
  const ticketMap = new Map(tickets.map((ticket) => [ticket.id, ticket]));
  const serviceInvoices = readInvoices().filter((invoice) =>
    !["Draft", "Void"].includes(invoice.status) &&
    !contractTicketIds.has(invoice.ticketId) &&
    ticketIds.has(invoice.ticketId)
  ).map((invoice) => {
    const payments = finance.payments.filter((payment) => payment.invoiceId === invoice.id);
    const paid = invoicePaidAmount(invoice, payments);
    const ticket = ticketMap.get(invoice.ticketId);
    return {
      id: invoice.id,
      recordType: "invoice",
      type: "Service",
      number: invoice.number,
      reference: `INV-${String(invoice.number).padStart(4, "0")}`,
      description: ticket?.description || ticket?.issue || ticket?.serviceType || "Service invoice",
      issueDate: invoice.issueDate,
      dueDate: invoice.dueDate,
      status: invoice.status,
      total: invoice.total,
      paid: roundMoney(paid),
      balance: roundMoney(Math.max(0, Number(invoice.total || 0) - paid)),
      payments: payments.map((payment) => ({
        date: payment.date,
        amount: payment.amount,
        method: payment.method || "Other",
        reference: payment.reference || ""
      }))
    };
  });
  const contractInvoices = contractPaymentSummaries(finance, customer.id).map((contract) => ({
    id: contract.id,
    recordType: "contract",
    type: "Contract",
    number: contract.number,
    reference: `C-${String(contract.number).padStart(4, "0")}`,
    description: contract.description,
    issueDate: contract.issueDate,
    dueDate: contract.dueDate,
    status: contract.status,
    total: contract.total,
    paid: contract.paid,
    balance: contract.balance,
    payments: contract.payments.map((payment) => ({
      date: payment.date,
      amount: payment.amount,
      method: payment.method || "Other",
      reference: payment.reference || ""
    }))
  }));
  const invoices = [...serviceInvoices, ...contractInvoices].sort((left, right) =>
    String(right.issueDate || "").localeCompare(String(left.issueDate || "")) ||
    Number(right.number || 0) - Number(left.number || 0)
  );
  sendJson(response, 200, {
    ok: true,
    customer: {
      name: customer.name,
      company: customer.company,
      email: customer.email,
      phone: customer.phone,
      address: customer.address
    },
    invoices,
    paymentsConfigured: zohoPaymentsConfigured()
  });
}

function readEstimates() {
  if (!existsSync(estimatesPath)) return [];
  try {
    const records = JSON.parse(readFileSync(estimatesPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeEstimates(records) {
  writeFileSync(estimatesPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function migrateEstimateStatuses() {
  const estimates = readEstimates();
  let changed = false;
  for (const estimate of estimates) {
    if (estimate.status === "Approved") {
      estimate.status = "Accepted";
      changed = true;
    } else if (estimate.status === "Converted") {
      estimate.status = "In Progress";
      changed = true;
    }
  }
  if (changed) writeEstimates(estimates);
}

async function handleEstimateTemplates(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "estimates")) {
    sendJson(response, 403, { ok: false, message: "Estimates access required." });
    return;
  }
  const templates = readEstimateTemplates();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, templates });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const type = String(payload.type || "");
    const name = String(payload.name || "").trim().slice(0, 80);
    const content = String(payload.content || "").trim().slice(0, 5000);
    if (!["notes", "terms"].includes(type) || !name || !content) {
      sendJson(response, 400, { ok: false, message: "Template name and text are required." });
      return;
    }
    const duplicate = templates.find((template) =>
      template.type === type && template.name.toLowerCase() === name.toLowerCase()
    );
    if (duplicate) {
      duplicate.content = content;
      duplicate.updatedAt = new Date().toISOString();
      duplicate.updatedBy = session.username;
    } else {
      templates.push({
        id: randomBytes(8).toString("hex"),
        type,
        name,
        content,
        updatedAt: new Date().toISOString(),
        updatedBy: session.username
      });
    }
    writeEstimateTemplates(templates);
    logActivity(session, "estimate-template.saved", `Saved ${type} template ${name}.`);
    sendJson(response, 200, { ok: true, templates });
    return;
  }
  if (request.method === "DELETE") {
    const removed = templates.find((template) => template.id === payload.id);
    if (!removed) {
      sendJson(response, 404, { ok: false, message: "Template not found." });
      return;
    }
    const remaining = templates.filter((template) => template.id !== removed.id);
    writeEstimateTemplates(remaining);
    logActivity(session, "estimate-template.deleted", `Deleted ${removed.type} template ${removed.name}.`);
    sendJson(response, 200, { ok: true, templates: remaining });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readEstimateTemplates() {
  if (!existsSync(estimateTemplatesPath)) return [];
  try {
    const templates = JSON.parse(readFileSync(estimateTemplatesPath, "utf8"));
    return Array.isArray(templates) ? templates : [];
  } catch {
    return [];
  }
}

function writeEstimateTemplates(templates) {
  writeFileSync(estimateTemplatesPath, JSON.stringify(templates, null, 2), { mode: 0o600 });
}

async function handleEstimateLineItems(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "estimates")) {
    sendJson(response, 403, { ok: false, message: "Estimates access required." });
    return;
  }
  const items = readEstimateLineItems();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, items });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const name = String(payload.name || "").trim().slice(0, 120);
    const rate = roundMoney(Math.max(0, Number(payload.rate ?? payload.price) || 0));
    if (!name) {
      sendJson(response, 400, { ok: false, message: "Item name is required." });
      return;
    }
    const existing = items.find((item) => item.name.toLowerCase() === name.toLowerCase());
    if (existing) {
      existing.name = name;
      existing.rate = rate;
      existing.updatedAt = new Date().toISOString();
      existing.updatedBy = session.username;
    } else {
      items.push({
        id: randomBytes(8).toString("hex"),
        name,
        rate,
        updatedAt: new Date().toISOString(),
        updatedBy: session.username
      });
    }
    writeEstimateLineItems(items);
    logActivity(session, "estimate-line-item.saved", `Saved quote item ${name}.`);
    sendJson(response, 200, { ok: true, items });
    return;
  }
  if (request.method === "DELETE") {
    const removed = items.find((item) => item.id === payload.id);
    if (!removed) {
      sendJson(response, 404, { ok: false, message: "Saved item not found." });
      return;
    }
    const remaining = items.filter((item) => item.id !== removed.id);
    writeEstimateLineItems(remaining);
    logActivity(session, "estimate-line-item.deleted", `Deleted quote item ${removed.name}.`);
    sendJson(response, 200, { ok: true, items: remaining });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readEstimateLineItems() {
  if (!existsSync(estimateLineItemsPath)) return [];
  try {
    const items = JSON.parse(readFileSync(estimateLineItemsPath, "utf8"));
    return Array.isArray(items) ? items : [];
  } catch {
    return [];
  }
}

function writeEstimateLineItems(items) {
  writeFileSync(estimateLineItemsPath, JSON.stringify(items, null, 2), { mode: 0o600 });
}

async function handleEstimateMaterialRules(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "estimates")) {
    sendJson(response, 403, { ok: false, message: "Estimates access required." });
    return;
  }
  const rules = readEstimateMaterialRules();
  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      rules,
      categories: estimateRuleCategories(),
      catalogItems: readCatalog().filter((item) => item.active)
    });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const name = String(payload.name || "").trim().slice(0, 80);
    const matchType = String(payload.matchType || "");
    const target = String(payload.target || "").trim();
    const amount = roundMoney(Math.max(0, Number(payload.amount) || 0));
    const validTarget = matchType === "category"
      ? estimateRuleCategories().some((category) => category.name === target)
      : matchType === "item"
        ? readCatalog().some((item) => item.id === target)
        : false;
    if (!name || !validTarget || amount <= 0) {
      sendJson(response, 400, { ok: false, message: "Complete the material rule with a valid target and amount." });
      return;
    }
    const rule = {
      id: String(payload.id || randomBytes(8).toString("hex")),
      name,
      matchType,
      target,
      mode: "per-item",
      amount,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    const index = rules.findIndex((record) => record.id === rule.id);
    if (index >= 0) rules[index] = rule;
    else rules.push(rule);
    writeEstimateMaterialRules(rules);
    logActivity(session, "estimate-material-rule.saved", `Saved material rule ${name}.`);
    sendJson(response, 200, { ok: true, rule, rules });
    return;
  }
  if (request.method === "DELETE") {
    const removed = rules.find((rule) => rule.id === payload.id);
    if (!removed) {
      sendJson(response, 404, { ok: false, message: "Material rule not found." });
      return;
    }
    const remaining = rules.filter((rule) => rule.id !== removed.id);
    writeEstimateMaterialRules(remaining);
    logActivity(session, "estimate-material-rule.deleted", `Deleted material rule ${removed.name}.`);
    sendJson(response, 200, { ok: true, rules: remaining });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readEstimateMaterialRules() {
  if (!existsSync(estimateMaterialRulesPath)) return [];
  try {
    const rules = JSON.parse(readFileSync(estimateMaterialRulesPath, "utf8"));
    return Array.isArray(rules) ? rules : [];
  } catch {
    return [];
  }
}

function writeEstimateMaterialRules(rules) {
  writeFileSync(estimateMaterialRulesPath, JSON.stringify(rules, null, 2), { mode: 0o600 });
}

function estimateRuleCategories() {
  const categories = readItemCategories().map((category) => ({ ...category }));
  const names = new Set(categories.map((category) => category.name.toLowerCase()));
  for (const item of readCatalog()) {
    const name = String(item.category || "").trim();
    if (!name || names.has(name.toLowerCase())) continue;
    names.add(name.toLowerCase());
    categories.push({ id: `catalog-${createHash("sha256").update(name).digest("hex").slice(0, 12)}`, name });
  }
  return categories.sort((a, b) => a.name.localeCompare(b.name));
}

function calculateEstimateMaterialRules(materialItems) {
  const applied = [];
  let total = 0;
  for (const rule of readEstimateMaterialRules()) {
    const matches = materialItems.filter((item) =>
      rule.matchType === "category"
        ? item.category === rule.target
        : item.catalogItemId === rule.target
    );
    if (!matches.length) continue;
    const quantity = matches.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
    const amount = roundMoney(rule.amount * quantity);
    total += amount;
    applied.push({
      id: rule.id,
      name: rule.name,
      mode: "per-item",
      quantity,
      amount
    });
  }
  return { total: roundMoney(total), applied };
}

async function handleEstimates(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "estimates")) {
    sendJson(response, 403, { ok: false, message: "Invoicing access required." });
    return;
  }
  const estimates = readEstimates();
  const url = new URL(request.url, publicOrigin(request));
  if (request.method === "GET" && url.pathname === "/api/estimates/pdf") {
    const estimate = estimates.find((record) => record.id === url.searchParams.get("id"));
    if (!estimate) {
      sendJson(response, 404, { ok: false, message: "Estimate not found." });
      return;
    }
    sendEstimatePdf(response, estimate);
    logActivity(session, "estimate.pdf", `Generated PDF for estimate Q-${String(estimate.number).padStart(4, "0")}.`);
    return;
  }
  if (request.method === "GET") {
    const includeCatalog = url.searchParams.get("includeCatalog") !== "0";
    sendJson(response, 200, {
      ok: true,
      estimates,
      customers: readCustomers(),
      ...(includeCatalog ? { catalogItems: readCatalog().filter((item) => item.active) } : {})
    });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST" && payload.action === "create-contract-ticket") {
    const estimate = estimates.find((record) => record.id === payload.id);
    if (!estimate || !["Accepted", "Approved"].includes(estimate.status)) {
      sendJson(response, 400, {
        ok: false,
        message: "Only accepted estimates can become contract tickets."
      });
      return;
    }
    if (estimate.ticketId) {
      const existingTicket = readTickets().find((record) => record.id === estimate.ticketId);
      sendJson(response, existingTicket ? 200 : 409, {
        ok: Boolean(existingTicket),
        message: existingTicket ? "This estimate already has a ticket." : "The linked ticket could not be found.",
        estimate,
        ticket: existingTicket || null
      });
      return;
    }
    const customer = readCustomers().find((record) => record.id === estimate.customerId);
    const tickets = readTickets();
    const now = new Date().toISOString();
    const ticket = {
      id: randomBytes(12).toString("hex"),
      number: tickets.reduce((max, item) => Math.max(max, Number(item.number) || 0), 0) + 1,
      ticketType: "Contract",
      customerId: customer?.id || estimate.customerId || "",
      customer: customer?.name || estimate.customer || "",
      company: customer?.company || "",
      email: customer?.email || "",
      phone: customer?.phone || "",
      address: customer?.primaryAddress || customer?.address || "",
      serviceType: estimate.title || "Contract Project",
      description: estimate.title || "Contract Project",
      status: "Open",
      priority: "Normal",
      assignedTo: "",
      scheduledDate: "",
      scheduledTime: "",
      hoursUsed: 0,
      legacyHours: 0,
      workLogs: [],
      usedItems: [],
      attachments: [],
      internalMessages: [],
      workNotes: "",
      resolution: "",
      sourceEstimateId: estimate.id,
      createdAt: now,
      createdBy: session.username,
      updatedAt: now,
      updatedBy: session.username
    };
    tickets.push(ticket);
    writeTickets(tickets);
    estimate.ticketId = ticket.id;
    estimate.contractTicketId = ticket.id;
    estimate.ticketCreatedAt = now;
    estimate.updatedAt = now;
    estimate.updatedBy = session.username;
    writeEstimates(estimates);
    const jobExpenses = readJobExpenses();
    let movedExpenses = false;
    for (const expense of jobExpenses) {
      if (expense.jobId !== `estimate:${estimate.id}`) continue;
      expense.jobId = ticket.id;
      movedExpenses = true;
    }
    if (movedExpenses) writeJobExpenses(jobExpenses);
    logActivity(session, "estimate.contract-ticket-created",
      `Created contract ticket ${ticketLabel(ticket)} from estimate Q-${String(estimate.number).padStart(4, "0")}.`);
    broadcastAllServiceEvent("tickets-updated", { ticketId: ticket.id });
    broadcastAllServiceEvent("job-workspace-updated", { ticketId: ticket.id });
    broadcastAllServiceEvent("dashboard-updated", { area: "tickets" });
    sendJson(response, 200, { ok: true, estimate, ticket });
    return;
  }
  if (request.method === "POST" && payload.action === "convert") {
    const estimate = estimates.find((record) => record.id === payload.id);
    if (!estimate || estimate.status !== "Accepted" || estimate.ticketId) {
      sendJson(response, 400, { ok: false, message: "Only accepted estimates that have not already been converted can be converted." });
      return;
    }
    const customer = readCustomers().find((record) => record.id === estimate.customerId);
    const tickets = readTickets();
    const ticket = {
      id: randomBytes(12).toString("hex"),
      number: tickets.reduce((max, item) => Math.max(max, Number(item.number) || 0), 0) + 1,
      ticketType: estimate.jobType === "Contract" ? "Contract" : "Service",
      customerId: customer?.id || "",
      customer: customer?.name || estimate.customer,
      company: customer?.company || "",
      email: customer?.email || "",
      phone: customer?.phone || "",
      address: customer?.address || "",
      description: estimate.title,
      status: "Open",
      priority: "Normal",
      assignedTo: "",
      scheduledDate: "",
      scheduledTime: "",
      workNotes: "",
      createdAt: new Date().toISOString(),
      createdBy: session.username
    };
    tickets.push(ticket);
    writeTickets(tickets);
    const invoices = readInvoices();
    const invoice = {
      id: randomBytes(12).toString("hex"),
      number: invoices.reduce((max, item) => Math.max(max, Number(item.number) || 0), 0) + 1,
      ticketId: ticket.id,
      ticketNumber: ticket.number,
      customer: ticket.customer,
      company: ticket.company,
      email: ticket.email,
      phone: ticket.phone,
      address: ticket.address,
      laborHours: 0,
      laborRate: 0,
      laborTotal: 0,
      materials: (estimate.materialItems || []).map((item) => ({
        name: `${item.name}${item.variationName ? ` - ${item.variationName}` : ""}`,
        sku: item.sku,
        quantity: item.quantity,
        unitCost: item.unitCost,
        total: item.total
      })),
      materialTotal: Number(estimate.catalogMaterialTotal || 0),
      customCharges: [
        ...(estimate.lines || []),
        ...(Number(estimate.automaticMaterialCost || 0) > 0 ? [{
          name: "Automatic material add-ons",
          quantity: 1,
          rate: Number(estimate.automaticMaterialCost),
          total: Number(estimate.automaticMaterialCost)
        }] : []),
        ...(Number(estimate.additionalCharges ?? estimate.manualAdditionalMaterialCost ?? 0) > 0 ? [{
          name: "Additional Charges",
          quantity: 1,
          rate: Number(estimate.additionalCharges ?? estimate.manualAdditionalMaterialCost),
          total: Number(estimate.additionalCharges ?? estimate.manualAdditionalMaterialCost)
        }] : [])
      ],
      customChargeTotal: roundMoney(
        (estimate.lines || []).reduce((sum, line) => sum + Number(line.total || 0), 0) +
        Number(estimate.automaticMaterialCost || 0) +
        Number(estimate.additionalCharges ?? estimate.manualAdditionalMaterialCost ?? 0)
      ),
      additionalCharges: Number(estimate.additionalCharges ?? estimate.manualAdditionalMaterialCost ?? 0),
      taxRate: estimate.taxRate,
      tax: estimate.tax,
      subtotal: estimate.subtotal,
      total: estimate.total,
      status: "Draft",
      issueDate: businessToday(),
      dueDate: "",
      notes: `Converted from estimate Q-${String(estimate.number).padStart(4, "0")}.`,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    invoices.push(invoice);
    writeInvoices(invoices);
    estimate.status = "In Progress";
    estimate.ticketId = ticket.id;
    estimate.invoiceId = invoice.id;
    estimate.convertedAt = new Date().toISOString();
    writeEstimates(estimates);
    const jobExpenses = readJobExpenses();
    let movedExpenses = false;
    for (const expense of jobExpenses) {
      if (expense.jobId !== `estimate:${estimate.id}`) continue;
      expense.jobId = ticket.id;
      movedExpenses = true;
    }
    if (movedExpenses) writeJobExpenses(jobExpenses);
    logActivity(session, "estimate.converted", `Converted estimate Q-${String(estimate.number).padStart(4, "0")} to a ticket and draft invoice.`);
    sendJson(response, 200, { ok: true, estimate, ticket, invoice });
    return;
  }
  if (request.method === "POST") {
    const customer = readCustomers().find((record) => record.id === payload.customerId);
    const existing = estimates.find((record) => record.id === payload.id);
    const catalog = readCatalog();
    const materialItems = [];
    for (const selected of (Array.isArray(payload.materialItems) ? payload.materialItems : []).slice(0, 100)) {
      const savedItem = (existing?.materialItems || []).find((item) =>
        item.catalogItemId === selected.catalogItemId &&
        String(item.variationId || "") === String(selected.variationId || "")
      );
      const catalogItem = catalog.find((item) =>
        item.id === selected.catalogItemId && (item.active || savedItem)
      );
      const variation = selected.variationId
        ? (catalogItem?.variations || []).find((item) => item.id === selected.variationId)
        : null;
      const quantity = Math.max(0, Number(selected.quantity) || 0);
      if ((!catalogItem && !savedItem) || !quantity ||
          (selected.variationId && !variation && !savedItem)) continue;
      const unitCost = savedItem && !variation
        ? Number(savedItem.unitCost || 0)
        : roundMoney(Number(catalogItem.unitCost || 0) + Number(variation?.priceAdjustment || 0));
      materialItems.push({
        id: randomBytes(8).toString("hex"),
        catalogItemId: catalogItem?.id || savedItem.catalogItemId,
        variationId: variation?.id || savedItem?.variationId || "",
        name: catalogItem?.name || savedItem.name,
        sku: catalogItem?.sku || savedItem.sku,
        category: catalogItem?.category || savedItem.category || "",
        variationName: variation?.name || savedItem?.variationName || "Standard",
        quantity,
        unitCost,
        total: roundMoney(quantity * unitCost)
      });
    }
    const materialRuleResult = calculateEstimateMaterialRules(materialItems);
    const automaticMaterialCost = materialRuleResult.total;
    const manualAdditionalMaterialCost = roundMoney(
      Math.max(0, Number(payload.additionalMaterialCost) || 0)
    );
    const additionalMaterialCost = automaticMaterialCost;
    const catalogMaterialTotal = roundMoney(
      materialItems.reduce((sum, item) => sum + item.total, 0)
    );
    const materialTotal = roundMoney(catalogMaterialTotal + automaticMaterialCost);
    const lines = (Array.isArray(payload.lines) ? payload.lines : []).slice(0, 100).map((line) => {
      const quantity = Math.max(0, Number(line.quantity) || 0);
      const rate = Math.max(0, Number(line.rate ?? line.price) || 0);
      return {
        name: String(line.name || "").trim().slice(0, 120),
        quantity,
        rate: roundMoney(rate),
        total: roundMoney(quantity * rate)
      };
    }).filter((line) => line.name && line.quantity > 0);
    if (!customer || !String(payload.title || "").trim() || (!lines.length && materialTotal <= 0)) {
      sendJson(response, 400, {
        ok: false,
        message: "Customer, title, and at least one line item are required."
      });
      return;
    }
    const lineTotal = roundMoney(lines.reduce((sum, line) => sum + line.total, 0));
    const subtotal = roundMoney(lineTotal + materialTotal + manualAdditionalMaterialCost);
    const taxRate = Math.max(0, Number(payload.taxRate) || 0);
    const estimate = {
      id: existing?.id || randomBytes(12).toString("hex"),
      number: existing?.number || estimates.reduce((max, item) => Math.max(max, Number(item.number) || 0), 0) + 1,
      customerId: customer.id,
      customer: customer.name,
      title: String(payload.title).trim().slice(0, 160),
      jobType: ["Service", "Contract"].includes(payload.jobType)
        ? payload.jobType
        : existing?.jobType === "Contract" ? "Contract" : "Service",
      lines,
      materialItems,
      catalogMaterialTotal,
      additionalMaterialCost,
      automaticMaterialCost,
      manualAdditionalMaterialCost,
      additionalCharges: manualAdditionalMaterialCost,
      appliedMaterialRules: materialRuleResult.applied,
      materialTotal,
      subtotal,
      taxRate,
      tax: roundMoney(subtotal * taxRate / 100),
      total: roundMoney(subtotal + subtotal * taxRate / 100),
      status: ["Draft", "Sent", "Accepted", "In Progress", "Done", "Paid"].includes(payload.status)
        ? payload.status : existing?.status || "Draft",
      validUntil: validDateOnly(payload.validUntil) || "",
      notes: String(payload.notes || "").trim().slice(0, 5000),
      terms: String(payload.terms || "").trim().slice(0, 5000),
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    if (estimate.status === "Paid" && existing?.status !== "Done" && existing?.status !== "Paid") {
      sendJson(response, 400, {
        ok: false,
        message: "Mark the estimate Done before marking it Paid."
      });
      return;
    }
    const index = estimates.findIndex((record) => record.id === estimate.id);
    if (index >= 0) estimates[index] = { ...existing, ...estimate };
    else estimates.push(estimate);
    writeEstimates(estimates);
    logActivity(session, index >= 0 ? "estimate.updated" : "estimate.created", `${index >= 0 ? "Updated" : "Created"} estimate Q-${String(estimate.number).padStart(4, "0")}.`, {
      undo: { collection: "estimates", recordId: estimate.id, before: existing ? structuredClone(existing) : null, after: structuredClone(index >= 0 ? estimates[index] : estimate) }
    });
    sendJson(response, 200, { ok: true, estimate });
    return;
  }
  if (request.method === "DELETE") {
    const estimate = estimates.find((record) => record.id === payload.id);
    if (!estimate || estimate.status !== "Draft") {
      sendJson(response, 400, { ok: false, message: "Only draft estimates can be deleted." });
      return;
    }
    writeEstimates(estimates.filter((record) => record.id !== estimate.id));
    logActivity(session, "estimate.deleted", `Deleted draft estimate Q-${String(estimate.number).padStart(4, "0")}.`, {
      undo: { collection: "estimates", recordId: estimate.id, before: structuredClone(estimate), after: null }
    });
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function sendEstimatePdf(response, estimate) {
  const number = `Q-${String(estimate.number).padStart(4, "0")}`;
  response.writeHead(200, {
    "Content-Type": "application/pdf",
    "Content-Disposition": `attachment; filename="${number}-${safeFilenamePart(estimate.customer || "customer")}.pdf"`,
    "Cache-Control": "private, no-store"
  });
  const doc = new PDFDocument({
    size: "LETTER",
    margin: 48,
    info: { Title: `${number} - ${estimate.title}` }
  });
  doc.pipe(response);
  const logoPath = join(root, "assets", "logo.png");
  if (existsSync(logoPath)) doc.image(logoPath, 48, 38, { width: 66 });
  doc.font("Helvetica-Bold").fontSize(19).fillColor("#182026")
    .text("Huber I.T. Professionals", 128, 48);
  doc.font("Helvetica").fontSize(10).fillColor("#66727b")
    .text("Professional Technology Services", 128, 74);
  doc.font("Helvetica-Bold").fontSize(24).fillColor("#087f8c")
    .text("QUOTE", 420, 45, { width: 125, align: "right" });
  doc.font("Helvetica").fontSize(10).fillColor("#303b40")
    .text(number, 420, 76, { width: 125, align: "right" });
  doc.moveTo(48, 116).lineTo(564, 116).strokeColor("#087f8c").lineWidth(2).stroke();

  doc.font("Helvetica-Bold").fontSize(10).fillColor("#182026").text("PREPARED FOR", 48, 140);
  doc.font("Helvetica").fontSize(11).text(estimate.customer || "Customer", 48, 158);
  const customer = readCustomers().find((record) => record.id === estimate.customerId);
  const customerDetails = [
    customer?.company,
    customer?.address,
    customer?.email,
    customer?.phone
  ].filter(Boolean);
  if (customerDetails.length) {
    doc.fontSize(9.5).fillColor("#526068").text(customerDetails.join("\n"), 48, 176, { width: 260 });
  }
  doc.font("Helvetica-Bold").fontSize(10).fillColor("#182026").text("QUOTE DETAILS", 360, 140);
  doc.font("Helvetica").fontSize(9.5).fillColor("#303b40")
    .text(`Created: ${estimate.updatedAt?.slice(0, 10) || businessToday()}`, 360, 158)
    .text(`Valid until: ${estimate.validUntil || "No expiration"}`, 360, 174)
    .text(`Status: ${estimate.status}`, 360, 190);

  const tableTop = Math.max(doc.y + 28, 240);
  const columns = { description: 48, quantity: 340, rate: 405, total: 490 };
  doc.rect(48, tableTop, 516, 26).fill("#243137");
  doc.font("Helvetica-Bold").fontSize(9).fillColor("#ffffff")
    .text("DESCRIPTION", columns.description + 8, tableTop + 9, { width: 270 })
    .text("QTY", columns.quantity, tableTop + 9, { width: 50, align: "right" })
    .text("PRICE", columns.rate, tableTop + 9, { width: 66, align: "right" })
    .text("TOTAL", columns.total, tableTop + 9, { width: 66, align: "right" });
  let y = tableTop + 26;
  let rowIndex = 0;
  const customerLines = [
    ...(estimate.lines || []),
    ...(Number(estimate.materialTotal || 0) > 0 ? [{
      name: "Materials",
      quantity: 1,
      rate: Number(estimate.materialTotal),
      total: Number(estimate.materialTotal)
    }] : []),
    ...(Number(estimate.additionalCharges || 0) > 0 ? [{
      name: "Additional Charges",
      quantity: 1,
      rate: Number(estimate.additionalCharges),
      total: Number(estimate.additionalCharges)
    }] : [])
  ];
  for (const line of customerLines) {
    const descriptionHeight = doc.heightOfString(String(line.name || ""), { width: 270 });
    const rowHeight = Math.max(28, descriptionHeight + 14);
    if (y + rowHeight > 680) {
      doc.addPage();
      y = 55;
    }
    doc.rect(48, y, 516, rowHeight).fill(rowIndex % 2 === 0 ? "#f4f7f8" : "#ffffff");
    doc.font("Helvetica").fontSize(9.5).fillColor("#263239")
      .text(String(line.name || ""), columns.description + 8, y + 8, { width: 270 })
      .text(String(line.quantity), columns.quantity, y + 8, { width: 50, align: "right" })
      .text(formatUsd(line.rate), columns.rate, y + 8, { width: 66, align: "right" })
      .text(formatUsd(line.total), columns.total, y + 8, { width: 66, align: "right" });
    y += rowHeight;
    rowIndex += 1;
  }
  y += 14;
  const totalsX = 370;
  doc.font("Helvetica").fontSize(10).fillColor("#303b40")
    .text("Subtotal", totalsX, y, { width: 90 })
    .text(formatUsd(estimate.subtotal), 470, y, { width: 94, align: "right" });
  y += 20;
  doc.text(`Tax (${Number(estimate.taxRate || 0)}%)`, totalsX, y, { width: 90 })
    .text(formatUsd(estimate.tax), 470, y, { width: 94, align: "right" });
  y += 24;
  doc.moveTo(totalsX, y).lineTo(564, y).strokeColor("#182026").lineWidth(1).stroke();
  y += 9;
  doc.font("Helvetica-Bold").fontSize(13).fillColor("#182026")
    .text("TOTAL", totalsX, y, { width: 90 })
    .text(formatUsd(estimate.total), 470, y, { width: 94, align: "right" });
  if (estimate.notes) {
    y += 45;
    if (y > 690) {
      doc.addPage();
      y = 55;
    }
    doc.font("Helvetica-Bold").fontSize(10).fillColor("#182026").text("NOTES", 48, y);
    doc.font("Helvetica").fontSize(9.5).fillColor("#526068")
      .text(estimate.notes, 48, y + 16, { width: 516, lineGap: 2 });
  }
  if (estimate.terms) {
    y = Math.max(doc.y + 24, y + (estimate.notes ? 55 : 45));
    if (y > 675) {
      doc.addPage();
      y = 55;
    }
    doc.font("Helvetica-Bold").fontSize(10).fillColor("#182026")
      .text("TERMS AND CONDITIONS", 48, y);
    doc.font("Helvetica").fontSize(9).fillColor("#526068")
      .text(estimate.terms, 48, y + 16, { width: 516, lineGap: 2 });
  }
  doc.font("Helvetica").fontSize(8.5).fillColor("#66727b")
    .text("Thank you for the opportunity to provide this quote.", 48, 735, {
      width: 516,
      align: "center"
    });
  doc.end();
}

function formatUsd(value) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" })
    .format(Number(value) || 0);
}

function safeFilenamePart(value) {
  return String(value || "").replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "quote";
}

function zohoPaymentCredential(name) {
  return String(process.env[name] || "").trim().replace(/^["']|["']$/g, "");
}

function zohoPaymentsConfigured() {
  return [
    "ZOHO_PAYMENTS_ACCOUNT_ID",
    "ZOHO_PAYMENTS_API_KEY",
    "ZOHO_PAYMENTS_CLIENT_ID",
    "ZOHO_PAYMENTS_CLIENT_SECRET",
    "ZOHO_PAYMENTS_REFRESH_TOKEN",
    "ZOHO_PAYMENTS_WEBHOOK_SIGNING_KEY"
  ].every((name) => Boolean(zohoPaymentCredential(name)));
}

let zohoAccessTokenCache = { token: "", expiresAt: 0 };

async function zohoPaymentsAccessToken() {
  if (zohoAccessTokenCache.token && zohoAccessTokenCache.expiresAt > Date.now() + 300_000) {
    return zohoAccessTokenCache.token;
  }
  if (!zohoPaymentsConfigured()) throw new Error("Zoho Payments is not configured.");
  const accountsUrl = zohoPaymentCredential("ZOHO_PAYMENTS_ACCOUNTS_URL") ||
    "https://accounts.zoho.com";
  const body = new URLSearchParams({
    refresh_token: zohoPaymentCredential("ZOHO_PAYMENTS_REFRESH_TOKEN"),
    client_id: zohoPaymentCredential("ZOHO_PAYMENTS_CLIENT_ID"),
    client_secret: zohoPaymentCredential("ZOHO_PAYMENTS_CLIENT_SECRET"),
    grant_type: "refresh_token"
  });
  const result = await fetch(`${accountsUrl}/oauth/v2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body
  });
  const data = await result.json().catch(() => ({}));
  if (!result.ok || !data.access_token) {
    throw new Error(data.error || "Zoho Payments OAuth token request failed.");
  }
  const expiresIn = Number(data.expires_in_sec || data.expires_in || 3600);
  zohoAccessTokenCache = {
    token: data.access_token,
    expiresAt: Date.now() + Math.max(300, expiresIn) * 1000
  };
  return data.access_token;
}

async function zohoPaymentsRequest(path, { method = "GET", body } = {}) {
  const accountId = zohoPaymentCredential("ZOHO_PAYMENTS_ACCOUNT_ID");
  const apiBase = zohoPaymentCredential("ZOHO_PAYMENTS_API_BASE") ||
    "https://payments.zoho.com/api/v1";
  const separator = path.includes("?") ? "&" : "?";
  const result = await fetch(`${apiBase}${path}${separator}account_id=${encodeURIComponent(accountId)}`, {
    method,
    headers: {
      "Authorization": `Zoho-oauthtoken ${await zohoPaymentsAccessToken()}`,
      ...(body ? { "Content-Type": "application/json" } : {})
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await result.json().catch(() => ({}));
  if (!result.ok || (data.code !== undefined && Number(data.code) !== 0)) {
    const message = data.message || data.error?.message || data.error || "Zoho Payments request failed.";
    throw new Error(String(message));
  }
  return data;
}

function readZohoPaymentSessions() {
  return readJsonArray(zohoPaymentSessionsPath);
}

function writeZohoPaymentSessions(records) {
  const cutoff = Date.now() - 90 * 24 * 60 * 60 * 1000;
  const retained = records.filter((record) =>
    !record.createdAt || Date.parse(record.createdAt) >= cutoff
  ).slice(-10_000);
  writeFileSync(zohoPaymentSessionsPath, JSON.stringify(retained, null, 2), { mode: 0o600 });
}

async function createZohoPaymentSession({
  customer, paymentType, recordId, amount, description, invoiceNumber
}) {
  if (!zohoPaymentsConfigured()) throw new Error("Zoho Payments is not configured.");
  const roundedAmount = roundMoney(amount);
  if (!(roundedAmount > 0)) throw new Error("The payment amount must be greater than zero.");
  const response = await zohoPaymentsRequest("/paymentsessions", {
    method: "POST",
    body: {
      amount: roundedAmount,
      currency: "USD",
      expires_in: 900,
      description,
      invoice_number: invoiceNumber,
      reference_number: invoiceNumber,
      meta_data: [
        { key: "pay_type", value: paymentType },
        { key: "record_id", value: recordId },
        { key: "customer_id", value: customer.id }
      ],
      configurations: { allowed_payment_methods: ["ach_debit", "card"] },
      max_retry_count: 3
    }
  });
  const session = response.payments_session || response.payment_session;
  const sessionId = session?.payments_session_id || session?.payment_session_id;
  if (!sessionId) throw new Error("Zoho Payments did not return a payment session.");
  const records = readZohoPaymentSessions();
  records.push({
    id: sessionId,
    customerId: customer.id,
    paymentType,
    recordId,
    amount: roundedAmount,
    currency: "USD",
    description,
    invoiceNumber,
    status: "created",
    createdAt: new Date().toISOString(),
    expiresAt: session.expires_at || ""
  });
  writeZohoPaymentSessions(records);
  return {
    accountId: zohoPaymentCredential("ZOHO_PAYMENTS_ACCOUNT_ID"),
    apiKey: zohoPaymentCredential("ZOHO_PAYMENTS_API_KEY"),
    domain: (zohoPaymentCredential("ZOHO_PAYMENTS_DOMAIN") || "US").toUpperCase(),
    paymentSessionId: sessionId,
    amount: roundedAmount.toFixed(2),
    currencyCode: "USD",
    currencySymbol: "$",
    business: "Huber I.T. Professionals",
    description,
    invoiceNumber,
    address: {
      name: customer.name || customer.company || "",
      email: customer.email || "",
      phone: customer.phone || ""
    }
  };
}

async function createInvoiceZohoPaymentSession(customer, invoice) {
  const finance = readFinance();
  const paid = invoicePaidAmount(invoice, finance.payments);
  const balance = roundMoney(Math.max(0, Number(invoice.total || 0) - paid));
  if (!(balance > 0)) throw new Error("This invoice has already been paid.");
  const invoiceNumber = `INV-${String(invoice.number).padStart(4, "0")}`;
  return createZohoPaymentSession({
    customer,
    paymentType: "invoice",
    recordId: invoice.id,
    amount: balance,
    description: `Payment for ${invoiceNumber}`,
    invoiceNumber
  });
}

async function createContractZohoPaymentSession(customer, contract, requestedAmount) {
  const amount = roundMoney(requestedAmount);
  if (!(amount > 0) || amount > contract.balance + 0.001) {
    throw new Error(`Enter an amount up to the ${formatUsd(contract.balance)} remaining contract balance.`);
  }
  const invoiceNumber = `C-${String(contract.number).padStart(4, "0")}`;
  return createZohoPaymentSession({
    customer,
    paymentType: "contract",
    recordId: contract.id,
    amount,
    description: `Payment for contract ${invoiceNumber}`,
    invoiceNumber
  });
}

function zohoPaymentSessionId(payment) {
  return String(payment?.payments_session_id || payment?.payment_session_id || "");
}

function zohoPaymentMethod(payment) {
  const type = String(payment?.payment_method?.type || payment?.payment_method_type || "").toLowerCase();
  return type === "ach_debit" || type === "ach" ? "ACH" : "Credit Card";
}

function findZohoPaymentMapping(payment, mappings) {
  const sessionId = zohoPaymentSessionId(payment);
  if (sessionId) return mappings.find((item) => item.id === sessionId);
  const metadata = Object.fromEntries((payment?.meta_data || []).map((item) =>
    [String(item.key || ""), String(item.value || "")]
  ));
  return [...mappings].reverse().find((item) =>
    item.paymentType === metadata.pay_type &&
    item.recordId === metadata.record_id &&
    item.customerId === metadata.customer_id &&
    Math.abs(Number(item.amount) - Number(payment.amount || payment.amount_captured)) < 0.001 &&
    !item.recordedPaymentId
  );
}

async function retrieveZohoPayment(paymentId) {
  const response = await zohoPaymentsRequest(`/payments/${encodeURIComponent(paymentId)}`);
  const payment = response.payment || response.payments?.[0];
  if (!payment?.payment_id) throw new Error("Zoho Payments could not verify this payment.");
  return payment;
}

function recordZohoPayment(payment, mapping) {
  return structuredStore.withTransaction(() => recordZohoPaymentParsed(payment, mapping));
}

function recordZohoPaymentParsed(payment, mapping) {
  if (String(payment.status || "").toLowerCase() !== "succeeded") {
    return { recorded: false, pending: String(payment.status || "").toLowerCase() === "pending" };
  }
  const paymentId = String(payment.payment_id);
  const paymentAmount = roundMoney(payment.amount_captured || payment.amount);
  if (Math.abs(paymentAmount - Number(mapping.amount)) > 0.001 ||
      String(payment.currency || "USD").toUpperCase() !== "USD") {
    throw new Error("Zoho payment details do not match the requested balance.");
  }
  const finance = readFinance();
  const existing = finance.payments.find((record) => record.zohoPaymentId === paymentId);
  let invoice;
  let ticket;
  if (mapping.paymentType === "invoice") {
    invoice = readInvoices().find((item) => item.id === mapping.recordId);
    if (!invoice) throw new Error("The invoice linked to this payment no longer exists.");
  } else {
    ticket = readTickets().find((item) =>
      item.id === mapping.recordId && (item.ticketType || "Service") === "Contract"
    );
    if (!ticket) throw new Error("The contract linked to this payment no longer exists.");
  }
  const reference = payment.transaction_reference_number || payment.reference_number || paymentId;
  const record = existing || {
    id: randomBytes(12).toString("hex"),
    invoiceId: mapping.paymentType === "invoice" ? mapping.recordId : "",
    contractTicketId: mapping.paymentType === "contract" ? mapping.recordId : "",
    description: mapping.description,
    amount: paymentAmount,
    date: businessToday(),
    method: zohoPaymentMethod(payment),
    reference,
    zohoPaymentId: paymentId,
    zohoPaymentSessionId: mapping.id,
    note: "Recorded by Zoho Payments.",
    createdAt: new Date().toISOString(),
    createdBy: "Zoho Payments"
  };
  if (!existing) {
    finance.payments.push(record);
    writeFinance(finance);
  }
  if (mapping.paymentType === "invoice") {
    const invoices = readInvoices();
    const savedInvoice = invoices.find((item) => item.id === mapping.recordId);
    savedInvoice.status = invoicePaymentStatus(savedInvoice, finance.payments);
    writeInvoices(invoices);
    logSystemActivity("invoice.zoho-paid",
      `Zoho Payments recorded payment for INV-${String(savedInvoice.number).padStart(4, "0")}.`,
      "Zoho Payments");
    broadcastAllServiceEvent("job-workspace-updated", { ticketId: savedInvoice.ticketId });
  } else {
    logSystemActivity("contract.zoho-paid",
      `Zoho Payments recorded a payment for ${ticketLabel(ticket)}.`, "Zoho Payments");
    broadcastAllServiceEvent("job-workspace-updated", { ticketId: ticket.id });
  }
  const mappings = readZohoPaymentSessions();
  const savedMapping = mappings.find((item) => item.id === mapping.id);
  if (savedMapping) {
    savedMapping.status = "succeeded";
    savedMapping.recordedPaymentId = record.id;
    savedMapping.zohoPaymentId = paymentId;
    savedMapping.updatedAt = new Date().toISOString();
    writeZohoPaymentSessions(mappings);
  }
  broadcastAllServiceEvent("dashboard-updated", { area: "finance" });
  broadcastAllServiceEvent("dashboard-updated", { area: "invoices" });
  return { recorded: !existing, paymentId: record.id };
}

async function confirmZohoPortalPayment(customer, payload) {
  const paymentId = String(payload.paymentId || "");
  const sessionId = String(payload.paymentSessionId || "");
  if (!paymentId || !sessionId) throw new Error("Zoho payment confirmation is incomplete.");
  const mapping = readZohoPaymentSessions().find((item) =>
    item.id === sessionId && item.customerId === customer.id
  );
  if (!mapping) throw new Error("This payment session is not valid for your account.");
  const payment = await retrieveZohoPayment(paymentId);
  if (zohoPaymentSessionId(payment) !== sessionId) {
    throw new Error("Zoho returned a payment for a different session.");
  }
  const status = String(payment.status || "").toLowerCase();
  if (status === "succeeded") {
    recordZohoPayment(payment, mapping);
    return { status: "succeeded", message: "Payment received. Thank you." };
  }
  if (status === "pending" || status === "initiated" || status === "processing") {
    return {
      status: "pending",
      message: "Payment submitted. Your balance will update after Zoho confirms it."
    };
  }
  throw new Error("Zoho did not confirm the payment. Please try again.");
}

async function handleZohoPaymentsWebhook(request, response) {
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const signingKey = zohoPaymentCredential("ZOHO_PAYMENTS_WEBHOOK_SIGNING_KEY");
  const raw = await readTextBody(request, 2_000_000);
  if (!signingKey ||
      !verifyZohoWebhookSignature(raw, request.headers["x-zoho-webhook-signature"], signingKey)) {
    sendJson(response, 400, { ok: false, message: "Invalid Zoho Payments signature." });
    return;
  }
  let event;
  try {
    event = JSON.parse(raw);
  } catch {
    sendJson(response, 400, { ok: false, message: "Invalid webhook payload." });
    return;
  }
  if (String(event.account_id || "") !== zohoPaymentCredential("ZOHO_PAYMENTS_ACCOUNT_ID")) {
    sendJson(response, 400, { ok: false, message: "Webhook account does not match." });
    return;
  }
  const processed = readJsonArray(zohoPaymentEventsPath);
  if (processed.includes(event.event_id)) {
    sendJson(response, 200, { ok: true });
    return;
  }
  try {
    const payment = event.event_object?.payment;
    const paymentId = payment?.payment_id;
    if (paymentId && ["payment.succeeded", "payment.pending", "payment.failed"].includes(event.event_type)) {
      const mappings = readZohoPaymentSessions();
      const mapping = findZohoPaymentMapping(payment, mappings);
      if (mapping && event.event_type === "payment.succeeded") {
        recordZohoPayment(payment, mapping);
      } else if (mapping) {
        mapping.status = event.event_type.replace("payment.", "");
        mapping.zohoPaymentId = paymentId;
        mapping.updatedAt = new Date().toISOString();
        writeZohoPaymentSessions(mappings);
      }
    }
    processed.push(event.event_id);
    writeFileSync(zohoPaymentEventsPath, JSON.stringify(processed.slice(-10_000), null, 2), {
      mode: 0o600
    });
    sendJson(response, 200, { received: true });
  } catch (error) {
    console.error("Zoho Payments webhook processing failed:", error);
    sendJson(response, 500, { ok: false, message: "Webhook processing failed." });
  }
}

function verifyZohoWebhookSignature(payload, header, signingKey) {
  const parts = Object.fromEntries(String(header || "").split(",").map((part) => {
    const index = part.indexOf("=");
    return index === -1 ? ["", ""] : [part.slice(0, index).trim(), part.slice(index + 1).trim()];
  }));
  const timestamp = parts.t;
  const signature = parts.v;
  const numericTimestamp = Number(timestamp);
  const timestampMs = numericTimestamp > 10_000_000_000
    ? numericTimestamp
    : numericTimestamp * 1000;
  if (!timestamp || !signature || !Number.isFinite(timestampMs) ||
      Math.abs(Date.now() - timestampMs) > 300_000) return false;
  const expected = createHmac("sha256", signingKey).update(`${timestamp}.${payload}`).digest("hex");
  const left = Buffer.from(signature, "hex");
  const right = Buffer.from(expected, "hex");
  return left.length === right.length && timingSafeEqual(left, right);
}

function readPortalAccess() {
  if (!existsSync(portalAccessPath)) return [];
  try {
    const records = JSON.parse(readFileSync(portalAccessPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writePortalAccess(records) {
  writeFileSync(portalAccessPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function readCustomerSessions() {
  if (!existsSync(customerSessionsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(customerSessionsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeCustomerSessions(records) {
  writeFileSync(customerSessionsPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function getCustomerPortalSession(request) {
  const token = getCookie(request, "huber_customer_portal");
  if (!token) return "";
  const tokenHash = createHash("sha256").update(token).digest("hex");
  return readCustomerSessions().find((record) =>
    record.tokenHash === tokenHash && record.expiresAt > Date.now()
  )?.customerId || "";
}

function invalidateCustomerSessions(customerId) {
  writeCustomerSessions(readCustomerSessions().filter((record) => record.customerId !== customerId));
}

async function handleCatalog(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }

  const items = readCatalog();
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, items });
    return;
  }

  if (!hasPermission(session, "catalog")) {
    sendJson(response, 403, { ok: false, message: "Catalog access required." });
    return;
  }

  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const item = payload.item;
    if (!item?.name || !item?.sku) {
      sendJson(response, 400, { ok: false, message: "Item name and SKU are required." });
      return;
    }
    const duplicate = items.find((record) =>
      record.sku.toLowerCase() === String(item.sku).trim().toLowerCase() &&
      record.id !== item.id
    );
    if (duplicate) {
      sendJson(response, 409, { ok: false, message: "That SKU is already in use." });
      return;
    }
    const unitCost = roundMoney(Math.max(0, Number(item.unitCost) || 0));
    const variationNames = new Set();
    const variations = [];
    for (const variation of (Array.isArray(item.variations) ? item.variations : []).slice(0, 50)) {
      const name = String(variation.name || "").trim().slice(0, 100);
      const priceAdjustment = roundMoney(Number(variation.priceAdjustment) || 0);
      const normalizedName = name.toLowerCase();
      if (!name || variationNames.has(normalizedName) || unitCost + priceAdjustment < 0) {
        sendJson(response, 400, {
          ok: false,
          message: "Each variation needs a unique name and a final price of zero or more."
        });
        return;
      }
      variationNames.add(normalizedName);
      variations.push({
        id: String(variation.id || randomBytes(8).toString("hex")),
        name,
        priceAdjustment
      });
    }
    const record = {
      id: item.id || randomBytes(12).toString("hex"),
      name: String(item.name).trim(),
      sku: String(item.sku).trim(),
      category: String(item.category || "").trim(),
      unitCost,
      variations,
      description: String(item.description || "").trim(),
      active: item.active !== false,
      updatedAt: new Date().toISOString()
    };
    const index = items.findIndex((existing) => existing.id === record.id);
    if (index >= 0) items[index] = record;
    else items.push(record);
    writeCatalog(items);
    sendJson(response, 200, { ok: true, item: record });
    return;
  }

  if (request.method === "DELETE") {
    writeCatalog(items.filter((item) => item.id !== payload.id));
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

async function handleCatalogLinkPreview(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  if (!hasPermission(session, "catalog")) {
    sendJson(response, 403, { ok: false, message: "Catalog access required." });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }

  const payload = await readJsonBody(request);
  const sourceUrl = String(payload.url || "").trim();
  let url;
  try {
    url = new URL(sourceUrl);
  } catch {
    sendJson(response, 400, { ok: false, message: "Enter a valid product or catalog URL." });
    return;
  }
  if (!["http:", "https:"].includes(url.protocol)) {
    sendJson(response, 400, { ok: false, message: "Only http and https links can be imported." });
    return;
  }

  try {
    const upstream = await fetch(url, {
      redirect: "follow",
      headers: {
        "User-Agent": "HuberCatalogImporter/1.0 (+https://www.huberitps.com)",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
      },
      signal: AbortSignal.timeout(15000)
    });
    if (!upstream.ok) {
      sendJson(response, 502, { ok: false, message: `The page returned ${upstream.status}.` });
      return;
    }
    const contentType = upstream.headers.get("content-type") || "";
    if (!contentType.includes("text/html") && !contentType.includes("application/xhtml")) {
      sendJson(response, 400, { ok: false, message: "That link did not return an HTML product page." });
      return;
    }
    const html = (await upstream.text()).slice(0, 3_000_000);
    const items = extractCatalogItemsFromHtml(html, upstream.url || url.href)
      .slice(0, 100);
    sendJson(response, 200, {
      ok: true,
      sourceUrl: upstream.url || url.href,
      items,
      message: items.length
        ? `Found ${items.length} possible catalog item${items.length === 1 ? "" : "s"}.`
        : "No products were detected. Try a direct product page or a page with product listing data."
    });
  } catch (error) {
    sendJson(response, 502, {
      ok: false,
      message: error.name === "TimeoutError"
        ? "The page took too long to load."
        : error.message || "Unable to read that link."
    });
  }
}

function extractCatalogItemsFromHtml(html, sourceUrl) {
  const items = [];
  const seen = new Set();
  for (const product of extractJsonLdProducts(html)) {
    const item = normalizeImportedProduct(product, sourceUrl);
    addImportedItem(items, seen, item);
  }
  for (const product of extractMetaProduct(html, sourceUrl)) {
    addImportedItem(items, seen, product);
  }
  if (!items.length) {
    for (const product of extractVisibleProductLines(html, sourceUrl)) {
      addImportedItem(items, seen, product);
    }
  }
  return items;
}

function addImportedItem(items, seen, item) {
  if (!item?.name) return;
  const sku = item.sku || catalogSkuFromName(item.name);
  const key = `${sku}|${item.name}`.toLowerCase();
  if (seen.has(key)) return;
  seen.add(key);
  items.push({
    name: String(item.name || "").trim().slice(0, 160),
    sku: String(sku).trim().slice(0, 80),
    category: String(item.category || "").trim().slice(0, 80),
    unitCost: roundMoney(Math.max(0, Number(item.unitCost) || 0)),
    description: String(item.description || "").replace(/\s+/g, " ").trim().slice(0, 600),
    sourceUrl: item.sourceUrl || ""
  });
}

function extractJsonLdProducts(html) {
  const products = [];
  for (const match of html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
    const text = decodeHtmlEntities(stripHtml(match[1])).trim();
    if (!text) continue;
    try {
      collectJsonLdProducts(JSON.parse(text), products);
    } catch {}
  }
  return products;
}

function collectJsonLdProducts(value, products) {
  if (!value) return;
  if (Array.isArray(value)) {
    value.forEach((item) => collectJsonLdProducts(item, products));
    return;
  }
  if (typeof value !== "object") return;
  if (Array.isArray(value["@graph"])) collectJsonLdProducts(value["@graph"], products);
  if (Array.isArray(value.itemListElement)) collectJsonLdProducts(value.itemListElement, products);
  if (value.item) collectJsonLdProducts(value.item, products);
  const type = Array.isArray(value["@type"]) ? value["@type"].join(" ") : String(value["@type"] || "");
  if (/product/i.test(type) || (value.name && (value.sku || value.mpn || value.offers))) {
    products.push(value);
  }
}

function normalizeImportedProduct(product, sourceUrl) {
  const offer = Array.isArray(product.offers) ? product.offers[0] : product.offers || {};
  const brand = typeof product.brand === "object" ? product.brand?.name : product.brand;
  const category = Array.isArray(product.category) ? product.category[0] : product.category;
  return {
    name: product.name || product.headline || "",
    sku: product.sku || product.mpn || product.model || "",
    category: category || brand || "",
    unitCost: offer.price || product.price || 0,
    description: product.description || "",
    sourceUrl
  };
}

function extractMetaProduct(html, sourceUrl) {
  const title = firstMetaContent(html, "og:title") || firstTagText(html, "title");
  if (!title) return [];
  const description = firstMetaContent(html, "og:description") ||
    firstMetaContent(html, "description") || "";
  const price = firstMetaContent(html, "product:price:amount") ||
    firstMetaContent(html, "og:price:amount") || "";
  const sku = firstMetaContent(html, "product:retailer_item_id") ||
    firstMetaContent(html, "sku") || "";
  return [{
    name: cleanProductTitle(title),
    sku,
    category: "",
    unitCost: price,
    description,
    sourceUrl
  }];
}

function extractVisibleProductLines(html, sourceUrl) {
  const text = decodeHtmlEntities(stripHtml(html))
    .split(/\r?\n/)
    .map((line) => line.replace(/\s+/g, " ").trim())
    .filter((line) => line.length >= 6 && line.length <= 220);
  const results = [];
  for (const line of text) {
    if (/^(home|privacy|terms|cart|login|search|menu|copyright)\b/i.test(line)) continue;
    const priceMatch = line.match(/\$?\b(\d{1,6}(?:,\d{3})*(?:\.\d{2})?)\b(?!.*\b\d{1,6}(?:,\d{3})*(?:\.\d{2})?\b)/);
    const modelMatch = line.match(/\b[A-Z]{1,8}[-_./]?[A-Z0-9]{2,}(?:[-_./][A-Z0-9]{2,})*\b/i);
    if (!priceMatch && !modelMatch) continue;
    const name = cleanProductTitle(line
      .replace(priceMatch?.[0] || "", "")
      .replace(modelMatch?.[0] || "", "")
      .trim());
    if (!name || name.length < 3) continue;
    results.push({
      name,
      sku: modelMatch?.[0] || "",
      category: "",
      unitCost: priceMatch?.[1] || 0,
      description: line,
      sourceUrl
    });
    if (results.length >= 30) break;
  }
  return results;
}

function firstMetaContent(html, property) {
  const escaped = property.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const patterns = [
    new RegExp(`<meta[^>]+property=["']${escaped}["'][^>]+content=["']([^"']*)["'][^>]*>`, "i"),
    new RegExp(`<meta[^>]+name=["']${escaped}["'][^>]+content=["']([^"']*)["'][^>]*>`, "i"),
    new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]+property=["']${escaped}["'][^>]*>`, "i"),
    new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]+name=["']${escaped}["'][^>]*>`, "i")
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match?.[1]) return decodeHtmlEntities(match[1]).trim();
  }
  return "";
}

function firstTagText(html, tag) {
  const match = html.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"));
  return match?.[1] ? decodeHtmlEntities(stripHtml(match[1])).trim() : "";
}

function stripHtml(value) {
  return String(value || "")
    .replace(/<script[\s\S]*?<\/script>/gi, "\n")
    .replace(/<style[\s\S]*?<\/style>/gi, "\n")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|li|tr|h[1-6])>/gi, "\n")
    .replace(/<[^>]+>/g, " ");
}

function decodeHtmlEntities(value) {
  return String(value || "")
    .replace(/&quot;/g, '"')
    .replace(/&#34;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ");
}

function cleanProductTitle(value) {
  return String(value || "")
    .replace(/\s+[|].*$/g, "")
    .replace(/\s+-\s+.*(?:store|shop|catalog|official).*$/i, "")
    .replace(/\s+/g, " ")
    .trim();
}

function catalogSkuFromName(name) {
  return String(name || "ITEM")
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 32) || `ITEM-${Date.now()}`;
}

async function handleTicketItems(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }

  const payload = await readJsonBody(request);
  const completed = completedMutation(session, payload.clientMutationId);
  if (completed) {
    sendJson(response, 200, completed);
    return;
  }
  const tickets = readTickets();
  const ticket = tickets.find((record) => record.id === payload.ticketId);
  if (!ticket) {
    sendJson(response, 404, { ok: false, message: "Ticket not found." });
    return;
  }
  if ((ticket.ticketType || "Service") !== "Service") {
    sendJson(response, 400, { ok: false, message: "Items can only be added to service tickets." });
    return;
  }
  if (!hasPermission(session, "service-tickets") && !ticketMatchesEmployee(ticket, session)) {
    sendJson(response, 403, { ok: false, message: "This ticket is not assigned to you." });
    return;
  }

  const catalogItem = readCatalog().find((item) => item.id === payload.catalogItemId && item.active);
  const quantity = Number(payload.quantity);
  const variation = payload.variationId
    ? (catalogItem?.variations || []).find((item) => item.id === payload.variationId)
    : null;
  if (!catalogItem || !Number.isFinite(quantity) || quantity <= 0 ||
      (payload.variationId && !variation)) {
    sendJson(response, 400, { ok: false, message: "Select an active item and valid quantity." });
    return;
  }
  const unitCost = roundMoney(
    Number(catalogItem.unitCost || 0) + Number(variation?.priceAdjustment || 0)
  );
  const usage = {
    id: randomBytes(12).toString("hex"),
    catalogItemId: catalogItem.id,
    name: catalogItem.name,
    sku: catalogItem.sku,
    variationId: variation?.id || "",
    variationName: variation?.name || "Standard",
    priceAdjustment: Number(variation?.priceAdjustment || 0),
    quantity,
    unitCost,
    employeeName: session.employeeName || session.username,
    username: session.username,
    loggedAt: new Date().toISOString()
  };
  ticket.usedItems = Array.isArray(ticket.usedItems) ? ticket.usedItems : [];
  ticket.usedItems.push(usage);
  writeTickets(tickets);
  broadcastAllServiceEvent("tickets-updated", { ticketId: ticket.id });
  const result = { ok: true, usage };
  rememberMutation(session, payload.clientMutationId, result);
  sendJson(response, 200, result);
}

async function handleTicketAttachments(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }

  const url = new URL(request.url, `http://${request.headers.host}`);
  const ticketId = url.searchParams.get("ticketId") || "";
  const tickets = readTickets();
  const ticket = tickets.find((record) => record.id === ticketId);
  if (!ticket) {
    sendJson(response, 404, { ok: false, message: "Ticket not found." });
    return;
  }
  if (!hasPermission(session, "service-tickets") && !ticketMatchesEmployee(ticket, session)) {
    sendJson(response, 403, { ok: false, message: "This ticket is not assigned to you." });
    return;
  }

  ticket.attachments = Array.isArray(ticket.attachments) ? ticket.attachments : [];

  if (request.method === "GET" && url.pathname === "/api/ticket-attachments") {
    sendJson(response, 200, { ok: true, attachments: ticket.attachments });
    return;
  }

  if (request.method === "POST" && url.pathname === "/api/ticket-attachments") {
    const name = validDocumentName(decodeURIComponent(request.headers["x-file-name"] || ""));
    if (!name) {
      sendJson(response, 400, { ok: false, message: "Invalid attachment filename." });
      return;
    }
    const file = await readBinaryBody(request, 25 * 1024 * 1024);
    const rawExtension = extname(name).toLowerCase();
    const extension = /^\.[a-z0-9]{1,10}$/.test(rawExtension) ? rawExtension : "";
    const storedName = `${randomBytes(16).toString("hex")}${extension}`;
    const folder = resolve(ticketAttachmentsPath, ticket.id);
    if (!folder.startsWith(`${ticketAttachmentsPath}${sep}`)) {
      sendJson(response, 400, { ok: false, message: "Invalid ticket attachment path." });
      return;
    }
    mkdirSync(folder, { recursive: true, mode: 0o700 });
    writeFileSync(join(folder, storedName), file, { mode: 0o600, flag: "wx" });
    const attachment = {
      id: randomBytes(12).toString("hex"),
      name,
      storedName,
      size: file.length,
      uploadedBy: session.username,
      employeeName: session.employeeName || session.username,
      uploadedAt: new Date().toISOString()
    };
    ticket.attachments.push(attachment);
    writeTickets(tickets);
    logActivity(session, "attachment.uploaded",
      `Uploaded ${attachment.name} to ${ticketLabel(ticket)}.`);
    broadcastAllServiceEvent("tickets-updated", { ticketId: ticket.id });
    sendJson(response, 200, { ok: true, attachment });
    return;
  }

  const attachmentId = url.searchParams.get("id") || "";
  const attachment = ticket.attachments.find((record) => record.id === attachmentId);
  if ((url.pathname === "/api/ticket-attachments/open" ||
       url.pathname === "/api/ticket-attachments/download") &&
      request.method === "GET") {
    const filePath = attachment && resolve(ticketAttachmentsPath, ticket.id, attachment.storedName);
    if (!attachment || !filePath?.startsWith(`${ticketAttachmentsPath}${sep}`) ||
        !existsSync(filePath)) {
      sendJson(response, 404, { ok: false, message: "Attachment not found." });
      return;
    }
    const previewTypes = {
      ".pdf": "application/pdf",
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".webp": "image/webp",
      ".gif": "image/gif",
      ".txt": "text/plain; charset=utf-8",
      ".csv": "text/plain; charset=utf-8"
    };
    const inline = url.pathname.endsWith("/open");
    response.writeHead(200, {
      "Content-Type": inline
        ? previewTypes[extname(attachment.name).toLowerCase()] || "application/octet-stream"
        : "application/octet-stream",
      "Content-Length": statSync(filePath).size,
      "Content-Disposition": `${inline ? "inline" : "attachment"}; filename*=UTF-8''${encodeURIComponent(attachment.name)}`,
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "private, no-store"
    });
    createReadStream(filePath).pipe(response);
    return;
  }

  if (request.method === "DELETE" && url.pathname === "/api/ticket-attachments") {
    if (!attachment) {
      sendJson(response, 404, { ok: false, message: "Attachment not found." });
      return;
    }
    const canDelete = hasPermission(session, "service-tickets") ||
      attachment.uploadedBy === session.username;
    if (!canDelete) {
      sendJson(response, 403, { ok: false, message: "You cannot delete this attachment." });
      return;
    }
    const filePath = resolve(ticketAttachmentsPath, ticket.id, attachment.storedName);
    if (filePath.startsWith(`${ticketAttachmentsPath}${sep}`) && existsSync(filePath)) {
      unlinkSync(filePath);
    }
    ticket.attachments = ticket.attachments.filter((record) => record.id !== attachment.id);
    writeTickets(tickets);
    logActivity(session, "attachment.deleted",
      `Deleted ${attachment.name} from ${ticketLabel(ticket)}.`);
    broadcastAllServiceEvent("tickets-updated", { ticketId: ticket.id });
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readCatalog() {
  if (!existsSync(catalogPath)) return [];
  try {
    return JSON.parse(readFileSync(catalogPath, "utf8")) || [];
  } catch {
    return [];
  }
}

function writeCatalog(items) {
  writeFileSync(catalogPath, JSON.stringify(items, null, 2), { mode: 0o600 });
}

async function handleCustomers(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "customers")) {
    sendJson(response, 403, { ok: false, message: "Service Ticket access required." });
    return;
  }
  let customers = readCustomers();
  if (request.method === "GET") {
    const tickets = readTickets();
    const url = new URL(request.url, publicOrigin(request));
    const includeTickets = url.searchParams.get("includeTickets") !== "0";
    const countsByCustomerId = new Map();
    const countsByCustomerName = new Map();
    for (const ticket of tickets) {
      if (ticket.isOffice) continue;
      if (ticket.customerId) {
        countsByCustomerId.set(ticket.customerId, (countsByCustomerId.get(ticket.customerId) || 0) + 1);
      } else {
        const name = String(ticket.customer || "").toLowerCase();
        if (name) countsByCustomerName.set(name, (countsByCustomerName.get(name) || 0) + 1);
      }
    }
    sendJson(response, 200, {
      ok: true,
      customers: customers.map((customer) => ({
        ...customer,
        ticketCount: (countsByCustomerId.get(customer.id) || 0) +
          (countsByCustomerName.get(String(customer.name || "").toLowerCase()) || 0)
      })),
      ...(includeTickets ? { tickets } : {})
    });
    return;
  }

  const payload = await readJsonBody(request);
  customers = readCustomers();
  if (request.method === "POST") {
    const customer = payload.customer || {};
    const name = String(customer.name || "").trim();
    if (!name) {
      sendJson(response, 400, { ok: false, message: "Customer name is required." });
      return;
    }
    const record = {
      id: customer.id || randomBytes(12).toString("hex"),
      name,
      company: String(customer.company || "").trim(),
      phone: String(customer.phone || "").trim(),
      email: String(customer.email || "").trim(),
      primaryAddress: String(customer.primaryAddress || "").trim(),
      additionalLocations: String(customer.additionalLocations || "").trim(),
      notes: String(customer.notes || "").trim(),
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    const index = customers.findIndex((item) => item.id === record.id);
    const previous = index >= 0 ? structuredClone(customers[index]) : null;
    if (index >= 0) customers[index] = record;
    else customers.push(record);
    writeCustomers(customers);
    logActivity(session, index >= 0 ? "customer.updated" : "customer.created",
      `${index >= 0 ? "Updated" : "Created"} customer ${record.name}.`, {
        undo: { collection: "customers", recordId: record.id, before: previous, after: structuredClone(record) }
      });
    sendJson(response, 200, { ok: true, customer: record });
    return;
  }

  if (request.method === "DELETE") {
    const customer = customers.find((item) => item.id === payload.id);
    if (!customer) {
      sendJson(response, 404, { ok: false, message: "Customer not found." });
      return;
    }
    if (readTickets().some((ticket) => ticket.customerId === customer.id)) {
      sendJson(response, 409, { ok: false, message: "This customer is linked to service tickets and cannot be deleted." });
      return;
    }
    if (readWarranties().some((warranty) => warranty.customerId === customer.id)) {
      sendJson(response, 409, { ok: false, message: "This customer is linked to warranty records and cannot be deleted." });
      return;
    }
    if (readCustomerCommunications().some((record) => record.customerId === customer.id)) {
      sendJson(response, 409, { ok: false, message: "Delete this customer's communication entries before deleting the customer." });
      return;
    }
    writeCustomers(customers.filter((item) => item.id !== customer.id));
    logActivity(session, "customer.deleted", `Deleted customer ${customer.name}.`, {
      undo: { collection: "customers", recordId: customer.id, before: structuredClone(customer), after: null }
    });
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readCustomers() {
  if (!existsSync(customersPath)) return [];
  try {
    const records = JSON.parse(readFileSync(customersPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeCustomers(customers) {
  writeFileSync(customersPath, JSON.stringify(customers, null, 2), { mode: 0o600 });
}

function readCustomerCommunications() {
  if (!existsSync(customerCommunicationsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(customerCommunicationsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeCustomerCommunications(records) {
  writeFileSync(customerCommunicationsPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

async function handleCustomerCommunications(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "customers")) {
    sendJson(response, session ? 403 : 401, {
      ok: false,
      message: session ? "Customer access required." : "Please sign in."
    });
    return;
  }
  const records = readCustomerCommunications();
  const url = new URL(request.url, publicOrigin(request));
  if (request.method === "GET") {
    const customerId = String(url.searchParams.get("customerId") || "");
    if (!readCustomers().some((customer) => customer.id === customerId)) {
      sendJson(response, 404, { ok: false, message: "Customer not found." });
      return;
    }
    sendJson(response, 200, {
      ok: true,
      communications: records
        .filter((record) => record.customerId === customerId)
        .sort((a,b) => String(b.occurredAt).localeCompare(String(a.occurredAt)))
    });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const customer = readCustomers().find((record) => record.id === payload.customerId);
    const type = ["Email", "Phone Call", "Text Message", "Meeting", "Site Visit", "Note"]
      .includes(payload.type) ? payload.type : "Note";
    const direction = ["Inbound", "Outbound", "Internal"].includes(payload.direction)
      ? payload.direction : "Internal";
    const subject = String(payload.subject || "").trim().slice(0, 160);
    const detail = String(payload.detail || "").trim().slice(0, 5000);
    const occurredAtDate = new Date(payload.occurredAt || Date.now());
    if (!customer || !subject || !detail || Number.isNaN(occurredAtDate.getTime())) {
      sendJson(response, 400, {
        ok: false,
        message: "Customer, subject, details, and a valid date are required."
      });
      return;
    }
    const existing = records.find((record) => record.id === payload.id);
    const record = {
      id: existing?.id || randomBytes(12).toString("hex"),
      customerId: customer.id,
      type,
      direction,
      subject,
      detail,
      contact: String(payload.contact || "").trim().slice(0, 160),
      occurredAt: occurredAtDate.toISOString(),
      createdAt: existing?.createdAt || new Date().toISOString(),
      createdBy: existing?.createdBy || session.username,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    const index = records.findIndex((item) => item.id === record.id);
    if (index >= 0) records[index] = record;
    else records.push(record);
    writeCustomerCommunications(records);
    logActivity(session, index >= 0 ? "customer.communication-updated" : "customer.communication-added",
      `${index >= 0 ? "Updated" : "Added"} ${type.toLowerCase()} for ${customer.name}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "customers" });
    sendJson(response, 200, { ok: true, communication: record });
    return;
  }
  if (request.method === "DELETE") {
    const record = records.find((item) => item.id === payload.id);
    if (!record) {
      sendJson(response, 404, { ok: false, message: "Communication entry not found." });
      return;
    }
    writeCustomerCommunications(records.filter((item) => item.id !== record.id));
    logActivity(session, "customer.communication-deleted", "Deleted a customer communication entry.");
    broadcastAllServiceEvent("dashboard-updated", { area: "customers" });
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readWarranties() {
  if (!existsSync(warrantiesPath)) return [];
  try {
    const records = JSON.parse(readFileSync(warrantiesPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeWarranties(records) {
  writeFileSync(warrantiesPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function warrantyStatus(warranty) {
  if (warranty.equipmentStatus === "Removed" || warranty.equipmentStatus === "Replaced") {
    return warranty.equipmentStatus;
  }
  if (!warranty.expiresAt) return "No Warranty";
  const today = businessToday();
  if (warranty.expiresAt < today) return "Expired";
  const warningDate = new Date(`${today}T12:00:00`);
  warningDate.setDate(warningDate.getDate() + 30);
  return warranty.expiresAt <= warningDate.toISOString().slice(0, 10)
    ? "Expiring Soon"
    : "Active";
}

async function handleWarranties(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "warranties")) {
    sendJson(response, 403, { ok: false, message: "Warranty Tracking access required." });
    return;
  }
  const warranties = readWarranties();
  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      warranties: warranties.map((record) => ({ ...record, status: warrantyStatus(record) })),
      customers: readCustomers(),
      catalogItems: readCatalog().filter((item) => item.active),
      tickets: readTickets().filter((ticket) =>
        (ticket.ticketType || "Service") === "Service" && !ticket.isOffice
      )
    });
    return;
  }

  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const customer = readCustomers().find((record) => record.id === payload.customerId);
    const catalogItem = readCatalog().find((record) => record.id === payload.catalogItemId);
    const variation = catalogItem && payload.variationId
      ? (catalogItem.variations || []).find((record) => record.id === payload.variationId)
      : null;
    const existing = warranties.find((record) => record.id === payload.id);
    const productName = String(payload.productName || catalogItem?.name || "").trim().slice(0, 160);
    const serialNumber = String(payload.serialNumber || "").trim().slice(0, 160);
    const installDate = validDateOnly(payload.installDate);
    const expiresAt = validDateOnly(payload.expiresAt);
    if (!customer || !productName || !serialNumber || !installDate) {
      sendJson(response, 400, {
        ok: false,
        message: "Customer, product, serial number, and installation date are required."
      });
      return;
    }
    if (expiresAt && expiresAt < installDate) {
      sendJson(response, 400, { ok: false, message: "Expiration date cannot be before installation date." });
      return;
    }
    if (warranties.some((record) =>
      record.id !== payload.id &&
      record.serialNumber.toLowerCase() === serialNumber.toLowerCase()
    )) {
      sendJson(response, 409, { ok: false, message: "That serial number is already being tracked." });
      return;
    }
    const ticket = readTickets().find((record) =>
      record.id === payload.ticketId &&
      (record.customerId === customer.id ||
        (!record.customerId && String(record.customer).toLowerCase() === customer.name.toLowerCase()))
    );
    const warranty = {
      id: existing?.id || randomBytes(12).toString("hex"),
      customerId: customer.id,
      customerName: customer.name,
      catalogItemId: catalogItem?.id || "",
      variationId: variation?.id || "",
      productName,
      manufacturer: String(payload.manufacturer || "").trim().slice(0, 120),
      model: String(payload.model || "").trim().slice(0, 120),
      equipmentStatus: ["Installed", "In Stock", "Removed", "Replaced"].includes(payload.equipmentStatus)
        ? payload.equipmentStatus : "Installed",
      sku: String(catalogItem?.sku || payload.sku || "").trim().slice(0, 80),
      variationName: String(variation?.name || payload.variationName || "").trim().slice(0, 120),
      serialNumber,
      installDate,
      expiresAt,
      location: String(payload.location || customer.primaryAddress || "").trim().slice(0, 500),
      ticketId: ticket?.id || "",
      ticketNumber: ticket?.number || "",
      notes: String(payload.notes || "").trim().slice(0, 5000),
      createdAt: existing?.createdAt || new Date().toISOString(),
      createdBy: existing?.createdBy || session.username,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    const index = warranties.findIndex((record) => record.id === warranty.id);
    if (index >= 0) warranties[index] = warranty;
    else warranties.push(warranty);
    writeWarranties(warranties);
    logActivity(session, index >= 0 ? "warranty.updated" : "warranty.created",
      `${index >= 0 ? "Updated" : "Created"} warranty for ${warranty.productName}, serial ${warranty.serialNumber}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "warranties" });
    sendJson(response, 200, { ok: true, warranty: { ...warranty, status: warrantyStatus(warranty) } });
    return;
  }

  if (request.method === "DELETE") {
    const warranty = warranties.find((record) => record.id === payload.id);
    if (!warranty) {
      sendJson(response, 404, { ok: false, message: "Warranty record not found." });
      return;
    }
    writeWarranties(warranties.filter((record) => record.id !== warranty.id));
    logActivity(session, "warranty.deleted",
      `Deleted warranty for ${warranty.productName}, serial ${warranty.serialNumber}.`);
    broadcastAllServiceEvent("dashboard-updated", { area: "warranties" });
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function handleCustomerHistory(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "customers")) {
    sendJson(response, 403, { ok: false, message: "Customer access required." });
    return;
  }
  if (request.method !== "GET") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const url = new URL(request.url, publicOrigin(request));
  const customer = readCustomers().find((record) => record.id === url.searchParams.get("customerId"));
  if (!customer) {
    sendJson(response, 404, { ok: false, message: "Customer not found." });
    return;
  }
  const matchesCustomer = (name, customerId) =>
    customerId === customer.id ||
    (!customerId && String(name || "").toLowerCase() === customer.name.toLowerCase());
  const tickets = readTickets().filter((ticket) =>
    !ticket.isOffice && matchesCustomer(ticket.customer, ticket.customerId)
  );
  const ticketIds = new Set(tickets.map((ticket) => ticket.id));
  const canViewFinancials = hasPermission(session, "invoicing") || hasPermission(session, "finance");
  const estimates = canViewFinancials ? readEstimates() : [];
  const invoices = canViewFinancials ? readInvoices() : [];
  const finance = canViewFinancials ? readFinance() : { payments: [] };
  const contractSummaries = canViewFinancials
    ? new Map(contractPaymentSummaries(finance)
      .filter((record) => ticketIds.has(record.id))
      .map((record) => [record.id, record]))
    : new Map();
  const jobs = tickets.map((ticket) => {
    const type = (ticket.ticketType || "Service") === "Contract" ? "Contract" : "Service";
    const estimate = estimates.find((record) =>
      record.ticketId === ticket.id || record.id === ticket.sourceEstimateId
    );
    let pending = 0;
    let received = 0;
    let owed = 0;
    if (canViewFinancials && type === "Contract") {
      const contract = contractSummaries.get(ticket.id);
      received = roundMoney(contract?.paid || 0);
      owed = roundMoney(contract?.balance || 0);
    } else if (canViewFinancials) {
      const jobInvoices = invoices.filter((invoice) =>
        invoice.ticketId === ticket.id && invoice.status !== "Void"
      );
      if (jobInvoices.length) {
        for (const invoice of jobInvoices) {
          const total = roundMoney(invoice.total || 0);
          if (invoice.status === "Draft") {
            pending += total;
            continue;
          }
          const paid = Math.min(total, invoicePaidAmount(invoice, finance.payments));
          received += paid;
          owed += Math.max(0, total - paid);
        }
      } else if (estimate && !["Draft", "Declined"].includes(estimate.status)) {
        pending = roundMoney(estimate.total || 0);
      }
    }
    pending = roundMoney(pending);
    received = roundMoney(received);
    owed = roundMoney(owed);
    return {
      id: ticket.id,
      number: ticketLabel(ticket),
      type,
      service: ticket.serviceType || ticket.description || "Service",
      description: ticket.description || "",
      status: ticket.status || "Open",
      date: ticket.scheduledDate || ticket.createdAt || "",
      pending: canViewFinancials ? pending : null,
      received: canViewFinancials ? received : null,
      owed: canViewFinancials ? owed : null,
      total: canViewFinancials ? roundMoney(pending + received + owed) : null,
      href: `/job-workspace.html?jobId=${encodeURIComponent(ticket.id)}`
    };
  }).sort((a, b) => String(b.date).localeCompare(String(a.date)));
  const summary = {
    pending: canViewFinancials ? roundMoney(jobs.reduce((sum, job) => sum + job.pending, 0)) : null,
    received: canViewFinancials ? roundMoney(jobs.reduce((sum, job) => sum + job.received, 0)) : null,
    owed: canViewFinancials ? roundMoney(jobs.reduce((sum, job) => sum + job.owed, 0)) : null
  };
  const history = tickets.map((ticket) => ({
    id: `ticket-${ticket.id}`,
    type: ticket.ticketType === "Contract" ? "Contract Ticket" : "Service Ticket",
    date: ticket.scheduledDate || ticket.createdAt || "",
    title: `${ticketLabel(ticket)} · ${ticket.serviceType || ticket.description || "Service"}`,
    detail: ticket.resolution || ticket.description || ticket.issue || "",
    status: ticket.status || "Open",
    href: "/service-tickets.html"
  }));

  history.push(...readCustomerCommunications()
    .filter((record) => record.customerId === customer.id)
    .map((record) => ({
      id: `communication-${record.id}`,
      type: record.type,
      date: record.occurredAt,
      title: record.subject,
      detail: [record.direction, record.contact, record.detail].filter(Boolean).join(" · "),
      status: record.direction,
      href: ""
    })));

  if (hasPermission(session, "service-tickets")) {
    history.push(...tickets.flatMap((ticket) =>
      (ticket.internalMessages || []).map((message) => ({
        id: `ticket-message-${message.id}`,
        type: "Service Message",
        date: message.createdAt,
        title: `${ticketLabel(ticket)} · ${message.employeeName}`,
        detail: message.message,
        status: message.fromOffice ? "Office" : "Technician",
        href: "/service-tickets.html"
      }))
    ));
  }

  if (hasPermission(session, "warranties")) {
    history.push(...readWarranties().filter((record) => record.customerId === customer.id).map((record) => ({
      id: `warranty-${record.id}`,
      type: "Warranty",
      date: record.installDate,
      title: `${record.productName}${record.model ? ` · ${record.model}` : record.variationName ? ` · ${record.variationName}` : ""}`,
      detail: `Serial ${record.serialNumber}${record.location ? ` · ${record.location}` : ""}` +
        `${record.expiresAt ? ` · Expires ${record.expiresAt}` : " · No warranty expiration"}`,
      status: warrantyStatus(record),
      href: "/warranties.html"
    })));
  }
  if (hasPermission(session, "estimates")) {
    history.push(...readEstimates().filter((record) => record.customerId === customer.id).map((record) => ({
      id: `estimate-${record.id}`,
      type: "Estimate",
      date: record.updatedAt || record.validUntil || "",
      title: `Q-${String(record.number).padStart(4, "0")} · ${record.title}`,
      detail: `$${Number(record.total || 0).toFixed(2)}`,
      status: record.status || "Draft",
      href: "/estimates.html"
    })));
  }
  if (hasPermission(session, "invoicing")) {
    const invoices = readInvoices().filter((record) =>
      ticketIds.has(record.ticketId) ||
      String(record.customer || "").toLowerCase() === customer.name.toLowerCase()
    );
    const invoiceIds = new Set(invoices.map((record) => record.id));
    history.push(...invoices.map((record) => ({
      id: `invoice-${record.id}`,
      type: "Invoice",
      date: record.issueDate || record.updatedAt || "",
      title: `Invoice #${record.number}`,
      detail: `$${Number(record.total || 0).toFixed(2)}${record.dueDate ? ` · Due ${record.dueDate}` : ""}`,
      status: record.status || "Draft",
      href: "/invoices.html"
    })));
    history.push(...(readFinance().payments || []).filter((record) =>
      invoiceIds.has(record.invoiceId)
    ).map((record) => ({
      id: `payment-${record.id}`,
      type: "Payment",
      date: record.date || record.createdAt || "",
      title: `Payment received · $${Number(record.amount || 0).toFixed(2)}`,
      detail: [record.method, record.reference].filter(Boolean).join(" · "),
      status: "Received",
      href: "/invoices.html"
    })));
  }
  history.sort((a, b) => String(b.date).localeCompare(String(a.date)));
  sendJson(response, 200, {
    ok: true,
    customer: { id: customer.id, name: customer.name },
    financialsVisible: canViewFinancials,
    jobs,
    summary,
    history
  });
}

function jobCustomer(ticket) {
  if (ticket.isOffice) return null;
  return readCustomers().find((customer) =>
    customer.id === ticket.customerId ||
    (!ticket.customerId && customer.name.toLowerCase() === String(ticket.customer || "").toLowerCase())
  ) || null;
}

const workspaceEstimateStatuses = new Set(["Accepted", "In Progress", "Done", "Paid", "Approved"]);
const jobExpenseCategories = ["Material", "Office", "Food", "Hotel", "Travel", "Equipment Rental", "Permit", "Other"];

function readJobExpenses() {
  if (!existsSync(jobExpensesPath)) return [];
  try {
    const records = JSON.parse(readFileSync(jobExpensesPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeJobExpenses(records) {
  writeFileSync(jobExpensesPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function activeEmployeeNames() {
  return [...new Set(readEmployees().filter((employee) => employee.status !== "Inactive").map((employee) =>
    `${employee.firstName || ""} ${employee.lastName || ""}`.trim()
  ).filter(Boolean))].sort();
}

function jobCostMetrics(ticket, estimates, jobId) {
  const primaryEstimate = [...estimates].sort((a, b) =>
    String(b.updatedAt || "").localeCompare(String(a.updatedAt || ""))
  )[0] || null;
  const workLogs = ticket?.workLogs || [];
  const laborEntries = workLogs.map((log) => {
    const hours = Math.max(0, Number(log.hours) || 0);
    const rate = roundMoney(employeeLaborRate(log.employeeName));
    return {
      employeeName: log.employeeName || "Unknown employee",
      hours,
      rate,
      cost: roundMoney(hours * rate),
      loggedAt: log.loggedAt || ""
    };
  });
  const laborCost = roundMoney(laborEntries.reduce((sum, entry) => sum + entry.cost, 0));
  const usedMaterialCost = roundMoney((ticket?.usedItems || []).reduce((sum, item) =>
    sum + Math.max(0, Number(item.quantity) || 0) * Math.max(0, Number(item.unitCost) || 0), 0));
  const expenses = readJobExpenses().filter((expense) => expense.jobId === jobId);
  const materialExpenses = roundMoney(expenses.filter((expense) => expense.category === "Material")
    .reduce((sum, expense) => sum + Number(expense.amount || 0), 0));
  const officeCharges = roundMoney(expenses.filter((expense) => expense.category === "Office")
    .reduce((sum, expense) => sum + Number(expense.amount || 0), 0));
  const otherExpenses = roundMoney(expenses.filter((expense) => !["Material", "Office"].includes(expense.category))
    .reduce((sum, expense) => sum + Number(expense.amount || 0), 0));
  const materialsCost = roundMoney(usedMaterialCost + materialExpenses);
  const totalExpenses = roundMoney(materialExpenses + officeCharges + otherExpenses);
  const totalCosts = roundMoney(laborCost + usedMaterialCost + totalExpenses);
  const estimateTotal = roundMoney(primaryEstimate?.total || 0);
  return {
    primaryEstimate,
    estimateTotal,
    laborCost,
    materialsCost,
    usedMaterialCost,
    materialExpenses,
    officeCharges,
    otherExpenses,
    totalExpenses,
    totalCosts,
    remaining: roundMoney(estimateTotal - totalCosts),
    laborEntries,
    expenses: expenses.sort((a, b) => String(b.date || b.createdAt).localeCompare(String(a.date || a.createdAt)))
  };
}

function jobWorkspaceDetail(ticket, session, estimateOverride = null) {
  const customer = jobCustomer(ticket);
  const canEstimate = hasPermission(session, "estimates");
  const canInvoice = hasPermission(session, "invoicing");
  const canWarranty = hasPermission(session, "warranties");
  const canCommunicate = hasPermission(session, "customers");
  const canDesign = hasPermission(session, "design-center");
  const canDocuments = hasPermission(session, "documents");
  const estimates = (estimateOverride ? [estimateOverride] : readEstimates().filter((estimate) =>
    estimate.ticketId === ticket.id ||
    (!estimate.ticketId && customer && estimate.customerId === customer.id &&
      String(estimate.title || "").toLowerCase() === String(ticket.description || "").toLowerCase())
  )).filter((estimate) => workspaceEstimateStatuses.has(estimate.status));
  const invoices = canInvoice ? readInvoices().filter((invoice) => invoice.ticketId === ticket.id) : [];
  const invoiceIds = new Set(invoices.map((invoice) => invoice.id));
  const finance = readFinance();
  const isContract = (ticket.ticketType || "Service") === "Contract";
  const contractSummary = isContract
    ? contractPaymentSummaries(finance).find((record) => record.id === ticket.id)
    : null;
  const payments = canInvoice ? finance.payments.filter((payment) =>
    invoiceIds.has(payment.invoiceId) || payment.contractTicketId === ticket.id
  ) : [];
  const equipment = canWarranty && customer ? readWarranties().filter((record) =>
    record.customerId === customer.id
  ).map((record) => ({
    ...record,
    status: warrantyStatus(record),
    linkedToJob: record.ticketId === ticket.id
  })) : [];
  const communications = canCommunicate && customer ? readCustomerCommunications().filter((record) =>
    record.customerId === customer.id
  ) : [];
  const designPlanIds = new Set(Array.isArray(ticket.designPlanIds) ? ticket.designPlanIds : []);
  const designs = canDesign ? readFloorPlans().filter((record) =>
    designPlanIds.has(record.id) || record.project?.contractTicketId === ticket.id
  ).map((record) => ({
    id: record.id,
    title: record.title,
    buildingName: record.project?.buildingName || "",
    floorName: record.project?.floorName || "",
    revisionCount: Array.isArray(record.revisions) ? record.revisions.length : 0,
    objectCount: Array.isArray(record.objects) ? record.objects.length : 0,
    updatedAt: record.updatedAt,
    updatedBy: record.updatedBy
  })) : [];
  const availableDocuments = canDocuments && existsSync(documentsPath)
    ? searchableDocumentFiles().sort((a, b) => a.localeCompare(b)).slice(0, 500)
    : [];
  const savedProject = ticket.projectWorkspace && typeof ticket.projectWorkspace === "object"
    ? ticket.projectWorkspace : {};
  const linkedDocuments = (Array.isArray(savedProject.documentPaths) ? savedProject.documentPaths : [])
    .filter((file) => availableDocuments.includes(file))
    .map((path) => ({
      path,
      name: path.split("/").pop() || path,
      type: /\.(pdf|svg|png|jpe?g)$/i.test(path) ? "Blueprint / Image" : "Document"
    }));
  const project = {
    name: String(savedProject.name || `${ticketLabel(ticket)} · ${ticket.customer || "Project"}`),
    notes: String(savedProject.notes || ""),
    documentPaths: linkedDocuments.map((record) => record.path),
    linkedDocuments,
    updatedAt: String(savedProject.updatedAt || ""),
    updatedBy: String(savedProject.updatedBy || "")
  };
  const timeline = [];
  timeline.push({
    id: `ticket-created-${ticket.id}`,
    type: "Job Created",
    date: ticket.createdAt || "",
    title: ticketLabel(ticket),
    detail: ticket.description || ticket.serviceType || "Service job"
  });
  if (ticket.scheduledDate) timeline.push({
    id: `scheduled-${ticket.id}`,
    type: "Scheduled",
    date: `${ticket.scheduledDate}T${ticket.scheduledTime || "12:00"}:00`,
    title: ticket.assignedTo || "Unassigned",
    detail: [ticket.scheduledDate, ticket.scheduledTime].filter(Boolean).join(" · ")
  });
  timeline.push(...(ticket.workLogs || []).map((log) => ({
    id: `work-${log.id}`,
    type: "Work Log",
    date: log.loggedAt,
    title: `${log.employeeName} · ${Number(log.hours || 0).toFixed(2)} hours`,
    detail: log.resolution || log.status || "Work recorded"
  })));
  timeline.push(...(ticket.internalMessages || []).map((message) => ({
    id: `message-${message.id}`,
    type: "Service Message",
    date: message.createdAt,
    title: message.employeeName,
    detail: message.message
  })));
  timeline.push(...(ticket.attachments || []).map((attachment) => ({
    id: `attachment-${attachment.id}`,
    type: "Attachment",
    date: attachment.uploadedAt,
    title: attachment.name,
    detail: `Uploaded by ${attachment.employeeName || attachment.uploadedBy || "employee"}`
  })));
  timeline.push(...estimates.map((estimate) => ({
    id: `estimate-${estimate.id}`,
    type: "Estimate",
    date: estimate.convertedAt || estimate.approvedAt || estimate.updatedAt || "",
    title: `Q-${String(estimate.number).padStart(4, "0")} · ${estimate.title}`,
    detail: `${formatUsd(estimate.total)} · ${estimate.status}`
  })));
  timeline.push(...invoices.map((invoice) => ({
    id: `invoice-${invoice.id}`,
    type: "Invoice",
    date: invoice.issueDate || invoice.updatedAt || "",
    title: `Invoice #${invoice.number}`,
    detail: `${formatUsd(invoice.total)} · ${invoice.status}`
  })));
  timeline.push(...payments.map((payment) => ({
    id: `payment-${payment.id}`,
    type: "Payment",
    date: payment.date || payment.createdAt || "",
    title: `${formatUsd(payment.amount)} received`,
    detail: [payment.method, payment.reference].filter(Boolean).join(" · ")
  })));
  timeline.push(...equipment.filter((record) => record.linkedToJob).map((record) => ({
    id: `equipment-${record.id}`,
    type: "Equipment Installed",
    date: record.installDate || record.createdAt || "",
    title: record.productName,
    detail: [record.model, record.serialNumber, record.location].filter(Boolean).join(" · ")
  })));
  timeline.push(...communications.map((record) => ({
    id: `communication-${record.id}`,
    type: record.type,
    date: record.occurredAt,
    title: record.subject,
    detail: [record.direction, record.contact, record.detail].filter(Boolean).join(" · ")
  })));
  const timelineStage = {
    "Job Created": 0,
    Estimate: 1,
    Scheduled: 2,
    "Service Message": 3,
    Attachment: 3,
    "Work Log": 4,
    "Equipment Installed": 5,
    Invoice: 6,
    Payment: 7
  };
  timeline.sort((a, b) => {
    const stageDifference = (timelineStage[a.type] ?? 3) - (timelineStage[b.type] ?? 3);
    return stageDifference || String(a.date || "").localeCompare(String(b.date || ""));
  });

  const paidTotal = isContract
    ? roundMoney(contractSummary?.paid || 0)
    : roundMoney(invoices.reduce((sum, invoice) =>
      sum + invoicePaidAmount(invoice, payments), 0));
  const invoiceTotal = isContract
    ? roundMoney(contractSummary?.total || estimates[0]?.total || 0)
    : roundMoney(invoices.reduce((sum, invoice) => sum + Number(invoice.total || 0), 0));
  const metrics = jobCostMetrics(ticket, estimates, ticket.id);
  const hasWork = Boolean((ticket.workLogs || []).length) || Number(ticket.hoursUsed || 0) > 0;
  const workComplete = ticket.status === "Closed";
  const paymentComplete = invoiceTotal > 0 && roundMoney(Math.max(0, invoiceTotal - paidTotal)) <= 0;
  const workflowSteps = [
    {
      id: "estimate",
      label: "Estimate approved",
      complete: estimates.length > 0,
      optional: estimates.length === 0,
      detail: estimates[0] ? `Q-${String(estimates[0].number).padStart(4, "0")} · ${estimates[0].status}` : "No linked estimate"
    },
    { id: "job", label: "Job created", complete: !ticket.quoteOnly, detail: ticket.quoteOnly ? "Contract ticket not created" : ticketLabel(ticket) },
    { id: "schedule", label: "Scheduled and assigned", complete: Boolean(ticket.scheduledDate && ticket.assignedTo), detail: ticket.scheduledDate ? `${ticket.scheduledDate} · ${ticket.assignedTo || "Unassigned"}` : "Not scheduled" },
    { id: "work", label: "Work completed", complete: workComplete, started: hasWork, detail: workComplete ? `${Number(ticket.hoursUsed || 0).toFixed(2)} hours · Closed` : hasWork ? `${Number(ticket.hoursUsed || 0).toFixed(2)} hours · In progress` : "No work logged" },
    ...(!isContract ? [{ id: "invoice", label: "Invoice prepared", complete: invoices.length > 0, detail: invoices[0] ? `#${invoices[0].number} · ${invoices[0].status}` : "Not created" }] : []),
    { id: "payment", label: "Payment received", complete: paymentComplete, detail: paymentComplete ? "Paid in full" : invoiceTotal > 0 ? `${formatUsd(Math.max(0, invoiceTotal - paidTotal))} remaining` : "No amount recorded" }
  ];
  const nextStep = workflowSteps.find((step) => !step.complete && !step.optional) || null;
  const nextActions = {
    job: { label: "Create Contract Ticket", href: `/estimates.html?estimateId=${encodeURIComponent(estimates[0]?.id || "")}` },
    schedule: { label: "Schedule in Dispatch", href: "/dispatch.html" },
    work: { label: hasWork ? "Review and close work" : "Open Service Tickets", href: "/service-tickets.html" },
    invoice: { label: "Create Invoice", href: `/invoices.html?ticketId=${encodeURIComponent(ticket.id)}` },
    payment: { label: isContract ? "Record Contract Payment" : "Review Payment", href: "/finance.html?tab=payments" }
  };
  const workflowChecks = [
    {
      id: "customer", label: "Customer and location",
      passed: Boolean(ticket.isOffice || (ticket.customer && (ticket.address || customer?.primaryAddress))),
      detail: ticket.isOffice ? "Office job does not require a customer address." : "Customer name and service address are recorded.",
      href: "/service-tickets.html"
    },
    {
      id: "estimate", label: "Approved estimate", passed: estimates.length > 0,
      optional: ticket.isOffice === true,
      detail: estimates.length ? `${estimates[0].status} estimate linked.` : "No accepted or approved estimate is linked.",
      href: "/estimates.html"
    },
    {
      id: "assignment", label: "Assignment and schedule",
      passed: Boolean(ticket.assignedTo && ticket.scheduledDate),
      detail: ticket.assignedTo && ticket.scheduledDate ? `${ticket.assignedTo} · ${ticket.scheduledDate}` : "Assign staff and a scheduled date.",
      href: "/dispatch.html"
    },
    {
      id: "work", label: "Work and resolution",
      passed: Boolean(hasWork && (ticket.resolution || (ticket.workLogs || []).some((log) => log.resolution))),
      detail: hasWork ? "Work exists; confirm that resolution notes are complete." : "No technician hours or work log has been recorded.",
      href: "/service-tickets.html"
    },
    {
      id: "materials", label: "Materials reviewed",
      passed: workComplete || (ticket.usedItems || []).length > 0, optional: true,
      detail: (ticket.usedItems || []).length ? `${ticket.usedItems.length} material entr${ticket.usedItems.length === 1 ? "y" : "ies"} recorded.` : "No materials recorded; verify that none were used.",
      href: "/service-tickets.html"
    },
    ...(!isContract ? [{
      id: "invoice", label: "Invoice prepared", passed: invoices.length > 0,
      detail: invoices.length ? `Invoice #${invoices[0].number} · ${invoices[0].status}` : "No invoice is linked to this service job.",
      href: `/invoices.html?ticketId=${encodeURIComponent(ticket.id)}`
    }] : []),
    {
      id: "payment", label: "Payment reconciled", passed: paymentComplete,
      detail: paymentComplete ? "The job is paid in full." : invoiceTotal > 0 ? `${formatUsd(Math.max(0, invoiceTotal - paidTotal))} remains outstanding.` : "No billable total or payment is recorded.",
      href: isContract ? "/finance.html?tab=payments" : "/invoices.html"
    },
    {
      id: "closeout", label: "Job closeout", passed: workComplete && paymentComplete,
      detail: workComplete && paymentComplete ? "Work and payment are complete." : "Close the work and reconcile payment before archiving.",
      href: "/service-tickets.html"
    }
  ];
  return {
    ticket,
    customer,
    estimates,
    invoices,
    payments,
    equipment,
    communications,
    designs,
    project,
    availableDocuments,
    timeline,
    metrics,
    expenses: metrics.expenses,
    employees: activeEmployeeNames(),
    expenseCategories: jobExpenseCategories,
    financials: {
      type: isContract ? "Contract" : "Invoice",
      invoiceTotal,
      paidTotal,
      balance: roundMoney(Math.max(0, invoiceTotal - paidTotal))
    },
    workflow: {
      steps: workflowSteps,
      completed: workflowSteps.filter((step) => step.complete).length,
      total: workflowSteps.length,
      nextStep,
      nextAction: nextStep ? nextActions[nextStep.id] || null : null
    },
    workflowAudit: {
      checks: workflowChecks,
      passed: workflowChecks.filter((check) => check.passed).length,
      required: workflowChecks.filter((check) => !check.optional).length,
      requiredPassed: workflowChecks.filter((check) => !check.optional && check.passed).length,
      ready: workflowChecks.filter((check) => !check.optional).every((check) => check.passed)
    },
    permissions: {
      estimates: canEstimate,
      invoicing: canInvoice,
      warranties: canWarranty,
      communications: canCommunicate,
      designCenter: canDesign,
      documents: canDocuments
    }
  };
}

function estimateWorkspaceTicket(estimate) {
  const customer = readCustomers().find((record) => record.id === estimate.customerId) || null;
  return {
    id: `estimate:${estimate.id}`,
    number: estimate.number,
    ticketType: estimate.jobType === "Contract" ? "Contract" : "Service",
    customerId: customer?.id || estimate.customerId || "",
    customer: customer?.name || estimate.customer || "Unknown customer",
    company: customer?.company || "",
    email: customer?.email || "",
    phone: customer?.phone || "",
    address: customer?.address || customer?.primaryAddress || "",
    description: estimate.title || "Approved estimate",
    status: ["Done", "Paid"].includes(estimate.status)
      ? "Closed" : estimate.status === "In Progress" ? "In Progress" : "Open",
    priority: "Normal",
    assignedTo: "",
    scheduledDate: "",
    scheduledTime: "",
    hoursUsed: 0,
    workLogs: [],
    usedItems: [],
    attachments: [],
    internalMessages: [],
    createdAt: estimate.acceptedAt || estimate.approvedAt || estimate.createdAt || estimate.updatedAt || "",
    quoteOnly: true
  };
}

async function handleJobWorkspace(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "job-workspace")) {
    sendJson(response, session ? 403 : 401, {
      ok: false,
      message: session ? "Job Workspace access required." : "Please sign in."
    });
    return;
  }
  const url = new URL(request.url, publicOrigin(request));
  const tickets = readTickets();
  const jobId = String(url.searchParams.get("jobId") || url.searchParams.get("ticketId") || "");
  if (request.method === "PATCH") {
    const payload = await readJsonBody(request);
    const requestedJobId = String(payload.jobId || jobId || "");
    const ticket = tickets.find((record) => record.id === requestedJobId);
    if (!ticket) {
      sendJson(response, 404, { ok: false, message: "Create the ticket before saving project details." });
      return;
    }
    const projectPayload = payload.project && typeof payload.project === "object" ? payload.project : {};
    const canEditDocuments = hasPermission(session, "documents");
    const availableDocuments = canEditDocuments && existsSync(documentsPath)
      ? searchableDocumentFiles() : [];
    const allowedDocuments = new Set(availableDocuments);
    const existingDocumentPaths = Array.isArray(ticket.projectWorkspace?.documentPaths)
      ? ticket.projectWorkspace.documentPaths : [];
    const documentPaths = canEditDocuments
      ? [...new Set((Array.isArray(projectPayload.documentPaths)
        ? projectPayload.documentPaths : []).map((path) => String(path || "").trim())
        .filter((path) => allowedDocuments.has(path)))].slice(0, 100)
      : existingDocumentPaths;
    ticket.projectWorkspace = {
      name: String(projectPayload.name || "").trim().slice(0, 160) || `${ticketLabel(ticket)} · ${ticket.customer || "Project"}`,
      notes: String(projectPayload.notes || "").trim().slice(0, 10000),
      documentPaths,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    ticket.updatedAt = new Date().toISOString();
    writeTickets(tickets);
    logActivity(session, "job.project.updated", `Updated project workspace for ${ticketLabel(ticket)}.`);
    broadcastAllServiceEvent("job-workspace-updated", { jobId: ticket.id });
    sendJson(response, 200, { ok: true, job: jobWorkspaceDetail(ticket, session) });
    return;
  }
  if (request.method !== "GET") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  if (jobId) {
    if (jobId.startsWith("estimate:")) {
      const estimateId = jobId.slice("estimate:".length);
      const estimate = readEstimates().find((record) =>
        record.id === estimateId && !record.ticketId && workspaceEstimateStatuses.has(record.status)
      );
      if (!estimate) {
        sendJson(response, 404, { ok: false, message: "Job not found." });
        return;
      }
      const ticket = estimateWorkspaceTicket(estimate);
      sendJson(response, 200, { ok: true, job: jobWorkspaceDetail(ticket, session, estimate) });
      return;
    }
    const ticket = tickets.find((record) => record.id === jobId);
    if (!ticket) {
      sendJson(response, 404, { ok: false, message: "Job not found." });
      return;
    }
    sendJson(response, 200, { ok: true, job: jobWorkspaceDetail(ticket, session) });
    return;
  }
  const invoiceMap = hasPermission(session, "invoicing")
    ? new Map(readInvoices().map((invoice) => [invoice.ticketId, invoice]))
    : new Map();
  const qualifyingEstimates = readEstimates().filter((estimate) => workspaceEstimateStatuses.has(estimate.status));
  const estimateMap = new Map(qualifyingEstimates.filter((estimate) => estimate.ticketId)
    .map((estimate) => [estimate.ticketId, estimate]));
  const jobs = tickets.map((ticket) => {
    const invoice = invoiceMap.get(ticket.id);
    const estimate = estimateMap.get(ticket.id);
    return {
      id: ticket.id,
      number: ticket.number,
      label: ticketLabel(ticket),
      ticketType: ticket.ticketType || "Service",
      customerId: ticket.customerId || "",
      customer: ticket.customer || "",
      company: ticket.company || "",
      description: ticket.description || ticket.serviceType || "Service job",
      status: ticket.status || "Open",
      priority: ticket.priority || "Normal",
      assignedTo: ticket.assignedTo || "",
      scheduledDate: ticket.scheduledDate || "",
      scheduledTime: ticket.scheduledTime || "",
      hoursUsed: Number(ticket.hoursUsed || 0),
      estimate: estimate ? { id: estimate.id, number: estimate.number, status: estimate.status } : null,
      invoice: invoice ? { id: invoice.id, number: invoice.number, status: invoice.status, total: invoice.total } : null,
      updatedAt: ticket.updatedAt || ticket.createdAt || ""
    };
  });
  for (const estimate of qualifyingEstimates.filter((record) => !record.ticketId)) {
    const ticket = estimateWorkspaceTicket(estimate);
    jobs.push({
      id: ticket.id,
      number: ticket.number,
      label: `Q-${String(estimate.number).padStart(4, "0")}`,
      ticketType: ticket.ticketType,
      customerId: ticket.customerId,
      customer: ticket.customer,
      company: ticket.company,
      description: ticket.description,
      status: ticket.status,
      priority: ticket.priority,
      assignedTo: "",
      scheduledDate: "",
      scheduledTime: "",
      hoursUsed: 0,
      estimate: { id: estimate.id, number: estimate.number, status: estimate.status },
      invoice: null,
      quoteOnly: true,
      updatedAt: estimate.updatedAt || estimate.createdAt || ""
    });
  }
  jobs.sort((a,b) => String(b.updatedAt || b.scheduledDate).localeCompare(String(a.updatedAt || a.scheduledDate)));
  sendJson(response, 200, { ok: true, jobs });
}

async function handleJobExpenses(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "job-workspace")) {
    sendJson(response, session ? 403 : 401, {
      ok: false,
      message: session ? "Job Workspace access required." : "Please sign in."
    });
    return;
  }
  const records = readJobExpenses();
  if (request.method === "GET") {
    const url = new URL(request.url, publicOrigin(request));
    const jobId = String(url.searchParams.get("jobId") || "");
    sendJson(response, 200, {
      ok: true,
      expenses: jobId ? records.filter((record) => record.jobId === jobId) : records,
      categories: jobExpenseCategories,
      employees: activeEmployeeNames()
    });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const jobId = String(payload.jobId || "").trim();
    const estimateId = jobId.startsWith("estimate:") ? jobId.slice("estimate:".length) : "";
    const jobExists = readTickets().some((ticket) => ticket.id === jobId) || readEstimates().some((estimate) =>
      estimate.id === estimateId && !estimate.ticketId && workspaceEstimateStatuses.has(estimate.status)
    );
    const category = String(payload.category || "").trim();
    const employeeName = String(payload.employeeName || "").trim();
    const amount = roundMoney(payload.amount);
    if (!jobExists) {
      sendJson(response, 404, { ok: false, message: "Job not found." });
      return;
    }
    if (!jobExpenseCategories.includes(category)) {
      sendJson(response, 400, { ok: false, message: "Choose a valid expense category." });
      return;
    }
    if (!employeeName || !activeEmployeeNames().includes(employeeName)) {
      sendJson(response, 400, { ok: false, message: "Choose an active employee." });
      return;
    }
    if (!(amount > 0)) {
      sendJson(response, 400, { ok: false, message: "Expense amount must be greater than zero." });
      return;
    }
    const expense = {
      id: randomBytes(12).toString("hex"),
      jobId,
      category,
      employeeName,
      description: String(payload.description || "").trim().slice(0, 500),
      amount,
      date: validDateOnly(payload.date) || businessToday(),
      createdAt: new Date().toISOString(),
      createdBy: session.username
    };
    records.push(expense);
    writeJobExpenses(records);
    logActivity(session, "job.expense.created", `Added ${formatUsd(amount)} ${category} expense to job workspace.`, {
      undo: { collection: "jobExpenses", recordId: expense.id, before: null, after: structuredClone(expense) }
    });
    broadcastAllServiceEvent("job-workspace-updated", { jobId });
    broadcastAllServiceEvent("dashboard-updated", { source: "job-expenses" });
    sendJson(response, 201, { ok: true, expense });
    return;
  }
  if (request.method === "DELETE") {
    const index = records.findIndex((record) => record.id === payload.id);
    if (index < 0) {
      sendJson(response, 404, { ok: false, message: "Job expense not found." });
      return;
    }
    const [expense] = records.splice(index, 1);
    writeJobExpenses(records);
    logActivity(session, "job.expense.deleted", `Deleted ${formatUsd(expense.amount)} job expense.`, {
      undo: { collection: "jobExpenses", recordId: expense.id, before: structuredClone(expense), after: null }
    });
    broadcastAllServiceEvent("job-workspace-updated", { jobId: expense.jobId });
    broadcastAllServiceEvent("dashboard-updated", { source: "job-expenses" });
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function defaultTaxData() {
  return {
    settings: {
      businessName: "Huber I.T. Professionals",
      einLastFour: "",
      accountingMethod: "cash",
      sdStateSalesTaxRate: 4.2,
      defaultMunicipalRate: 0,
      salesTaxFrequency: "monthly",
      federalEstimateRate: 25,
      federalWithholdingRate: 0,
      socialSecurityRate: 6.2,
      medicareRate: 1.45,
      futaRate: 0.6,
      sdReemploymentRate: 0,
      contractorExciseRate: 2,
      taxReserveRate: 25,
      currentReserveBalance: 0
    },
    filings: [],
    useTaxItems: []
  };
}

function readTaxData() {
  const defaults = defaultTaxData();
  if (!existsSync(taxesPath)) return defaults;
  try {
    const saved = JSON.parse(readFileSync(taxesPath, "utf8"));
    return {
      settings: { ...defaults.settings, ...(saved.settings || {}) },
      filings: Array.isArray(saved.filings) ? saved.filings : [],
      useTaxItems: Array.isArray(saved.useTaxItems) ? saved.useTaxItems : []
    };
  } catch {
    return defaults;
  }
}

function writeTaxData(data) {
  writeFileSync(taxesPath, JSON.stringify(data, null, 2), { mode: 0o600 });
}

function taxDateRange(url) {
  const today = businessToday();
  return {
    from: validDateOnly(url.searchParams.get("from")) || `${today.slice(0, 4)}-01-01`,
    to: validDateOnly(url.searchParams.get("to")) || today
  };
}

function calculateTaxCenter(data, from, to) {
  const settings = data.settings;
  const allInvoices = readInvoices().filter((invoice) => !["Draft", "Void"].includes(invoice.status));
  const financePayments = readFinance().payments || [];
  const invoiceEntries = settings.accountingMethod === "cash"
    ? allInvoices.map((invoice) => {
        const payments = financePayments.filter((payment) =>
          payment.invoiceId === invoice.id && payment.date >= from && payment.date <= to
        );
        const received = payments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
        const ratio = Number(invoice.total || 0) > 0
          ? Math.min(1, received / Number(invoice.total)) : 0;
        return {
          invoice,
          taxableAmount: roundMoney(Number(invoice.subtotal || 0) * ratio),
          taxAmount: roundMoney(Number(invoice.tax || 0) * ratio)
        };
      }).filter((entry) => entry.taxableAmount > 0 || entry.taxAmount > 0)
    : allInvoices.filter((invoice) =>
        invoice.issueDate >= from && invoice.issueDate <= to
      ).map((invoice) => ({
        invoice,
        taxableAmount: Number(invoice.subtotal || 0),
        taxAmount: Number(invoice.tax || 0)
      }));
  const taxableSales = roundMoney(invoiceEntries.reduce((sum, entry) =>
    sum + entry.taxableAmount, 0));
  const salesTaxCollected = roundMoney(invoiceEntries.reduce((sum, entry) =>
    sum + entry.taxAmount, 0));
  const stateSalesTax = roundMoney(invoiceEntries.reduce((sum, entry) =>
    sum + Math.min(
      entry.taxAmount,
      entry.taxableAmount * Number(settings.sdStateSalesTaxRate || 0) / 100
    ), 0));
  const municipalSalesTax = roundMoney(Math.max(0, salesTaxCollected - stateSalesTax));
  const useTax = roundMoney(data.useTaxItems.filter((record) =>
    record.date >= from && record.date <= to
  ).reduce((sum, record) => sum + Number(record.taxAmount || 0), 0));

  const payroll = payrollData(from, to);
  const grossWages = Number(payroll.totals.grossPay || 0);
  const federalWithholding = roundMoney(grossWages * Number(settings.federalWithholdingRate || 0) / 100);
  const employeeSocialSecurity = roundMoney(grossWages * Number(settings.socialSecurityRate || 0) / 100);
  const employerSocialSecurity = employeeSocialSecurity;
  const employeeMedicare = roundMoney(grossWages * Number(settings.medicareRate || 0) / 100);
  const employerMedicare = employeeMedicare;
  const futa = roundMoney(grossWages * Number(settings.futaRate || 0) / 100);
  const sdReemployment = roundMoney(grossWages * Number(settings.sdReemploymentRate || 0) / 100);
  const federalPayrollDeposit = roundMoney(
    federalWithholding + employeeSocialSecurity + employerSocialSecurity +
    employeeMedicare + employerMedicare
  );

  const finance = readFinance();
  const calculatedFinance = calculateFinance(finance);
  const receivedInRange = roundMoney(finance.payments.filter((record) =>
    record.date >= from && record.date <= to
  ).reduce((sum, record) => sum + Number(record.amount || 0), 0));
  const deductions = roundMoney(finance.expenses.filter((record) =>
    record.date >= from && record.date <= to
  ).reduce((sum, record) => sum + Number(record.amount || 0), 0));
  const estimatedProfit = roundMoney(Math.max(0, receivedInRange - deductions - grossWages));
  const federalEstimatedIncomeTax = roundMoney(
    estimatedProfit * Number(settings.federalEstimateRate || 0) / 100
  );
  const reserveTarget = roundMoney(
    receivedInRange * Number(settings.taxReserveRate || 0) / 100
  );
  const contractorFilings = data.filings.filter((record) =>
    record.type === "SD Contractor Excise" &&
    record.periodEnd >= from && record.periodStart <= to
  );
  const contractorExcise = roundMoney(contractorFilings.reduce((sum, record) =>
    sum + Number(record.amount || 0), 0));

  return {
    from,
    to,
    summary: {
      taxableSales,
      salesTaxCollected,
      stateSalesTax,
      municipalSalesTax,
      useTax,
      grossWages,
      federalWithholding,
      employeeSocialSecurity,
      employerSocialSecurity,
      employeeMedicare,
      employerMedicare,
      federalPayrollDeposit,
      futa,
      sdReemployment,
      deductions,
      received: receivedInRange,
      estimatedProfit,
      federalEstimatedIncomeTax,
      contractorExcise,
      reserveTarget,
      reserveBalance: roundMoney(settings.currentReserveBalance || 0),
      reserveDifference: roundMoney(Number(settings.currentReserveBalance || 0) - reserveTarget),
      totalPrepared: roundMoney(
        salesTaxCollected + useTax + federalPayrollDeposit + futa +
        sdReemployment + federalEstimatedIncomeTax + contractorExcise
      ),
      financeNetIncome: calculatedFinance.summary.netIncome
    },
    invoices: invoiceEntries.map(({ invoice, taxableAmount, taxAmount }) => ({
      id: invoice.id,
      number: invoice.number,
      issueDate: invoice.issueDate,
      customer: invoice.customer,
      subtotal: taxableAmount,
      taxRate: invoice.taxRate,
      tax: taxAmount
    })),
    payroll
  };
}

function taxCsv(data, calculated) {
  const escapeCsv = (value) => `"${String(value ?? "").replaceAll("\"", "\"\"")}"`;
  const rows = [
    ["South Dakota Tax Center", `${calculated.from} through ${calculated.to}`],
    [],
    ["Category", "Amount"],
    ["Taxable sales", calculated.summary.taxableSales],
    ["Sales tax collected", calculated.summary.salesTaxCollected],
    ["South Dakota state sales tax", calculated.summary.stateSalesTax],
    ["Municipal sales tax", calculated.summary.municipalSalesTax],
    ["Use tax", calculated.summary.useTax],
    ["Gross wages", calculated.summary.grossWages],
    ["Federal payroll deposit estimate", calculated.summary.federalPayrollDeposit],
    ["FUTA estimate", calculated.summary.futa],
    ["South Dakota reemployment estimate", calculated.summary.sdReemployment],
    ["Federal estimated income tax", calculated.summary.federalEstimatedIncomeTax],
    ["Deductible expenses", calculated.summary.deductions],
    ["Tax reserve target", calculated.summary.reserveTarget],
    [],
    ["Filings"],
    ["Type", "Period start", "Period end", "Due date", "Amount", "Status", "Paid date", "Confirmation"],
    ...data.filings.map((record) => [
      record.type, record.periodStart, record.periodEnd, record.dueDate,
      record.amount, record.status, record.paidDate, record.confirmation
    ])
  ];
  return rows.map((row) => row.map(escapeCsv).join(",")).join("\r\n");
}

function sendTaxPdf(response, data, calculated) {
  const doc = new PDFDocument({
    size: "LETTER",
    margin: 48,
    info: { Title: `Tax Summary ${calculated.from} through ${calculated.to}` }
  });
  response.writeHead(200, {
    "Content-Type": "application/pdf",
    "Content-Disposition": `attachment; filename="tax-summary-${calculated.from}-to-${calculated.to}.pdf"`,
    "Cache-Control": "no-store"
  });
  doc.pipe(response);
  doc.fontSize(18).text(data.settings.businessName || "Business Tax Summary");
  doc.fontSize(10).fillColor("#526068").text(
    `South Dakota Tax Center · ${calculated.from} through ${calculated.to}`
  );
  doc.moveDown().fillColor("#182026");
  const rows = [
    ["Taxable sales", calculated.summary.taxableSales],
    ["Sales tax collected", calculated.summary.salesTaxCollected],
    ["South Dakota state sales tax", calculated.summary.stateSalesTax],
    ["Municipal sales tax", calculated.summary.municipalSalesTax],
    ["Use tax", calculated.summary.useTax],
    ["Gross wages", calculated.summary.grossWages],
    ["Federal payroll deposit estimate", calculated.summary.federalPayrollDeposit],
    ["FUTA estimate", calculated.summary.futa],
    ["South Dakota reemployment estimate", calculated.summary.sdReemployment],
    ["Federal estimated income tax", calculated.summary.federalEstimatedIncomeTax],
    ["Tracked deductions", calculated.summary.deductions],
    ["Tax reserve target", calculated.summary.reserveTarget],
    ["Current tax reserve", calculated.summary.reserveBalance]
  ];
  doc.fontSize(13).text("Prepared Summary").moveDown(0.4);
  for (const [label, amount] of rows) {
    const y = doc.y;
    doc.fontSize(10).text(label, 48, y, { width: 360 });
    doc.text(formatUsd(amount), 408, y, { width: 130, align: "right" });
    doc.moveDown(0.55);
  }
  doc.moveDown().fontSize(13).text("Filing Records").moveDown(0.4);
  if (!data.filings.length) {
    doc.fontSize(10).fillColor("#526068").text("No filing records in the Tax Center.");
  } else {
    for (const filing of data.filings) {
      if (doc.y > 700) doc.addPage();
      doc.fontSize(10).fillColor("#182026").text(
        `${filing.type} · ${filing.status} · ${formatUsd(filing.amount)}`
      );
      doc.fontSize(9).fillColor("#526068").text(
        `${filing.periodStart} through ${filing.periodEnd} · Due ${filing.dueDate}` +
        `${filing.confirmation ? ` · Confirmation ${filing.confirmation}` : ""}`
      );
      doc.moveDown(0.45);
    }
  }
  doc.moveDown().fontSize(8).fillColor("#526068").text(
    "Preparation report only. Verify amounts and filing requirements with a qualified tax professional."
  );
  doc.end();
}

async function handleTaxes(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "taxes")) {
    sendJson(response, 403, { ok: false, message: "Tax Center access required." });
    return;
  }
  const url = new URL(request.url, publicOrigin(request));
  const data = readTaxData();
  const { from, to } = taxDateRange(url);
  if (request.method === "GET") {
    const calculated = calculateTaxCenter(data, from, to);
    if (url.searchParams.get("format") === "pdf") {
      sendTaxPdf(response, data, calculated);
      return;
    }
    if (url.searchParams.get("format") === "csv") {
      response.writeHead(200, {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="tax-summary-${from}-to-${to}.csv"`,
        "Cache-Control": "no-store"
      });
      response.end(taxCsv(data, calculated));
      return;
    }
    sendJson(response, 200, {
      ok: true,
      settings: data.settings,
      filings: [...data.filings].sort((a, b) => a.dueDate.localeCompare(b.dueDate)),
      useTaxItems: [...data.useTaxItems].sort((a, b) => b.date.localeCompare(a.date)),
      ...calculated,
      paymentLinks: {
        irs: "https://www.irs.gov/payments/pay-business-taxes-from-your-bank-account",
        eftps: "https://www.eftps.gov/eftps/",
        southDakota: "https://dor.sd.gov/online-services/",
        sdReemployment: "https://dlr.sd.gov/ra/businesses/default.aspx"
      }
    });
    return;
  }
  if (!["POST", "DELETE"].includes(request.method)) {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const payload = await readJsonBody(request);
  const action = String(payload.action || "");
  if (request.method === "POST" && action === "save-settings") {
    const numericFields = [
      "sdStateSalesTaxRate", "defaultMunicipalRate", "federalEstimateRate",
      "federalWithholdingRate", "socialSecurityRate", "medicareRate", "futaRate",
      "sdReemploymentRate", "contractorExciseRate", "taxReserveRate", "currentReserveBalance"
    ];
    const settings = { ...data.settings };
    for (const field of numericFields) {
      const value = Number(payload.settings?.[field]);
      if (!Number.isFinite(value) || value < 0 || value > (field === "currentReserveBalance" ? 1000000000 : 100)) {
        sendJson(response, 400, { ok: false, message: "Enter valid non-negative tax settings." });
        return;
      }
      settings[field] = roundMoney(value);
    }
    settings.businessName = String(payload.settings?.businessName || "").trim().slice(0, 160);
    settings.einLastFour = String(payload.settings?.einLastFour || "").replace(/\D/g, "").slice(-4);
    settings.accountingMethod = payload.settings?.accountingMethod === "accrual" ? "accrual" : "cash";
    settings.salesTaxFrequency = ["monthly", "quarterly", "annual"].includes(payload.settings?.salesTaxFrequency)
      ? payload.settings.salesTaxFrequency : "monthly";
    data.settings = settings;
    writeTaxData(data);
    logActivity(session, "tax.settings-updated", "Updated Tax Center settings.");
  } else if (request.method === "POST" && action === "save-filing") {
    const allowedTypes = [
      "Federal Estimated Income", "Federal Payroll Deposit", "Form 941",
      "FUTA Form 940", "SD Sales and Use", "SD Reemployment Assistance",
      "SD Contractor Excise", "Other"
    ];
    const existing = data.filings.find((record) => record.id === payload.filing?.id);
    const filing = {
      id: existing?.id || randomBytes(12).toString("hex"),
      type: allowedTypes.includes(payload.filing?.type) ? payload.filing.type : "Other",
      periodStart: validDateOnly(payload.filing?.periodStart),
      periodEnd: validDateOnly(payload.filing?.periodEnd),
      dueDate: validDateOnly(payload.filing?.dueDate),
      amount: roundMoney(Math.max(0, Number(payload.filing?.amount) || 0)),
      status: ["Planned", "Ready", "Filed", "Paid"].includes(payload.filing?.status)
        ? payload.filing.status : "Planned",
      paidDate: validDateOnly(payload.filing?.paidDate),
      confirmation: String(payload.filing?.confirmation || "").trim().slice(0, 160),
      notes: String(payload.filing?.notes || "").trim().slice(0, 2000),
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    if (!filing.periodStart || !filing.periodEnd || !filing.dueDate || filing.periodEnd < filing.periodStart) {
      sendJson(response, 400, { ok: false, message: "Enter a valid filing period and due date." });
      return;
    }
    const index = data.filings.findIndex((record) => record.id === filing.id);
    if (index >= 0) data.filings[index] = filing;
    else data.filings.push(filing);
    writeTaxData(data);
    logActivity(session, index >= 0 ? "tax.filing-updated" : "tax.filing-created",
      `${index >= 0 ? "Updated" : "Created"} ${filing.type} filing.`);
  } else if (request.method === "POST" && action === "add-use-tax") {
    const purchaseAmount = roundMoney(Math.max(0, Number(payload.item?.purchaseAmount) || 0));
    const rate = roundMoney(Math.max(0, Number(payload.item?.rate) || 0));
    const item = {
      id: randomBytes(12).toString("hex"),
      date: validDateOnly(payload.item?.date) || businessToday(),
      vendor: String(payload.item?.vendor || "").trim().slice(0, 160),
      description: String(payload.item?.description || "").trim().slice(0, 240),
      purchaseAmount,
      rate,
      taxAmount: roundMoney(purchaseAmount * rate / 100),
      createdAt: new Date().toISOString(),
      createdBy: session.username
    };
    if (!item.description || !(purchaseAmount > 0)) {
      sendJson(response, 400, { ok: false, message: "Enter the untaxed purchase and amount." });
      return;
    }
    data.useTaxItems.push(item);
    writeTaxData(data);
    logActivity(session, "tax.use-tax-added", `Added use tax item ${item.description}.`);
  } else if (request.method === "DELETE" && action === "delete-filing") {
    data.filings = data.filings.filter((record) => record.id !== payload.id);
    writeTaxData(data);
    logActivity(session, "tax.filing-deleted", "Deleted a tax filing record.");
  } else if (request.method === "DELETE" && action === "delete-use-tax") {
    data.useTaxItems = data.useTaxItems.filter((record) => record.id !== payload.id);
    writeTaxData(data);
    logActivity(session, "tax.use-tax-deleted", "Deleted a use tax item.");
  } else {
    sendJson(response, 400, { ok: false, message: "Unknown Tax Center action." });
    return;
  }
  broadcastAllServiceEvent("dashboard-updated", { area: "taxes" });
  sendJson(response, 200, {
    ok: true,
    settings: data.settings,
    filings: data.filings,
    useTaxItems: data.useTaxItems,
    ...calculateTaxCenter(data, from, to)
  });
}

async function handleTicketMessages(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  const payload = request.method === "POST" ? await readJsonBody(request) : {};
  const url = new URL(request.url, `http://${request.headers.host}`);
  const ticketId = payload.ticketId || url.searchParams.get("ticketId") || "";
  const tickets = readTickets();
  const ticket = tickets.find((record) => record.id === ticketId);
  if (!ticket || (!hasPermission(session, "service-tickets") && !ticketMatchesEmployee(ticket, session))) {
    sendJson(response, 404, { ok: false, message: "Ticket not found." });
    return;
  }
  ticket.internalMessages = Array.isArray(ticket.internalMessages) ? ticket.internalMessages : [];
  if (request.method === "GET") {
    sendJson(response, 200, { ok: true, messages: ticket.internalMessages });
    return;
  }
  if (request.method === "POST") {
    const text = String(payload.message || "").trim();
    if (!text || text.length > 4000) {
      sendJson(response, 400, { ok: false, message: "Enter a message up to 4,000 characters." });
      return;
    }
    const message = {
      id: randomBytes(12).toString("hex"),
      username: session.username,
      employeeName: session.employeeName || session.username,
      role: session.role || "Employee",
      fromOffice: hasPermission(session, "service-tickets"),
      message: text,
      createdAt: new Date().toISOString()
    };
    ticket.internalMessages.push(message);
    writeTickets(tickets);
    logActivity(session, "ticket.message", `Added an internal message to ${ticketLabel(ticket)}.`);
    broadcastAllServiceEvent("tickets-updated", { ticketId: ticket.id });
    if (hasPermission(session, "service-tickets")) notifyAssignedEmployeeOfMessage(ticket, message);
    sendJson(response, 200, { ok: true, message });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function notifyAssignedEmployeeOfMessage(ticket, message) {
  const notifications = readNotifications();
  for (const name of ticketAssignees(ticket)) {
    const assigned = name.toLowerCase();
    const recipient = readUsers().find((user) =>
      String(user.employeeName || "").toLowerCase() === assigned ||
      assigned.split(/\s+/)[0] === String(user.username || "").toLowerCase());
    if (!recipient || recipient.username === message.username) continue;
    const notification = {
      id: randomBytes(12).toString("hex"), username: recipient.username, ticketId: ticket.id,
      title: `New message on ${ticketLabel(ticket)}`,
      message: `${message.employeeName}: ${message.message.slice(0, 120)}`,
      createdAt: new Date().toISOString(), read: false
    };
    notifications.push(notification);
    broadcastServiceEvent(recipient.username, "ticket-updated", { ticketId: ticket.id });
    void sendPushNotification(recipient.username, notification).catch((error) =>
      console.error("Unable to prepare message notification:", error.message));
  }
  writeNotifications(notifications.slice(-2000));
}

function handleCompletionReport(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "service-tickets")) {
    sendJson(response, 403, { ok: false, message: "Service Ticket access required." });
    return;
  }
  const url = new URL(request.url, `http://${request.headers.host}`);
  const ticket = readTickets().find((record) => record.id === url.searchParams.get("ticketId"));
  if (!ticket || (ticket.ticketType || "Service") !== "Service") {
    sendJson(response, 404, { ok: false, message: "Service ticket not found." });
    return;
  }
  if (ticket.status !== "Closed") {
    sendJson(response, 400, { ok: false, message: "Close the ticket before generating its completion report." });
    return;
  }

  const filename = `${ticketLabel(ticket)}-completion-report.pdf`;
  response.writeHead(200, {
    "Content-Type": "application/pdf",
    "Content-Disposition": `attachment; filename="${filename}"`,
    "Cache-Control": "private, no-store"
  });
  const doc = new PDFDocument({ size: "LETTER", margin: 48, info: { Title: `${ticketLabel(ticket)} Completion Report` } });
  doc.pipe(response);
  const logoPath = join(root, "assets", "logo.png");
  if (existsSync(logoPath)) doc.image(logoPath, 48, 38, { width: 58 });
  doc.fontSize(18).fillColor("#182026").text("Huber I.T. Professionals", 120, 48);
  doc.fontSize(10).fillColor("#66727b").text("Service Completion Report", 120, 73);
  doc.moveDown(4);
  doc.fontSize(16).fillColor("#087f8c").text(ticketLabel(ticket));
  doc.fontSize(10).fillColor("#182026");
  reportField(doc, "Customer", [ticket.customer, ticket.company].filter(Boolean).join(" - "));
  reportField(doc, "Contact", [ticket.phone, ticket.email].filter(Boolean).join(" | ") || "Not provided");
  reportField(doc, "Service address", ticket.address || "Not provided");
  reportField(doc, "Service", ticket.serviceType || "Service");
  reportField(doc, "Scheduled", [ticket.scheduledDate, ticket.scheduledTime].filter(Boolean).join(" ") || "Not scheduled");
  reportField(doc, "Completed", ticket.signature?.signedAt
    ? new Date(ticket.signature.signedAt).toLocaleString("en-US") : "Ticket closed");
  reportSection(doc, "Issue and Work Notes", ticket.description || "None");
  reportSection(doc, "Resolution", ticket.resolution || "None");
  reportSection(doc, "Labor", `Total hours: ${ticket.hoursUsed || "0"}\n${
    (ticket.workLogs || []).map((entry) =>
      `${entry.employeeName}: ${entry.hours} hours - ${entry.resolution}`
    ).join("\n") || "No detailed labor entries."
  }`);
  reportSection(doc, "Items Used", (ticket.usedItems || []).map((item) =>
    `${item.name}${item.variationName ? ` - ${item.variationName}` : ""} (${item.sku}) - Quantity ${item.quantity}`
  ).join("\n") || "No items recorded.");
  reportSection(doc, "Attachments", (ticket.attachments || []).map((item) => item.name).join("\n") || "No attachments.");
  if (ticket.signature?.storedName) {
    const signaturePath = resolve(ticketSignaturesPath, ticket.signature.storedName);
    if (signaturePath.startsWith(`${ticketSignaturesPath}${sep}`) && existsSync(signaturePath)) {
      if (doc.y > 590) doc.addPage();
      doc.moveDown().fontSize(12).fillColor("#182026").text("Customer Signature");
      doc.image(signaturePath, 48, doc.y + 8, { fit: [260, 110] });
      doc.moveDown(8).fontSize(9).fillColor("#66727b")
        .text(`Signed by ${ticket.signature.signedBy || ticket.customer} on ${new Date(ticket.signature.signedAt).toLocaleString("en-US")}`);
    }
  }
  doc.end();
  logActivity(session, "ticket.report", `Generated completion report for ${ticketLabel(ticket)}.`);
}

function reportField(doc, label, value) {
  doc.font("Helvetica-Bold").text(`${label}: `, { continued: true })
    .font("Helvetica").text(String(value || ""));
}

function reportSection(doc, title, text) {
  if (doc.y > 650) doc.addPage();
  doc.moveDown().font("Helvetica-Bold").fontSize(11).fillColor("#182026").text(title);
  doc.moveDown(0.25).font("Helvetica").fontSize(9.5).fillColor("#303b40").text(String(text || ""), {
    lineGap: 2
  });
}

function readPresentations() {
  if (!existsSync(presentationsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(presentationsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writePresentations(records) {
  writeFileSync(presentationsPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function exportedFilePath(folderName, title, id) {
  const folder = join(documentsPath, folderName);
  mkdirSync(folder, { recursive: true, mode: 0o700 });
  removeExportedFile(folderName, id);
  const suffix = `--${id}.pdf`;
  return join(folder, `${safeFilenamePart(title)}${suffix}`);
}

function removeExportedFile(folderName, id) {
  const folder = join(documentsPath, folderName);
  if (!existsSync(folder)) return;
  const suffix = `--${id}.pdf`;
  for (const name of readdirSync(folder)) {
    if (name.endsWith(suffix)) unlinkSync(join(folder, name));
  }
}

function finishPdf(doc, filePath) {
  return new Promise((resolvePdf, rejectPdf) => {
    const output = createWriteStream(filePath, { mode: 0o600 });
    output.on("finish", resolvePdf);
    output.on("error", rejectPdf);
    doc.on("error", rejectPdf);
    doc.pipe(output);
    doc.end();
  });
}

function presentationImageFile(src) {
  const id = new URL(String(src || ""), "http://localhost").searchParams.get("id") || "";
  if (!/^[a-f0-9]{24}$/.test(id)) return "";
  const name = readdirSync(presentationImagesPath).find((file) => file.startsWith(`${id}.`));
  return name ? join(presentationImagesPath, name) : "";
}

async function exportPresentationToFileBrowser(presentation) {
  const filePath = exportedFilePath("Presentations", presentation.title, presentation.id);
  const doc = new PDFDocument({ size: [960, 540], margin: 0, autoFirstPage: false,
    info: { Title: presentation.title, Author: "Huber I.T. Professionals" } });
  const logoPath = join(root, "assets", "logo.png");
  for (const slide of presentation.slides) {
    doc.addPage({ size: [960, 540], margin: 0 });
    doc.rect(0, 0, 960, 540).fill(slide.background || "#101719");
    if (slide.showLogo && existsSync(logoPath)) {
      doc.image(logoPath, 32, 24, { fit: [72, 52], align: "center", valign: "center" });
      doc.rect(32, 88, 896, 3).fill("#28a9b3");
    }
    for (const item of slide.elements) {
      doc.save();
      if (item.rotation) doc.rotate(item.rotation, { origin: [item.x + item.w / 2, item.y + item.h / 2] });
      if (item.type === "shape") {
        doc.roundedRect(item.x, item.y, item.w, item.h, item.radius || 0)
          .fillAndStroke(item.fill || "#087f8c", item.borderColor || item.fill || "#087f8c");
      } else if (item.type === "text") {
        doc.font(Number(item.fontWeight) >= 700 ? "Helvetica-Bold" : "Helvetica")
          .fontSize(item.fontSize || 32).fillColor(item.color || "#edf3f5")
          .text(item.text || "", item.x, item.y + 3, { width: item.w, height: item.h,
            align: item.textAlign || "left", lineGap: 0 });
      } else if (item.type === "image") {
        const imagePath = presentationImageFile(item.src);
        if (imagePath && existsSync(imagePath)) {
          try { doc.image(imagePath, item.x, item.y, { fit: [item.w, item.h], align: "center", valign: "center" }); } catch {}
        }
      }
      doc.restore();
    }
  }
  await finishPdf(doc, filePath);
  broadcastAllServiceEvent("documents-updated", { path: "Presentations" });
  return `Presentations/${filePath.split(sep).pop()}`;
}

function cleanPresentationElement(element) {
  const type = ["text", "shape", "image"].includes(element?.type) ? element.type : "text";
  const number = (value, fallback, min, max) => Math.min(max, Math.max(min,
    Number.isFinite(Number(value)) ? Number(value) : fallback));
  const clean = {
    id: /^[a-zA-Z0-9_-]{1,80}$/.test(String(element?.id || ""))
      ? String(element.id) : randomBytes(8).toString("hex"),
    type,
    x: number(element?.x, 80, 0, 940),
    y: number(element?.y, 100, 0, 520),
    w: number(element?.w, 400, 20, 960),
    h: number(element?.h, 90, 20, 540),
    rotation: number(element?.rotation, 0, -180, 180)
  };
  if (type === "text") Object.assign(clean, {
    text: String(element?.text || "").slice(0, 3000),
    fontSize: number(element?.fontSize, 32, 8, 160),
    color: /^#[0-9a-f]{6}$/i.test(String(element?.color)) ? element.color : "#edf3f5",
    fontWeight: ["400", "600", "700", "800", "900"].includes(String(element?.fontWeight))
      ? String(element.fontWeight) : "600",
    textAlign: ["left", "center", "right"].includes(element?.textAlign)
      ? element.textAlign : "left"
  });
  if (type === "shape") Object.assign(clean, {
    fill: /^#[0-9a-f]{6}$/i.test(String(element?.fill)) ? element.fill : "#087f8c",
    borderColor: /^#[0-9a-f]{6}$/i.test(String(element?.borderColor))
      ? element.borderColor : "#28a9b3",
    borderWidth: number(element?.borderWidth, 0, 0, 20),
    radius: number(element?.radius, 4, 0, 80)
  });
  if (type === "image") Object.assign(clean, {
    src: String(element?.src || "").startsWith("/api/presentations/image?id=")
      ? String(element.src).slice(0, 200) : "",
    fit: ["contain", "cover"].includes(element?.fit) ? element.fit : "contain"
  });
  return clean;
}

async function handlePresentations(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "presentations") && !hasPermission(session, "office-suite")) {
    sendJson(response, 403, { ok: false, message: "Presentations access required." });
    return;
  }
  const url = new URL(request.url, `http://${request.headers.host}`);
  if (request.method === "GET" && url.pathname === "/api/presentations/image") {
    const id = String(url.searchParams.get("id") || "");
    const name = readdirSync(presentationImagesPath).find((file) => file.startsWith(`${id}.`));
    const filePath = name && join(presentationImagesPath, name);
    if (!/^[a-f0-9]{24}$/.test(id) || !filePath || !existsSync(filePath)) {
      sendJson(response, 404, { ok: false, message: "Presentation image not found." });
      return;
    }
    response.writeHead(200, {
      "Content-Type": mimeTypes[extname(filePath)] || "application/octet-stream",
      "Content-Length": statSync(filePath).size,
      "Cache-Control": "private, max-age=3600",
      "X-Content-Type-Options": "nosniff"
    });
    createReadStream(filePath).pipe(response);
    return;
  }
  if (request.method === "POST" && url.pathname === "/api/presentations/image") {
    const extensionByType = {
      "image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp"
    };
    const extension = extensionByType[String(request.headers["content-type"] || "").split(";")[0]];
    if (!extension) {
      sendJson(response, 400, { ok: false, message: "Choose a PNG, JPG, or WebP image." });
      return;
    }
    const id = randomBytes(12).toString("hex");
    const file = await readBinaryBody(request, 15 * 1024 * 1024);
    writeFileSync(join(presentationImagesPath, `${id}${extension}`), file, { mode: 0o600, flag: "wx" });
    sendJson(response, 200, { ok: true, id, src: `/api/presentations/image?id=${id}` });
    return;
  }
  const records = readPresentations();
  if (request.method === "GET" && url.pathname === "/api/presentations") {
    const id = String(url.searchParams.get("id") || "");
    if (id) {
      const presentation = records.find((record) => record.id === id);
      if (!presentation) {
        sendJson(response, 404, { ok: false, message: "Presentation not found." });
        return;
      }
      sendJson(response, 200, { ok: true, presentation });
      return;
    }
    sendJson(response, 200, {
      ok: true,
      presentations: records.map(({ id, title, slides, updatedAt, updatedBy }) => ({
        id, title, slideCount: slides.length, updatedAt, updatedBy
      })).sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)))
    });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST" && url.pathname === "/api/presentations") {
    const existing = records.find((record) => record.id === payload.id);
    const title = String(payload.title || "Untitled Presentation").trim().slice(0, 120) ||
      "Untitled Presentation";
    const sourceSlides = Array.isArray(payload.slides) ? payload.slides.slice(0, 100) : [];
    const slides = (sourceSlides.length ? sourceSlides : [{}]).map((slide) => ({
      id: /^[a-zA-Z0-9_-]{1,80}$/.test(String(slide?.id || ""))
        ? String(slide.id) : randomBytes(8).toString("hex"),
      background: /^#[0-9a-f]{6}$/i.test(String(slide?.background))
        ? slide.background : "#101719",
      showLogo: slide?.showLogo !== false,
      elements: (Array.isArray(slide?.elements) ? slide.elements : []).slice(0, 100)
        .map(cleanPresentationElement)
    }));
    const now = new Date().toISOString();
    const presentation = {
      id: existing?.id || randomBytes(12).toString("hex"),
      title,
      slides,
      createdAt: existing?.createdAt || now,
      createdBy: existing?.createdBy || session.username,
      updatedAt: now,
      updatedBy: session.username
    };
    const index = records.findIndex((record) => record.id === presentation.id);
    if (index >= 0) records[index] = presentation;
    else records.push(presentation);
    writePresentations(records);
    let exportPath = "", exportWarning = "";
    try {
      exportPath = await exportPresentationToFileBrowser(presentation);
    } catch (error) {
      exportWarning = `Presentation saved, but its File Browser PDF could not be updated: ${error.message}`;
    }
    logActivity(session, index >= 0 ? "presentation.updated" : "presentation.created",
      `${index >= 0 ? "Updated" : "Created"} presentation ${presentation.title}.`);
    sendJson(response, 200, { ok: true, presentation, exportPath, warning: exportWarning });
    return;
  }
  if (request.method === "DELETE" && url.pathname === "/api/presentations") {
    const removed = records.find((record) => record.id === payload.id);
    if (!removed) {
      sendJson(response, 404, { ok: false, message: "Presentation not found." });
      return;
    }
    writePresentations(records.filter((record) => record.id !== removed.id));
    removeExportedFile("Presentations", removed.id);
    logActivity(session, "presentation.deleted", `Deleted presentation ${removed.title}.`);
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readSpreadsheets() {
  if (!existsSync(spreadsheetsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(spreadsheetsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function cleanSpreadsheet(value, existing = {}) {
  const validCell = /^[A-Z]{1,2}[1-9][0-9]{0,2}$/;
  const cleanFormat = (format = {}) => ({
    bold: Boolean(format.bold),
    italic: Boolean(format.italic),
    align: ["left", "center", "right"].includes(format.align) ? format.align : "left",
    number: ["general", "currency", "percent"].includes(format.number) ? format.number : "general",
    fill: /^#[0-9a-f]{6}$/i.test(String(format.fill || "")) ? format.fill : "",
    color: /^#[0-9a-f]{6}$/i.test(String(format.color || "")) ? format.color : ""
  });
  const sheets = (Array.isArray(value?.sheets) ? value.sheets : []).slice(0, 30).map((sheet, index) => {
    const cells = {};
    for (const [address, cell] of Object.entries(sheet?.cells || {}).slice(0, 20000)) {
      if (!validCell.test(address)) continue;
      const text = String(cell?.value ?? "").slice(0, 5000);
      const format = cleanFormat(cell?.format);
      if (text || Object.values(format).some(Boolean)) cells[address] = { value: text, format };
    }
    return {
      id: /^[a-zA-Z0-9_-]{1,80}$/.test(String(sheet?.id || ""))
        ? String(sheet.id) : randomBytes(8).toString("hex"),
      name: String(sheet?.name || `Sheet ${index + 1}`).trim().slice(0, 50) || `Sheet ${index + 1}`,
      cells
    };
  });
  if (!sheets.length) sheets.push({ id: randomBytes(8).toString("hex"), name: "Sheet 1", cells: {} });
  const now = new Date().toISOString();
  return {
    id: existing.id || String(value?.id || "").trim() || randomBytes(12).toString("hex"),
    title: String(value?.title || "Untitled Workbook").trim().slice(0, 120) || "Untitled Workbook",
    sheets,
    activeSheetId: sheets.some((sheet) => sheet.id === value?.activeSheetId)
      ? value.activeSheetId : sheets[0].id,
    createdAt: existing.createdAt || now,
    createdBy: existing.createdBy || "",
    updatedAt: now,
    updatedBy: ""
  };
}

function spreadsheetCsv(record) {
  const sheet = record.sheets.find((item) => item.id === record.activeSheetId) || record.sheets[0];
  const entries = Object.entries(sheet?.cells || {});
  let maxRow = 1, maxColumn = 1;
  const columnNumber = (letters) => [...letters].reduce((total, char) => total * 26 + char.charCodeAt(0) - 64, 0);
  for (const [address] of entries) {
    const match = address.match(/^([A-Z]+)(\d+)$/);
    if (!match) continue;
    maxColumn = Math.max(maxColumn, columnNumber(match[1]));
    maxRow = Math.max(maxRow, Number(match[2]));
  }
  const columnLetters = (number) => {
    let result = "";
    while (number > 0) { number -= 1; result = String.fromCharCode(65 + number % 26) + result; number = Math.floor(number / 26); }
    return result;
  };
  const quote = (value) => {
    const text = String(value ?? "");
    return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };
  return Array.from({ length: maxRow }, (_, row) =>
    Array.from({ length: maxColumn }, (_, column) => quote(sheet.cells?.[`${columnLetters(column + 1)}${row + 1}`]?.value || "")).join(",")
  ).join("\n");
}

function exportSpreadsheetToFileBrowser(record) {
  const folder = join(documentsPath, "Spreadsheets");
  mkdirSync(folder, { recursive: true, mode: 0o700 });
  const suffix = `--${record.id}.csv`;
  for (const name of readdirSync(folder)) if (name.endsWith(suffix)) unlinkSync(join(folder, name));
  const fileName = `${safeFilenamePart(record.title)}${suffix}`;
  writeFileSync(join(folder, fileName), spreadsheetCsv(record), { mode: 0o600 });
  broadcastAllServiceEvent("documents-updated", { path: "Spreadsheets" });
  return `Spreadsheets/${fileName}`;
}

async function handleSpreadsheets(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "office-suite") && !hasPermission(session, "spreadsheets")) {
    sendJson(response, 403, { ok: false, message: "Huber Office Suite access required." });
    return;
  }
  const url = new URL(request.url, `http://${request.headers.host}`);
  const records = readSpreadsheets();
  if (request.method === "GET") {
    const id = String(url.searchParams.get("id") || "");
    if (id) {
      const workbook = records.find((record) => record.id === id);
      if (!workbook) return sendJson(response, 404, { ok: false, message: "Workbook not found." });
      return sendJson(response, 200, { ok: true, workbook });
    }
    return sendJson(response, 200, { ok: true, workbooks: records.map(({ id, title, sheets, updatedAt, updatedBy }) => ({
      id, title, sheetCount: sheets?.length || 0, updatedAt, updatedBy
    })).sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt))) });
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const index = records.findIndex((record) => record.id === String(payload.id || ""));
    const workbook = cleanSpreadsheet(payload, index >= 0 ? records[index] : {});
    workbook.createdBy = index >= 0 ? records[index].createdBy : session.username;
    workbook.updatedBy = session.username;
    if (index >= 0) records[index] = workbook; else records.push(workbook);
    writeFileSync(spreadsheetsPath, JSON.stringify(records, null, 2), { mode: 0o600 });
    const exportPath = exportSpreadsheetToFileBrowser(workbook);
    logActivity(session, index >= 0 ? "spreadsheet.updated" : "spreadsheet.created",
      `${index >= 0 ? "Updated" : "Created"} workbook ${workbook.title}.`);
    broadcastAllServiceEvent("spreadsheets-updated", { id: workbook.id });
    return sendJson(response, 200, { ok: true, workbook, exportPath });
  }
  if (request.method === "DELETE") {
    const removed = records.find((record) => record.id === String(payload.id || ""));
    if (!removed) return sendJson(response, 404, { ok: false, message: "Workbook not found." });
    writeFileSync(spreadsheetsPath, JSON.stringify(records.filter((record) => record.id !== removed.id), null, 2), { mode: 0o600 });
    const folder = join(documentsPath, "Spreadsheets");
    if (existsSync(folder)) for (const name of readdirSync(folder)) if (name.endsWith(`--${removed.id}.csv`)) unlinkSync(join(folder, name));
    logActivity(session, "spreadsheet.deleted", `Deleted workbook ${removed.title}.`);
    broadcastAllServiceEvent("spreadsheets-updated", { id: removed.id, deleted: true });
    return sendJson(response, 200, { ok: true });
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readFloorPlans() {
  if (!existsSync(floorPlansPath)) return [];
  try {
    const records = JSON.parse(readFileSync(floorPlansPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeFloorPlans(records) {
  writeFileSync(floorPlansPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function cleanFloorPlanObject(source) {
  const types = ["wall", "room", "door", "window", "label", "callout", "dimension", "column", "stairs", "network-device", "cable"];
  const type = types.includes(source?.type) ? source.type : "label";
  const number = (value, fallback = 0, min = -20000, max = 20000) =>
    Math.min(max, Math.max(min, Number.isFinite(Number(value)) ? Number(value) : fallback));
  const color = (value, fallback) => /^#[0-9a-f]{6}$/i.test(String(value || "")) ? value : fallback;
  const clean = {
    id: /^[a-zA-Z0-9_-]{1,80}$/.test(String(source?.id || ""))
      ? String(source.id) : randomBytes(8).toString("hex"),
    type,
    layer: ["Architecture", "Openings", "Annotations", "Equipment", "Cabling"].includes(source?.layer)
      ? source.layer : "Architecture",
    locked: source?.locked === true
  };
  if (["wall", "dimension"].includes(type)) Object.assign(clean, {
    x1: number(source?.x1), y1: number(source?.y1), x2: number(source?.x2, 120), y2: number(source?.y2),
    thickness: number(source?.thickness, type === "wall" ? 6 : 1, 1, 36),
    color: color(source?.color, type === "wall" ? "#263238" : "#087f8c")
  });
  if (["room", "stairs"].includes(type)) Object.assign(clean, {
    x: number(source?.x), y: number(source?.y), w: number(source?.w, 120, 6, 10000),
    h: number(source?.h, 120, 6, 10000), label: String(source?.label || "").slice(0, 120),
    fill: color(source?.fill, type === "room" ? "#e7f1f3" : "#dce5e8"),
    color: color(source?.color, "#607d86")
  });
  if (["door", "window"].includes(type)) Object.assign(clean, {
    x: number(source?.x), y: number(source?.y), width: number(source?.width, type === "door" ? 36 : 48, 12, 240),
    rotation: number(source?.rotation, 0, -360, 360), color: color(source?.color, "#087f8c")
  });
  if (type === "door") Object.assign(clean, {
    doorStyle: ["single", "double", "sliding"].includes(source?.doorStyle) ? source.doorStyle : "single",
    swing: ["inward", "outward"].includes(source?.swing) ? source.swing : "inward",
    hinge: ["left", "right"].includes(source?.hinge) ? source.hinge : "left"
  });
  if (type === "label") Object.assign(clean, {
    x: number(source?.x), y: number(source?.y), text: String(source?.text || "Room").slice(0, 500),
    fontSize: number(source?.fontSize, 18, 6, 144), color: color(source?.color, "#182026")
  });
  if (type === "callout") Object.assign(clean, {
    x: number(source?.x), y: number(source?.y), targetX: number(source?.targetX), targetY: number(source?.targetY),
    text: String(source?.text || "Add note").slice(0, 1000), width: number(source?.width, 180, 72, 600),
    fontSize: number(source?.fontSize, 14, 8, 48), fill: color(source?.fill, "#ffffff"),
    color: color(source?.color, "#087f8c")
  });
  if (type === "column") Object.assign(clean, {
    x: number(source?.x), y: number(source?.y), size: number(source?.size, 12, 3, 120),
    fill: color(source?.fill, "#455a64"), color: color(source?.color, "#263238")
  });
  if (type === "network-device") Object.assign(clean, {
    x: number(source?.x), y: number(source?.y),
    equipmentType: ["camera", "access-reader", "door-controller", "network-switch", "wireless-ap", "data-jack", "nvr", "rack", "smoke-detector", "air-quality-sensor", "motion-sensor", "all-in-one-sensor", "relay", "ai-speaker", "siren"].includes(source?.equipmentType)
      ? source.equipmentType : "camera",
    label: String(source?.label || "").slice(0, 120),
    autoLabel: source?.autoLabel !== false,
    deviceNumber: number(source?.deviceNumber, 0, 0, 9999),
    coverageRadius: number(source?.coverageRadius, 0, 0, 2400),
    coverageAngle: number(source?.coverageAngle, 0, 0, 180),
    mount: ["wall", "ceiling"].includes(source?.mount) ? source.mount
      : ["camera", "wireless-ap", "smoke-detector", "air-quality-sensor", "motion-sensor", "all-in-one-sensor", "ai-speaker", "siren"].includes(source?.equipmentType) ? "ceiling" : "wall",
    rotation: number(source?.rotation, 0, -360, 360),
    color: color(source?.color, "#087f8c")
  });
  if (type === "cable") Object.assign(clean, {
    points: (Array.isArray(source?.points) ? source.points : []).slice(0, 250).map((point) => ({
      x: number(point?.x), y: number(point?.y),
      deviceId: /^[a-zA-Z0-9_-]{1,80}$/.test(String(point?.deviceId || "")) ? String(point.deviceId) : ""
    })),
    cableType: ["cat5e", "cat6", "fiber", "coax", "speaker", "access-control"].includes(source?.cableType)
      ? source.cableType : "cat5e",
    label: String(source?.label || "").slice(0, 120),
    thickness: number(source?.thickness, 2, 1, 12),
    color: color(source?.color, "#1976d2")
  });
  return clean;
}

function cleanFloorPlanLayers(source) {
  return {
    Architecture: source?.Architecture !== false,
    Openings: source?.Openings !== false,
    Annotations: source?.Annotations !== false,
    Equipment: source?.Equipment !== false,
    Cabling: source?.Cabling !== false,
    coverage: source?.coverage !== false
  };
}

function cleanFloorPlanProject(source) {
  return {
    buildingId: /^[a-zA-Z0-9_-]{1,80}$/.test(String(source?.buildingId || ""))
      ? String(source.buildingId) : randomBytes(8).toString("hex"),
    buildingName: String(source?.buildingName || "").trim().slice(0, 140),
    floorName: String(source?.floorName || "First Floor").trim().slice(0, 80) || "First Floor",
    floorOrder: Math.min(200, Math.max(-20, Math.round(Number(source?.floorOrder) || 1))),
    contractTicketId: /^[a-zA-Z0-9_-]{1,80}$/.test(String(source?.contractTicketId || ""))
      ? String(source.contractTicketId) : "",
    contractTicketNumber: String(source?.contractTicketNumber || "").trim().slice(0, 40),
    customerSite: String(source?.customerSite || "").trim().slice(0, 140)
  };
}

function createFloorPlanFromLidar(payload, session) {
  const metersToInches = 39.3700787402;
  const number = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
  const safeArray = (value, limit) => Array.isArray(value) ? value.slice(0, limit) : [];
  const rooms = safeArray(payload?.rooms, 100);
  const staged = [];
  const bounds = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity };

  const surfaceGeometry = (surface) => {
    const dimensions = safeArray(surface?.dimensions, 3).map((value) => number(value));
    const transform = safeArray(surface?.transform, 16).map((value) => number(value));
    if (dimensions.length !== 3 || transform.length !== 16 || dimensions[0] <= 0) return null;
    const centerX = transform[12] * metersToInches;
    const centerY = transform[14] * metersToInches;
    let axisX = transform[0];
    let axisY = transform[2];
    const magnitude = Math.hypot(axisX, axisY) || 1;
    axisX /= magnitude;
    axisY /= magnitude;
    const width = dimensions[0] * metersToInches;
    return {
      id: /^[a-zA-Z0-9_-]{1,80}$/.test(String(surface?.id || ""))
        ? String(surface.id) : randomBytes(8).toString("hex"),
      centerX,
      centerY,
      axisX,
      axisY,
      width,
      rotation: Math.atan2(axisY, axisX) * 180 / Math.PI,
      x1: centerX - axisX * width / 2,
      y1: centerY - axisY * width / 2,
      x2: centerX + axisX * width / 2,
      y2: centerY + axisY * width / 2
    };
  };
  const extendBounds = (...points) => {
    for (const point of points) {
      bounds.minX = Math.min(bounds.minX, point.x);
      bounds.minY = Math.min(bounds.minY, point.y);
      bounds.maxX = Math.max(bounds.maxX, point.x);
      bounds.maxY = Math.max(bounds.maxY, point.y);
    }
  };

  for (const [roomIndex, room] of rooms.entries()) {
    const roomWalls = [];
    for (const surface of safeArray(room?.walls, 1000)) {
      const geometry = surfaceGeometry(surface);
      if (!geometry) continue;
      roomWalls.push(geometry);
      extendBounds({ x: geometry.x1, y: geometry.y1 }, { x: geometry.x2, y: geometry.y2 });
      staged.push({
        id: `lidar_wall_${geometry.id}`,
        type: "wall",
        layer: "Architecture",
        x1: geometry.x1,
        y1: geometry.y1,
        x2: geometry.x2,
        y2: geometry.y2,
        thickness: 6,
        color: "#263238"
      });
    }
    const addOpening = (surface, type) => {
      const geometry = surfaceGeometry(surface);
      if (!geometry) return;
      extendBounds({ x: geometry.x1, y: geometry.y1 }, { x: geometry.x2, y: geometry.y2 });
      staged.push({
        id: `lidar_${type}_${geometry.id}`,
        type,
        layer: "Openings",
        x: geometry.centerX,
        y: geometry.centerY,
        width: geometry.width,
        rotation: geometry.rotation,
        color: "#087f8c",
        ...(type === "door" ? { doorStyle: "single", swing: "inward", hinge: "left" } : {})
      });
    };
    for (const surface of safeArray(room?.doors, 500)) addOpening(surface, "door");
    for (const surface of safeArray(room?.windows, 500)) addOpening(surface, "window");
    if (roomWalls.length) {
      const centerX = roomWalls.reduce((total, wall) => total + wall.centerX, 0) / roomWalls.length;
      const centerY = roomWalls.reduce((total, wall) => total + wall.centerY, 0) / roomWalls.length;
      staged.push({
        id: `lidar_room_${roomIndex + 1}_${randomBytes(4).toString("hex")}`,
        type: "label",
        layer: "Annotations",
        x: centerX,
        y: centerY,
        text: String(room?.name || `Room ${roomIndex + 1}`).trim().slice(0, 120) || `Room ${roomIndex + 1}`,
        fontSize: 18,
        color: "#182026"
      });
    }
  }

  if (!staged.some((object) => object.type === "wall") || !Number.isFinite(bounds.minX)) {
    const error = new Error("The LiDAR scan did not contain any usable walls.");
    error.statusCode = 400;
    throw error;
  }

  const margin = 120;
  const offsetX = margin - bounds.minX;
  const offsetY = margin - bounds.minY;
  const objects = staged.map((object) => {
    const shifted = { ...object };
    if ("x" in shifted) shifted.x += offsetX;
    if ("y" in shifted) shifted.y += offsetY;
    if ("x1" in shifted) shifted.x1 += offsetX;
    if ("y1" in shifted) shifted.y1 += offsetY;
    if ("x2" in shifted) shifted.x2 += offsetX;
    if ("y2" in shifted) shifted.y2 += offsetY;
    return cleanFloorPlanObject(shifted);
  });
  const now = new Date().toISOString();
  const title = String(payload?.title || "LiDAR Floor Plan").trim().slice(0, 140) || "LiDAR Floor Plan";
  return {
    id: randomBytes(12).toString("hex"),
    title,
    canvas: {
      width: Math.min(10000, Math.max(600, Math.ceil((bounds.maxX - bounds.minX + margin * 2) / 12) * 12)),
      height: Math.min(10000, Math.max(600, Math.ceil((bounds.maxY - bounds.minY + margin * 2) / 12) * 12)),
      grid: 12,
      unit: "ft",
      showLegend: true
    },
    objects,
    layers: cleanFloorPlanLayers({ coverage: false }),
    project: cleanFloorPlanProject({
      buildingName: payload?.buildingName,
      floorName: payload?.floorName,
      floorOrder: payload?.floorOrder
    }),
    revisions: [],
    topology: cleanFloorPlanTopology({}, objects),
    importSource: {
      type: "iphone-roomplan",
      capturedAt: Number.isFinite(Date.parse(payload?.capturedAt)) ? new Date(payload.capturedAt).toISOString() : now,
      deviceName: String(payload?.deviceName || "iPhone LiDAR").trim().slice(0, 100),
      roomCount: rooms.length
    },
    createdAt: now,
    createdBy: session.username,
    updatedAt: now,
    updatedBy: session.username
  };
}

function cleanFloorPlanRevisions(source) {
  return (Array.isArray(source) ? source : []).slice(-20).map((revision) => {
    const snapshotObjects = (Array.isArray(revision?.snapshot?.objects) ? revision.snapshot.objects : [])
      .slice(0, 3000).map(cleanFloorPlanObject);
    return {
      id: /^[a-zA-Z0-9_-]{1,80}$/.test(String(revision?.id || ""))
        ? String(revision.id) : randomBytes(8).toString("hex"),
      label: String(revision?.label || "Revision").trim().slice(0, 40) || "Revision",
      notes: String(revision?.notes || "").trim().slice(0, 240),
      createdAt: Number.isFinite(Date.parse(revision?.createdAt))
        ? new Date(revision.createdAt).toISOString() : new Date().toISOString(),
      snapshot: {
        canvas: {
          width: Math.min(10000, Math.max(300, Number(revision?.snapshot?.canvas?.width) || 1440)),
          height: Math.min(10000, Math.max(300, Number(revision?.snapshot?.canvas?.height) || 960)),
          grid: Math.min(120, Math.max(3, Number(revision?.snapshot?.canvas?.grid) || 12)),
          unit: ["in", "ft"].includes(revision?.snapshot?.canvas?.unit) ? revision.snapshot.canvas.unit : "ft",
          showLegend: revision?.snapshot?.canvas?.showLegend !== false
        },
        objects: snapshotObjects,
        layers: cleanFloorPlanLayers(revision?.snapshot?.layers),
        project: cleanFloorPlanProject(revision?.snapshot?.project),
        topology: cleanFloorPlanTopology(revision?.snapshot?.topology, snapshotObjects)
      }
    };
  });
}

function cleanFloorPlanTopology(source, objects = []) {
  const safeId = (value) => /^[a-zA-Z0-9_-]{1,80}$/.test(String(value || ""))
    ? String(value) : randomBytes(8).toString("hex");
  const racks = (Array.isArray(source?.racks) ? source.racks : []).slice(0, 50).map((rack) => ({
    id: safeId(rack?.id),
    name: String(rack?.name || "Network Rack").trim().slice(0, 100) || "Network Rack"
  }));
  const rackIds = new Set(racks.map((rack) => rack.id));
  const switches = (Array.isArray(source?.switches) ? source.switches : []).slice(0, 200).map((networkSwitch) => ({
    id: safeId(networkSwitch?.id),
    rackId: rackIds.has(String(networkSwitch?.rackId || "")) ? String(networkSwitch.rackId) : racks[0]?.id || "",
    name: String(networkSwitch?.name || "Network Switch").trim().slice(0, 100) || "Network Switch",
    category: ["switch", "gateway", "super-link", "ups"].includes(networkSwitch?.category) ? networkSwitch.category : "switch",
    model: String(networkSwitch?.model || "").trim().slice(0, 120),
    portCount: Math.min(networkSwitch?.category === "ups" ? 16 : 96, Math.max(2, Math.round(Number(networkSwitch?.portCount) || (networkSwitch?.category === "ups" ? 8 : 24))))
  })).filter((networkSwitch) => networkSwitch.rackId);
  const switchMap = new Map(switches.map((networkSwitch) => [networkSwitch.id, networkSwitch]));
  const deviceIds = new Set(objects.filter((item) => item.type === "network-device" && !["network-switch", "rack"].includes(item.equipmentType)).map((item) => item.id));
  const occupied = new Set();
  const assignments = [];
  for (const assignment of (Array.isArray(source?.assignments) ? source.assignments : []).slice(0, 3000)) {
    const deviceId = String(assignment?.deviceId || "");
    const switchId = String(assignment?.switchId || "");
    const networkSwitch = switchMap.get(switchId);
    const port = Math.round(Number(assignment?.port));
    const key = `${switchId}:${port}`;
    if (!deviceIds.has(deviceId) || !networkSwitch || networkSwitch.category === "ups" || port < 1 || port > networkSwitch.portCount || occupied.has(key)) continue;
    occupied.add(key);
    assignments.push({ deviceId, switchId, port });
  }
  const links = [];
  const cleanLinkPort = (value, equipment) => {
    const text = String(value || "").toLowerCase();
    if (["sfp1", "sfp2"].includes(text)) return text;
    const port = Math.round(Number(value));
    return port >= 1 && port <= equipment.portCount ? String(port) : "";
  };
  for (const link of (Array.isArray(source?.links) ? source.links : []).slice(0, 1000)) {
    const fromId = String(link?.fromId || "");
    const toId = String(link?.toId || "");
    const from = switchMap.get(fromId);
    const to = switchMap.get(toId);
    const fromPort = from ? cleanLinkPort(link?.fromPort, from) : "";
    const toPort = to ? cleanLinkPort(link?.toPort, to) : "";
    const fromKey = `${fromId}:${fromPort}`;
    const toKey = `${toId}:${toPort}`;
    if (!from || !to || from.category === "ups" || to.category === "ups" || fromId === toId || !fromPort || !toPort || occupied.has(fromKey) || occupied.has(toKey)) continue;
    occupied.add(fromKey);
    occupied.add(toKey);
    links.push({
      id: safeId(link?.id), fromId, fromPort, toId, toPort,
      type: ["cat6", "fiber", "sfp-dac"].includes(link?.type) ? link.type : "cat6"
    });
  }
  const powerLinks = [];
  const poweredDevices = new Set();
  const occupiedOutlets = new Set();
  for (const powerLink of (Array.isArray(source?.powerLinks) ? source.powerLinks : []).slice(0, 1000)) {
    const deviceId = String(powerLink?.deviceId || "");
    const upsId = String(powerLink?.upsId || "");
    const device = switchMap.get(deviceId);
    const ups = switchMap.get(upsId);
    const outlet = Math.round(Number(powerLink?.outlet));
    const outletKey = `${upsId}:${outlet}`;
    if (!device || !ups || device.category === "ups" || ups.category !== "ups" || outlet < 1 || outlet > ups.portCount || poweredDevices.has(deviceId) || occupiedOutlets.has(outletKey)) continue;
    poweredDevices.add(deviceId);
    occupiedOutlets.add(outletKey);
    powerLinks.push({ id: safeId(powerLink?.id), deviceId, upsId, outlet });
  }
  return { racks, switches, assignments, links, powerLinks };
}

function mergeFloorPlanTopologies(plans = [], objects = []) {
  const uniqueBy = (items, key) => [...new Map(items.map((item) => [key(item), item])).values()];
  const topologies = plans.map((plan) => plan?.topology).filter(Boolean);
  return cleanFloorPlanTopology({
    racks: uniqueBy(topologies.flatMap((topology) => topology.racks || []), (item) => item.id),
    switches: uniqueBy(topologies.flatMap((topology) => topology.switches || []), (item) => item.id),
    assignments: uniqueBy(topologies.flatMap((topology) => topology.assignments || []), (item) => item.deviceId),
    links: uniqueBy(topologies.flatMap((topology) => topology.links || []), (item) => item.id || `${item.fromId}:${item.fromPort}:${item.toId}:${item.toPort}`),
    powerLinks: uniqueBy(topologies.flatMap((topology) => topology.powerLinks || []), (item) => item.id || `${item.deviceId}:${item.upsId}:${item.outlet}`)
  }, objects);
}

const blueprintEquipment = {
  camera: { name: "Camera", short: "CAM" },
  "access-reader": { name: "Access Reader", short: "AR" },
  "door-controller": { name: "Door Controller", short: "DC" },
  "network-switch": { name: "Network Switch", short: "SW" },
  "wireless-ap": { name: "Wireless Access Point", short: "AP" },
  "data-jack": { name: "Data Jack", short: "DJ" },
  nvr: { name: "Network Video Recorder", short: "NVR" },
  rack: { name: "Equipment Rack", short: "RACK" },
  "smoke-detector": { name: "Smoke Detector", short: "SD" },
  "air-quality-sensor": { name: "Air Quality Sensor", short: "AQ" },
  "motion-sensor": { name: "Motion Sensor", short: "MS" },
  "all-in-one-sensor": { name: "All-in-One Sensor", short: "AIO" },
  relay: { name: "Relay", short: "RLY" },
  "ai-speaker": { name: "AI Speaker", short: "AIS" },
  siren: { name: "Siren", short: "SRN" }
};

const blueprintCables = {
  cat5e: "Cat5e", cat6: "Cat6", fiber: "Fiber", coax: "Coax",
  speaker: "Speaker Wire", "access-control": "Access Control"
};

const blueprintEquipmentColors = {
  camera: "#d84343", "access-reader": "#8e44ad", "door-controller": "#6c3483",
  "network-switch": "#087f8c", "wireless-ap": "#1976d2", "data-jack": "#455a64",
  nvr: "#ad6b13", rack: "#263238", "smoke-detector": "#c0392b",
  "air-quality-sensor": "#168f85", "motion-sensor": "#7d5bbe",
  "all-in-one-sensor": "#286fa3", relay: "#b06d12", "ai-speaker": "#3e6c7c",
  siren: "#ba3d55"
};

const blueprintCeilingEquipment = new Set([
  "camera", "wireless-ap", "smoke-detector", "air-quality-sensor", "motion-sensor",
  "all-in-one-sensor", "ai-speaker", "siren"
]);

const blueprintCableColors = {
  cat5e: "#1976d2", cat6: "#00a0a8", fiber: "#b33dc6", coax: "#d97904",
  speaker: "#388e3c", "access-control": "#c43d36"
};

function blueprintDeviceEdgePoint(device, toward) {
  const dx = (toward?.x ?? device.x + 1) - device.x;
  const dy = (toward?.y ?? device.y) - device.y;
  const distance = Math.hypot(dx, dy) || 1;
  const radius = 17;
  const ceiling = blueprintCeilingEquipment.has(device.equipmentType) && device.mount !== "wall";
  if (ceiling) return { x: device.x + dx / distance * radius, y: device.y + dy / distance * radius };
  const angle = -(device.rotation || 0) * Math.PI / 180;
  const localX = dx * Math.cos(angle) - dy * Math.sin(angle);
  const localY = dx * Math.sin(angle) + dy * Math.cos(angle);
  const factor = radius / (Math.max(Math.abs(localX), Math.abs(localY)) || 1);
  const edgeX = localX * factor;
  const edgeY = localY * factor;
  const back = -angle;
  return {
    x: device.x + edgeX * Math.cos(back) - edgeY * Math.sin(back),
    y: device.y + edgeX * Math.sin(back) + edgeY * Math.cos(back)
  };
}

function blueprintCablePoints(item, deviceMap) {
  const raw = item.points || [];
  return raw.map((point, index) => {
    const device = deviceMap.get(point.deviceId);
    if (!device) return { x: point.x, y: point.y };
    const neighbor = raw[index === raw.length - 1 ? index - 1 : index + 1];
    const neighborDevice = deviceMap.get(neighbor?.deviceId);
    return blueprintDeviceEdgePoint(device, neighborDevice || neighbor);
  });
}

function blueprintCableLength(item, deviceMap) {
  const points = blueprintCablePoints(item, deviceMap);
  return points.slice(1).reduce((total, point, index) => {
    const previous = points[index];
    return total + Math.hypot(point.x - previous.x, point.y - previous.y);
  }, 0);
}

function wrapBlueprintCalloutText(value, maxCharacters = 28) {
  const paragraphs = String(value || "Add note").split(/\r?\n/);
  const lines = [];
  for (const paragraph of paragraphs) {
    const words = paragraph.trim().split(/\s+/).filter(Boolean);
    if (!words.length) {
      lines.push("");
      continue;
    }
    let line = "";
    for (const word of words) {
      const next = line ? `${line} ${word}` : word;
      if (line && next.length > maxCharacters) {
        lines.push(line);
        line = word;
      } else line = next;
    }
    if (line) lines.push(line);
  }
  return (lines.length ? lines : ["Add note"]).slice(0, 12);
}

function blueprintCalloutGeometry(item) {
  const width = Math.max(72, Number(item.width) || 180);
  const fontSize = Math.max(8, Number(item.fontSize) || 14);
  const padding = Math.max(8, fontSize * 0.65);
  const lines = wrapBlueprintCalloutText(item.text, Math.max(10, Math.floor((width - padding * 2) / (fontSize * 0.58))));
  const lineHeight = fontSize * 1.25;
  const height = Math.max(fontSize + padding * 2, lines.length * lineHeight + padding * 2);
  const centerX = Number(item.x) + width / 2;
  const centerY = Number(item.y) + height / 2;
  const dx = Number(item.targetX) - centerX;
  const dy = Number(item.targetY) - centerY;
  const edgeRatio = Math.max(Math.abs(dx) / (width / 2), Math.abs(dy) / (height / 2));
  const factor = edgeRatio > 1 ? 1 / edgeRatio : 1;
  const anchorX = centerX + dx * factor;
  const anchorY = centerY + dy * factor;
  const angle = Math.atan2(Number(item.targetY) - anchorY, Number(item.targetX) - anchorX);
  const arrowLength = Math.max(10, fontSize * 0.9);
  const arrowAngle = Math.PI / 7;
  return {
    width, height, padding, lines, lineHeight, anchorX, anchorY,
    arrowAX: Number(item.targetX) - arrowLength * Math.cos(angle - arrowAngle),
    arrowAY: Number(item.targetY) - arrowLength * Math.sin(angle - arrowAngle),
    arrowBX: Number(item.targetX) - arrowLength * Math.cos(angle + arrowAngle),
    arrowBY: Number(item.targetY) - arrowLength * Math.sin(angle + arrowAngle)
  };
}

function floorPlanContentBounds(objects, canvas) {
  let minX = Number.POSITIVE_INFINITY;
  let minY = Number.POSITIVE_INFINITY;
  let maxX = Number.NEGATIVE_INFINITY;
  let maxY = Number.NEGATIVE_INFINITY;
  const include = (x1, y1, x2 = x1, y2 = y1) => {
    minX = Math.min(minX, Number(x1) || 0, Number(x2) || 0);
    minY = Math.min(minY, Number(y1) || 0, Number(y2) || 0);
    maxX = Math.max(maxX, Number(x1) || 0, Number(x2) || 0);
    maxY = Math.max(maxY, Number(y1) || 0, Number(y2) || 0);
  };
  for (const item of objects) {
    if (["wall", "dimension"].includes(item.type)) {
      const padding = item.type === "wall" ? Math.max(8, Number(item.thickness) || 0) : 8;
      include(
        Math.min(item.x1, item.x2) - padding,
        Math.min(item.y1, item.y2) - padding,
        Math.max(item.x1, item.x2) + padding,
        Math.max(item.y1, item.y2) + padding
      );
    } else if (["room", "stairs"].includes(item.type)) {
      include(item.x, item.y, item.x + item.w, item.y + item.h);
    } else if (item.type === "door") {
      const radius = Math.max(24, Number(item.width) || 36);
      include(item.x - radius, item.y - radius, item.x + radius, item.y + radius);
    } else if (item.type === "window") {
      const half = Math.max(12, (Number(item.width) || 36) / 2);
      include(item.x - half, item.y - 8, item.x + half, item.y + 8);
    } else if (item.type === "column") {
      const half = Math.max(8, (Number(item.size) || 18) / 2);
      include(item.x - half, item.y - half, item.x + half, item.y + half);
    } else if (item.type === "label") {
      include(item.x, item.y, item.x + Math.max(72, String(item.text || "").length * 8), item.y + Math.max(18, Number(item.fontSize) || 14));
    } else if (item.type === "callout") {
      const geometry = blueprintCalloutGeometry(item);
      include(
        Math.min(item.x, item.targetX) - 8, Math.min(item.y, item.targetY) - 8,
        Math.max(item.x + geometry.width, item.targetX) + 8, Math.max(item.y + geometry.height, item.targetY) + 8
      );
    } else if (item.type === "network-device") {
      include(item.x - 32, item.y - 32, item.x + 32, item.y + 48);
    } else if (item.type === "cable") {
      for (const point of item.points || []) include(point.x - 6, point.y - 6, point.x + 6, point.y + 6);
    }
  }
  if (!Number.isFinite(minX) || !Number.isFinite(minY) || !Number.isFinite(maxX) || !Number.isFinite(maxY)) {
    return { minX: 0, minY: 0, width: canvas.width, height: canvas.height };
  }
  const rawWidth = Math.max(120, maxX - minX);
  const rawHeight = Math.max(120, maxY - minY);
  const padding = Math.max(36, Math.min(120, Math.max(rawWidth, rawHeight) * 0.06));
  return {
    minX: minX - padding,
    minY: minY - padding,
    width: rawWidth + padding * 2,
    height: rawHeight + padding * 2
  };
}

function blueprintSvgEscape(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&apos;"
  })[character]);
}

function renderFloorPlanBlueprintSvg(response, plan) {
  const letter = plan.blueprintInfo?.paperSize === "letter";
  const pageWidth = letter ? 11 * 72 : 36 * 72;
  const pageHeight = letter ? 8.5 * 72 : 24 * 72;
  const margin = letter ? 18 : 42;
  const titleHeight = letter ? 78 : 132;
  const drawingWidth = pageWidth - margin * 2;
  const drawingHeight = pageHeight - margin * 2 - titleHeight;
  const contentBounds = floorPlanContentBounds(plan.objects, plan.canvas);
  const hasLegend = plan.objects.some((item) => ["network-device", "cable"].includes(item.type));
  const legendReserve = hasLegend ? (letter ? 238 : 880) : 0;
  const planDrawingWidth = drawingWidth - legendReserve;
  const fitScale = Math.min(
    (planDrawingWidth - (letter ? 18 : 56)) / contentBounds.width,
    (drawingHeight - (letter ? 18 : 56)) / contentBounds.height
  );
  const scale = Math.max(0.2, Math.min(letter ? 4 : 7, fitScale));
  const originX = margin + (planDrawingWidth - contentBounds.width * scale) / 2 - contentBounds.minX * scale;
  const originY = margin + (drawingHeight - contentBounds.height * scale) / 2 - contentBounds.minY * scale;
  const info = plan.blueprintInfo || {};
  const deviceMap = new Map(plan.objects.filter((item) => item.type === "network-device").map((item) => [item.id, item]));
  const xml = [];
  const text = (value) => blueprintSvgEscape(value);
  const color = (value, fallback = "#263238") => /^#[0-9a-f]{3,8}$/i.test(String(value || "")) ? value : fallback;
  xml.push(`<?xml version="1.0" encoding="UTF-8"?>`);
  xml.push(`<svg xmlns="http://www.w3.org/2000/svg" width="${letter ? 11 : 36}in" height="${letter ? 8.5 : 24}in" viewBox="0 0 ${pageWidth} ${pageHeight}" role="img" aria-labelledby="blueprint-title blueprint-description">`);
  xml.push(`<title id="blueprint-title">${text(plan.title)} Blueprint</title><desc id="blueprint-description">Floor plan blueprint generated by Huber I.T. Professionals Design Center.</desc>`);
  xml.push(`<rect width="${pageWidth}" height="${pageHeight}" fill="#ffffff"/><rect x="24" y="24" width="${pageWidth - 48}" height="${pageHeight - 48}" fill="none" stroke="#182026" stroke-width="2"/>`);
  xml.push(`<defs><clipPath id="drawing-clip"><rect x="${margin}" y="${margin}" width="${drawingWidth}" height="${drawingHeight}"/></clipPath></defs>`);
  xml.push(`<rect x="${margin}" y="${margin}" width="${drawingWidth}" height="${drawingHeight}" fill="#ffffff" stroke="#607d86" stroke-width="0.8"/>`);
  xml.push(`<g clip-path="url(#drawing-clip)"><g transform="translate(${originX} ${originY}) scale(${scale})">`);
  const planTextSize = Math.max(4, 10 / scale);
  for (const item of plan.objects) {
    const itemColor = color(item.color);
    if (item.type === "wall") {
      xml.push(`<line x1="${item.x1}" y1="${item.y1}" x2="${item.x2}" y2="${item.y2}" stroke="${itemColor}" stroke-width="${Math.max(1, item.thickness)}" stroke-linecap="square"/>`);
    } else if (item.type === "room") {
      xml.push(`<rect x="${item.x}" y="${item.y}" width="${item.w}" height="${item.h}" fill="${color(item.fill, "#e7f1f3")}" fill-opacity="0.14" stroke="${itemColor}"/>`);
      if (item.label) xml.push(`<text x="${item.x + item.w / 2}" y="${item.y + item.h / 2}" fill="#263238" font-family="Arial,Helvetica,sans-serif" font-size="${planTextSize}" font-weight="700" text-anchor="middle" dominant-baseline="middle">${text(item.label)}</text>`);
    } else if (item.type === "stairs") {
      xml.push(`<rect x="${item.x}" y="${item.y}" width="${item.w}" height="${item.h}" fill="none" stroke="${itemColor}"/>`);
      const steps = Math.max(2, Math.floor(item.h / 12));
      for (let index = 1; index < steps; index += 1) xml.push(`<line x1="${item.x}" y1="${item.y + item.h * index / steps}" x2="${item.x + item.w}" y2="${item.y + item.h * index / steps}" stroke="${itemColor}" stroke-width="0.6"/>`);
    } else if (item.type === "door") {
      const direction = item.swing === "outward" ? 1 : -1;
      xml.push(`<g transform="translate(${item.x} ${item.y}) rotate(${item.rotation || 0})"><line x1="-3" y1="0" x2="${item.width + 3}" y2="0" stroke="#ffffff" stroke-width="${Math.max(8, item.width / 5)}"/>`);
      if (item.doorStyle === "sliding") {
        xml.push(`<line x1="${item.width * .08}" y1="-5" x2="${item.width * .62}" y2="-5" stroke="${itemColor}" stroke-width="2.4"/><line x1="${item.width * .38}" y1="5" x2="${item.width * .92}" y2="5" stroke="${itemColor}" stroke-width="2.4"/>`);
      } else if (item.doorStyle === "double") {
        const half = item.width / 2;
        xml.push(`<line x1="0" y1="0" x2="0" y2="${direction * half}" stroke="${itemColor}" stroke-width="2.4"/><line x1="${item.width}" y1="0" x2="${item.width}" y2="${direction * half}" stroke="${itemColor}" stroke-width="2.4"/><path d="M ${half} 0 A ${half} ${half} 0 0 ${direction > 0 ? 1 : 0} 0 ${direction * half}" fill="none" stroke="${itemColor}" stroke-width="0.8"/><path d="M ${half} 0 A ${half} ${half} 0 0 ${direction > 0 ? 0 : 1} ${item.width} ${direction * half}" fill="none" stroke="${itemColor}" stroke-width="0.8"/>`);
      } else {
        const hingeX = item.hinge === "right" ? item.width : 0;
        const leafEndX = item.hinge === "right" ? item.width : 0;
        const arcStartX = item.hinge === "right" ? 0 : item.width;
        xml.push(`<line x1="${hingeX}" y1="0" x2="${leafEndX}" y2="${direction * item.width}" stroke="${itemColor}" stroke-width="2.4"/><path d="M ${arcStartX} 0 A ${item.width} ${item.width} 0 0 ${item.hinge === "right" ? (direction < 0 ? 1 : 0) : (direction > 0 ? 1 : 0)} ${hingeX} ${direction * item.width}" fill="none" stroke="${itemColor}" stroke-width="0.8"/>`);
      }
      xml.push(`</g>`);
    } else if (item.type === "window") {
      xml.push(`<line x1="${item.x - item.width / 2}" y1="${item.y - 2}" x2="${item.x + item.width / 2}" y2="${item.y - 2}" stroke="${itemColor}" stroke-width="1.5"/><line x1="${item.x - item.width / 2}" y1="${item.y + 2}" x2="${item.x + item.width / 2}" y2="${item.y + 2}" stroke="${itemColor}" stroke-width="1.5"/>`);
    } else if (item.type === "column") {
      xml.push(`<rect x="${item.x - item.size / 2}" y="${item.y - item.size / 2}" width="${item.size}" height="${item.size}" fill="${color(item.fill, "#455a64")}"/>`);
    } else if (item.type === "label") {
      xml.push(`<text x="${item.x}" y="${item.y}" fill="${itemColor}" font-family="Arial,Helvetica,sans-serif" font-size="${Math.max(planTextSize, item.fontSize * .65)}" font-weight="700">${text(item.text)}</text>`);
    } else if (item.type === "callout") {
      const geometry = blueprintCalloutGeometry(item);
      const fontSize = Math.max(planTextSize, Number(item.fontSize) || 14);
      xml.push(`<line x1="${geometry.anchorX}" y1="${geometry.anchorY}" x2="${item.targetX}" y2="${item.targetY}" stroke="${itemColor}" stroke-width="2"/>`);
      xml.push(`<polygon points="${item.targetX},${item.targetY} ${geometry.arrowAX},${geometry.arrowAY} ${geometry.arrowBX},${geometry.arrowBY}" fill="${itemColor}"/>`);
      xml.push(`<rect x="${item.x}" y="${item.y}" width="${geometry.width}" height="${geometry.height}" rx="4" fill="${color(item.fill, "#ffffff")}" stroke="${itemColor}" stroke-width="1.5"/>`);
      xml.push(`<text x="${item.x + geometry.padding}" y="${item.y + geometry.padding + fontSize}" fill="${itemColor}" font-family="Arial,Helvetica,sans-serif" font-size="${fontSize}" font-weight="700">${geometry.lines.map((line, index) => `<tspan x="${item.x + geometry.padding}" dy="${index ? geometry.lineHeight : 0}">${text(line)}</tspan>`).join("")}</text>`);
    } else if (item.type === "dimension") {
      const length = Math.hypot(item.x2 - item.x1, item.y2 - item.y1) / 12;
      xml.push(`<line x1="${item.x1}" y1="${item.y1}" x2="${item.x2}" y2="${item.y2}" stroke="${itemColor}" stroke-width="0.7" stroke-dasharray="${5 / scale} ${3 / scale}"/><text x="${(item.x1 + item.x2) / 2}" y="${(item.y1 + item.y2) / 2 - 5 / scale}" fill="${itemColor}" font-family="Arial,Helvetica,sans-serif" font-size="${planTextSize}" font-weight="700" text-anchor="middle">${length.toFixed(1)} ft</text>`);
    } else if (item.type === "network-device") {
      const equipment = blueprintEquipment[item.equipmentType] || blueprintEquipment.camera;
      const ceilingMounted = blueprintCeilingEquipment.has(item.equipmentType) && item.mount !== "wall";
      xml.push(ceilingMounted
        ? `<circle cx="${item.x}" cy="${item.y}" r="14" fill="#ffffff" stroke="${itemColor}" stroke-width="1.5"/>`
        : `<rect x="${item.x - 14}" y="${item.y - 14}" width="28" height="28" fill="#ffffff" stroke="${itemColor}" stroke-width="1.5"/>`);
      xml.push(`<text x="${item.x}" y="${item.y + 2.5 / scale}" fill="${itemColor}" font-family="Arial,Helvetica,sans-serif" font-size="${Math.max(4, 7 / scale)}" font-weight="700" text-anchor="middle">${text(equipment.short)}</text><text x="${item.x}" y="${item.y + 18 + planTextSize}" fill="#263238" font-family="Arial,Helvetica,sans-serif" font-size="${planTextSize}" font-weight="700" text-anchor="middle">${text(item.label || equipment.name)}</text>`);
    } else if (item.type === "cable" && item.points.length > 1) {
      const points = blueprintCablePoints(item, deviceMap).map((point) => `${point.x},${point.y}`).join(" ");
      xml.push(`<polyline points="${points}" fill="none" stroke="${itemColor}" stroke-width="${Math.max(.8, item.thickness || 2)}" stroke-linejoin="round" stroke-linecap="round"/>`);
    }
  }
  xml.push(`</g></g>`);

  const deviceCounts = new Map();
  const cableCounts = new Map();
  for (const item of plan.objects) {
    if (item.type === "network-device") deviceCounts.set(item.equipmentType, (deviceCounts.get(item.equipmentType) || 0) + 1);
    if (item.type === "cable") {
      const record = cableCounts.get(item.cableType) || { count: 0, length: 0 };
      record.count += 1;
      record.length += blueprintCableLength(item, deviceMap);
      cableCounts.set(item.cableType, record);
    }
  }
  const legendRows = [
    ...[...deviceCounts].map(([type, count]) => ({ kind: "device", type, color: blueprintEquipmentColors[type] || "#455a64", short: blueprintEquipment[type]?.short || "DEV", label: blueprintEquipment[type]?.name || type, value: String(count) })),
    ...[...cableCounts].map(([type, record]) => ({ kind: "cable", type, color: blueprintCableColors[type] || "#455a64", label: blueprintCables[type] || type, value: `${record.count} run${record.count === 1 ? "" : "s"} · ${(record.length / 12).toFixed(1)} ft` }))
  ];
  if (legendRows.length) {
    const baseHeight = 42 + legendRows.length * 22;
    const legendScale = letter
      ? Math.max(0.56, Math.min(0.72, (drawingHeight - 20) / baseHeight))
      : Math.max(1.35, Math.min(2.6, (drawingHeight - 32) / baseHeight));
    const legendWidth = 330 * legendScale;
    const legendHeight = baseHeight * legendScale;
    const legendX = margin + drawingWidth - legendWidth - 16;
    const legendY = margin + 16;
    xml.push(`<g font-family="Arial,Helvetica,sans-serif"><rect x="${legendX}" y="${legendY}" width="${legendWidth}" height="${legendHeight}" rx="${5 * legendScale}" fill="#ffffff" fill-opacity=".96" stroke="#52666d"/><text x="${legendX + 14 * legendScale}" y="${legendY + 23 * legendScale}" fill="#182026" font-size="${12 * legendScale}" font-weight="700">NETWORK LEGEND</text>`);
    legendRows.forEach((row, index) => {
      const y = legendY + (37 + index * 22) * legendScale;
      if (row.kind === "device") xml.push(`<rect x="${legendX + 15 * legendScale}" y="${y - 8 * legendScale}" width="${13 * legendScale}" height="${13 * legendScale}" fill="#fff" stroke="${row.color}"/><text x="${legendX + 21.5 * legendScale}" y="${y + .5 * legendScale}" fill="${row.color}" font-size="${(row.short.length > 2 ? 4.2 : 5.2) * legendScale}" font-weight="700" text-anchor="middle">${text(row.short)}</text>`);
      else xml.push(`<line x1="${legendX + 14 * legendScale}" y1="${y - legendScale}" x2="${legendX + 30 * legendScale}" y2="${y - legendScale}" stroke="${row.color}" stroke-width="${2.5 * legendScale}"/>`);
      xml.push(`<text x="${legendX + 39 * legendScale}" y="${y}" fill="#263238" font-size="${8.5 * legendScale}">${text(row.label)}</text><text x="${legendX + 315 * legendScale}" y="${y}" fill="#263238" font-size="${8.5 * legendScale}" font-weight="700" text-anchor="end">${text(row.value)}</text>`);
    });
    xml.push(`</g>`);
  }

  const titleY = pageHeight - margin - titleHeight;
  const logoPath = join(root, "assets", "logo.png");
  if (letter) {
    const companyWidth = 205;
    const detailsWidth = 220;
    const centerX = margin + companyWidth + 12;
    const centerWidth = drawingWidth - companyWidth - detailsWidth - 24;
    const detailsX = pageWidth - margin - detailsWidth + 10;
    xml.push(`<g font-family="Arial,Helvetica,sans-serif"><rect x="${margin}" y="${titleY}" width="${drawingWidth}" height="${titleHeight}" fill="#fff" stroke="#182026"/><line x1="${margin + companyWidth}" y1="${titleY}" x2="${margin + companyWidth}" y2="${titleY + titleHeight}" stroke="#182026"/><line x1="${pageWidth - margin - detailsWidth}" y1="${titleY}" x2="${pageWidth - margin - detailsWidth}" y2="${titleY + titleHeight}" stroke="#182026"/>`);
    if (existsSync(logoPath)) xml.push(`<image x="${margin + 8}" y="${titleY + 9}" width="38" height="38" preserveAspectRatio="xMidYMid meet" href="data:image/png;base64,${readFileSync(logoPath).toString("base64")}"/>`);
    xml.push(`<text x="${margin + 52}" y="${titleY + 20}" fill="#087f8c" font-size="8.5" font-weight="700">HUBER I.T. PROFESSIONALS</text><text x="${margin + 52}" y="${titleY + 33}" fill="#34444a" font-size="5.5">${text(String(info.companyAddress || "").replace(/\s*\r?\n\s*/g, " · "))}</text><text x="${margin + 8}" y="${titleY + 67}" fill="#66767d" font-size="5.5">DESIGN CENTER · FLOOR PLAN BLUEPRINT</text>`);
    xml.push(`<text x="${centerX}" y="${titleY + 20}" fill="#182026" font-size="12" font-weight="700">${text(plan.title)}</text><text x="${centerX}" y="${titleY + 37}" fill="#66767d" font-size="5.5" font-weight="700">CONTRACT</text><text x="${centerX + 45}" y="${titleY + 37}" fill="#182026" font-size="7">${text(info.contractTicket || "Not assigned")}</text><text x="${centerX}" y="${titleY + 53}" fill="#66767d" font-size="5.5" font-weight="700">SITE</text><text x="${centerX + 45}" y="${titleY + 53}" fill="#182026" font-size="7">${text(info.customerSite || "Not specified")}</text>`);
    xml.push(`<text x="${detailsX}" y="${titleY + 16}" fill="#66767d" font-size="5.5" font-weight="700">PREPARED BY</text><text x="${detailsX + 67}" y="${titleY + 16}" fill="#182026" font-size="7">${text(info.preparedBy || "Not specified")}</text><text x="${detailsX}" y="${titleY + 33}" fill="#66767d" font-size="5.5" font-weight="700">PLAN AREA</text><text x="${detailsX + 67}" y="${titleY + 33}" fill="#182026" font-size="7">${Math.round(plan.canvas.width / 12)} ft × ${Math.round(plan.canvas.height / 12)} ft</text><text x="${detailsX}" y="${titleY + 50}" fill="#66767d" font-size="5.5" font-weight="700">SCALE</text><text x="${detailsX + 67}" y="${titleY + 50}" fill="#182026" font-size="7">1/4&quot; = 1&apos;-0&quot;</text><text x="${detailsX}" y="${titleY + 67}" fill="#66767d" font-size="5.5">Generated ${text(new Date().toLocaleDateString("en-US"))} · Sheet FP-1</text></g></svg>`);
  } else {
    const companyWidth = 520;
    const detailsWidth = 520;
    const centerX = margin + companyWidth + 22;
    const centerWidth = drawingWidth - companyWidth - detailsWidth - 44;
    const detailsX = pageWidth - margin - detailsWidth + 18;
    xml.push(`<g font-family="Arial,Helvetica,sans-serif"><rect x="${margin}" y="${titleY}" width="${drawingWidth}" height="${titleHeight}" fill="#fff" stroke="#182026" stroke-width="1.2"/><line x1="${margin + companyWidth}" y1="${titleY}" x2="${margin + companyWidth}" y2="${titleY + titleHeight}" stroke="#182026"/><line x1="${pageWidth - margin - detailsWidth}" y1="${titleY}" x2="${pageWidth - margin - detailsWidth}" y2="${titleY + titleHeight}" stroke="#182026"/>`);
    if (existsSync(logoPath)) xml.push(`<image x="${margin + 15}" y="${titleY + 18}" width="76" height="76" preserveAspectRatio="xMidYMid meet" href="data:image/png;base64,${readFileSync(logoPath).toString("base64")}"/>`);
    xml.push(`<text x="${margin + 104}" y="${titleY + 33}" fill="#087f8c" font-size="16" font-weight="700">HUBER I.T. PROFESSIONALS</text>`);
    String(info.companyAddress || "").split(/\r?\n/).slice(0, 3).forEach((line, index) => xml.push(`<text x="${margin + 104}" y="${titleY + 52 + index * 13}" fill="#34444a" font-size="8.5">${text(line)}</text>`));
    xml.push(`<text x="${margin + 18}" y="${titleY + 118}" fill="#66767d" font-size="8">DESIGN CENTER · FLOOR PLAN BLUEPRINT</text>`);
    xml.push(`<text x="${centerX}" y="${titleY + 34}" fill="#182026" font-size="21" font-weight="700">${text(plan.title)}</text><text x="${centerX}" y="${titleY + 57}" fill="#66767d" font-size="8" font-weight="700">CONTRACT TICKET</text><text x="${centerX}" y="${titleY + 74}" fill="#182026" font-size="12" font-weight="700">${text(info.contractTicket || "Not assigned")}</text><text x="${centerX}" y="${titleY + 92}" fill="#66767d" font-size="8" font-weight="700">CUSTOMER / SITE</text><text x="${centerX}" y="${titleY + 108}" fill="#182026" font-size="10">${text(info.customerSite || "Not specified")}</text>`);
    xml.push(`<text x="${detailsX}" y="${titleY + 25}" fill="#182026" font-size="10" font-weight="700">ISSUE INFORMATION</text><text x="${detailsX}" y="${titleY + 45}" fill="#66767d" font-size="8" font-weight="700">PREPARED BY</text><text x="${detailsX + 92}" y="${titleY + 45}" fill="#182026" font-size="10">${text(info.preparedBy || "Not specified")}</text><text x="${detailsX}" y="${titleY + 67}" fill="#66767d" font-size="8" font-weight="700">PLAN AREA</text><text x="${detailsX + 92}" y="${titleY + 67}" fill="#182026" font-size="10">${Math.round(plan.canvas.width / 12)} ft × ${Math.round(plan.canvas.height / 12)} ft</text><text x="${detailsX}" y="${titleY + 89}" fill="#66767d" font-size="8" font-weight="700">SCALE</text><text x="${detailsX + 92}" y="${titleY + 89}" fill="#182026" font-size="10">Scale 1/4&quot; = 1&apos;-0&quot;${plan.currentRevision ? ` · ${text(plan.currentRevision)}` : ""}</text><text x="${detailsX}" y="${titleY + 116}" fill="#66767d" font-size="8">Generated ${text(new Date().toLocaleString("en-US"))} · ${plan.objects.length} objects · Sheet FP-1</text></g></svg>`);
  }
  const safeName = plan.title.replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").toLowerCase() || "floor-plan";
  response.writeHead(200, {
    "Content-Type": "image/svg+xml; charset=utf-8",
    "Content-Disposition": `attachment; filename="${safeName}-blueprint.svg"`,
    "Cache-Control": "no-store"
  });
  response.end(xml.join(""));
}

function renderNetworkTopologyLetterBlueprint(doc, plan, pageWidth, pageHeight, margin) {
  const topology = plan.topology || { racks: [], switches: [], assignments: [], links: [], powerLinks: [] };
  if (!topology.racks.length && !topology.switches.length) return;
  const info = plan.blueprintInfo || {};
  const devices = new Map(plan.objects.filter((item) => item.type === "network-device").map((item) => [item.id, item]));
  const assignments = new Map(topology.assignments.map((item) => [`${item.switchId}:${item.port}`, item]));
  const equipmentMap = new Map(topology.switches.map((item) => [item.id, item]));
  const rackMap = new Map(topology.racks.map((item) => [item.id, item]));
  let pageOpen = false;
  let sheet = 0;
  let y = 0;
  const footer = () => {
    if (!pageOpen) return;
    doc.font("Helvetica").fontSize(5.5).fillColor("#66767d").text("Huber I.T. Professionals", margin, pageHeight - 24, { lineBreak: false });
    doc.font("Helvetica-Bold").text(`Sheet NT-${sheet}`, pageWidth - margin - 70, pageHeight - 24, { width: 70, align: "right", lineBreak: false });
  };
  const newPage = (title = "NETWORK TOPOLOGY") => {
    footer();
    sheet += 1;
    doc.addPage({ size: [pageWidth, pageHeight], margin: 0 });
    pageOpen = true;
    doc.rect(12, 12, pageWidth - 24, pageHeight - 24).lineWidth(1).stroke("#182026");
    const logo = join(root, "assets", "logo.png");
    if (existsSync(logo)) doc.image(logo, margin, 25, { fit: [38, 38] });
    doc.font("Helvetica-Bold").fontSize(15).fillColor("#182026").text(title, margin + 48, 27, { lineBreak: false });
    doc.font("Helvetica").fontSize(7).fillColor("#526068").text(plan.title, margin + 48, 48, { lineBreak: false });
    doc.font("Helvetica-Bold").fontSize(5.5).fillColor("#66767d").text("CONTRACT", pageWidth - margin - 175, 29, { lineBreak: false });
    doc.font("Helvetica-Bold").fontSize(8).fillColor("#182026").text(info.contractTicket || "Not assigned", pageWidth - margin - 115, 27, { width: 115, align: "right", lineBreak: false, ellipsis: true });
    doc.font("Helvetica").fontSize(6).fillColor("#526068").text(info.customerSite || "", pageWidth - margin - 175, 45, { width: 175, align: "right", lineBreak: false, ellipsis: true });
    doc.moveTo(margin, 68).lineTo(pageWidth - margin, 68).lineWidth(.7).stroke("#607d86");
    y = 80;
  };
  const equipmentHeight = (item) => item.category === "ups" ? 64 : Math.max(40, 24 + Math.ceil(item.portCount / (item.category === "gateway" ? 4 : 12)) * 18);
  const drawPort = (x, portY, port, used, uplink) => {
    const width = 20;
    doc.rect(x, portY, width, 13).fillAndStroke(uplink ? "#d97904" : used ? "#087f8c" : "#303b40", "#151d20");
    for (let contact = 0; contact < 8; contact += 1) doc.rect(x + 2.5 + contact * 2, portY + 2, .7, 3).fill("#d9aa43");
    doc.font("Helvetica-Bold").fontSize(4.5).fillColor("#ffffff").text(String(port), x, portY + 6.2, { width, align: "center", lineBreak: false });
  };
  const links = new Map();
  for (const link of topology.links || []) {
    links.set(`${link.fromId}:${link.fromPort}`, link);
    links.set(`${link.toId}:${link.toPort}`, link);
  }
  for (const rack of topology.racks) {
    const rackEquipment = topology.switches.filter((item) => item.rackId === rack.id);
    const rackHeight = Math.max(110, 34 + rackEquipment.reduce((total, item) => total + equipmentHeight(item) + 5, 0));
    if (!pageOpen || y + rackHeight > pageHeight - 38) newPage("NETWORK RACK ELEVATION");
    const rackX = margin + 8;
    const rackWidth = pageWidth - margin * 2 - 16;
    const faceWidth = Math.min(525, rackWidth * .74);
    doc.rect(rackX, y, rackWidth, rackHeight).fillAndStroke("#c9ced0", "#7f888c");
    doc.rect(rackX + 8, y + 22, faceWidth, rackHeight - 32).fillAndStroke("#f7f8f8", "#9aa3a6");
    doc.font("Helvetica-Bold").fontSize(8).fillColor("#263238").text(rack.name, rackX + 10, y + 8, { width: rackWidth - 20, lineBreak: false, ellipsis: true });
    let unitY = y + 28;
    for (const item of rackEquipment) {
      const height = equipmentHeight(item);
      const faceX = rackX + 14;
      const width = faceWidth - 12;
      doc.rect(faceX, unitY, width, height).fillAndStroke("#d9ddde", "#666f73");
      doc.circle(faceX + 17, unitY + height / 2, 7).lineWidth(1).stroke("#607078");
      doc.font("Helvetica-Bold").fontSize(4.5).fillColor("#607078").text("U", faceX + 10, unitY + height / 2 - 2, { width: 14, align: "center", lineBreak: false });
      if (item.category === "ups") {
        doc.roundedRect(faceX + 38, unitY + 12, 54, 28, 3).fillAndStroke("#071820", "#34464d");
        doc.font("Helvetica-Bold").fontSize(7).fillColor("#55d9f2").text("100%", faceX + 38, unitY + 21, { width: 54, align: "center", lineBreak: false });
        const outlets = Math.min(item.portCount, 8);
        for (let outlet = 1; outlet <= outlets; outlet += 1) {
          const x = faceX + 115 + (outlet - 1) * 34;
          doc.roundedRect(x, unitY + 18, 25, 20, 2).fillAndStroke("#edf0f1", "#69767a");
          doc.font("Helvetica-Bold").fontSize(4.5).fillColor("#263238").text(String(outlet), x, unitY + 25, { width: 25, align: "center", lineBreak: false });
        }
      } else {
        const portsPerRow = item.category === "gateway" ? 4 : 12;
        const portsX = faceX + 52;
        for (let port = 1; port <= item.portCount; port += 1) {
          const column = (port - 1) % portsPerRow;
          const row = Math.floor((port - 1) / portsPerRow);
          const assignment = assignments.get(`${item.id}:${port}`);
          const uplink = links.get(`${item.id}:${port}`);
          drawPort(portsX + column * 24, unitY + 7 + row * 18, port, Boolean(assignment), Boolean(uplink));
        }
        if (item.category !== "super-link") {
          for (let sfp = 1; sfp <= 2; sfp += 1) {
            const x = faceX + width - 62 + (sfp - 1) * 28;
            const linked = links.has(`${item.id}:sfp${sfp}`);
            doc.rect(x, unitY + height / 2 - 8, 24, 16).fillAndStroke(linked ? "#d97904" : "#899397", "#354146");
            doc.font("Helvetica-Bold").fontSize(3.8).fillColor("#ffffff").text(`SFP ${sfp}`, x, unitY + height / 2 - 1.5, { width: 24, align: "center", lineBreak: false });
          }
        }
      }
      const labelX = rackX + faceWidth + 18;
      doc.font("Helvetica-Bold").fontSize(8).fillColor("#263238").text(item.name, labelX, unitY + height / 2 - 9, { width: rackWidth - faceWidth - 28, lineBreak: false, ellipsis: true });
      doc.font("Helvetica").fontSize(5.5).fillColor("#66767d").text(`${item.model || "Model not specified"} · ${item.portCount} ${item.category === "ups" ? "outlets" : "ports"}`, labelX, unitY + height / 2 + 4, { width: rackWidth - faceWidth - 28, lineBreak: false, ellipsis: true });
      unitY += height + 5;
    }
    y += rackHeight + 10;
  }
  const tablePage = (title, columns) => {
    newPage(title);
    doc.rect(margin, y, pageWidth - margin * 2, 20).fill("#263238");
    doc.font("Helvetica-Bold").fontSize(5.5).fillColor("#ffffff");
    columns.forEach((column) => doc.text(column.label, column.x, y + 7, { width: column.width, lineBreak: false }));
    y += 20;
  };
  const assignmentRows = (topology.assignments || []).filter((item) => Number(item.port) > 0 && devices.has(item.deviceId));
  const assignmentColumns = [
    { label: "RACK", x: margin + 6, width: 90 }, { label: "EQUIPMENT", x: margin + 100, width: 150 },
    { label: "PORT", x: margin + 255, width: 45 }, { label: "FLOOR-PLAN DEVICE", x: margin + 305, width: pageWidth - margin * 2 - 311 }
  ];
  if (assignmentRows.length) tablePage("PORT ASSIGNMENT SCHEDULE", assignmentColumns);
  for (const assignment of assignmentRows) {
    if (y + 16 > pageHeight - 34) tablePage("PORT ASSIGNMENTS · CONTINUED", assignmentColumns);
    const networkSwitch = equipmentMap.get(assignment.switchId);
    const rack = rackMap.get(networkSwitch?.rackId);
    const device = devices.get(assignment.deviceId);
    const equipment = blueprintEquipment[device?.equipmentType] || blueprintEquipment.camera;
    doc.rect(margin, y, pageWidth - margin * 2, 16).fillAndStroke("#ffffff", "#c4ced1");
    doc.font("Helvetica").fontSize(6).fillColor("#263238");
    doc.text(rack?.name || "Rack", assignmentColumns[0].x, y + 5, { width: assignmentColumns[0].width, lineBreak: false, ellipsis: true });
    doc.text(networkSwitch?.name || "Equipment", assignmentColumns[1].x, y + 5, { width: assignmentColumns[1].width, lineBreak: false, ellipsis: true });
    doc.font("Helvetica-Bold").text(String(assignment.port), assignmentColumns[2].x, y + 5, { width: assignmentColumns[2].width, lineBreak: false });
    doc.font("Helvetica").text(`${equipment.short} · ${device?.label || equipment.name}${device?.topologyPageTitle ? ` · ${device.topologyPageTitle}` : ""}`, assignmentColumns[3].x, y + 5, { width: assignmentColumns[3].width, lineBreak: false, ellipsis: true });
    y += 16;
  }
  const connectionRows = (topology.links || []).map((link) => ({
    from: `${equipmentMap.get(link.fromId)?.name || "Equipment"} · ${String(link.fromPort).toUpperCase()}`,
    type: String(link.type || "cat6").toUpperCase(),
    to: `${equipmentMap.get(link.toId)?.name || "Equipment"} · ${String(link.toPort).toUpperCase()}`
  }));
  const connectionColumns = [
    { label: "FROM", x: margin + 6, width: 260 }, { label: "CONNECTION", x: margin + 272, width: 120 },
    { label: "TO", x: margin + 398, width: pageWidth - margin * 2 - 404 }
  ];
  if (connectionRows.length) tablePage("EQUIPMENT UPLINKS", connectionColumns);
  for (const row of connectionRows) {
    if (y + 18 > pageHeight - 34) tablePage("EQUIPMENT UPLINKS · CONTINUED", connectionColumns);
    doc.rect(margin, y, pageWidth - margin * 2, 18).fillAndStroke("#fff8ed", "#d6b27b");
    doc.font("Helvetica").fontSize(6).fillColor("#263238").text(row.from, connectionColumns[0].x, y + 6, { width: connectionColumns[0].width, lineBreak: false, ellipsis: true });
    doc.font("Helvetica-Bold").fillColor("#9a5c00").text(row.type, connectionColumns[1].x, y + 6, { width: connectionColumns[1].width, lineBreak: false });
    doc.font("Helvetica").fillColor("#263238").text(row.to, connectionColumns[2].x, y + 6, { width: connectionColumns[2].width, lineBreak: false, ellipsis: true });
    y += 18;
  }
  footer();
}

function renderNetworkTopologyBlueprint(doc, plan, pageWidth, pageHeight, margin) {
  const topology = plan.topology || { racks: [], switches: [], assignments: [], links: [] };
  if (!topology.racks.length && !topology.switches.length) return;
  const info = plan.blueprintInfo || {};
  const devices = new Map(plan.objects.filter((item) => item.type === "network-device").map((item) => [item.id, item]));
  const assignments = new Map(topology.assignments.map((item) => [`${item.switchId}:${item.port}`, item]));
  const equipmentMap = new Map(topology.switches.map((item) => [item.id, item]));
  const links = new Map();
  for (const link of topology.links || []) {
    links.set(`${link.fromId}:${link.fromPort}`, { ...link, otherId: link.toId, otherPort: link.toPort });
    links.set(`${link.toId}:${link.toPort}`, { ...link, otherId: link.fromId, otherPort: link.fromPort });
  }
  const assignedDeviceIds = new Set(topology.assignments.filter((item) => item.port > 0).map((item) => item.deviceId));
  let sheet = 0;
  let y = 0;
  let pageOpen = false;
  const contentWidth = pageWidth - margin * 2;
  const printablePort = (value) => String(value).startsWith("sfp")
    ? String(value).toUpperCase().replace("SFP", "SFP ") : `Port ${value}`;
  const drawFooter = () => {
    if (!pageOpen) return;
    doc.font("Helvetica").fontSize(8).fillColor("#66767d").text(`Huber I.T. Professionals · Generated ${new Date().toLocaleString("en-US")}`, margin, pageHeight - 57, { lineBreak: false });
    doc.font("Helvetica-Bold").text(`Sheet NT-${sheet}`, pageWidth - margin - 100, pageHeight - 57, { width: 100, align: "right", lineBreak: false });
  };
  const newSheet = () => {
    drawFooter();
    sheet += 1;
    doc.addPage({ size: [pageWidth, pageHeight], margin: 0 });
    pageOpen = true;
    doc.rect(24, 24, pageWidth - 48, pageHeight - 48).lineWidth(2).stroke("#182026");
    const logo = join(root, "assets", "logo.png");
    if (existsSync(logo)) doc.image(logo, margin, 42, { fit: [72, 72] });
    doc.font("Helvetica-Bold").fontSize(26).fillColor("#182026").text("NETWORK RACK ELEVATION", margin + 92, 46, { lineBreak: false });
    doc.font("Helvetica").fontSize(13).fillColor("#526068").text(plan.title, margin + 92, 82, { lineBreak: false });
    doc.font("Helvetica-Bold").fontSize(8).fillColor("#66767d").text("CONTRACT TICKET", pageWidth - margin - 390, 52, { lineBreak: false });
    doc.font("Helvetica-Bold").fontSize(12).fillColor("#182026").text(info.contractTicket || "Not assigned", pageWidth - margin - 270, 49, { width: 270, align: "right", lineBreak: false, ellipsis: true });
    doc.font("Helvetica").fontSize(9).fillColor("#526068").text(info.customerSite || "", pageWidth - margin - 390, 77, { width: 390, align: "right", lineBreak: false, ellipsis: true });
    doc.moveTo(margin, 116).lineTo(pageWidth - margin, 116).lineWidth(1).stroke("#607d86");
    y = 142;
  };
  const ensureSpace = (height) => { if (!pageOpen || y + height > pageHeight - 90) newSheet(); };
  const switchHeight = (networkSwitch) => {
    if (networkSwitch.category === "ups") return 104;
    if (networkSwitch.category === "super-link") return 78;
    const portsPerRow = networkSwitch.category === "gateway" ? 4 : 12;
    return Math.max(66, 32 + Math.ceil(networkSwitch.portCount / portsPerRow) * 34);
  };
  const drawRack = (rack, rackSwitches, part, totalParts) => {
    const rackWidth = Math.min(1120, contentWidth * .58);
    const rackX = margin + 90;
    const labelX = rackX + rackWidth + 54;
    const labelWidth = pageWidth - margin - labelX;
    const interiorHeight = rackSwitches.reduce((sum, networkSwitch) => sum + switchHeight(networkSwitch) + 8, 0);
    const rackHeight = Math.max(360, interiorHeight + 88);
    ensureSpace(rackHeight + 22);
    const rackY = y;
    const innerX = rackX + 30;
    const innerWidth = rackWidth - 60;
    doc.rect(rackX, rackY, rackWidth, rackHeight).fillAndStroke("#c9ced0", "#7f888c");
    doc.rect(innerX, rackY + 34, innerWidth, rackHeight - 68).fillAndStroke("#f7f8f8", "#9aa3a6");
    doc.rect(rackX, rackY, rackWidth, 34).fillAndStroke("#dce0e1", "#7f888c");
    doc.rect(rackX, rackY + rackHeight - 34, rackWidth, 34).fillAndStroke("#bfc5c7", "#7f888c");
    doc.rect(rackX + 12, rackY + 34, 18, rackHeight - 68).fill("#aeb5b8");
    doc.rect(rackX + rackWidth - 30, rackY + 34, 18, rackHeight - 68).fill("#aeb5b8");
    doc.font("Helvetica-Bold").fontSize(11).fillColor("#263238").text(`${rack.name}${totalParts > 1 ? ` · ${part}/${totalParts}` : ""}`, rackX + 16, rackY + 11, { width: rackWidth - 32, lineBreak: false, ellipsis: true });
    let unitY = rackY + 46;
    for (const networkSwitch of rackSwitches) {
      const rows = Math.ceil(networkSwitch.portCount / 12);
      const faceHeight = switchHeight(networkSwitch);
      const faceX = innerX + 10;
      const faceWidth = innerWidth - 20;
      doc.rect(faceX, unitY, faceWidth, faceHeight).fillAndStroke("#d9ddde", "#666f73");
      doc.rect(faceX + 7, unitY + 6, faceWidth - 14, faceHeight - 12).lineWidth(.6).stroke("#a3abad");
      for (const screwX of [faceX + 8, faceX + faceWidth - 8]) {
        doc.circle(screwX, unitY + 9, 3).fillAndStroke("#8b9497", "#5e676a");
        doc.circle(screwX, unitY + faceHeight - 9, 3).fillAndStroke("#8b9497", "#5e676a");
      }
      doc.circle(faceX + 35, unitY + faceHeight / 2, 13).lineWidth(1.7).stroke("#607078");
      doc.font("Helvetica-Bold").fontSize(8).fillColor("#607078").text("U", faceX + 22, unitY + faceHeight / 2 - 3, { width: 26, align: "center", lineBreak: false });
      if (networkSwitch.category === "ups") {
        doc.font("Helvetica-Bold").fontSize(6).fillColor("#536168").text("UniFi UPS 2U", faceX + 20, unitY + faceHeight - 18, { width: 80, align: "center", lineBreak: false });
        doc.roundedRect(faceX + 108, unitY + 18, 88, 48, 5).fillAndStroke("#071820", "#34464d");
        doc.font("Helvetica-Bold").fontSize(11).fillColor("#55d9f2").text("100%", faceX + 108, unitY + 29, { width: 88, align: "center", lineBreak: false });
        doc.font("Helvetica").fontSize(5.5).fillColor("#9eeaf7").text("8 MIN · ONLINE", faceX + 108, unitY + 49, { width: 88, align: "center", lineBreak: false });
        const ventX = faceX + 226;
        const ventWidth = faceWidth - 476;
        for (let slot = 0; slot < Math.max(1, Math.floor(ventWidth / 7)); slot += 1) {
          doc.rect(ventX + slot * 7, unitY + 20, 2, 54).fill("#7b878b");
        }
        const outletCount = Math.max(1, networkSwitch.portCount);
        const outletColumns = Math.min(4, outletCount);
        const outletWidth = 36;
        const outletGap = 7;
        const outletStart = faceX + faceWidth - outletColumns * (outletWidth + outletGap) - 35;
        for (let outlet = 1; outlet <= outletCount; outlet += 1) {
          const column = (outlet - 1) % outletColumns;
          const row = Math.floor((outlet - 1) / outletColumns);
          const x = outletStart + column * (outletWidth + outletGap);
          const outletY = unitY + 17 + row * 35;
          const power = (topology.powerLinks || []).find((item) => item.upsId === networkSwitch.id && Number(item.outlet) === outlet);
          const backup = outlet <= 4;
          doc.roundedRect(x, outletY, outletWidth, 27, 3).fillAndStroke(power ? "#dff5e8" : "#edf0f1", power ? "#138a55" : "#69767a");
          doc.rect(x, outletY + 23, outletWidth, 4).fill(backup ? "#21a06b" : "#e3a72d");
          doc.font("Helvetica-Bold").fontSize(5.5).fillColor("#263238").text(`${backup ? "B" : "S"}${backup ? outlet : outlet - 4}`, x, outletY + 9, { width: outletWidth, align: "center", lineBreak: false });
        }
        doc.font("Helvetica").fontSize(5).fillColor("#66767d").text("BACKUP", outletStart, unitY + faceHeight - 12, { width: 75, lineBreak: false });
        doc.text("SURGE", outletStart + 80, unitY + faceHeight - 12, { width: 75, lineBreak: false });
      } else {
        const isGateway = networkSwitch.category === "gateway";
        const isSuperLink = networkSwitch.category === "super-link";
        if (isSuperLink) {
          doc.roundedRect(faceX + 68, unitY + 12, 190, faceHeight - 24, 9).fillAndStroke("#fbfcfc", "#b7c1c4");
          doc.circle(faceX + 96, unitY + faceHeight / 2, 14).lineWidth(1.6).stroke("#2c93d5");
          doc.font("Helvetica-Bold").fontSize(7).fillColor("#2c93d5").text("SL", faceX + 82, unitY + faceHeight / 2 - 3, { width: 28, align: "center", lineBreak: false });
          doc.font("Helvetica-Bold").fontSize(10).fillColor("#46545a").text("SuperLink", faceX + 120, unitY + 23, { width: 120, lineBreak: false });
          doc.font("Helvetica").fontSize(6).fillColor("#748389").text("PoE · USB-C · RF", faceX + 120, unitY + 41, { width: 120, lineBreak: false });
        } else {
          doc.roundedRect(faceX + 66, unitY + faceHeight / 2 - 19, 42, 38, 3).fillAndStroke("#071126", "#273243");
          doc.circle(faceX + 87, unitY + faceHeight / 2, 10).lineWidth(1.4).stroke("#8ec5ff");
          doc.circle(faceX + 87, unitY + faceHeight / 2, 4).fill("#142246");
          if (isGateway) {
            doc.rect(faceX + 142, unitY + faceHeight / 2 - 23, 270, 46).fillAndStroke("#c9ced0", "#71787b");
            doc.circle(faceX + 398, unitY + faceHeight / 2, 2).fill("#3b4448");
          }
        }
        const portsPerRow = isGateway ? 4 : isSuperLink ? 4 : 12;
        const portsX = isGateway ? faceX + faceWidth - 420 : faceX + (isSuperLink ? 286 : 142);
        const sfpReserve = isSuperLink ? 30 : isGateway ? 238 : 156;
        const portsWidth = Math.max(130, faceX + faceWidth - sfpReserve - portsX);
        const gap = 5;
        const portWidth = Math.max(18, (portsWidth - gap * (portsPerRow - 1)) / portsPerRow);
        for (let port = 1; port <= networkSwitch.portCount; port += 1) {
          const column = (port - 1) % portsPerRow;
          const row = Math.floor((port - 1) / portsPerRow);
          const x = portsX + column * (portWidth + gap);
          const portY = unitY + Math.max(12, (faceHeight - Math.ceil(networkSwitch.portCount / portsPerRow) * 34) / 2) + row * 34;
          const assignment = assignments.get(`${networkSwitch.id}:${port}`);
          const link = links.get(`${networkSwitch.id}:${port}`);
          const device = assignment && devices.get(assignment.deviceId);
          const fill = link ? "#d97904" : device ? "#087f8c" : "#303b40";
          const stroke = link ? "#7e4700" : device ? "#00545d" : "#151d20";
          const notch = Math.min(7, portWidth * .22);
          doc.save().moveTo(x, portY).lineTo(x + portWidth, portY).lineTo(x + portWidth, portY + 16).lineTo(x + portWidth - notch, portY + 16).lineTo(x + portWidth - notch, portY + 22).lineTo(x + notch, portY + 22).lineTo(x + notch, portY + 16).lineTo(x, portY + 16).closePath().fillAndStroke(fill, stroke);
          const contactGap = Math.max(1.5, (portWidth - 10) / 8);
          for (let contact = 0; contact < 8; contact += 1) doc.rect(x + 5 + contact * contactGap, portY + 3, 1.2, 5).fill("#d9aa43");
          doc.restore();
          doc.font("Helvetica-Bold").fontSize(5.5).fillColor("#ffffff").text(String(port), x, portY + 10, { width: portWidth, align: "center", lineBreak: false });
          if (device || link) {
            doc.circle(x + portWidth - 3, portY - 3, 2).fill("#38b957");
            doc.circle(x + portWidth - 8, portY - 3, 2).fill("#e5b73f");
            const plugColor = link ? "#3971ff" : "#eef1f2";
            doc.roundedRect(x + 2, portY + 8, Math.max(8, portWidth - 4), 13, 2).fillAndStroke(plugColor, link ? "#2852c4" : "#aeb7ba");
            doc.moveTo(x + portWidth / 2, portY + 21).lineTo(x + portWidth / 2, portY + 30).lineWidth(4).stroke(plugColor);
          }
        }
        if (isGateway) {
          const wanX = faceX + faceWidth - 220;
          const wanY = unitY + faceHeight / 2 - 13;
          doc.rect(wanX, wanY, 30, 27).fillAndStroke("#242d31", "#12191c");
          doc.font("Helvetica-Bold").fontSize(5).fillColor("#263238").text("WAN", wanX, wanY - 10, { width: 30, align: "center", lineBreak: false });
          doc.circle(wanX + 25, wanY + 31, 2).fill("#38b957");
        }
        if (!isSuperLink) {
          const sfpX = faceX + faceWidth - (isGateway ? 142 : 150);
          for (let sfp = 1; sfp <= 2; sfp += 1) {
            const portKey = `sfp${sfp}`;
            const link = links.get(`${networkSwitch.id}:${portKey}`);
            const x = sfpX + (isGateway ? 0 : (sfp - 1) * 62);
            const sfpY = isGateway ? unitY + 10 + (sfp - 1) * 34 : unitY + Math.max(15, (faceHeight - 28) / 2);
            doc.rect(x, sfpY, 54, 28).fillAndStroke(link ? "#d97904" : "#899397", link ? "#7e4700" : "#354146");
            doc.rect(x + 6, sfpY + 5, 42, 15).fillAndStroke(link ? "#a75d00" : "#5f6b70", "#303a3e");
            const sfpLabel = isGateway ? "SFP28" : "SFP+";
            doc.font("Helvetica-Bold").fontSize(5.2).fillColor("#ffffff").text(`${sfpLabel} ${sfp}`, x, sfpY + 21, { width: 54, align: "center", lineBreak: false });
            if (link) doc.circle(x + 49, sfpY - 3, 2).fill("#38b957");
          }
        }
      }
      doc.circle(faceX + faceWidth - 28, unitY + 15, 3).fill("#38b957");
      doc.circle(faceX + faceWidth - 18, unitY + 15, 3).fill("#e5b73f");
      doc.moveTo(rackX + rackWidth, unitY + faceHeight / 2).lineTo(labelX - 13, unitY + faceHeight / 2).lineWidth(.7).stroke("#8a969a");
      doc.font("Helvetica-Bold").fontSize(11).fillColor("#263238").text(networkSwitch.name, labelX, unitY + faceHeight / 2 - 11, { width: labelWidth, lineBreak: false, ellipsis: true });
      const category = ({ switch: "Switch", gateway: "Gateway", "super-link": "Super-Link", ups: "Battery UPS" })[networkSwitch.category] || "Switch";
      doc.font("Helvetica").fontSize(8).fillColor("#66767d").text(`${category} · ${networkSwitch.model || "Model not specified"} · ${networkSwitch.portCount} ${networkSwitch.category === "ups" ? "outlets" : "ports"}`, labelX, unitY + faceHeight / 2 + 6, { width: labelWidth, lineBreak: false, ellipsis: true });
      unitY += faceHeight + 8;
    }
    y += rackHeight + 24;
  };
  newSheet();
  const maxRackInterior = pageHeight - 400;
  for (const rack of topology.racks) {
    const rackSwitches = topology.switches.filter((item) => item.rackId === rack.id);
    if (!rackSwitches.length) {
      drawRack(rack, [], 1, 1);
      continue;
    }
    const chunks = [];
    let chunk = [];
    let chunkHeight = 0;
    for (const networkSwitch of rackSwitches) {
      const height = switchHeight(networkSwitch) + 8;
      if (chunk.length && chunkHeight + height > maxRackInterior) {
        chunks.push(chunk);
        chunk = [];
        chunkHeight = 0;
      }
      chunk.push(networkSwitch);
      chunkHeight += height;
    }
    if (chunk.length) chunks.push(chunk);
    chunks.forEach((rackChunk, index) => drawRack(rack, rackChunk, index + 1, chunks.length));
  }
  const portAssignments = topology.assignments
    .filter((assignment) => assignment.port > 0 && devices.has(assignment.deviceId))
    .sort((a, b) => a.switchId.localeCompare(b.switchId) || a.port - b.port);
  if (portAssignments.length) {
    const switchMap = new Map(topology.switches.map((networkSwitch) => [networkSwitch.id, networkSwitch]));
    const rackMap = new Map(topology.racks.map((rack) => [rack.id, rack]));
    const drawScheduleHeader = () => {
      ensureSpace(62);
      doc.font("Helvetica-Bold").fontSize(12).fillColor("#182026").text("PORT ASSIGNMENT SCHEDULE", margin, y, { lineBreak: false });
      y += 24;
      doc.rect(margin, y, contentWidth, 24).fill("#263238");
      doc.font("Helvetica-Bold").fontSize(7).fillColor("#ffffff");
      doc.text("RACK", margin + 10, y + 8, { width: 330, lineBreak: false });
      doc.text("RACK EQUIPMENT", margin + 360, y + 8, { width: 430, lineBreak: false });
      doc.text("PORT", margin + 820, y + 8, { width: 100, lineBreak: false });
      doc.text("FLOOR-PLAN DEVICE", margin + 950, y + 8, { width: contentWidth - 960, lineBreak: false });
      y += 24;
    };
    drawScheduleHeader();
    for (const assignment of portAssignments) {
      if (y + 24 > pageHeight - 90) {
        newSheet();
        drawScheduleHeader();
      }
      const networkSwitch = switchMap.get(assignment.switchId);
      const rack = rackMap.get(networkSwitch?.rackId);
      const device = devices.get(assignment.deviceId);
      const equipment = blueprintEquipment[device.equipmentType] || blueprintEquipment.camera;
      doc.rect(margin, y, contentWidth, 24).fillAndStroke(y % 48 ? "#ffffff" : "#f2f5f6", "#c4ced1");
      doc.font("Helvetica").fontSize(7.5).fillColor("#263238");
      doc.text(rack?.name || "Rack", margin + 10, y + 8, { width: 330, lineBreak: false, ellipsis: true });
      doc.text(networkSwitch?.name || "Switch", margin + 360, y + 8, { width: 430, lineBreak: false, ellipsis: true });
      doc.font("Helvetica-Bold").text(String(assignment.port), margin + 820, y + 8, { width: 100, lineBreak: false });
      doc.font("Helvetica").text(`${equipment.short} · ${device.label || equipment.name}${device.topologyPageTitle ? ` · ${device.topologyPageTitle}` : ""}`, margin + 950, y + 8, { width: contentWidth - 960, lineBreak: false, ellipsis: true });
      y += 24;
    }
    y += 24;
  }
  if ((topology.links || []).length) {
    ensureSpace(64);
    doc.font("Helvetica-Bold").fontSize(12).fillColor("#182026").text("EQUIPMENT UPLINKS", margin, y, { lineBreak: false });
    y += 24;
    doc.rect(margin, y, contentWidth, 24).fill("#7e4700");
    doc.font("Helvetica-Bold").fontSize(7).fillColor("#ffffff");
    doc.text("FROM", margin + 10, y + 8, { width: 690, lineBreak: false });
    doc.text("CONNECTION", margin + 730, y + 8, { width: 260, lineBreak: false });
    doc.text("TO", margin + 1020, y + 8, { width: contentWidth - 1030, lineBreak: false });
    y += 24;
    for (const link of topology.links) {
      if (y + 24 > pageHeight - 90) {
        newSheet();
        doc.font("Helvetica-Bold").fontSize(12).fillColor("#182026").text("EQUIPMENT UPLINKS · CONTINUED", margin, y, { lineBreak: false });
        y += 26;
      }
      const from = equipmentMap.get(link.fromId);
      const to = equipmentMap.get(link.toId);
      doc.rect(margin, y, contentWidth, 24).fillAndStroke("#fff8ed", "#d6b27b");
      doc.font("Helvetica").fontSize(7.5).fillColor("#263238");
      doc.text(`${from?.name || "Equipment"} · ${printablePort(link.fromPort)}`, margin + 10, y + 8, { width: 690, lineBreak: false, ellipsis: true });
      doc.font("Helvetica-Bold").fillColor("#9a5c00").text(String(link.type || "cat6").toUpperCase(), margin + 730, y + 8, { width: 260, lineBreak: false });
      doc.font("Helvetica").fillColor("#263238").text(`${to?.name || "Equipment"} · ${printablePort(link.toPort)}`, margin + 1020, y + 8, { width: contentWidth - 1030, lineBreak: false, ellipsis: true });
      y += 24;
    }
    y += 24;
  }
  if ((topology.powerLinks || []).length) {
    ensureSpace(64);
    doc.font("Helvetica-Bold").fontSize(12).fillColor("#182026").text("UPS POWER ASSIGNMENTS", margin, y, { lineBreak: false });
    y += 24;
    doc.rect(margin, y, contentWidth, 24).fill("#0d6f45");
    doc.font("Helvetica-Bold").fontSize(7).fillColor("#ffffff");
    doc.text("POWERED EQUIPMENT", margin + 10, y + 8, { width: 760, lineBreak: false });
    doc.text("BATTERY UPS", margin + 800, y + 8, { width: 650, lineBreak: false });
    doc.text("OUTLET", margin + 1480, y + 8, { width: contentWidth - 1490, lineBreak: false });
    y += 24;
    for (const powerLink of topology.powerLinks) {
      if (y + 24 > pageHeight - 90) {
        newSheet();
        doc.font("Helvetica-Bold").fontSize(12).fillColor("#182026").text("UPS POWER ASSIGNMENTS · CONTINUED", margin, y, { lineBreak: false });
        y += 26;
      }
      const device = equipmentMap.get(powerLink.deviceId);
      const ups = equipmentMap.get(powerLink.upsId);
      doc.rect(margin, y, contentWidth, 24).fillAndStroke("#eff8f3", "#9ac9ae");
      doc.font("Helvetica").fontSize(7.5).fillColor("#263238");
      doc.text(device?.name || "Equipment", margin + 10, y + 8, { width: 760, lineBreak: false, ellipsis: true });
      doc.text(ups?.name || "Battery UPS", margin + 800, y + 8, { width: 650, lineBreak: false, ellipsis: true });
      doc.font("Helvetica-Bold").fillColor("#0d6f45").text(String(powerLink.outlet), margin + 1480, y + 8, { width: contentWidth - 1490, lineBreak: false });
      y += 24;
    }
    y += 24;
  }
  const unassigned = [...devices.values()].filter((device) => !["network-switch", "rack"].includes(device.equipmentType) && !assignedDeviceIds.has(device.id));
  if (unassigned.length) {
    ensureSpace(70 + Math.ceil(unassigned.length / 3) * 18);
    doc.font("Helvetica-Bold").fontSize(11).fillColor("#b13a32").text("UNASSIGNED FLOOR-PLAN DEVICES", margin, y, { lineBreak: false });
    y += 22;
    unassigned.forEach((device, index) => {
      const column = index % 3;
      const row = Math.floor(index / 3);
      const equipment = blueprintEquipment[device.equipmentType] || blueprintEquipment.camera;
      doc.font("Helvetica").fontSize(8).fillColor("#34444a").text(`• ${device.label || equipment.name} (${equipment.short})${device.topologyPageTitle ? ` · ${device.topologyPageTitle}` : ""}`, margin + column * (contentWidth / 3), y + row * 18, { width: contentWidth / 3 - 15, lineBreak: false, ellipsis: true });
    });
  }
  drawFooter();
}

function drawPdfBlueprintCallout(doc, item, minimumTextSize = 4) {
  const geometry = blueprintCalloutGeometry(item);
  const color = item.color || "#087f8c";
  const fontSize = Math.max(minimumTextSize, Number(item.fontSize) || 14);
  doc.save().strokeColor(color).fillColor(color);
  doc.moveTo(geometry.anchorX, geometry.anchorY).lineTo(item.targetX, item.targetY).lineWidth(2).stroke();
  doc.polygon(
    [item.targetX, item.targetY],
    [geometry.arrowAX, geometry.arrowAY],
    [geometry.arrowBX, geometry.arrowBY]
  ).fill(color);
  doc.roundedRect(item.x, item.y, geometry.width, geometry.height, 4).fillAndStroke(item.fill || "#ffffff", color);
  doc.font("Helvetica-Bold").fontSize(fontSize).fillColor(color);
  geometry.lines.forEach((line, index) => doc.text(
    line, item.x + geometry.padding, item.y + geometry.padding + index * geometry.lineHeight,
    { width: geometry.width - geometry.padding * 2, lineBreak: false, ellipsis: true }
  ));
  doc.restore();
}

function renderCoverageBlueprintPage(doc, plan, pageWidth, pageHeight, margin) {
  const info = plan.blueprintInfo || {};
  const drawingY = 126;
  const drawingWidth = pageWidth - margin * 2;
  const drawingHeight = pageHeight - drawingY - 72;
  const bounds = floorPlanContentBounds(plan.objects, plan.canvas);
  const scale = 1.5;
  const originX = margin + (drawingWidth - bounds.width * scale) / 2 - bounds.minX * scale;
  const originY = drawingY + (drawingHeight - bounds.height * scale) / 2 - bounds.minY * scale;
  doc.addPage({ size: [pageWidth, pageHeight], margin: 0 });
  doc.rect(24, 24, pageWidth - 48, pageHeight - 48).lineWidth(2).stroke("#182026");
  const logo = join(root, "assets", "logo.png");
  if (existsSync(logo)) doc.image(logo, margin, 42, { fit: [58, 58] });
  doc.font("Helvetica-Bold").fontSize(22).fillColor("#182026").text("EQUIPMENT COVERAGE PLAN", margin + 76, 45, { lineBreak: false });
  doc.font("Helvetica").fontSize(10).fillColor("#526068").text(
    [plan.title, plan.project?.buildingName, plan.project?.floorName].filter(Boolean).join(" · "),
    margin + 76, 78, { width: 1100, lineBreak: false, ellipsis: true }
  );
  doc.font("Helvetica-Bold").fontSize(9).fillColor("#182026").text("Scale 1/4\" = 1'-0\"", margin + 76, 96, { lineBreak: false });
  doc.font("Helvetica-Bold").fontSize(8).fillColor("#66767d").text("CONTRACT TICKET", pageWidth - margin - 390, 48, { lineBreak: false });
  doc.font("Helvetica-Bold").fontSize(12).fillColor("#182026").text(info.contractTicket || "Not assigned", pageWidth - margin - 270, 46, { width: 270, align: "right", lineBreak: false });
  doc.font("Helvetica").fontSize(9).fillColor("#526068").text(info.customerSite || "", pageWidth - margin - 390, 73, { width: 390, align: "right", lineBreak: false, ellipsis: true });
  doc.rect(margin, drawingY, drawingWidth, drawingHeight).lineWidth(0.8).stroke("#607d86");
  doc.save().rect(margin, drawingY, drawingWidth, drawingHeight).clip().translate(originX, originY).scale(scale);
  for (const item of plan.objects.filter((record) => record.type === "network-device")) {
    const radius = Math.min(2400, Math.max(12, Number(item.coverageRadius) || ({ camera: 180, "wireless-ap": 300, "access-reader": 48 }[item.equipmentType] || 0)));
    if (!radius) continue;
    doc.save().lineWidth(Math.max(0.8, 1.2 / scale)).dash(7 / scale, { space: 5 / scale }).fillOpacity(0.12);
    if (item.equipmentType === "wireless-ap") {
      doc.circle(item.x, item.y, radius).fillAndStroke("#1976d2", "#1976d2");
    } else if (item.equipmentType === "access-reader") {
      doc.circle(item.x, item.y, radius).fillAndStroke("#8e44ad", "#8e44ad");
    } else if (item.equipmentType === "camera") {
      const angle = Math.min(180, Math.max(10, Number(item.coverageAngle) || 70));
      const start = ((Number(item.rotation) || 0) - angle / 2) * Math.PI / 180;
      const end = ((Number(item.rotation) || 0) + angle / 2) * Math.PI / 180;
      const x1 = item.x + Math.cos(start) * radius;
      const y1 = item.y + Math.sin(start) * radius;
      const x2 = item.x + Math.cos(end) * radius;
      const y2 = item.y + Math.sin(end) * radius;
      doc.path(`M ${item.x} ${item.y} L ${x1} ${y1} A ${radius} ${radius} 0 0 1 ${x2} ${y2} Z`).fillAndStroke("#d84343", "#d84343");
    }
    doc.undash().fillOpacity(1).restore();
  }
  const deviceMap = new Map(plan.objects.filter((item) => item.type === "network-device").map((item) => [item.id, item]));
  const textSize = Math.max(4, 9 / scale);
  for (const item of plan.objects) {
    const color = item.color || "#263238";
    doc.save().strokeColor(color).fillColor(color);
    if (item.type === "wall") doc.moveTo(item.x1, item.y1).lineTo(item.x2, item.y2).lineWidth(Math.max(1, item.thickness)).stroke();
    else if (item.type === "room") doc.rect(item.x, item.y, item.w, item.h).fillOpacity(0.08).fillAndStroke(item.fill || "#e7f1f3", color).fillOpacity(1);
    else if (item.type === "window") doc.moveTo(item.x - item.width / 2, item.y - 2).lineTo(item.x + item.width / 2, item.y - 2).moveTo(item.x - item.width / 2, item.y + 2).lineTo(item.x + item.width / 2, item.y + 2).lineWidth(1.5).stroke();
    else if (item.type === "door") {
      doc.save().translate(item.x, item.y).rotate(item.rotation || 0).moveTo(0, 0).lineTo(item.width, 0).lineWidth(2).stroke();
      const direction = item.swing === "outward" ? 1 : -1;
      doc.moveTo(0, 0).lineTo(0, direction * item.width).lineWidth(1.6).stroke().restore();
    } else if (item.type === "label") doc.font("Helvetica-Bold").fontSize(Math.max(textSize, item.fontSize * 0.55)).text(item.text || "", item.x, item.y, { lineBreak: false });
    else if (item.type === "callout") drawPdfBlueprintCallout(doc, item, textSize);
    else if (item.type === "cable" && item.points.length > 1) {
      const points = blueprintCablePoints(item, deviceMap);
      doc.moveTo(points[0].x, points[0].y); for (const point of points.slice(1)) doc.lineTo(point.x, point.y);
      doc.lineWidth(Math.max(0.8, item.thickness || 2)).stroke();
    } else if (item.type === "network-device") {
      const equipment = blueprintEquipment[item.equipmentType] || blueprintEquipment.camera;
      const ceiling = blueprintCeilingEquipment.has(item.equipmentType) && item.mount !== "wall";
      if (ceiling) doc.circle(item.x, item.y, 14).fillAndStroke("#ffffff", color);
      else doc.rect(item.x - 14, item.y - 14, 28, 28).fillAndStroke("#ffffff", color);
      doc.font("Helvetica-Bold").fontSize(Math.max(4, 7 / scale)).fillColor(color).text(equipment.short, item.x - 14, item.y - 3 / scale, { width: 28, align: "center", lineBreak: false });
      doc.font("Helvetica-Bold").fontSize(textSize).fillColor("#263238").text(item.label || equipment.name, item.x - 55 / scale, item.y + 18, { width: 110 / scale, align: "center", lineBreak: false });
    }
    doc.restore();
  }
  doc.restore();
  const legendY = pageHeight - 54;
  doc.font("Helvetica-Bold").fontSize(8).fillColor("#d84343").text("CAMERA FIELD OF VIEW", margin, legendY, { lineBreak: false });
  doc.fillColor("#1976d2").text("WI-FI COVERAGE", margin + 180, legendY, { lineBreak: false });
  doc.fillColor("#8e44ad").text("ACCESS READER AREA", margin + 315, legendY, { lineBreak: false });
  doc.font("Helvetica").fillColor("#66767d").text("Coverage is a planning estimate and should be verified during installation.", margin + 500, legendY, { lineBreak: false });
  doc.font("Helvetica-Bold").text("Sheet CV-1", pageWidth - margin - 100, legendY, { width: 100, align: "right", lineBreak: false });
}

function renderFloorPlanBlueprintPage(doc, plan, sheetNumber = 1, addPage = false) {
  const letter = plan.blueprintInfo?.paperSize === "letter";
  const pageWidth = letter ? 11 * 72 : 36 * 72;
  const pageHeight = letter ? 8.5 * 72 : 24 * 72;
  const margin = letter ? 18 : 42;
  const titleHeight = letter ? 78 : 132;
  const drawingWidth = pageWidth - margin * 2;
  const drawingHeight = pageHeight - margin * 2 - titleHeight;
  const contentBounds = floorPlanContentBounds(plan.objects, plan.canvas);
  const hasLegend = plan.objects.some((item) => ["network-device", "cable"].includes(item.type));
  const legendReserve = hasLegend ? (letter ? 238 : 880) : 0;
  const planDrawingWidth = drawingWidth - legendReserve;
  const fitScale = Math.min(
    (planDrawingWidth - (letter ? 18 : 56)) / contentBounds.width,
    (drawingHeight - (letter ? 18 : 56)) / contentBounds.height
  );
  const scale = Math.max(0.2, Math.min(letter ? 4 : 7, fitScale));
  const originX = margin + (planDrawingWidth - contentBounds.width * scale) / 2 - contentBounds.minX * scale;
  const originY = margin + (drawingHeight - contentBounds.height * scale) / 2 - contentBounds.minY * scale;
  const floorPlanDevices = new Map(plan.objects.filter((item) => item.type === "network-device").map((item) => [item.id, item]));
  const info = plan.blueprintInfo || {};
  if (addPage) doc.addPage({ size: [pageWidth, pageHeight], margin: 0 });
  doc.rect(24, 24, pageWidth - 48, pageHeight - 48).lineWidth(2).stroke("#182026");
  doc.rect(margin, margin, drawingWidth, drawingHeight).lineWidth(0.8).stroke("#607d86");
  doc.save().rect(margin, margin, drawingWidth, drawingHeight).clip().translate(originX, originY).scale(scale);
  const textSize = Math.max(4, 10 / scale);
  for (const item of plan.objects) {
    const color = item.color || "#263238";
    doc.save().strokeColor(color).fillColor(color);
    if (item.type === "wall") {
      doc.moveTo(item.x1, item.y1).lineTo(item.x2, item.y2).lineWidth(Math.max(1, item.thickness)).stroke();
    } else if (item.type === "room") {
      doc.rect(item.x, item.y, item.w, item.h).fillOpacity(0.14).fillAndStroke(item.fill || "#e7f1f3", color).fillOpacity(1);
      if (item.label) doc.font("Helvetica-Bold").fontSize(textSize).fillColor("#263238").text(item.label, item.x, item.y + item.h / 2 - textSize / 2, { width: item.w, align: "center", lineBreak: false });
    } else if (item.type === "stairs") {
      doc.rect(item.x, item.y, item.w, item.h).lineWidth(1).stroke();
      const steps = Math.max(2, Math.floor(item.h / 12));
      for (let index = 1; index < steps; index += 1) doc.moveTo(item.x, item.y + item.h * index / steps).lineTo(item.x + item.w, item.y + item.h * index / steps).lineWidth(0.6).stroke();
    } else if (item.type === "door") {
      doc.save().translate(item.x, item.y).rotate(item.rotation || 0);
      doc.moveTo(-3, 0).lineTo(item.width + 3, 0).lineWidth(Math.max(8, item.width / 5)).stroke("#ffffff");
      doc.moveTo(0, -5).lineTo(0, 5).moveTo(item.width, -5).lineTo(item.width, 5).lineWidth(2).stroke(color);
      const direction = item.swing === "outward" ? 1 : -1;
      if (item.doorStyle === "sliding") {
        doc.moveTo(item.width * 0.08, -5).lineTo(item.width * 0.62, -5).moveTo(item.width * 0.38, 5).lineTo(item.width * 0.92, 5).lineWidth(2.4).stroke(color);
      } else if (item.doorStyle === "double") {
        const half = item.width / 2;
        doc.moveTo(0, 0).lineTo(0, direction * half).moveTo(item.width, 0).lineTo(item.width, direction * half).lineWidth(2.4).stroke(color);
        doc.path(`M ${half} 0 A ${half} ${half} 0 0 ${direction > 0 ? 1 : 0} 0 ${direction * half}`).lineWidth(0.8).stroke(color);
        doc.path(`M ${half} 0 A ${half} ${half} 0 0 ${direction > 0 ? 0 : 1} ${item.width} ${direction * half}`).lineWidth(0.8).stroke(color);
      } else if (item.hinge === "right") {
        doc.moveTo(item.width, 0).lineTo(item.width, direction * item.width).lineWidth(2.4).stroke(color);
        doc.path(`M 0 0 A ${item.width} ${item.width} 0 0 ${direction < 0 ? 1 : 0} ${item.width} ${direction * item.width}`).lineWidth(0.8).stroke(color);
      } else {
        doc.moveTo(0, 0).lineTo(0, direction * item.width).lineWidth(2.4).stroke(color);
        doc.path(`M ${item.width} 0 A ${item.width} ${item.width} 0 0 ${direction > 0 ? 1 : 0} 0 ${direction * item.width}`).lineWidth(0.8).stroke(color);
      }
      doc.restore();
    } else if (item.type === "window") {
      doc.moveTo(item.x - item.width / 2, item.y - 2).lineTo(item.x + item.width / 2, item.y - 2).moveTo(item.x - item.width / 2, item.y + 2).lineTo(item.x + item.width / 2, item.y + 2).lineWidth(1.5).stroke();
    } else if (item.type === "column") {
      doc.rect(item.x - item.size / 2, item.y - item.size / 2, item.size, item.size).fill(item.fill || "#455a64");
    } else if (item.type === "label") {
      doc.font("Helvetica-Bold").fontSize(Math.max(textSize, item.fontSize * 0.65)).fillColor(color).text(item.text || "", item.x, item.y, { lineBreak: false });
    } else if (item.type === "callout") {
      drawPdfBlueprintCallout(doc, item, textSize);
    } else if (item.type === "dimension") {
      doc.moveTo(item.x1, item.y1).lineTo(item.x2, item.y2).lineWidth(0.7).dash(5 / scale, { space: 3 / scale }).stroke().undash();
      const length = Math.hypot(item.x2 - item.x1, item.y2 - item.y1) / 12;
      doc.font("Helvetica-Bold").fontSize(textSize).text(`${length.toFixed(1)} ft`, (item.x1 + item.x2) / 2 - 30 / scale, (item.y1 + item.y2) / 2 - 12 / scale, { width: 60 / scale, align: "center", lineBreak: false });
    } else if (item.type === "network-device") {
      const equipment = blueprintEquipment[item.equipmentType] || blueprintEquipment.camera;
      const ceilingMounted = blueprintCeilingEquipment.has(item.equipmentType) && item.mount !== "wall";
      if (ceilingMounted) doc.circle(item.x, item.y, 14).fillAndStroke("#ffffff", color);
      else doc.rect(item.x - 14, item.y - 14, 28, 28).fillAndStroke("#ffffff", color);
      doc.font("Helvetica-Bold").fontSize(Math.max(4, 7 / scale)).fillColor(color).text(equipment.short, item.x - 14, item.y - 3 / scale, { width: 28, align: "center", lineBreak: false });
      doc.font("Helvetica-Bold").fontSize(textSize).fillColor("#263238").text(item.label || equipment.name, item.x - 55 / scale, item.y + 18, { width: 110 / scale, align: "center", lineBreak: false });
    } else if (item.type === "cable" && item.points.length > 1) {
      const points = blueprintCablePoints(item, floorPlanDevices);
      doc.moveTo(points[0].x, points[0].y);
      for (const point of points.slice(1)) doc.lineTo(point.x, point.y);
      doc.lineWidth(Math.max(0.8, item.thickness || 2)).stroke();
    }
    doc.restore();
  }
  doc.restore();
  const deviceCounts = new Map();
  const cableCounts = new Map();
  for (const item of plan.objects) {
    if (item.type === "network-device") deviceCounts.set(item.equipmentType, (deviceCounts.get(item.equipmentType) || 0) + 1);
    if (item.type === "cable") {
      const record = cableCounts.get(item.cableType) || { count: 0, length: 0 };
      record.count += 1;
      record.length += blueprintCableLength(item, floorPlanDevices);
      cableCounts.set(item.cableType, record);
    }
  }
  const legendRows = [
    ...[...deviceCounts].map(([type, count]) => ({
      kind: "device", type, color: blueprintEquipmentColors[type] || "#455a64",
      short: blueprintEquipment[type]?.short || "DEV",
      label: blueprintEquipment[type]?.name || type, value: String(count)
    })),
    ...[...cableCounts].map(([type, record]) => ({
      kind: "cable", type, color: blueprintCableColors[type] || "#455a64",
      label: blueprintCables[type] || type, value: `${record.count} run${record.count === 1 ? "" : "s"} · ${(record.length / 12).toFixed(1)} ft`
    }))
  ];
  if (legendRows.length) {
    const baseLegendHeight = 42 + legendRows.length * 22;
    const legendScale = letter
      ? Math.max(0.56, Math.min(0.72, (drawingHeight - 20) / baseLegendHeight))
      : Math.max(1.35, Math.min(2.6, (drawingHeight - 32) / baseLegendHeight));
    const legendWidth = 330 * legendScale;
    const legendHeight = baseLegendHeight * legendScale;
    const legendX = margin + drawingWidth - legendWidth - 16;
    const legendY = margin + 16;
    doc.save().fillOpacity(0.96).roundedRect(legendX, legendY, legendWidth, legendHeight, 5 * legendScale).fillAndStroke("#ffffff", "#52666d").fillOpacity(1);
    doc.font("Helvetica-Bold").fontSize(12 * legendScale).fillColor("#182026").text("NETWORK LEGEND", legendX + 14 * legendScale, legendY + 12 * legendScale, { lineBreak: false });
    legendRows.forEach((row, index) => {
      const y = legendY + (37 + index * 22) * legendScale;
      if (row.kind === "device") {
        doc.rect(legendX + 15 * legendScale, y - 8 * legendScale, 13 * legendScale, 13 * legendScale).fillAndStroke("#ffffff", row.color);
        doc.font("Helvetica-Bold").fontSize((row.short.length > 2 ? 4.2 : 5.2) * legendScale).fillColor(row.color).text(row.short, legendX + 15 * legendScale, y - 4.7 * legendScale, { width: 13 * legendScale, align: "center", lineBreak: false });
      } else {
        doc.moveTo(legendX + 14 * legendScale, y - legendScale).lineTo(legendX + 30 * legendScale, y - legendScale).lineWidth(2.5 * legendScale).stroke(row.color);
      }
      doc.font("Helvetica").fontSize(8.5 * legendScale).fillColor("#263238").text(row.label, legendX + 39 * legendScale, y - 7 * legendScale, { width: 175 * legendScale, lineBreak: false, ellipsis: true });
      doc.font("Helvetica-Bold").fontSize(8.5 * legendScale).text(row.value, legendX + 216 * legendScale, y - 7 * legendScale, { width: 99 * legendScale, align: "right", lineBreak: false, ellipsis: true });
    });
    doc.restore();
  }
  const titleY = pageHeight - margin - titleHeight;
  if (letter) {
    const companyWidth = 205;
    const detailsWidth = 220;
    const centerX = margin + companyWidth + 12;
    const centerWidth = drawingWidth - companyWidth - detailsWidth - 24;
    const detailsX = pageWidth - margin - detailsWidth + 10;
    doc.rect(margin, titleY, drawingWidth, titleHeight).lineWidth(1).stroke("#182026");
    doc.moveTo(margin + companyWidth, titleY).lineTo(margin + companyWidth, titleY + titleHeight).stroke();
    doc.moveTo(pageWidth - margin - detailsWidth, titleY).lineTo(pageWidth - margin - detailsWidth, titleY + titleHeight).stroke();
    const blueprintLogo = join(root, "assets", "logo.png");
    if (existsSync(blueprintLogo)) doc.image(blueprintLogo, margin + 8, titleY + 9, { fit: [38, 38], align: "center", valign: "center" });
    doc.font("Helvetica-Bold").fontSize(8.5).fillColor("#087f8c").text("HUBER I.T. PROFESSIONALS", margin + 52, titleY + 10, { width: companyWidth - 58, lineBreak: false });
    doc.font("Helvetica").fontSize(5.5).fillColor("#34444a").text(String(info.companyAddress || "").replace(/\s*\r?\n\s*/g, " · "), margin + 52, titleY + 24, { width: companyWidth - 58, height: 24, ellipsis: true });
    doc.font("Helvetica").fontSize(5.5).fillColor("#66767d").text("DESIGN CENTER · FLOOR PLAN BLUEPRINT", margin + 8, titleY + 62, { lineBreak: false });
    doc.font("Helvetica-Bold").fontSize(12).fillColor("#182026").text(plan.title, centerX, titleY + 8, { width: centerWidth, lineBreak: false, ellipsis: true });
    doc.font("Helvetica-Bold").fontSize(5.5).fillColor("#66767d").text("CONTRACT", centerX, titleY + 27, { lineBreak: false });
    doc.font("Helvetica").fontSize(7).fillColor("#182026").text(info.contractTicket || "Not assigned", centerX + 45, titleY + 25, { width: centerWidth - 45, lineBreak: false, ellipsis: true });
    doc.font("Helvetica-Bold").fontSize(5.5).fillColor("#66767d").text("SITE", centerX, titleY + 44, { lineBreak: false });
    doc.font("Helvetica").fontSize(7).fillColor("#182026").text(info.customerSite || "Not specified", centerX + 45, titleY + 42, { width: centerWidth - 45, lineBreak: false, ellipsis: true });
    doc.font("Helvetica-Bold").fontSize(5.5).fillColor("#66767d").text("PREPARED BY", detailsX, titleY + 10, { lineBreak: false });
    doc.font("Helvetica").fontSize(7).fillColor("#182026").text(info.preparedBy || "Not specified", detailsX + 67, titleY + 8, { width: detailsWidth - 85, lineBreak: false, ellipsis: true });
    doc.font("Helvetica-Bold").fontSize(5.5).fillColor("#66767d").text("PLAN AREA", detailsX, titleY + 27, { lineBreak: false });
    doc.font("Helvetica").fontSize(7).fillColor("#182026").text(`${Math.round(plan.canvas.width / 12)} ft × ${Math.round(plan.canvas.height / 12)} ft`, detailsX + 67, titleY + 25, { lineBreak: false });
    doc.font("Helvetica-Bold").fontSize(5.5).fillColor("#66767d").text("SCALE", detailsX, titleY + 44, { lineBreak: false });
    doc.font("Helvetica").fontSize(7).fillColor("#182026").text("1/4\" = 1'-0\"", detailsX + 67, titleY + 42, { lineBreak: false });
    doc.font("Helvetica").fontSize(5.5).fillColor("#66767d").text(`Generated ${new Date().toLocaleDateString("en-US")} · Sheet FP-${sheetNumber}`, detailsX, titleY + 62, { width: detailsWidth - 20, lineBreak: false, ellipsis: true });
  } else {
  doc.rect(margin, titleY, drawingWidth, titleHeight).lineWidth(1.2).stroke("#182026");
  const companyWidth = 520;
  const detailsWidth = 520;
  doc.moveTo(margin + companyWidth, titleY).lineTo(margin + companyWidth, titleY + titleHeight).stroke();
  doc.moveTo(pageWidth - margin - detailsWidth, titleY).lineTo(pageWidth - margin - detailsWidth, titleY + titleHeight).stroke();
  const blueprintLogo = join(root, "assets", "logo.png");
  if (existsSync(blueprintLogo)) doc.image(blueprintLogo, margin + 15, titleY + 18, { fit: [76, 76], align: "center", valign: "center" });
  doc.font("Helvetica-Bold").fontSize(16).fillColor("#087f8c").text("HUBER I.T. PROFESSIONALS", margin + 104, titleY + 19, { width: companyWidth - 120, lineBreak: false });
  doc.font("Helvetica").fontSize(8.5).fillColor("#34444a").text(info.companyAddress || "", margin + 104, titleY + 45, { width: companyWidth - 122, height: 58, ellipsis: true });
  doc.font("Helvetica").fontSize(8).fillColor("#66767d").text("DESIGN CENTER · FLOOR PLAN BLUEPRINT", margin + 18, titleY + 108, { lineBreak: false });
  const centerX = margin + companyWidth + 22;
  const centerWidth = drawingWidth - companyWidth - detailsWidth - 44;
  doc.font("Helvetica-Bold").fontSize(21).fillColor("#182026").text(plan.title, centerX, titleY + 14, { width: centerWidth, lineBreak: false, ellipsis: true });
  doc.font("Helvetica-Bold").fontSize(8).fillColor("#66767d").text("CONTRACT TICKET", centerX, titleY + 49, { lineBreak: false });
  doc.font("Helvetica-Bold").fontSize(12).fillColor("#182026").text(info.contractTicket || "Not assigned", centerX, titleY + 62, { width: centerWidth, lineBreak: false, ellipsis: true });
  doc.font("Helvetica-Bold").fontSize(8).fillColor("#66767d").text("CUSTOMER / SITE", centerX, titleY + 84, { lineBreak: false });
  doc.font("Helvetica").fontSize(10).fillColor("#182026").text(info.customerSite || "Not specified", centerX, titleY + 97, { width: centerWidth, lineBreak: false, ellipsis: true });
  const detailsX = pageWidth - margin - detailsWidth + 18;
  doc.font("Helvetica-Bold").fontSize(10).fillColor("#182026").text("ISSUE INFORMATION", detailsX, titleY + 14, { lineBreak: false });
  doc.font("Helvetica-Bold").fontSize(8).fillColor("#66767d").text("PREPARED BY", detailsX, titleY + 36, { lineBreak: false });
  doc.font("Helvetica").fontSize(10).fillColor("#182026").text(info.preparedBy || "Not specified", detailsX + 92, titleY + 34, { width: detailsWidth - 124, lineBreak: false, ellipsis: true });
  doc.font("Helvetica-Bold").fontSize(8).fillColor("#66767d").text("PLAN AREA", detailsX, titleY + 58, { lineBreak: false });
  doc.font("Helvetica").fontSize(10).fillColor("#182026").text(`${Math.round(plan.canvas.width / 12)} ft × ${Math.round(plan.canvas.height / 12)} ft`, detailsX + 92, titleY + 56, { lineBreak: false });
  doc.font("Helvetica-Bold").fontSize(8).fillColor("#66767d").text("SCALE", detailsX, titleY + 80, { lineBreak: false });
  doc.font("Helvetica").fontSize(10).fillColor("#182026").text(`Scale 1/4\" = 1'-0\"${plan.currentRevision ? ` · ${plan.currentRevision}` : ""}`, detailsX + 92, titleY + 78, { lineBreak: false });
  const floorIssue = [plan.project?.buildingName, plan.project?.floorName].filter(Boolean).join(" · ");
  doc.font("Helvetica").fontSize(8).fillColor("#66767d").text(`${floorIssue ? `${floorIssue} · ` : ""}Generated ${new Date().toLocaleString("en-US")} · ${plan.objects.length} objects · Sheet FP-${sheetNumber}`, detailsX, titleY + 106, { width: detailsWidth - 36, lineBreak: false, ellipsis: true });
  }
}

function renderFloorPlanBlueprint(response, inputPlans) {
  const plans = (Array.isArray(inputPlans) ? inputPlans : [inputPlans]).filter(Boolean);
  const firstPlan = plans[0];
  const letter = firstPlan.blueprintInfo?.paperSize === "letter";
  const pageWidth = letter ? 11 * 72 : 36 * 72;
  const pageHeight = letter ? 8.5 * 72 : 24 * 72;
  const margin = letter ? 18 : 42;
  const safeName = firstPlan.title.replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").toLowerCase() || "floor-plan";
  const doc = new PDFDocument({
    size: [pageWidth, pageHeight], margin: 0, compress: true,
    info: { Title: `${firstPlan.title} Blueprint`, Author: "Huber I.T. Professionals", Subject: "Floor Plan Blueprint" }
  });
  response.writeHead(200, {
    "Content-Type": "application/pdf",
    "Content-Disposition": `attachment; filename="${safeName}-blueprint.pdf"`,
    "Cache-Control": "no-store"
  });
  doc.pipe(response);
  plans.forEach((plan, index) => renderFloorPlanBlueprintPage(doc, plan, index + 1, index > 0));
  if (firstPlan.blueprintInfo?.includeCoverage) {
    plans.forEach((plan) => renderCoverageBlueprintPage(doc, plan, pageWidth, pageHeight, margin));
  }
  const topologyPlan = plans.find((plan) => plan.topology?.racks?.length || plan.topology?.switches?.length);
  if (topologyPlan) {
    const topologyPayload = {
      ...topologyPlan,
      title: firstPlan.title,
      objects: plans.flatMap((plan) => (plan.objects || []).map((item) => ({
        ...item,
        topologyPageTitle: plan.title
      })))
    };
    if (letter) renderNetworkTopologyLetterBlueprint(doc, topologyPayload, pageWidth, pageHeight, margin);
    else renderNetworkTopologyBlueprint(doc, topologyPayload, pageWidth, pageHeight, margin);
  }
  doc.end();
}

async function handleFloorPlans(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "design-center")) {
    sendJson(response, 403, { ok: false, message: "Design Center access required." });
    return;
  }
  const url = new URL(request.url, `http://${request.headers.host}`);
  const records = readFloorPlans();
  if (request.method === "GET" && url.pathname === "/api/floor-plans") {
    const buildingId = String(url.searchParams.get("buildingId") || "");
    if (buildingId) {
      const projectPlans = records
        .filter((record) => record.project?.buildingId === buildingId)
        .sort((a, b) => (Number(a.project?.floorOrder) || 0) - (Number(b.project?.floorOrder) || 0)
          || String(a.title || "").localeCompare(String(b.title || "")));
      const projectObjects = projectPlans.flatMap((record) => Array.isArray(record.objects) ? record.objects : []);
      const topology = mergeFloorPlanTopologies(projectPlans, projectObjects);
      sendJson(response, 200, { ok: true, plans: projectPlans.map((record) => ({ ...record, topology })) });
      return;
    }
    const id = String(url.searchParams.get("id") || "");
    if (id) {
      const plan = records.find((record) => record.id === id);
      if (!plan) {
        sendJson(response, 404, { ok: false, message: "Floor plan not found." });
        return;
      }
      const projectPlans = records.filter((record) => record.project?.buildingId === plan.project?.buildingId);
      const projectObjects = projectPlans.flatMap((record) => Array.isArray(record.objects) ? record.objects : []);
      sendJson(response, 200, { ok: true, plan: { ...plan, topology: mergeFloorPlanTopologies(projectPlans, projectObjects) } });
      return;
    }
    sendJson(response, 200, {
      ok: true,
      plans: records.map(({ id, title, canvas, objects, project, revisions, importSource, updatedAt, updatedBy }) => ({
        id, title, canvas, project: cleanFloorPlanProject(project), revisionCount: Array.isArray(revisions) ? revisions.length : 0,
        importSource: importSource?.type === "iphone-roomplan" ? {
          type: "iphone-roomplan",
          roomCount: Math.min(100, Math.max(1, Math.round(Number(importSource.roomCount) || 1)))
        } : null,
        objectCount: objects.length, updatedAt, updatedBy
      })).sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)))
    });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST" && url.pathname === "/api/floor-plans/lidar") {
    let plan;
    try {
      plan = createFloorPlanFromLidar(payload, session);
    } catch (error) {
      sendJson(response, error.statusCode || 400, {
        ok: false,
        message: error.message || "Unable to import the LiDAR scan."
      });
      return;
    }
    records.push(plan);
    writeFloorPlans(records);
    logActivity(session, "floor-plan.lidar-imported",
      `Imported ${plan.importSource.roomCount} LiDAR room${plan.importSource.roomCount === 1 ? "" : "s"} into ${plan.title}.`);
    broadcastAllServiceEvent("floor-plans-updated", { id: plan.id, updatedAt: plan.updatedAt, source: "lidar" });
    sendJson(response, 200, { ok: true, plan });
    return;
  }
  if (request.method === "POST" && ["/api/floor-plans/pdf", "/api/floor-plans/svg"].includes(url.pathname)) {
    const blueprintInfo = {
      companyAddress: String(payload.blueprintInfo?.companyAddress || "").trim().slice(0, 300),
      contractTicket: String(payload.blueprintInfo?.contractTicket || "").trim().slice(0, 80),
      customerSite: String(payload.blueprintInfo?.customerSite || "").trim().slice(0, 140),
      preparedBy: String(payload.blueprintInfo?.preparedBy || "").trim().slice(0, 120),
      paperSize: payload.blueprintInfo?.paperSize === "letter" ? "letter" : "architectural",
      includeCoverage: payload.blueprintInfo?.includeCoverage === true
    };
    const cleanBlueprintPlan = (source) => {
      const layers = cleanFloorPlanLayers(source.layers);
      const objects = (Array.isArray(source.objects) ? source.objects : []).slice(0, 3000).map(cleanFloorPlanObject)
        .filter((item) => layers[item.type === "cable" ? "Cabling" : item.layer] !== false);
      return {
        id: String(source.id || ""),
        title: String(source.title || "Untitled Floor Plan").trim().slice(0, 140) || "Untitled Floor Plan",
        canvas: {
          width: Math.min(10000, Math.max(300, Number(source.canvas?.width) || 1440)),
          height: Math.min(10000, Math.max(300, Number(source.canvas?.height) || 960))
        },
        layers,
        project: cleanFloorPlanProject(source.project),
        currentRevision: String((Array.isArray(source.revisions) ? source.revisions.at(-1)?.label : "") || "").trim().slice(0, 40),
        blueprintInfo,
        objects,
        topology: cleanFloorPlanTopology(source.topology, objects)
      };
    };
    const plan = cleanBlueprintPlan(payload);
    const format = url.pathname.endsWith("/svg") ? "SVG" : "PDF";
    if (format === "SVG") renderFloorPlanBlueprintSvg(response, plan);
    else {
      const buildingId = plan.project?.buildingId;
      const projectRecords = buildingId
        ? records.filter((record) => record.project?.buildingId === buildingId)
        : [];
      if (!projectRecords.some((record) => record.id === plan.id)) projectRecords.push(payload);
      const projectPlans = projectRecords
        .map((record) => record.id === plan.id ? plan : cleanBlueprintPlan(record))
        .sort((a, b) => (Number(a.project?.floorOrder) || 0) - (Number(b.project?.floorOrder) || 0)
          || String(a.title).localeCompare(String(b.title)));
      const projectObjects = projectPlans.flatMap((projectPlan) => projectPlan.objects || []);
      const projectTopology = mergeFloorPlanTopologies([payload, ...projectRecords], projectObjects);
      projectPlans.forEach((projectPlan) => { projectPlan.topology = projectTopology; });
      renderFloorPlanBlueprint(response, projectPlans.length ? projectPlans : [plan]);
    }
    logActivity(session, `floor-plan.${format.toLowerCase()}-exported`, `Exported ${format} blueprint ${plan.title}.`);
    return;
  }
  if (request.method === "POST" && url.pathname === "/api/floor-plans") {
    const existing = records.find((record) => record.id === payload.id);
    const now = new Date().toISOString();
    const objects = (Array.isArray(payload.objects) ? payload.objects : []).slice(0, 3000).map(cleanFloorPlanObject);
    const canvas = {
      width: Math.min(10000, Math.max(300, Number(payload.canvas?.width) || 1440)),
      height: Math.min(10000, Math.max(300, Number(payload.canvas?.height) || 960)),
      grid: Math.min(120, Math.max(3, Number(payload.canvas?.grid) || 12)),
      unit: ["in", "ft"].includes(payload.canvas?.unit) ? payload.canvas.unit : "ft",
      showLegend: payload.canvas?.showLegend !== false
    };
    const project = cleanFloorPlanProject(payload.project);
    const linkedContract = project.contractTicketId && readTickets().find((ticket) =>
      ticket.id === project.contractTicketId && (ticket.ticketType || "Service") === "Contract"
    );
    if (linkedContract) {
      project.contractTicketNumber = `C-${String(linkedContract.number || 0).padStart(4, "0")}`;
      project.customerSite = linkedContract.customer || linkedContract.company || linkedContract.officeTitle || project.customerSite;
    } else {
      project.contractTicketId = "";
      project.contractTicketNumber = "";
    }
    const projectPeers = records.filter((record) => record.id !== existing?.id && record.project?.buildingId === project.buildingId);
    const projectObjects = [...objects, ...projectPeers.flatMap((record) => Array.isArray(record.objects) ? record.objects : [])];
    const topologyHasContent = (topology) => ["racks", "switches", "assignments", "links", "powerLinks"]
      .some((key) => Array.isArray(topology?.[key]) && topology[key].length);
    const inheritedTopology = !existing && !topologyHasContent(payload.topology)
      ? mergeFloorPlanTopologies(projectPeers, projectObjects)
      : null;
    const plan = {
      id: existing?.id || randomBytes(12).toString("hex"),
      title: String(payload.title || "Untitled Floor Plan").trim().slice(0, 140) || "Untitled Floor Plan",
      canvas,
      objects,
      layers: cleanFloorPlanLayers(payload.layers),
      project,
      revisions: cleanFloorPlanRevisions(payload.revisions),
      topology: cleanFloorPlanTopology(inheritedTopology || payload.topology, projectObjects),
      importSource: existing?.importSource || null,
      createdAt: existing?.createdAt || now,
      createdBy: existing?.createdBy || session.username,
      updatedAt: now,
      updatedBy: session.username
    };
    const index = records.findIndex((record) => record.id === plan.id);
    if (index >= 0) records[index] = plan;
    else records.push(plan);
    for (const record of records) {
      if (record.id !== plan.id && record.project?.buildingId === plan.project.buildingId) {
        record.topology = structuredClone(plan.topology);
      }
    }
    writeFloorPlans(records);
    const tickets = readTickets();
    let ticketsChanged = false;
    for (const ticket of tickets) {
      if ((ticket.ticketType || "Service") !== "Contract") continue;
      const current = Array.isArray(ticket.designPlanIds) ? ticket.designPlanIds : [];
      const withoutPlan = current.filter((id) => id !== plan.id);
      if (ticket.id === plan.project.contractTicketId) withoutPlan.push(plan.id);
      const next = [...new Set(withoutPlan)];
      if (JSON.stringify(next) !== JSON.stringify(current)) {
        ticket.designPlanIds = next;
        ticketsChanged = true;
      }
    }
    if (ticketsChanged) {
      writeTickets(tickets);
      broadcastAllServiceEvent("tickets-updated", { designPlanId: plan.id });
      broadcastAllServiceEvent("job-workspace-updated", { ticketId: plan.project.contractTicketId });
    }
    logActivity(session, index >= 0 ? "floor-plan.updated" : "floor-plan.created",
      `${index >= 0 ? "Updated" : "Created"} floor plan ${plan.title}.`);
    broadcastAllServiceEvent("floor-plans-updated", { id: plan.id, updatedAt: now });
    sendJson(response, 200, { ok: true, plan });
    return;
  }
  if (request.method === "DELETE" && url.pathname === "/api/floor-plans") {
    const removed = records.find((record) => record.id === payload.id);
    if (!removed) {
      sendJson(response, 404, { ok: false, message: "Floor plan not found." });
      return;
    }
    writeFloorPlans(records.filter((record) => record.id !== removed.id));
    const tickets = readTickets();
    let ticketsChanged = false;
    for (const ticket of tickets) {
      if (!Array.isArray(ticket.designPlanIds) || !ticket.designPlanIds.includes(removed.id)) continue;
      ticket.designPlanIds = ticket.designPlanIds.filter((id) => id !== removed.id);
      ticketsChanged = true;
    }
    if (ticketsChanged) writeTickets(tickets);
    logActivity(session, "floor-plan.deleted", `Deleted floor plan ${removed.title}.`);
    broadcastAllServiceEvent("floor-plans-updated", { id: removed.id, deleted: true });
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readCompanyDocuments() {
  if (!existsSync(companyDocumentsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(companyDocumentsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function cleanCompanyDocument(value, existing = {}) {
  const theme = value?.theme === "dark" ? "dark" : "light";
  return {
    id: existing.id || String(value?.id || "").trim() || randomUUID(),
    name: String(value?.name || value?.title || "Untitled Document").trim().slice(0, 120) || "Untitled Document",
    title: String(value?.title || "Untitled Document").trim().slice(0, 180) || "Untitled Document",
    reference: String(value?.reference || "").trim().slice(0, 120),
    date: String(value?.date || "").trim().slice(0, 30),
    body: String(value?.body || "").replace(/\r\n/g, "\n").slice(0, 100000),
    theme,
    fontSize: Math.max(10, Math.min(28, Number(value?.fontSize) || 14)),
    showLogo: value?.showLogo !== false,
    createdAt: existing.createdAt || new Date().toISOString(),
    createdBy: existing.createdBy || "",
    updatedAt: new Date().toISOString(),
    updatedBy: ""
  };
}

async function exportCompanyDocumentToFileBrowser(record) {
  const filePath = exportedFilePath("Company Documents", record.name, record.id);
  const dark = record.theme === "dark";
  const background = dark ? "#090d0f" : "#ffffff";
  const foreground = dark ? "#ffffff" : "#111111";
  const muted = dark ? "#bdc8cc" : "#58656b";
  const doc = new PDFDocument({ size: "LETTER", margins: { top: 54, right: 50, bottom: 54, left: 50 },
    info: { Title: record.title, Author: "Huber I.T. Professionals" } });
  const decoratePage = () => {
    const priorY = doc.y;
    doc.save().rect(0, 0, doc.page.width, doc.page.height).fill(background).restore();
    doc.font("Helvetica").fontSize(8).fillColor(muted)
      .text("Huber I.T. Professionals", 50, doc.page.height - 34, { width: 250 })
      .text("Company Document", doc.page.width - 250, doc.page.height - 34, { width: 200, align: "right" });
    doc.y = priorY;
  };
  decoratePage();
  doc.on("pageAdded", decoratePage);
  const logoPath = join(root, "assets", "logo.png");
  doc.font("Helvetica-Bold").fontSize(24).fillColor(foreground)
    .text(record.title || "Untitled Document", 50, 55, { width: 410, height: 64 });
  if (record.showLogo && existsSync(logoPath)) {
    doc.image(logoPath, 485, 44, { fit: [77, 58], align: "right", valign: "center" });
  }
  const meta = [record.reference, record.date ? new Date(`${record.date}T12:00:00`).toLocaleDateString("en-US", {
    year: "numeric", month: "long", day: "numeric"
  }) : ""].filter(Boolean).join("  |  ");
  if (meta) doc.font("Helvetica").fontSize(9).fillColor(muted).text(meta, 50, 112, { width: 512 });
  doc.rect(50, 136, 512, 3).fill("#087f8c");
  doc.font("Helvetica").fontSize(record.fontSize || 14).fillColor(foreground)
    .text(record.body || "", 50, 160, { width: 512, lineGap: 4 });
  await finishPdf(doc, filePath);
  broadcastAllServiceEvent("documents-updated", { path: "Company Documents" });
  return `Company Documents/${filePath.split(sep).pop()}`;
}

async function handleCompanyDocuments(request, response) {
  const session = getSession(request);
  if (!session || (!hasPermission(session, "document-maker") && !hasPermission(session, "office-suite"))) {
    sendJson(response, 403, { ok: false, message: "Document Maker access required." });
    return;
  }
  const url = new URL(request.url, "http://localhost");
  let records = readCompanyDocuments();

  if (request.method === "GET") {
    const id = String(url.searchParams.get("id") || "").trim();
    if (id) {
      const document = records.find((record) => record.id === id);
      if (!document) return sendJson(response, 404, { ok: false, message: "Document not found." });
      sendJson(response, 200, { ok: true, document });
      return;
    }
    sendJson(response, 200, {
      ok: true,
      documents: records
        .map(({ id, name, title, theme, updatedAt, updatedBy }) => ({ id, name, title, theme, updatedAt, updatedBy }))
        .sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)))
    });
    return;
  }

  if (request.method === "POST") {
    const payload = await readJsonBody(request);
    records = readCompanyDocuments();
    const index = records.findIndex((record) => record.id === String(payload.id || ""));
    const existing = index >= 0 ? records[index] : {};
    const document = cleanCompanyDocument(payload, existing);
    document.createdBy = existing.createdBy || session.username;
    document.updatedBy = session.username;
    if (index >= 0) records[index] = document;
    else records.push(document);
    writeFileSync(companyDocumentsPath, JSON.stringify(records, null, 2), { mode: 0o600 });
    let exportPath = "", exportWarning = "";
    try {
      exportPath = await exportCompanyDocumentToFileBrowser(document);
    } catch (error) {
      exportWarning = `Document saved, but its File Browser PDF could not be updated: ${error.message}`;
    }
    logActivity(session, index >= 0 ? "document.updated" : "document.created", `${index >= 0 ? "Updated" : "Created"} company document ${document.name}.`);
    sendJson(response, 200, { ok: true, document, exportPath, warning: exportWarning });
    return;
  }

  if (request.method === "DELETE") {
    const payload = await readJsonBody(request);
    records = readCompanyDocuments();
    const index = records.findIndex((record) => record.id === String(payload.id || ""));
    if (index < 0) return sendJson(response, 404, { ok: false, message: "Document not found." });
    const [removed] = records.splice(index, 1);
    writeFileSync(companyDocumentsPath, JSON.stringify(records, null, 2), { mode: 0o600 });
    removeExportedFile("Company Documents", removed.id);
    logActivity(session, "document.deleted", `Deleted company document ${removed.name}.`);
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readTrainingVideos() {
  if (!existsSync(trainingVideosPath)) return [];
  try {
    const records = JSON.parse(readFileSync(trainingVideosPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function seedInitialTrainingVideo() {
  const now = new Date().toISOString();
  const initial = {
    id: "document-maker-guide",
    title: "How to Use Document Maker",
    category: "Company Software",
    description: "Create a branded company document, apply bullets and paper themes, save it, and find the PDF in File Browser.",
    videoUrl: "/assets/training/document-maker-guide.mp4?v=2",
    thumbnailUrl: "/assets/training/document-maker-thumbnail.jpg?v=2",
    createdAt: now,
    createdBy: "System",
    updatedAt: now
  };
  const records = readTrainingVideos();
  const index = records.findIndex((record) => record.id === initial.id);
  if (index < 0) records.push(initial);
  else {
    records[index] = {
      ...records[index],
      videoUrl: initial.videoUrl,
      thumbnailUrl: initial.thumbnailUrl,
      updatedAt: now
    };
  }
  writeFileSync(trainingVideosPath, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function validTrainingVideoUrl(value) {
  const local = String(value || "").trim();
  if (/^\/assets\/training\/[a-zA-Z0-9._-]+\.(mp4|webm|ogg)(\?v=\d+)?$/i.test(local)) return local;
  try {
    const url = new URL(String(value || "").trim());
    if (!["https:", "http:"].includes(url.protocol)) return "";
    const host = url.hostname.toLowerCase().replace(/^www\./, "");
    const direct = /\.(mp4|webm|ogg)$/i.test(url.pathname);
    if (!["youtube.com", "youtu.be", "vimeo.com", "player.vimeo.com"].includes(host) && !direct) return "";
    return url.href.slice(0, 1000);
  } catch {
    return "";
  }
}

async function handleTrainingVideos(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Sign in to view training videos." });
    return;
  }
  const records = readTrainingVideos();
  const canManage = session.username === "Huber58" || String(session.role).toLowerCase() === "admin";

  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      canManage,
      user: {
        username: session.username,
        employeeName: session.employeeName,
        role: session.role,
        position: readEmployees().find((employee) =>
          `${employee.firstName || ""} ${employee.lastName || ""}`.trim().toLowerCase() ===
          String(session.employeeName || "").trim().toLowerCase()
        )?.jobTitle || session.role
      },
      videos: records.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
    });
    return;
  }
  if (!canManage) {
    sendJson(response, 403, { ok: false, message: "Administrator access required." });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST") {
    const title = String(payload.title || "").trim().slice(0, 140);
    const videoUrl = validTrainingVideoUrl(payload.videoUrl);
    if (!title || !videoUrl) {
      sendJson(response, 400, { ok: false, message: "Enter a title and a YouTube, Vimeo, MP4, WebM, or OGG link." });
      return;
    }
    const existingIndex = records.findIndex((record) => record.id === String(payload.id || ""));
    const existing = existingIndex >= 0 ? records[existingIndex] : null;
    const video = {
      id: existing?.id || randomBytes(12).toString("hex"),
      title,
      category: String(payload.category || "General").trim().slice(0, 60) || "General",
      description: String(payload.description || "").trim().slice(0, 1000),
      videoUrl,
      thumbnailUrl: existing?.thumbnailUrl || "",
      createdAt: existing?.createdAt || new Date().toISOString(),
      createdBy: existing?.createdBy || session.username,
      updatedAt: new Date().toISOString()
    };
    if (existingIndex >= 0) records[existingIndex] = video;
    else records.push(video);
    writeFileSync(trainingVideosPath, JSON.stringify(records, null, 2), { mode: 0o600 });
    logActivity(session, existing ? "training.updated" : "training.created", `${existing ? "Updated" : "Added"} training video ${video.title}.`);
    broadcastAllServiceEvent("training-updated", {});
    sendJson(response, 200, { ok: true, video });
    return;
  }
  if (request.method === "DELETE") {
    const index = records.findIndex((record) => record.id === String(payload.id || ""));
    if (index < 0) return sendJson(response, 404, { ok: false, message: "Training video not found." });
    const [removed] = records.splice(index, 1);
    writeFileSync(trainingVideosPath, JSON.stringify(records, null, 2), { mode: 0o600 });
    logActivity(session, "training.deleted", `Deleted training video ${removed.title}.`);
    broadcastAllServiceEvent("training-updated", {});
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

async function handleDocuments(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "documents")) {
    sendJson(response, 403, { ok: false, message: "Documents access required." });
    return;
  }

  const url = new URL(request.url, `http://${request.headers.host}`);

  if (request.method === "GET" && url.pathname === "/api/documents/tree") {
    sendJson(response, 200, {
      ok: true,
      folders: readDocumentFolders(documentsPath)
    });
    return;
  }

  if (request.method === "GET" && url.pathname === "/api/documents") {
    const folder = resolveDocumentPath(url.searchParams.get("path") || "");
    if (!folder || !existsSync(folder) || !statSync(folder).isDirectory()) {
      sendJson(response, 404, { ok: false, message: "Folder not found." });
      return;
    }

    const items = readdirSync(folder, { withFileTypes: true })
      .filter((item) => !item.isSymbolicLink())
      .map((item) => {
        const fullPath = join(folder, item.name);
        const stats = statSync(fullPath);
        return {
          name: item.name,
          type: item.isDirectory() ? "folder" : "file",
          size: item.isDirectory() ? null : stats.size,
          modified: stats.mtime.toISOString()
        };
      })
      .sort((a, b) => a.type === b.type
        ? a.name.localeCompare(b.name)
        : a.type === "folder" ? -1 : 1);
    sendJson(response, 200, { ok: true, items });
    return;
  }

  if (request.method === "GET" && url.pathname === "/api/documents/download") {
    const filePath = resolveDocumentPath(url.searchParams.get("path") || "");
    if (!filePath || !existsSync(filePath) || !statSync(filePath).isFile()) {
      sendJson(response, 404, { ok: false, message: "File not found." });
      return;
    }
    const name = filePath.split(sep).pop();
    response.writeHead(200, {
      "Content-Type": "application/octet-stream",
      "Content-Length": statSync(filePath).size,
      "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(name)}`,
      "Cache-Control": "no-store"
    });
    createReadStream(filePath).pipe(response);
    return;
  }

  if (request.method === "GET" && url.pathname === "/api/documents/open") {
    const filePath = resolveDocumentPath(url.searchParams.get("path") || "");
    if (!filePath || !existsSync(filePath) || !statSync(filePath).isFile()) {
      sendJson(response, 404, { ok: false, message: "File not found." });
      return;
    }
    const name = filePath.split(sep).pop();
    const previewTypes = {
      ".pdf": "application/pdf",
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".webp": "image/webp",
      ".gif": "image/gif",
      ".txt": "text/plain; charset=utf-8",
      ".csv": "text/plain; charset=utf-8"
    };
    response.writeHead(200, {
      "Content-Type": previewTypes[extname(filePath).toLowerCase()] || "application/octet-stream",
      "Content-Length": statSync(filePath).size,
      "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(name)}`,
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "private, no-store"
    });
    createReadStream(filePath).pipe(response);
    return;
  }

  if (request.method === "POST" && url.pathname === "/api/documents/folder") {
    const payload = await readJsonBody(request);
    const parent = resolveDocumentPath(payload.path || "");
    const name = validDocumentName(payload.name);
    if (!parent || !name || !existsSync(parent) || !statSync(parent).isDirectory()) {
      sendJson(response, 400, { ok: false, message: "Enter a valid folder name." });
      return;
    }
    const folder = resolveDocumentPath(join(payload.path || "", name));
    if (existsSync(folder)) {
      sendJson(response, 409, { ok: false, message: "A folder with that name already exists." });
      return;
    }
    mkdirSync(folder, { mode: 0o700 });
    logActivity(session, "document.folder-created", `Created document folder ${name}.`);
    broadcastAllServiceEvent("documents-updated", { path: payload.path || "" });
    sendJson(response, 200, { ok: true });
    return;
  }

  if (request.method === "POST" && url.pathname === "/api/documents/upload") {
    const parentPath = url.searchParams.get("path") || "";
    const parent = resolveDocumentPath(parentPath);
    const name = validDocumentName(decodeURIComponent(request.headers["x-file-name"] || ""));
    if (!parent || !name || !existsSync(parent) || !statSync(parent).isDirectory()) {
      sendJson(response, 400, { ok: false, message: "Invalid upload location or filename." });
      return;
    }
    const filePath = resolveDocumentPath(join(parentPath, name));
    if (existsSync(filePath)) {
      sendJson(response, 409, { ok: false, message: `${name} already exists.` });
      return;
    }
    const file = await readBinaryBody(request, 25 * 1024 * 1024);
    writeFileSync(filePath, file, { mode: 0o600, flag: "wx" });
    logActivity(session, "document.uploaded", `Uploaded document ${name}.`);
    broadcastAllServiceEvent("documents-updated", { path: parentPath });
    sendJson(response, 200, { ok: true });
    return;
  }

  if (request.method === "PATCH" && url.pathname === "/api/documents") {
    const payload = await readJsonBody(request);
    const sourcePath = String(payload.path || "").replace(/\\/g, "/");
    const source = resolveDocumentPath(sourcePath);
    if (!source || source === documentsPath || !existsSync(source)) {
      sendJson(response, 404, { ok: false, message: "Document or folder not found." });
      return;
    }

    const sourceName = source.split(sep).pop();
    const sourceParentPath = sourcePath.split("/").slice(0, -1).join("/");
    let destinationPath = "";
    if (payload.action === "rename") {
      const name = validDocumentName(payload.name);
      if (!name) {
        sendJson(response, 400, { ok: false, message: "Enter a valid name." });
        return;
      }
      destinationPath = join(sourceParentPath, name).replace(/\\/g, "/");
    } else if (payload.action === "move") {
      const destinationFolderPath = String(payload.destination || "").replace(/\\/g, "/");
      const destinationFolder = resolveDocumentPath(destinationFolderPath);
      if (!destinationFolder || !existsSync(destinationFolder) || !statSync(destinationFolder).isDirectory()) {
        sendJson(response, 400, { ok: false, message: "Destination folder not found." });
        return;
      }
      if (statSync(source).isDirectory() &&
          (destinationFolder === source || destinationFolder.startsWith(`${source}${sep}`))) {
        sendJson(response, 400, { ok: false, message: "A folder cannot be moved inside itself." });
        return;
      }
      destinationPath = join(destinationFolderPath, sourceName).replace(/\\/g, "/");
    } else {
      sendJson(response, 400, { ok: false, message: "Unsupported document action." });
      return;
    }

    const destination = resolveDocumentPath(destinationPath);
    if (!destination) {
      sendJson(response, 400, { ok: false, message: "Invalid destination." });
      return;
    }
    if (destination === source) {
      sendJson(response, 200, { ok: true, path: destinationPath });
      return;
    }
    if (existsSync(destination)) {
      sendJson(response, 409, { ok: false, message: "An item with that name already exists in the destination." });
      return;
    }

    renameSync(source, destination);
    const action = payload.action === "rename" ? "renamed" : "moved";
    logActivity(session, `document.${action}`, `${action === "renamed" ? "Renamed" : "Moved"} document ${sourceName}.`);
    broadcastAllServiceEvent("documents-updated", {
      path: destinationPath.split("/").slice(0, -1).join("/")
    });
    sendJson(response, 200, { ok: true, path: destinationPath });
    return;
  }

  if (request.method === "DELETE" && url.pathname === "/api/documents") {
    const payload = await readJsonBody(request);
    const filePath = resolveDocumentPath(payload.path || "");
    if (!filePath || filePath === documentsPath || !existsSync(filePath)) {
      sendJson(response, 404, { ok: false, message: "Document or folder not found." });
      return;
    }
    const deletedName = filePath.split(sep).pop();
    const isFolder = statSync(filePath).isDirectory();
    if (isFolder) rmSync(filePath, { recursive: true, force: false });
    else unlinkSync(filePath);
    logActivity(session, "document.deleted", `Deleted document ${deletedName}.`);
    broadcastAllServiceEvent("documents-updated", {
      path: String(payload.path || "").replace(/\\/g, "/").split("/").slice(0, -1).join("/")
    });
    sendJson(response, 200, { ok: true });
    return;
  }

  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function readDocumentFolders(folder, relativePath = "", depth = 0) {
  const folders = [];
  const children = readdirSync(folder, { withFileTypes: true })
    .filter((item) => item.isDirectory() && !item.isSymbolicLink())
    .sort((a, b) => a.name.localeCompare(b.name));
  for (const child of children) {
    const childPath = join(relativePath, child.name).replace(/\\/g, "/");
    folders.push({ name: child.name, path: childPath, depth });
    folders.push(...readDocumentFolders(join(folder, child.name), childPath, depth + 1));
  }
  return folders;
}

function resolveDocumentPath(relativePath) {
  const target = resolve(documentsPath, String(relativePath || "").replace(/\\/g, "/"));
  if (target !== documentsPath && !target.startsWith(`${documentsPath}${sep}`)) return null;
  return target;
}

function validDocumentName(value) {
  const name = String(value || "").trim();
  if (!name || name === "." || name === ".." || /[/\\\0]/.test(name)) return "";
  return name;
}

function ticketLabel(ticket) {
  const prefix = ticket.ticketType === "Contract" ? "C" : ticket.nonChargeable ? "NCS" : "T";
  return `${prefix}-${String(ticket.number).padStart(4, "0")}`;
}

function readActivity() {
  if (!existsSync(activityPath)) return [];
  try {
    const records = JSON.parse(readFileSync(activityPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeActivity(records) {
  writeFileSync(activityPath, JSON.stringify(records.slice(-5000), null, 2), { mode: 0o600 });
}

function logActivity(session, type, message, metadata = {}) {
  if (!session) return;
  const records = readActivity();
  const record = {
    id: randomBytes(12).toString("hex"),
    type,
    message,
    username: session.username,
    employeeName: session.employeeName || session.username,
    createdAt: new Date().toISOString()
  };
  if (metadata.undo) record.undo = metadata.undo;
  records.push(record);
  writeActivity(records);
  broadcastAllServiceEvent("dashboard-updated", { area: type });
}

function logSystemActivity(type, message, actor = "System") {
  logActivity({ username: actor, employeeName: actor }, type, message);
}

function readJsonArray(filePath) {
  if (!existsSync(filePath)) return [];
  try {
    const records = JSON.parse(readFileSync(filePath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function logSecurityEvent(type, message, details = {}) {
  const records = readJsonArray(securityEventsPath);
  records.push({
    id: randomBytes(12).toString("hex"),
    type,
    message,
    username: String(details.username || ""),
    ip: String(details.ip || ""),
    userAgent: String(details.userAgent || "").slice(0, 300),
    createdAt: new Date().toISOString()
  });
  writeFileSync(securityEventsPath, JSON.stringify(records.slice(-5000), null, 2), { mode: 0o600 });
}

async function handleSecurityCenter(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "security")) {
    sendJson(response, 403, { ok: false, message: "Security Center access required." });
    return;
  }
  if (request.method === "GET") {
    const activeSessions = [...sessions.entries()].map(([id, record]) => ({
      id,
      username: record.username,
      employeeName: record.employeeName,
      role: record.role,
      expiresAt: record.expiresAt
    })).sort((a, b) => a.expiresAt - b.expiresAt);
    const auditEvents = readActivity().filter((event) =>
      /^(account|user|role|security|portal\.access|backup|data\.)/.test(event.type)
    ).map((event) => ({ ...event, ip: "", userAgent: "" }));
    const events = [...readJsonArray(securityEventsPath), ...auditEvents]
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 500);
    const since = Date.now() - 24 * 60 * 60 * 1000;
    sendJson(response, 200, {
      ok: true,
      sessions: activeSessions,
      trustedDevices: readTrustedTwoFactorDevices().map((device) => ({
        id: device.id,
        username: device.username,
        createdAt: device.createdAt,
        expiresAt: device.expiresAt
      })),
      events,
      summary: {
        activeSessions: activeSessions.length,
        failedLogins24h: events.filter((event) =>
          event.type === "login.failed" && new Date(event.createdAt).getTime() >= since
        ).length,
        trustedDevices: readTrustedTwoFactorDevices().length,
        twoFactorUsers: readUsers().filter((user) => user.totpSecret).length
      }
    });
    return;
  }
  const payload = await readJsonBody(request);
  if (request.method === "POST" && payload.action === "revoke-session") {
    const target = sessions.get(payload.id);
    if (target && payload.id !== hashSessionToken(getCookie(request, "huber_session"))) {
      sessions.delete(payload.id);
      persistSessions();
      logActivity(session, "security.session-revoked", `Revoked ${target.username}'s session.`);
    }
    sendJson(response, 200, { ok: true });
    return;
  }
  if (request.method === "POST" && payload.action === "clear-failures") {
    loginAttempts.clear();
    logActivity(session, "security.lockouts-cleared", "Cleared active login lockouts.");
    sendJson(response, 200, { ok: true });
    return;
  }
  sendJson(response, 405, { ok: false, message: "Method not allowed." });
}

function payrollData(from, to) {
  const employeeByName = new Map(readEmployees().map((employee) => [
    `${employee.firstName || ""} ${employee.lastName || ""}`.trim().toLowerCase(),
    employee
  ]));
  const weekly = new Map();
  for (const record of readTimeRecords()) {
    if (!record.clockOut || record.clockIn.slice(0, 10) < from || record.clockIn.slice(0, 10) > to) continue;
    const start = new Date(record.clockIn);
    const end = new Date(record.clockOut);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end <= start) continue;
    const name = record.employeeName || record.username;
    const employee = employeeByName.get(String(name).trim().toLowerCase());
    const rate = Number.isFinite(Number(record.laborRate))
      ? Number(record.laborRate)
      : employee?.payType === "Salary"
        ? Number(employee.wage || 0) / 2080
        : Number(employee?.wage || 0);
    const weekDate = new Date(`${record.clockIn.slice(0, 10)}T12:00:00`);
    weekDate.setDate(weekDate.getDate() - ((weekDate.getDay() + 6) % 7));
    const week = weekDate.toISOString().slice(0, 10);
    const key = `${name.toLowerCase()}|${week}`;
    const current = weekly.get(key) || { employeeName: name, hours: 0, rate };
    const hours = (end - start) / 3600000;
    current.hours += hours;
    current.rate = rate;
    weekly.set(key, current);
  }
  const totals = new Map();
  for (const week of weekly.values()) {
    const regularHours = Math.min(40, week.hours);
    const overtimeHours = Math.max(0, week.hours - 40);
    const row = totals.get(week.employeeName) || {
      employeeName: week.employeeName,
      regularHours: 0,
      overtimeHours: 0,
      grossPay: 0,
      rate: week.rate
    };
    row.regularHours += regularHours;
    row.overtimeHours += overtimeHours;
    row.grossPay += regularHours * week.rate + overtimeHours * week.rate * 1.5;
    totals.set(week.employeeName, row);
  }
  const rows = [...totals.values()].map((row) => ({
    ...row,
    regularHours: roundMoney(row.regularHours),
    overtimeHours: roundMoney(row.overtimeHours),
    grossPay: roundMoney(row.grossPay)
  })).sort((a, b) => a.employeeName.localeCompare(b.employeeName));
  return {
    from,
    to,
    rows,
    totals: {
      regularHours: roundMoney(rows.reduce((sum, row) => sum + row.regularHours, 0)),
      overtimeHours: roundMoney(rows.reduce((sum, row) => sum + row.overtimeHours, 0)),
      grossPay: roundMoney(rows.reduce((sum, row) => sum + row.grossPay, 0))
    }
  };
}

function defaultPayrollData() {
  return {
    settings: {
      socialSecurityRate: 6.2,
      medicareRate: 1.45,
      defaultFederalWithholdingRate: 0,
      providerName: "",
      providerUrl: "",
      paySchedule: "Biweekly"
    },
    profiles: {},
    runs: []
  };
}

function readPayrollData() {
  const defaults = defaultPayrollData();
  if (!existsSync(payrollPath)) return defaults;
  try {
    const saved = JSON.parse(readFileSync(payrollPath, "utf8"));
    return {
      settings: { ...defaults.settings, ...(saved.settings || {}) },
      profiles: saved.profiles && typeof saved.profiles === "object" ? saved.profiles : {},
      runs: Array.isArray(saved.runs) ? saved.runs : []
    };
  } catch {
    return defaults;
  }
}

function writePayrollData(data) {
  writeFileSync(payrollPath, JSON.stringify(data, null, 2), { mode: 0o600 });
}

function calculatePayrollDetails(from, to, data, adjustments = {}) {
  const base = payrollData(from, to);
  const employees = readEmployees();
  const employeeByName = new Map(employees.map((employee) => [
    `${employee.firstName || ""} ${employee.lastName || ""}`.trim().toLowerCase(),
    employee
  ]));
  const rows = base.rows.map((row) => {
    const employee = employeeByName.get(row.employeeName.toLowerCase());
    const profile = {
      federalWithholdingRate: data.settings.defaultFederalWithholdingRate,
      retirementRate: 0,
      healthInsurance: 0,
      otherPreTax: 0,
      garnishment: 0,
      otherPostTax: 0,
      paymentMethod: "External provider",
      paymentReference: "",
      ...(data.profiles[employee?.id] || {})
    };
    const adjustment = adjustments[employee?.id] || {};
    const bonus = roundMoney(Math.max(0, Number(adjustment.bonus) || 0));
    const reimbursement = roundMoney(Math.max(0, Number(adjustment.reimbursement) || 0));
    const grossWithBonus = roundMoney(row.grossPay + bonus);
    const retirement = roundMoney(grossWithBonus * Number(profile.retirementRate || 0) / 100);
    const healthInsurance = roundMoney(Math.max(0, Number(profile.healthInsurance) || 0));
    const otherPreTax = roundMoney(Math.max(0, Number(profile.otherPreTax) || 0));
    const preTaxDeductions = roundMoney(Math.min(
      grossWithBonus,
      retirement + healthInsurance + otherPreTax
    ));
    const taxableWages = roundMoney(Math.max(0, grossWithBonus - preTaxDeductions));
    const federalWithholding = roundMoney(
      taxableWages * Number(profile.federalWithholdingRate || 0) / 100
    );
    const socialSecurity = roundMoney(
      taxableWages * Number(data.settings.socialSecurityRate || 0) / 100
    );
    const medicare = roundMoney(
      taxableWages * Number(data.settings.medicareRate || 0) / 100
    );
    const garnishment = roundMoney(Math.max(0, Number(profile.garnishment) || 0));
    const otherPostTax = roundMoney(Math.max(0, Number(profile.otherPostTax) || 0));
    const postTaxDeductions = roundMoney(Math.min(
      Math.max(0, grossWithBonus - preTaxDeductions - federalWithholding - socialSecurity - medicare),
      garnishment + otherPostTax
    ));
    const totalDeductions = roundMoney(
      preTaxDeductions + federalWithholding + socialSecurity + medicare + postTaxDeductions
    );
    return {
      ...row,
      employeeId: employee?.id || "",
      zohoEmployeeId: employee?.zohoEmployeeId || "",
      bonus,
      reimbursement,
      grossWithBonus,
      taxableWages,
      retirement,
      healthInsurance,
      otherPreTax,
      preTaxDeductions,
      federalWithholding,
      socialSecurity,
      medicare,
      garnishment,
      otherPostTax,
      postTaxDeductions,
      totalDeductions,
      netPay: roundMoney(Math.max(0, grossWithBonus - totalDeductions + reimbursement)),
      paymentMethod: profile.paymentMethod,
      paymentReference: profile.paymentReference
    };
  });
  return {
    from,
    to,
    rows,
    totals: {
      regularHours: base.totals.regularHours,
      overtimeHours: base.totals.overtimeHours,
      grossPay: roundMoney(rows.reduce((sum, row) => sum + row.grossWithBonus, 0)),
      bonuses: roundMoney(rows.reduce((sum, row) => sum + row.bonus, 0)),
      reimbursements: roundMoney(rows.reduce((sum, row) => sum + row.reimbursement, 0)),
      deductions: roundMoney(rows.reduce((sum, row) => sum + row.totalDeductions, 0)),
      employerTaxes: roundMoney(rows.reduce((sum, row) =>
        sum + row.socialSecurity + row.medicare, 0)),
      netPay: roundMoney(rows.reduce((sum, row) => sum + row.netPay, 0))
    }
  };
}

function payrollCsv(data, filename, response) {
  const escapeCsv = (value) => `"${String(value ?? "").replaceAll("\"", "\"\"")}"`;
  const csv = [
    ["Zoho Employee ID", "Employee", "Regular Hours", "Overtime Hours", "Hourly Rate", "Gross Earnings"],
    ...data.rows.map((row) => [
      row.zohoEmployeeId || "", row.employeeName, row.regularHours, row.overtimeHours, row.rate,
      row.grossPay ?? row.grossWithBonus
    ])
  ].map((row) => row.map(escapeCsv).join(",")).join("\r\n");
  response.writeHead(200, {
    "Content-Type": "text/csv; charset=utf-8",
    "Content-Disposition": `attachment; filename="${filename}"`,
    "Cache-Control": "no-store"
  });
  response.end(csv);
}

function sendPayStub(response, run, row) {
  const doc = new PDFDocument({
    size: "LETTER",
    margin: 48,
    info: { Title: `${row.employeeName} pay stub ${run.from} through ${run.to}` }
  });
  response.writeHead(200, {
    "Content-Type": "application/pdf",
    "Content-Disposition": `attachment; filename="pay-stub-${run.from}-to-${run.to}.pdf"`,
    "Cache-Control": "private, no-store"
  });
  doc.pipe(response);
  const logoPath = join(root, "assets", "logo.png");
  if (existsSync(logoPath)) doc.image(logoPath, 48, 38, { width: 58 });
  doc.fontSize(18).text("Huber I.T. Professionals", 120, 48);
  doc.fontSize(10).fillColor("#526068").text("Employee Pay Statement", 120, 73);
  doc.moveDown(4).fillColor("#182026");
  doc.fontSize(15).text(row.employeeName);
  doc.fontSize(10).text(`Pay period: ${run.from} through ${run.to}`);
  doc.text(`Pay run status: ${run.status}${run.paidAt ? ` · Paid ${run.paidAt.slice(0, 10)}` : ""}`);
  doc.moveDown();
  const fields = [
    ["Regular hours", row.regularHours],
    ["Overtime hours", row.overtimeHours],
    ["Hourly rate", formatUsd(row.rate)],
    ["Gross earnings", formatUsd(row.grossPay)],
    ["Bonus", formatUsd(row.bonus)],
    ["Reimbursement", formatUsd(row.reimbursement)],
    ["Pre-tax deductions", `-${formatUsd(row.preTaxDeductions)}`],
    ["Federal withholding", `-${formatUsd(row.federalWithholding)}`],
    ["Social Security", `-${formatUsd(row.socialSecurity)}`],
    ["Medicare", `-${formatUsd(row.medicare)}`],
    ["Post-tax deductions", `-${formatUsd(row.postTaxDeductions)}`],
    ["Net pay", formatUsd(row.netPay)]
  ];
  for (const [label, value] of fields) reportField(doc, label, value);
  doc.moveDown().fontSize(8).fillColor("#526068").text(
    "This statement reflects the payroll profile and adjustments saved with this pay run."
  );
  doc.end();
}

function readApprovals() {
  if (!existsSync(approvalsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(approvalsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function readApprovalPolicies() {
  const defaults = {
    expenseThreshold: 500,
    requireTimeAdjustments: true,
    requireInvoiceVoids: true,
    requirePayrollExports: true
  };
  if (!existsSync(approvalPoliciesPath)) return defaults;
  try {
    return { ...defaults, ...JSON.parse(readFileSync(approvalPoliciesPath, "utf8")) };
  } catch {
    return defaults;
  }
}

function writeApprovalPolicies(policies) {
  writeFileSync(approvalPoliciesPath, JSON.stringify(policies, null, 2), { mode: 0o600 });
}

function writeApprovals(records) {
  writeFileSync(approvalsPath, JSON.stringify(records.slice(-5000), null, 2), { mode: 0o600 });
}

function createApprovalRequest(session, type, payload, summary) {
  const records = readApprovals();
  const record = {
    id: randomBytes(12).toString("hex"),
    type,
    payload,
    summary,
    status: "Pending",
    ownerOnly: type === "invoice-no-hours",
    requestedBy: session.username,
    requestedByName: session.employeeName || session.username,
    createdAt: new Date().toISOString()
  };
  records.push(record);
  writeApprovals(records);
  logActivity(session, "approval.requested", `Requested approval: ${summary}.`);
  broadcastAllServiceEvent("dashboard-updated", { area: "approvals" });
  return record;
}

function applyApprovedRequest(record, session) {
  if (record.type === "time-adjustment") {
    const records = readTimeRecords();
    const entry = records.find((item) => item.id === record.payload.id);
    if (!entry) throw new Error("The time entry no longer exists.");
    const clockIn = new Date(record.payload.clockIn);
    const clockOut = record.payload.clockOut ? new Date(record.payload.clockOut) : null;
    entry.clockIn = clockIn.toISOString();
    entry.clockOut = clockOut ? clockOut.toISOString() : null;
    entry.adjustedBy = session.username;
    entry.adjustedAt = new Date().toISOString();
    entry.adjustmentNote = record.payload.note;
    if (clockOut) {
      const rate = Number.isFinite(Number(entry.laborRate))
        ? Number(entry.laborRate) : employeeLaborRate(entry.employeeName);
      entry.laborRate = roundMoney(rate);
      entry.laborCost = roundMoney((clockOut - clockIn) / 3600000 * rate);
    } else {
      delete entry.laborCost;
    }
    writeTimeRecords(records);
    broadcastServiceEvent(entry.username, "time-updated");
    return;
  }
  if (record.type === "expense") {
    const finance = readFinance();
    if (!finance.groups.some((group) => group.id === record.payload.groupId)) {
      throw new Error("The expense allocation group no longer exists.");
    }
    finance.expenses.push({
      id: randomBytes(12).toString("hex"),
      ...record.payload,
      createdAt: new Date().toISOString(),
      createdBy: record.requestedBy,
      approvedBy: session.username
    });
    writeFinance(finance);
    return;
  }
  if (record.type === "invoice-void") {
    const invoices = readInvoices();
    const invoice = invoices.find((item) => item.id === record.payload.invoiceId);
    if (!invoice) throw new Error("The invoice no longer exists.");
    if (readFinance().payments.some(payment => payment.invoiceId === invoice.id)) {
      throw new Error("This invoice has payments and cannot be voided. Correct its payments first.");
    }
    invoice.status = "Void";
    invoice.updatedAt = new Date().toISOString();
    invoice.updatedBy = session.username;
    writeInvoices(invoices);
    return;
  }
  if (record.type === "invoice-no-hours") {
    const invoices = readInvoices();
    const invoice = invoices.find((item) => item.id === record.payload.invoiceId);
    if (!invoice) throw new Error("The invoice no longer exists.");
    const ticket = readTickets().find((item) => item.id === invoice.ticketId);
    if (!ticket) throw new Error("The linked service ticket no longer exists.");
    if (ticket.status !== "Closed") {
      throw new Error("The linked service ticket is no longer closed.");
    }
    const requestedStatus = ["Sent", "Paid"].includes(record.payload.requestedStatus)
      ? record.payload.requestedStatus : "Sent";
    if (requestedStatus === "Paid" && invoicePaidAmount(invoice, readFinance().payments) < Number(invoice.total) - 0.001) {
      throw new Error("Record the payment in Finance before marking this invoice paid.");
    }
    invoice.status = requestedStatus;
    invoice.noHoursApprovedAt = new Date().toISOString();
    invoice.noHoursApprovedBy = session.username;
    invoice.updatedAt = new Date().toISOString();
    invoice.updatedBy = session.username;
    writeInvoices(invoices);
    if (requestedStatus === "Paid") {
      const estimates = readEstimates();
      let changed = false;
      for (const estimate of estimates) {
        if (estimate.invoiceId !== invoice.id || estimate.status === "Paid") continue;
        estimate.status = "Paid";
        estimate.updatedAt = new Date().toISOString();
        estimate.updatedBy = session.username;
        changed = true;
      }
      if (changed) writeEstimates(estimates);
    }
    broadcastAllServiceEvent("dashboard-updated", { area: "invoices" });
    broadcastAllServiceEvent("job-workspace-updated", { ticketId: ticket.id });
    return;
  }
  if (record.type === "payroll-export") return;
  throw new Error("Unsupported approval request.");
}

async function handleApprovals(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "approvals")) {
    sendJson(response, 403, { ok: false, message: "Approval access required." });
    return;
  }
  const records = readApprovals();
  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      policies: readApprovalPolicies(),
      canApproveOwnerOnly: session.username === "Huber58",
      approvals: [...records].sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const payload = await readJsonBody(request);
  if (payload.action === "save-policies") {
    const policies = {
      expenseThreshold: roundMoney(Math.max(0, Number(payload.policies?.expenseThreshold) || 0)),
      requireTimeAdjustments: Boolean(payload.policies?.requireTimeAdjustments),
      requireInvoiceVoids: Boolean(payload.policies?.requireInvoiceVoids),
      requirePayrollExports: Boolean(payload.policies?.requirePayrollExports)
    };
    writeApprovalPolicies(policies);
    logActivity(session, "approval.policies-updated", "Updated approval policies.");
    sendJson(response, 200, { ok: true, policies });
    return;
  }
  const record = records.find((item) => item.id === payload.id);
  if (!record || record.status !== "Pending" || !["approve", "deny"].includes(payload.action)) {
    sendJson(response, 400, { ok: false, message: "This approval request is no longer pending." });
    return;
  }
  if (payload.action === "approve" && record.type === "invoice-no-hours" &&
      session.username !== "Huber58") {
    sendJson(response, 403, {
      ok: false,
      message: "Only the owner account Huber58 can approve a zero-hour invoice."
    });
    return;
  }
  if (payload.action === "approve") applyApprovedRequest(record, session);
  record.status = payload.action === "approve" ? "Approved" : "Denied";
  record.reviewedAt = new Date().toISOString();
  record.reviewedBy = session.username;
  record.reviewNote = String(payload.note || "").trim().slice(0, 500);
  writeApprovals(records);
  logActivity(session, `approval.${record.status.toLowerCase()}`,
    `${record.status} request: ${record.summary}.`);
  broadcastAllServiceEvent("dashboard-updated", { area: "approvals" });
  sendJson(response, 200, { ok: true, approval: record });
}

async function handlePayroll(request, response) {
  const session = getSession(request);
  if (!hasPermission(session, "payroll")) {
    sendJson(response, 403, { ok: false, message: "Reports access required." });
    return;
  }
  const url = new URL(request.url, publicOrigin(request));
  const today = new Date();
  const monday = new Date(today);
  monday.setDate(today.getDate() - ((today.getDay() + 6) % 7));
  const from = validDateOnly(url.searchParams.get("from")) || monday.toISOString().slice(0, 10);
  const to = validDateOnly(url.searchParams.get("to")) || businessToday();
  const store = readPayrollData();
  const runId = String(url.searchParams.get("runId") || "");
  const run = runId ? store.runs.find((record) => record.id === runId) : null;
  if (request.method === "GET" && url.pathname === "/api/payroll/pay-stub") {
    const row = run?.rows.find((record) => record.employeeId === url.searchParams.get("employeeId"));
    if (!run || !row) {
      sendJson(response, 404, { ok: false, message: "Pay stub not found." });
      return;
    }
    sendPayStub(response, run, row);
    return;
  }
  const data = run || calculatePayrollDetails(from, to, store);
  if (url.searchParams.get("format") === "csv") {
    const exportApproved = !readApprovalPolicies().requirePayrollExports ||
      hasPermission(session, "approvals") || readApprovals().some((record) =>
      record.type === "payroll-export" &&
      record.requestedBy === session.username &&
      record.status === "Approved" &&
      record.payload.from === data.from &&
      record.payload.to === data.to
    );
    if (!exportApproved) {
      sendJson(response, 403, {
        ok: false,
        message: "This Zoho payroll export requires approval."
      });
      return;
    }
    payrollCsv(data, `payroll-${data.from}-to-${data.to}.csv`, response);
    return;
  }
  if (request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      ...data,
      settings: store.settings,
      profiles: store.profiles,
      employees: readEmployees().filter((employee) => employee.status !== "Inactive"),
      exportApproved: !readApprovalPolicies().requirePayrollExports ||
        hasPermission(session, "approvals") || readApprovals().some((record) =>
        record.type === "payroll-export" && record.requestedBy === session.username &&
        record.status === "Approved" && record.payload.from === data.from && record.payload.to === data.to
      ),
      runs: store.runs.map(({ rows, ...record }) => ({ ...record, employeeCount: rows.length }))
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    });
    return;
  }
  if (!["POST", "DELETE"].includes(request.method)) {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const payload = await readJsonBody(request);
  const action = String(payload.action || "");
  if (request.method === "POST" && action === "request-export") {
    const existing = readApprovals().find((record) =>
      record.type === "payroll-export" && record.requestedBy === session.username &&
      record.status === "Pending" && record.payload.from === from && record.payload.to === to
    );
    const approval = existing || createApprovalRequest(session, "payroll-export", { from, to },
      `Export Zoho payroll hours for ${from} through ${to}`);
    sendJson(response, 202, {
      ok: true,
      approvalPending: true,
      approval,
      message: existing ? "This payroll export is already pending." : "Payroll export submitted for approval."
    });
    return;
  }
  if (request.method === "POST" && action === "save-profile") {
    const employee = readEmployees().find((record) => record.id === payload.employeeId);
    if (!employee) {
      sendJson(response, 404, { ok: false, message: "Employee not found." });
      return;
    }
    const number = (field, maximum = 1000000) =>
      roundMoney(Math.min(maximum, Math.max(0, Number(payload.profile?.[field]) || 0)));
    store.profiles[employee.id] = {
      federalWithholdingRate: number("federalWithholdingRate", 100),
      retirementRate: number("retirementRate", 100),
      healthInsurance: number("healthInsurance"),
      otherPreTax: number("otherPreTax"),
      garnishment: number("garnishment"),
      otherPostTax: number("otherPostTax"),
      paymentMethod: ["External provider", "Bank ACH", "Check", "Cash"].includes(payload.profile?.paymentMethod)
        ? payload.profile.paymentMethod : "External provider",
      paymentReference: String(payload.profile?.paymentReference || "").trim().slice(0, 80),
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    writePayrollData(store);
    logActivity(session, "payroll.profile-updated",
      `Updated payroll deductions for ${employee.firstName} ${employee.lastName}.`);
  } else if (request.method === "POST" && action === "save-settings") {
    store.settings = {
      socialSecurityRate: roundMoney(Math.min(100, Math.max(0, Number(payload.settings?.socialSecurityRate) || 0))),
      medicareRate: roundMoney(Math.min(100, Math.max(0, Number(payload.settings?.medicareRate) || 0))),
      defaultFederalWithholdingRate: roundMoney(Math.min(100, Math.max(0, Number(payload.settings?.defaultFederalWithholdingRate) || 0))),
      providerName: String(payload.settings?.providerName || "").trim().slice(0, 100),
      providerUrl: /^https:\/\/[^\s]+$/i.test(String(payload.settings?.providerUrl || "").trim())
        ? String(payload.settings.providerUrl).trim().slice(0, 500) : "",
      paySchedule: ["Weekly", "Biweekly", "Semimonthly", "Monthly"].includes(payload.settings?.paySchedule)
        ? payload.settings.paySchedule : "Biweekly"
    };
    writePayrollData(store);
    logActivity(session, "payroll.settings-updated", "Updated payroll calculation settings.");
  } else if (request.method === "POST" && action === "create-run") {
    if (!from || !to || to < from) {
      sendJson(response, 400, { ok: false, message: "Enter a valid payroll period." });
      return;
    }
    if (store.runs.some((record) =>
      record.from === from && record.to === to && record.status !== "Void"
    )) {
      sendJson(response, 409, { ok: false, message: "A pay run already exists for this period." });
      return;
    }
    const calculated = calculatePayrollDetails(from, to, store, payload.adjustments || {});
    if (!calculated.rows.length) {
      sendJson(response, 400, { ok: false, message: "No completed employee shifts exist in this period." });
      return;
    }
    const newRun = {
      id: randomBytes(12).toString("hex"),
      ...calculated,
      status: "Draft",
      paymentProvider: store.settings.providerName || "Not connected",
      paymentProviderUrl: store.settings.providerUrl || "",
      paymentConfirmation: "",
      createdAt: new Date().toISOString(),
      createdBy: session.username,
      updatedAt: new Date().toISOString(),
      updatedBy: session.username
    };
    store.runs.push(newRun);
    writePayrollData(store);
    logActivity(session, "payroll.run-created", `Created payroll run ${from} through ${to}.`);
  } else if (request.method === "POST" && ["approve-run", "mark-paid", "void-run"].includes(action)) {
    const editable = store.runs.find((record) => record.id === payload.id);
    if (!editable) {
      sendJson(response, 404, { ok: false, message: "Pay run not found." });
      return;
    }
    if (action === "approve-run" && editable.status !== "Draft") {
      sendJson(response, 409, { ok: false, message: "Only draft pay runs can be approved." });
      return;
    }
    if (action === "mark-paid" && editable.status !== "Approved") {
      sendJson(response, 409, { ok: false, message: "Approve the pay run before marking it paid." });
      return;
    }
    if (action === "void-run" && editable.status === "Paid") {
      sendJson(response, 409, { ok: false, message: "A paid run cannot be voided." });
      return;
    }
    editable.status = action === "approve-run" ? "Approved" : action === "mark-paid" ? "Paid" : "Void";
    editable.paymentConfirmation = action === "mark-paid"
      ? String(payload.confirmation || "").trim().slice(0, 160) : editable.paymentConfirmation;
    if (action === "mark-paid" && !editable.paymentConfirmation) {
      sendJson(response, 400, { ok: false, message: "Enter the provider or bank confirmation number." });
      return;
    }
    if (action === "approve-run") editable.approvedAt = new Date().toISOString();
    if (action === "mark-paid") editable.paidAt = new Date().toISOString();
    editable.updatedAt = new Date().toISOString();
    editable.updatedBy = session.username;
    writePayrollData(store);
    logActivity(session, `payroll.run-${editable.status.toLowerCase()}`,
      `${editable.status} payroll run ${editable.from} through ${editable.to}.`);
  } else if (request.method === "DELETE" && action === "delete-run") {
    const existing = store.runs.find((record) => record.id === payload.id);
    if (!existing || existing.status !== "Draft") {
      sendJson(response, 409, { ok: false, message: "Only draft pay runs can be deleted." });
      return;
    }
    store.runs = store.runs.filter((record) => record.id !== existing.id);
    writePayrollData(store);
    logActivity(session, "payroll.run-deleted", `Deleted payroll run ${existing.from} through ${existing.to}.`);
  } else {
    sendJson(response, 400, { ok: false, message: "Unknown payroll action." });
    return;
  }
  broadcastAllServiceEvent("dashboard-updated", { area: "payroll" });
  const refreshed = calculatePayrollDetails(from, to, store);
  sendJson(response, 200, {
    ok: true,
    ...refreshed,
    settings: store.settings,
    profiles: store.profiles,
    employees: readEmployees().filter((employee) => employee.status !== "Inactive"),
    runs: store.runs.map(({ rows, ...record }) => ({ ...record, employeeCount: rows.length }))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  });
}

function searchableDocumentFiles(directory = documentsPath, prefix = "", results = []) {
  if (results.length >= 500) return results;
  for (const item of readdirSync(directory, { withFileTypes: true })) {
    if (item.isSymbolicLink()) continue;
    const relativePath = prefix ? `${prefix}/${item.name}` : item.name;
    const fullPath = join(directory, item.name);
    if (item.isDirectory()) searchableDocumentFiles(fullPath, relativePath, results);
    else results.push(relativePath);
    if (results.length >= 500) break;
  }
  return results;
}

function handleGlobalSearch(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  const url = new URL(request.url, publicOrigin(request));
  const query = String(url.searchParams.get("q") || "").trim().toLowerCase();
  if (query.length < 2) {
    sendJson(response, 200, { ok: true, results: [] });
    return;
  }
  const results = [];
  const add = (type, title, detail, href, haystack = "") => {
    if (results.length >= 40 || !`${title} ${detail} ${haystack}`.toLowerCase().includes(query)) return;
    results.push({ type, title, detail, href });
  };
  if (hasPermission(session, "customers")) {
    for (const customer of readCustomers()) {
      add("Customer", customer.name, customer.company || customer.primaryAddress || "",
        `/customers.html?customerId=${encodeURIComponent(customer.id)}`, `${customer.phone} ${customer.email} ${customer.additionalLocations}`);
    }
  }
  if (hasPermission(session, "service-tickets")) {
    for (const ticket of readTickets()) {
      add(ticket.ticketType === "Contract" ? "Contract Ticket" : "Service Ticket",
        ticketLabel(ticket), ticket.customer || "", `/service-tickets.html?ticketId=${encodeURIComponent(ticket.id)}`,
        `${ticket.serviceType} ${ticket.description} ${ticket.status} ${ticket.address}`);
    }
  }
  if (hasPermission(session, "warranties")) {
    for (const equipment of readWarranties()) {
      add("Equipment", equipment.productName, `${equipment.customerName} · ${equipment.serialNumber}`,
        "/warranties.html",
        `${equipment.manufacturer} ${equipment.model} ${equipment.location} ${equipment.equipmentStatus}`);
    }
  }
  if (hasPermission(session, "invoicing")) {
    for (const invoice of readInvoices()) {
      add("Invoice", `Invoice #${invoice.number}`, `${invoice.customer} · ${formatUsd(invoice.total)}`,
        `/invoices.html?invoiceId=${encodeURIComponent(invoice.id)}`, `${invoice.status} ${invoice.company} ${invoice.address}`);
    }
  }
  if (hasPermission(session, "employee-records")) {
    for (const employee of readEmployees()) {
      add("Employee", `${employee.firstName} ${employee.lastName}`, employee.jobTitle || "",
        `/employee-records.html?employeeId=${encodeURIComponent(employee.id)}`, `${employee.email} ${employee.phone} ${employee.zohoEmployeeId}`);
    }
  }
  if (hasPermission(session, "documents")) {
    try {
      for (const file of searchableDocumentFiles()) {
        add("Document", file.split("/").pop(), file, `/api/documents/download?path=${encodeURIComponent(file)}`);
      }
    } catch {
      // Document storage may be temporarily unavailable.
    }
  }
  sendJson(response, 200, { ok: true, results });
}

async function handleLocalAssistant(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  const payload = await readJsonBody(request);
  const question = String(payload.question || "").trim();
  if (!question) {
    sendJson(response, 400, { ok: false, message: "Ask me a question first." });
    return;
  }

  const query = question.toLowerCase();
  const permissions = new Set(effectivePermissions(session));
  const today = businessToday();
  const money = (value) => new Intl.NumberFormat("en-US", {
    style: "currency", currency: "USD", maximumFractionDigits: 0
  }).format(Number(value) || 0);
  const reply = (title, answer, href = "", actionLabel = "Open") =>
    sendJson(response, 200, { ok: true, title, answer, href, actionLabel });

  if (session.username === "Huber58" && /(?:storage|disk|unas|nas|space left|free space)/.test(query)) {
    const storage = storageCenterSnapshot();
    reply("Storage status",
      `${storage.writable ? "Storage is online" : "Storage needs attention"}. ${storage.capacity.usedPercent}% is used, ${Math.round(storage.capacity.freeBytes / 1073741824)} GB is free, and managed files use ${Math.round(storage.totalManagedBytes / 1048576)} MB. Active path: ${storage.root}.`,
      "/operations-center.html#storage", "Open storage manager");
    return;
  }

  if (session.username === "Huber58" && /(?:software update|website version|desktop (?:update|version|release)|app installer|update center)/.test(query)) {
    const updates = operationsUpdateSnapshot();
    reply("Update status",
      `The website is version ${updates.websiteVersion}. ${updates.desktop ? `The current Dashboard desktop release is ${updates.desktop.version}.` : "No Dashboard desktop release is published."} ${updates.publishedApps.length} installer package${updates.publishedApps.length === 1 ? " is" : "s are"} in the catalog.`,
      "/operations-center.html#updates", "Open update center");
    return;
  }

  if (session.username === "Huber58" && /(?:audit|system check|health check|anything wrong|system issue)/.test(query)) {
    const audit = operationsAuditSnapshot();
    reply("System audit",
      `${audit.summary.healthy} checks are healthy, ${audit.summary.warnings} have warnings, and ${audit.summary.errors} have errors.`,
      "/operations-center.html#audit", "Review audit");
    return;
  }

  if (session.username === "Huber58" && /(?:analytics|performance|completion rate|job trend|operations trend)/.test(query)) {
    const analytics = operationsAnalyticsSnapshot(90);
    reply("Operational analytics",
      `Over the last 90 days there were ${analytics.tickets.total} jobs: ${analytics.tickets.service} service and ${analytics.tickets.contracts} contract. ${analytics.tickets.completionRate}% are closed, with ${money(analytics.finance.invoiceTotal)} invoiced.`,
      "/operations-center.html#analytics", "Open analytics");
    return;
  }

  if (/help|what can you|what do you know/.test(query)) {
    reply("Here is what I can help with.",
      "Ask how to create tickets, customers, expenses, payments, invoices, estimates, employees, inventory, catalog items, folders, or file uploads. I can also answer questions about today's jobs, ticket status, overdue invoices, available staff, approvals, low inventory, storage, updates, system audits, and operational analytics.");
    return;
  }

  const asksHowToCreate = /(?:how (?:do|can) i|how to|where (?:do|can) i|show me how to|steps? to).*(?:create|make|add|start|open)|(?:create|make|add|start|open|new).*(?:how|where)/.test(query);
  const asksForNewTicket = /(?:new|create|make|add|start|open).*(?:service|contract)?\s*(?:job|ticket)|(?:service|contract)?\s*(?:job|ticket).*(?:new|create|make|add|start|open)/.test(query);
  const asksForWorkflow = asksHowToCreate || /\b(?:new|create|make|add|record|upload|start)\b/.test(query);

  const workflowGuides = [
    {
      pattern: /\b(?:customer|client)\b/,
      permission: "customers",
      title: "Add a new customer",
      answer: "Open Customers and click New Customer. Enter the customer name, company, phone, email, primary service address, any additional locations, and notes, then click Save Customer.",
      href: "/customers.html?new=1",
      actionLabel: "Add customer"
    },
    {
      pattern: /\bexpenses?\b/,
      permission: "finance",
      title: "Record an expense",
      answer: "Open Finance and select Expenses. Enter the description, amount, date, allocation group, employee if applicable, and a note, then click Record Expense. You can attach the receipt from Expense History afterward.",
      href: "/finance.html?view=expenses",
      actionLabel: "Record expense"
    },
    {
      pattern: /\bpayment\b/,
      permission: "finance",
      title: "Record a payment",
      answer: "Open Finance and select Payments. Choose the invoice or contract ticket, enter the amount, date, method, reference, and note, then click Record Payment.",
      href: "/finance.html?view=payments",
      actionLabel: "Record payment"
    },
    {
      pattern: /\binvoice\b/,
      permission: "invoicing",
      title: "Create an invoice",
      answer: "Open Invoicing and click New Invoice. Select an eligible closed service ticket, set the dates, labor, charges, tax, status, notes, and payment instructions, then click Save Invoice.",
      href: "/invoices.html?new=1",
      actionLabel: "Create invoice"
    },
    {
      pattern: /\b(?:estimate|quote)\b/,
      permission: "estimates",
      title: "Create an estimate",
      answer: "Open Estimates & Quotes and click New Estimate. Choose the customer, enter the project details and line items, set notes, terms, validity, and status, then click Save Estimate.",
      href: "/estimates.html?new=1",
      actionLabel: "Create estimate"
    },
    {
      pattern: /\bemployee\b/,
      permission: "employee-records",
      title: "Add an employee",
      answer: "Open Employee Records and click Add Employee. Enter their contact, position, wage, hire date, status, notes, and access permissions, then click Save Employee.",
      href: "/employee-records.html",
      actionLabel: "Open employee records"
    },
    {
      pattern: /\b(?:inventory|stock)\b/,
      permission: "inventory",
      title: "Add inventory",
      answer: "Open Inventory and click Add Item. Select the catalog item and variation, enter the quantity, location, reorder level, serial or notes as needed, then click Save Item.",
      href: "/inventory.html",
      actionLabel: "Open inventory"
    },
    {
      pattern: /\bcatalog\b/,
      permission: "catalog",
      title: "Add a catalog item",
      answer: "Open Catalog and click Add Item. Enter the product name, SKU, category, unit cost, description, and any variations, then save the item.",
      href: "/catalog.html",
      actionLabel: "Open catalog"
    },
    {
      pattern: /\b(?:document|file|folder)\b/,
      permission: "documents",
      title: "Add company files",
      answer: "Open File Browser. Use New Folder to organize files or Upload Files to select documents from your device. You can also drag files directly into the current folder.",
      href: "/documents.html",
      actionLabel: "Open file browser"
    }
  ];

  if (asksForWorkflow) {
    const guide = workflowGuides.find((item) => item.pattern.test(query));
    if (guide) {
      if (!permissions.has(guide.permission)) {
        reply("Access required", `Your account does not currently have permission to use ${guide.title.toLowerCase()}. Ask an administrator to enable the ${guide.permission} permission.`);
        return;
      }
      reply(guide.title, guide.answer, guide.href, guide.actionLabel);
      return;
    }
  }

  if ((asksHowToCreate || asksForNewTicket) && /(?:job|ticket)/.test(query) &&
      permissions.has("service-tickets")) {
    if (/contract/.test(query)) {
      reply("Create a contract ticket",
        "Open Service Tickets, select the Contract Tickets tab, then click New Contract Ticket. Choose or enter the customer, assign the employees, set the schedule and job details, add phases if needed, then click Save Ticket.",
        "/service-tickets.html?type=Contract&new=1", "Create contract ticket");
      return;
    }
    reply("Create a service ticket",
      "Open Service Tickets and click New Service Ticket. Choose an existing customer or enter the customer details, select the service type and priority, assign the employees, set the date and time, describe the issue, then click Save Ticket. Use Office Ticket for internal work or Non-Chargeable Service when appropriate.",
      "/service-tickets.html?new=1", "Create service ticket");
    return;
  }

  if (/(job|ticket|schedule|dispatch)/.test(query) &&
      (permissions.has("service-tickets") || permissions.has("schedule") || permissions.has("dispatch"))) {
    const tickets = readTickets();
    const open = tickets.filter((ticket) => ticket.status !== "Closed");
    const todayJobs = open.filter((ticket) => ticket.scheduledDate === today);
    const unassigned = open.filter((ticket) => !String(ticket.assignedTo || "").trim());
    const inProgress = open.filter((ticket) => String(ticket.status).toLowerCase() === "in progress");
    const href = permissions.has("dispatch") ? "/dispatch.html" : "/service-tickets.html";
    if (/today|scheduled/.test(query)) {
      const preview = todayJobs.slice(0, 3).map((ticket) =>
        `${ticket.scheduledTime || "Any time"} ${ticketLabel(ticket)} for ${ticket.customer || "Internal"}`
      ).join("; ");
      reply("Today's work", todayJobs.length
        ? `${todayJobs.length} job${todayJobs.length === 1 ? " is" : "s are"} scheduled today. ${preview}${todayJobs.length > 3 ? "; and more." : "."}`
        : "No open jobs are scheduled for today.", href, "Open schedule");
      return;
    }
    if (/unassigned|without.*(employee|tech)|need.*assign/.test(query)) {
      reply("Unassigned tickets", `${unassigned.length} open ticket${unassigned.length === 1 ? " is" : "s are"} waiting for an assignment.`, href, "Open dispatch");
      return;
    }
    if (/in.?progress|being worked/.test(query)) {
      reply("Work in progress", `${inProgress.length} ticket${inProgress.length === 1 ? " is" : "s are"} currently in progress.`, "/service-tickets.html", "Open tickets");
      return;
    }
    reply("Ticket overview", `${open.length} tickets are open, ${inProgress.length} are in progress, and ${unassigned.length} are unassigned.`, href, "Open tickets");
    return;
  }

  if (/(invoice|payment|outstanding|overdue|money|finance)/.test(query) &&
      (permissions.has("invoicing") || permissions.has("finance"))) {
    const invoices = readInvoices();
    const balances = new Map(calculateFinance(readFinance()).invoices.map((invoice) =>
      [invoice.id, Number(invoice.balance) || 0]));
    const outstanding = invoices.filter((invoice) =>
      !["Draft", "Void", "Paid"].includes(invoice.status) && Number(balances.get(invoice.id) || 0) > 0);
    const overdue = outstanding.filter((invoice) => invoice.dueDate && invoice.dueDate < today);
    const outstandingTotal = outstanding.reduce((sum, invoice) => sum + Number(balances.get(invoice.id) || 0), 0);
    const overdueTotal = overdue.reduce((sum, invoice) => sum + Number(balances.get(invoice.id) || 0), 0);
    if (/overdue/.test(query)) {
      reply("Overdue invoices", `${overdue.length} invoice${overdue.length === 1 ? " is" : "s are"} overdue, totaling ${money(overdueTotal)}.`, "/invoices.html", "Review invoices");
    } else {
      reply("Invoice balances", `${outstanding.length} invoice${outstanding.length === 1 ? " has" : "s have"} an outstanding balance totaling ${money(outstandingTotal)}.`, "/finance.html", "Open finance");
    }
    return;
  }

  if (/(employee|staff|technician|clocked|available|who is working)/.test(query) &&
      (permissions.has("employee-records") || permissions.has("employee-time") || permissions.has("schedule") || permissions.has("dispatch"))) {
    const employees = readEmployees().filter((employee) => employee.status !== "Inactive");
    const activeNames = new Set(readTimeRecords().filter((record) => !record.clockOut)
      .map((record) => String(record.employeeName || record.username || "").trim().toLowerCase()));
    const clockedIn = employees.filter((employee) =>
      activeNames.has(`${employee.firstName || ""} ${employee.lastName || ""}`.trim().toLowerCase()));
    const employeeHref = permissions.has("employee-records") ? "/employee-records.html" : "/schedule.html";
    reply("Staff overview", `${employees.length} employees are active and ${clockedIn.length} ${clockedIn.length === 1 ? "is" : "are"} currently clocked in${clockedIn.length ? `: ${clockedIn.map((employee) => `${employee.firstName} ${employee.lastName}`).join(", ")}.` : "."}`, employeeHref, permissions.has("employee-records") ? "Open employees" : "Open schedule");
    return;
  }

  if (/(customer|client)/.test(query) && permissions.has("customers")) {
    const customers = readCustomers();
    const activeJobs = readTickets().filter((ticket) => ticket.status !== "Closed");
    reply("Customer overview", `${customers.length} customer record${customers.length === 1 ? " is" : "s are"} on file with ${activeJobs.length} active job${activeJobs.length === 1 ? "" : "s"} across the company.`, "/customers.html", "Open customers");
    return;
  }

  if (/approval/.test(query) && permissions.has("approvals")) {
    const pending = readApprovals().filter((record) => record.status === "Pending");
    reply("Pending approvals", `${pending.length} approval${pending.length === 1 ? " is" : "s are"} waiting for review.`, "/approvals.html", "Review approvals");
    return;
  }

  if (/(inventory|stock|low item|reorder)/.test(query) && permissions.has("inventory")) {
    const low = readInventory().filter((record) => Number(record.quantity) <= Number(record.reorderLevel));
    reply("Inventory status", `${low.length} inventory item${low.length === 1 ? " is" : "s are"} at or below the reorder level.`, "/inventory.html", "Open inventory");
    return;
  }

  reply("I need a little more direction.",
    "I can answer local questions about jobs, tickets, invoices, staff, approvals, and inventory. You can also keep typing to search for a specific customer, employee, invoice, or document.");
}

function undoStore(name) {
  const stores = {
    tickets: { read: readTickets, write: writeTickets, event: "tickets-updated" },
    customers: { read: readCustomers, write: writeCustomers, event: "dashboard-updated" },
    estimates: { read: readEstimates, write: writeEstimates, event: "job-workspace-updated" },
    invoices: { read: readInvoices, write: writeInvoices, event: "dashboard-updated" },
    jobExpenses: { read: readJobExpenses, write: writeJobExpenses, event: "job-workspace-updated" }
  };
  return stores[name] || null;
}

function restoreActivityChange(entry) {
  const undo = entry.undo;
  const store = undoStore(undo?.collection);
  if (!store || !undo.recordId) throw new Error("This change cannot be restored.");
  const records = store.read();
  const index = records.findIndex((record) => record.id === undo.recordId);
  if (undo.before == null) {
    if (index < 0) throw new Error("The created record no longer exists.");
    const currentStamp = String(records[index].updatedAt || records[index].createdAt || "");
    const savedStamp = String(undo.after?.updatedAt || undo.after?.createdAt || "");
    if (savedStamp && currentStamp !== savedStamp) {
      throw new Error("This record has newer changes and cannot be removed by undo.");
    }
    records.splice(index, 1);
  } else if (undo.after == null) {
    if (index >= 0) throw new Error("A record with this ID already exists.");
    records.push(undo.before);
  } else {
    if (index < 0) throw new Error("The changed record no longer exists.");
    const currentStamp = String(records[index].updatedAt || records[index].createdAt || "");
    const savedStamp = String(undo.after.updatedAt || undo.after.createdAt || "");
    if (savedStamp && currentStamp !== savedStamp) {
      throw new Error("This record has newer changes. Undo would overwrite them.");
    }
    records[index] = undo.before;
  }
  store.write(records);
  broadcastAllServiceEvent(store.event, { recordId: undo.recordId, area: undo.collection });
  broadcastAllServiceEvent("dashboard-updated", { area: undo.collection });
}

async function handleActivity(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can view full activity history." });
    return;
  }
  const url = new URL(request.url, `http://${request.headers.host}`);
  if (request.method === "POST" && url.pathname === "/api/activity/undo") {
    const payload = await readJsonBody(request);
    const all = readActivity();
    const entry = all.find((record) => record.id === payload.id);
    if (!entry?.undo || entry.undo.undoneAt) {
      sendJson(response, 409, { ok: false, message: "This activity cannot be undone." });
      return;
    }
    try {
      restoreActivityChange(entry);
    } catch (error) {
      sendJson(response, 409, { ok: false, message: error.message });
      return;
    }
    entry.undo.undoneAt = new Date().toISOString();
    entry.undo.undoneBy = session.username;
    writeActivity(all);
    logActivity(session, "activity.undo", `Undid: ${entry.message}`);
    sendJson(response, 200, { ok: true, message: "The previous version was restored." });
    return;
  }
  if (request.method !== "GET") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const query = String(url.searchParams.get("q") || "").trim().toLowerCase();
  const username = String(url.searchParams.get("username") || "");
  const type = String(url.searchParams.get("type") || "");
  const from = String(url.searchParams.get("from") || "");
  const to = String(url.searchParams.get("to") || "");
  const all = readActivity();
  const activity = all
    .filter((entry) => !query ||
      `${entry.message} ${entry.employeeName} ${entry.username} ${entry.type}`.toLowerCase().includes(query))
    .filter((entry) => !username || entry.username === username)
    .filter((entry) => !type || entry.type === type)
    .filter((entry) => !from || entry.createdAt.slice(0, 10) >= from)
    .filter((entry) => !to || entry.createdAt.slice(0, 10) <= to)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 1000);
  sendJson(response, 200, {
    ok: true,
    activity: activity.map((entry) => ({
      ...entry,
      undo: entry.undo ? {
        available: !entry.undo.undoneAt,
        collection: entry.undo.collection,
        undoneAt: entry.undo.undoneAt || "",
        undoneBy: entry.undo.undoneBy || ""
      } : null
    })),
    users: [...new Set(all.map((entry) => entry.username))].sort(),
    types: [...new Set(all.map((entry) => entry.type))].sort()
  });
}

function readAlertDismissals() {
  if (!existsSync(alertDismissalsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(alertDismissalsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

async function handleAlerts(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const payload = await readJsonBody(request);
  const id = String(payload.id || "");
  const action = String(payload.action || "");
  if (!/^[a-f0-9]{64}$/.test(id) || !["acknowledge", "snooze"].includes(action)) {
    sendJson(response, 400, { ok: false, message: "Invalid alert action." });
    return;
  }
  const records = readAlertDismissals().filter((record) =>
    !(record.id === id && record.username === session.username)
  );
  records.push({
    id,
    username: session.username,
    action,
    until: action === "snooze"
      ? new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
      : "",
    createdAt: new Date().toISOString()
  });
  writeFileSync(alertDismissalsPath, JSON.stringify(records.slice(-5000), null, 2), { mode: 0o600 });
  logActivity(session, `alert.${action}`, `${action === "snooze" ? "Snoozed" : "Acknowledged"} a dashboard alert.`);
  sendJson(response, 200, { ok: true });
}

function handleDashboardSummary(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  const alerts = [];
  const today = businessToday();
  const operations = {};
  const permissions = new Set(effectivePermissions(session));
  const activeEmployees = readEmployees().filter((employee) => employee.status !== "Inactive");
  const awayNames = new Set(readAvailability()
    .filter((record) =>
      record.status === "Approved" && record.startDate <= today && record.endDate >= today
    )
    .map((record) => String(record.employeeName || "").trim().toLowerCase()));
  const activeShifts = new Set(readTimeRecords()
    .filter((record) => !record.clockOut)
    .map((record) =>
      String(record.employeeName || record.username || "").trim().toLowerCase()
    ));

  if (permissions.has("dispatch") || permissions.has("service-tickets") || permissions.has("schedule")) {
    const openTickets = readTickets().filter((ticket) => ticket.status !== "Closed");
    operations.jobsToday = openTickets
      .filter((ticket) => ticket.scheduledDate === today)
      .map((ticket) => ({
        id: ticket.id,
        label: ticketLabel(ticket),
        customer: ticket.customer || "",
        assignedTo: ticket.assignedTo || "Unassigned",
        scheduledTime: ticket.scheduledTime || "",
        location: ticket.address || (ticket.isOffice ? "Huber I.T. Professionals" : ""),
        type: ticket.isOffice ? "Internal" : (ticket.serviceType || ticket.ticketType || "On-Site"),
        status: ticket.status || "Scheduled"
      }));
    operations.unassignedJobs = openTickets.filter((ticket) => !ticket.assignedTo).length;
  }
  if (permissions.has("employee-time") || permissions.has("schedule") ||
      permissions.has("availability") || permissions.has("dispatch")) {
    operations.availableStaff = activeEmployees
      .map((employee) => `${employee.firstName || ""} ${employee.lastName || ""}`.trim())
      .filter((name) => name && !awayNames.has(name.toLowerCase()))
      .map((name) => ({ name, clockedIn: activeShifts.has(name.toLowerCase()) }));
    operations.awayStaff = activeEmployees
      .map((employee) => `${employee.firstName || ""} ${employee.lastName || ""}`.trim())
      .filter((name) => name && awayNames.has(name.toLowerCase()));
  }
  if (permissions.has("invoicing") || permissions.has("finance")) {
    const invoiceBalances = new Map(calculateFinance(readFinance()).invoices.map((invoice) =>
      [invoice.id, invoice.balance]
    ));
    const overdue = readInvoices().filter((invoice) =>
      !["Draft", "Void", "Paid"].includes(invoice.status) &&
      invoice.dueDate && invoice.dueDate < today &&
      Number(invoiceBalances.get(invoice.id) || 0) > 0
    );
    operations.overdueInvoices = {
      count: overdue.length,
      total: roundMoney(overdue.reduce((sum, invoice) =>
        sum + Number(invoiceBalances.get(invoice.id) || 0), 0))
    };
  }
  if (permissions.has("approvals")) {
    operations.pendingApprovals = readApprovals()
      .filter((record) => record.status === "Pending").length;
  }
  if (permissions.has("inventory")) {
    operations.lowInventory = readInventory().filter((record) =>
      Number(record.quantity) <= Number(record.reorderLevel)
    ).length;
  }

  if (hasPermission(session, "service-tickets") || hasPermission(session, "schedule")) {
    for (const ticket of readTickets().filter((record) =>
      record.status !== "Closed" && record.scheduledDate && record.scheduledDate < today
    )) {
      alerts.push({
        type: "overdue",
        title: `${ticketLabel(ticket)} is overdue`,
        detail: `${ticket.customer} was scheduled for ${ticket.scheduledDate}.`,
        href: "/service-tickets.html"
      });
    }
  }

  if (hasPermission(session, "service-tickets")) {
    for (const ticket of readTickets()) {
      for (const message of (ticket.internalMessages || []).filter((entry) => !entry.fromOffice).slice(-5)) {
        alerts.push({
          type: "message",
          title: `Employee message on ${ticketLabel(ticket)}`,
          detail: `${message.employeeName}: ${message.message.slice(0, 140)}`,
          href: "/service-tickets.html"
        });
      }
    }
  }

  if (hasPermission(session, "inventory")) {
    for (const item of readInventory().filter((record) =>
      Number(record.quantity) <= Number(record.reorderLevel)
    )) {
      alerts.push({
        type: "inventory",
        title: `Low inventory: ${item.name}${item.variationName ? ` - ${item.variationName}` : ""}`,
        detail: `${item.quantity} remaining; reorder level is ${item.reorderLevel}.`,
        href: "/inventory.html"
      });
    }
  }

  if (hasPermission(session, "unifi")) {
    const unifi = readUnifiData();
    for (const site of unifi.cache.sites || []) {
      const offline = unifiOfflineCount(site);
      if (offline) {
        alerts.push({
          type: "unifi",
          title: `UniFi devices offline: ${unifiSiteName(site)}`,
          detail: `${offline} device${offline === 1 ? " is" : "s are"} currently reported offline.`,
          href: "/unifi.html"
        });
      }
      const updates = Number(site.statistics?.counts?.pendingUpdateDevice) || 0;
      if (updates) {
        alerts.push({
          type: "unifi-update",
          title: `UniFi updates available: ${unifiSiteName(site)}`,
          detail: `${updates} device${updates === 1 ? " has" : "s have"} an update pending.`,
          href: "/unifi.html"
        });
      }
    }
    for (const host of unifi.cache.hosts || []) {
      const backup = host.latestBackupTime ? new Date(host.latestBackupTime) : null;
      if (backup && Date.now() - backup.getTime() <= 7 * 86400000) continue;
      alerts.push({
        type: "unifi-backup",
        title: "UniFi console backup needs attention",
        detail: `${host.reportedState?.name || host.reportedState?.hostname || "Console"} has ${backup ? "not backed up in over 7 days" : "no reported backup"}.`,
        href: "/unifi.html"
      });
    }
    for (const item of Object.values(unifi.cache.protect || {})) {
      for (const sensor of item.sensors || []) {
        const battery = sensor.wirelessConnectionState?.batteryStatus || sensor.batteryStatus || {};
        if (!battery.isLow) continue;
        alerts.push({
          type: "unifi-sensor",
          title: `Low UniFi sensor battery: ${sensor.name || sensor.modelKey || "Sensor"}`,
          detail: `Battery is ${battery.percentage ?? "reported low"}${battery.percentage == null ? "" : "%"}.`,
          href: "/unifi.html"
        });
      }
    }
  }

  if (hasPermission(session, "warranties")) {
    for (const warranty of readWarranties().filter((record) =>
      ["Expired", "Expiring Soon"].includes(warrantyStatus(record))
    )) {
      const status = warrantyStatus(warranty);
      alerts.push({
        type: "warranty",
        title: `${status}: ${warranty.productName}`,
        detail: `${warranty.customerName} · Serial ${warranty.serialNumber} · ${status === "Expired" ? "Expired" : "Expires"} ${warranty.expiresAt}.`,
        href: "/warranties.html"
      });
    }
  }

  if (hasPermission(session, "taxes")) {
    const today = businessToday();
    const upcoming = new Date(`${today}T12:00:00`);
    upcoming.setDate(upcoming.getDate() + 14);
    const upcomingDate = upcoming.toISOString().slice(0, 10);
    for (const filing of readTaxData().filings.filter((record) =>
      record.status !== "Paid" && record.dueDate <= upcomingDate
    )) {
      const overdue = filing.dueDate < today;
      alerts.push({
        type: "tax",
        title: `${overdue ? "Overdue" : "Tax due soon"}: ${filing.type}`,
        detail: `$${Number(filing.amount || 0).toFixed(2)} ${overdue ? "was" : "is"} due ${filing.dueDate}.`,
        href: "/taxes.html"
      });
    }
  }

  if (hasPermission(session, "approvals")) {
    for (const approval of readApprovals().filter((record) => record.status === "Pending")) {
      alerts.push({
        type: "approval",
        title: "Approval requested",
        detail: `${approval.requestedByName}: ${approval.summary}`,
        href: "/approvals.html"
      });
    }
  }

  if (hasPermission(session, "bills")) {
    const today = businessToday();
    for (const bill of readBills().filter((record) =>
      !["Paid", "Paid Off"].includes(record.status) && record.dueDate < today
    )) {
      alerts.push({
        type: "bill",
        title: `${bill.type || "Bill"} overdue: ${bill.name}`,
        detail: `$${Number(bill.amount || 0).toFixed(2)} was due ${bill.dueDate}.`,
        href: "/bills.html"
      });
    }
  }

  if (hasPermission(session, "employee-time") || hasPermission(session, "reports")) {
    for (const record of readTimeRecords().filter((entry) =>
      !entry.clockOut && Date.now() - new Date(entry.clockIn).getTime() > 16 * 60 * 60 * 1000
    )) {
      alerts.push({
        type: "time",
        title: `Long active shift`,
        detail: `${record.employeeName || record.username} has been clocked in for more than 16 hours.`,
        href: "/employee-time.html"
      });
    }
  }

  const dismissed = readAlertDismissals().filter((record) =>
    record.username === session.username &&
    (record.action === "acknowledge" || new Date(record.until) > new Date())
  );
  const visibleAlerts = alerts
    .map((alert) => ({
      ...alert,
      id: createHash("sha256")
        .update(`${alert.type}|${alert.title}|${alert.detail}`)
        .digest("hex")
    }))
    .filter((alert) => !dismissed.some((record) => record.id === alert.id));

  sendJson(response, 200, {
    ok: true,
    alerts: visibleAlerts.slice(0, 30),
    operations,
    activity: session.username === "Huber58"
      ? readActivity().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 20)
      : []
  });
}

function handleTicketSignature(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }
  const url = new URL(request.url, `http://${request.headers.host}`);
  const ticket = readTickets().find((record) => record.id === url.searchParams.get("ticketId"));
  if (!ticket?.signature?.storedName ||
      (!hasPermission(session, "service-tickets") && !ticketMatchesEmployee(ticket, session))) {
    sendJson(response, 404, { ok: false, message: "Signature not found." });
    return;
  }
  const filePath = resolve(ticketSignaturesPath, ticket.signature.storedName);
  if (!filePath.startsWith(`${ticketSignaturesPath}${sep}`) || !existsSync(filePath)) {
    sendJson(response, 404, { ok: false, message: "Signature not found." });
    return;
  }
  response.writeHead(200, {
    "Content-Type": "image/png",
    "Content-Length": statSync(filePath).size,
    "Cache-Control": "private, no-store",
    "X-Content-Type-Options": "nosniff"
  });
  createReadStream(filePath).pipe(response);
}

const managedStorageBuckets = () => [
  ["Documents", documentsPath],
  ["Ticket attachments", ticketAttachmentsPath],
  ["Receipts", receiptFilesPath],
  ["Mail uploads", mailUploadsPath],
  ["Mail cache", mailCachePath],
  ["Presentation images", presentationImagesPath],
  ["Badge photos", badgePhotosPath],
  ["Installed apps", installedAppFilesPath],
  ["Desktop installers", desktopInstallerPackagesPath]
];

function directoryUsageBytes(directoryPath) {
  if (!fsExistsSync(directoryPath)) return 0;
  let total = 0;
  const pending = [directoryPath];
  while (pending.length) {
    const current = pending.pop();
    let entries = [];
    try { entries = readdirSync(current, { withFileTypes: true }); } catch { continue; }
    for (const entry of entries) {
      const target = join(current, entry.name);
      if (entry.isDirectory()) pending.push(target);
      else if (entry.isFile()) {
        try { total += statSync(target).size; } catch {}
      }
    }
  }
  return total;
}

function storageCenterSnapshot() {
  let writable = true;
  let message = "Storage is available.";
  const probePath = join(managedStorageRoot, `.storage-probe-${process.pid}`);
  try {
    mkdirSync(managedStorageRoot, { recursive: true, mode: 0o700 });
    fsWriteFileSync(probePath, "ok", { mode: 0o600 });
    unlinkSync(probePath);
  } catch (error) {
    writable = false;
    message = error.message || "Storage is not writable.";
  }
  let capacity = { totalBytes: 0, freeBytes: 0, usedPercent: 0 };
  try {
    const disk = statfsSync(managedStorageRoot);
    capacity.totalBytes = Number(disk.blocks) * Number(disk.bsize);
    capacity.freeBytes = Number(disk.bavail) * Number(disk.bsize);
    capacity.usedPercent = capacity.totalBytes
      ? Math.round((1 - capacity.freeBytes / capacity.totalBytes) * 1000) / 10 : 0;
  } catch {}
  const buckets = managedStorageBuckets().map(([name, path]) => ({
    name,
    path,
    bytes: directoryUsageBytes(path),
    available: fsExistsSync(path)
  }));
  return {
    root: managedStorageRoot,
    source: process.env.FILE_STORAGE_ROOT ? "environment" : runtimeStorageSettings.storageRoot ? "saved" : "local",
    writable,
    message,
    restartRequired: Boolean(runtimeStorageSettings.pendingRestart),
    capacity,
    totalManagedBytes: buckets.reduce((sum, bucket) => sum + bucket.bytes, 0),
    buckets
  };
}

function operationsUpdateSnapshot() {
  let websiteVersion = "Unknown";
  try { websiteVersion = fsReadFileSync(join(root, "version.txt"), "utf8").trim() || "Unknown"; } catch {}
  let desktop = null;
  try {
    desktop = JSON.parse(fsReadFileSync(join(desktopUpdateDirectory(), "latest-mac-arm64.json"), "utf8"));
  } catch {}
  const publishedApps = readDesktopInstallerCatalog().map((app) => ({
    id: app.id,
    name: app.name,
    version: app.version,
    platform: app.platform,
    arch: app.arch,
    publishedAt: app.publishedAt,
    size: Number(app.size || 0)
  }));
  const history = readActivity()
    .filter((record) => /(?:site\.update|desktop\.update-published|desktop-app\.published)/.test(record.type))
    .slice(-30)
    .reverse();
  return { websiteVersion, desktop, publishedApps, history };
}

function operationsAuditSnapshot() {
  const checks = [];
  const add = (name, status, detail, action = "") => checks.push({ name, status, detail, action });
  let databaseHealthy = false;
  try { databaseHealthy = structuredStore.integrityCheck(); } catch {}
  add("SQLite integrity", databaseHealthy ? "Healthy" : "Error",
    databaseHealthy ? "Database integrity check passed." : "Database integrity check failed.", "Open diagnostics");

  const storage = storageCenterSnapshot();
  add("Managed file storage", storage.writable ? "Healthy" : "Error",
    storage.writable ? `${storage.root} is writable.` : storage.message, "Review storage");
  add("Storage capacity", storage.capacity.usedPercent >= 90 ? "Error" : storage.capacity.usedPercent >= 80 ? "Warning" : "Healthy",
    `${storage.capacity.usedPercent}% used with ${Math.round(storage.capacity.freeBytes / 1073741824)} GB free.`, "Review storage");

  const backupPath = resolve(process.env.BACKUP_STATUS_PATH || join(root, ".data", "last-backup.json"));
  let backupAge = null;
  try {
    const status = JSON.parse(fsReadFileSync(backupPath, "utf8"));
    const timestamp = new Date(status.lastSuccess || 0).getTime();
    if (Number.isFinite(timestamp)) backupAge = Math.floor((Date.now() - timestamp) / 86400000);
  } catch {}
  add("Backup recency", backupAge == null || backupAge > 8 ? "Warning" : "Healthy",
    backupAge == null ? "No successful backup is recorded." : `Last successful backup was ${backupAge} day(s) ago.`, "Open diagnostics");

  const envPath = join(root, ".env");
  if (fsExistsSync(envPath)) {
    const mode = statSync(envPath).mode & 0o777;
    add("Environment file permissions", mode & 0o077 ? "Warning" : "Healthy",
      mode & 0o077 ? `.env permissions are ${mode.toString(8)}; use 600 on Ubuntu.` : ".env is restricted to its owner.");
  } else {
    add("Environment configuration", "Info", "No .env file is present in this installation.");
  }
  const missingCoreFiles = ["server.mjs", "dashboard.html", "login.html", "version.txt"]
    .filter((name) => !fsExistsSync(join(root, name)));
  add("Core application files", missingCoreFiles.length ? "Error" : "Healthy",
    missingCoreFiles.length ? `Missing: ${missingCoreFiles.join(", ")}.` : "Required application files are present.");

  const stats = structuredStore.stats();
  add("Indexed data", "Healthy", `${stats.records} records across ${stats.collections} SQLite collections.`);
  return {
    generatedAt: new Date().toISOString(),
    summary: {
      errors: checks.filter((check) => check.status === "Error").length,
      warnings: checks.filter((check) => check.status === "Warning").length,
      healthy: checks.filter((check) => check.status === "Healthy").length
    },
    checks
  };
}

function operationsAnalyticsSnapshot(days = 90) {
  const rangeDays = [30, 90, 365].includes(Number(days)) ? Number(days) : 90;
  const cutoff = Date.now() - rangeDays * 86400000;
  const dateOf = (record, ...fields) => {
    for (const field of fields) {
      const value = new Date(record[field] || 0).getTime();
      if (Number.isFinite(value) && value > 0) return value;
    }
    return 0;
  };
  const tickets = readTickets().filter((ticket) =>
    dateOf(ticket, "createdAt", "scheduledDate", "date") >= cutoff);
  const service = tickets.filter((ticket) => (ticket.ticketType || "Service") !== "Contract");
  const contracts = tickets.filter((ticket) => ticket.ticketType === "Contract");
  const closed = tickets.filter((ticket) => String(ticket.status).toLowerCase() === "closed");
  const hours = tickets.reduce((sum, ticket) => sum + Number(ticket.hours || ticket.totalHours || 0), 0);
  const finance = calculateFinance(readFinance());
  const invoices = readInvoices().filter((invoice) => dateOf(invoice, "date", "createdAt", "issueDate") >= cutoff);
  const invoiceTotal = invoices.reduce((sum, invoice) => sum + Number(invoice.total || 0), 0);
  const jobExpenses = readJobExpenses().filter((expense) => dateOf(expense, "date", "createdAt") >= cutoff);
  const jobExpenseTotal = jobExpenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
  const byStatus = Object.entries(tickets.reduce((map, ticket) => {
    const status = String(ticket.status || "Open");
    map[status] = (map[status] || 0) + 1;
    return map;
  }, {})).map(([status, count]) => ({ status, count })).sort((a, b) => b.count - a.count);
  const weekly = Array.from({ length: Math.min(12, Math.ceil(rangeDays / 7)) }, (_, reverseIndex) => {
    const index = Math.min(12, Math.ceil(rangeDays / 7)) - reverseIndex - 1;
    const start = Date.now() - (index + 1) * 7 * 86400000;
    const end = Date.now() - index * 7 * 86400000;
    const weekTickets = tickets.filter((ticket) => {
      const date = dateOf(ticket, "createdAt", "scheduledDate", "date");
      return date >= start && date < end;
    });
    return {
      label: new Date(start).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      created: weekTickets.length,
      closed: weekTickets.filter((ticket) => String(ticket.status).toLowerCase() === "closed").length
    };
  });
  return {
    rangeDays,
    tickets: { total: tickets.length, service: service.length, contracts: contracts.length, closed: closed.length,
      completionRate: tickets.length ? Math.round(closed.length / tickets.length * 1000) / 10 : 0, hours, byStatus },
    finance: { invoiceTotal: roundMoney(invoiceTotal), received: finance.summary.received,
      outstanding: finance.summary.outstanding, jobExpenses: roundMoney(jobExpenseTotal), netIncome: finance.summary.netIncome },
    weekly
  };
}

async function handleOperationsCenter(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can use Operations Center." });
    return;
  }
  const url = new URL(request.url, publicOrigin(request));
  if (request.method === "GET") {
    const view = String(url.searchParams.get("view") || "overview");
    const payload = { ok: true, view };
    if (view === "overview" || view === "storage") payload.storage = storageCenterSnapshot();
    if (view === "overview" || view === "updates") payload.updates = operationsUpdateSnapshot();
    if (view === "overview" || view === "audit") payload.audit = operationsAuditSnapshot();
    if (view === "overview" || view === "analytics") payload.analytics = operationsAnalyticsSnapshot(url.searchParams.get("days"));
    sendJson(response, 200, payload);
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  const payload = await readJsonBody(request);
  if (payload.action !== "move-storage") {
    sendJson(response, 400, { ok: false, message: "Unknown Operations Center action." });
    return;
  }
  const destination = resolve(String(payload.storageRoot || "").trim());
  if (!destination || destination === resolve("/") || destination === root || destination.startsWith(`${root}${sep}`)) {
    sendJson(response, 400, { ok: false, message: "Choose an absolute mounted storage path outside the website folder." });
    return;
  }
  try {
    mkdirSync(destination, { recursive: true, mode: 0o700 });
    const probe = join(destination, `.storage-probe-${process.pid}`);
    fsWriteFileSync(probe, "ok", { mode: 0o600 });
    unlinkSync(probe);
    let copiedBytes = 0;
    for (const [, sourcePath] of managedStorageBuckets()) {
      if (!fsExistsSync(sourcePath)) continue;
      const targetPath = join(destination, basename(sourcePath));
      if (resolve(sourcePath) === resolve(targetPath)) continue;
      copiedBytes += directoryUsageBytes(sourcePath);
      cpSync(sourcePath, targetPath, { recursive: true, force: false, errorOnExist: false });
    }
    mkdirSync(dirname(storageSettingsRuntimePath), { recursive: true, mode: 0o700 });
    fsWriteFileSync(storageSettingsRuntimePath, `${JSON.stringify({
      storageRoot: destination,
      pendingRestart: true,
      movedAt: new Date().toISOString(),
      movedBy: session.username
    }, null, 2)}\n`, { mode: 0o600 });
    logActivity(session, "storage.migrated", `Copied managed file storage to ${destination}.`);
    sendJson(response, 200, {
      ok: true,
      copiedBytes,
      restartRequired: true,
      message: "Files were copied and verified. Restart server.mjs to activate the new storage location; the original files remain as a safety copy."
    });
  } catch (error) {
    sendJson(response, 500, { ok: false, message: error.message || "Storage migration failed." });
  }
}

function hostCpuUsage() {
  const cores = cpus();
  const current = cores.reduce((summary, core) => {
    const times = Object.values(core.times || {}).reduce((sum, value) => sum + Number(value || 0), 0);
    summary.total += times;
    summary.idle += Number(core.times?.idle || 0);
    return summary;
  }, { total: 0, idle: 0 });
  const previous = diagnosticsCpuSnapshot;
  diagnosticsCpuSnapshot = current;
  const totalDelta = previous ? current.total - previous.total : current.total;
  const idleDelta = previous ? current.idle - previous.idle : current.idle;
  const used = totalDelta > 0 ? (1 - idleDelta / totalDelta) * 100 : 0;
  return {
    cores: cores.length,
    percent: Math.round(Math.min(100, Math.max(0, used)) * 10) / 10
  };
}

function hostResourceSnapshot() {
  const cpu = hostCpuUsage();
  const memoryTotalBytes = totalmem();
  const memoryFreeBytes = freemem();
  const memoryUsedBytes = Math.max(0, memoryTotalBytes - memoryFreeBytes);
  return {
    hostname: hostname(),
    platform: platform(),
    release: release(),
    architecture: process.arch,
    uptimeSeconds: Math.floor(systemUptime()),
    cpuCores: cpu.cores,
    cpuPercent: cpu.percent,
    loadAverage: loadavg().map((value) => Math.round(value * 100) / 100),
    memoryTotalBytes,
    memoryFreeBytes,
    memoryUsedBytes,
    memoryUsedPercent: memoryTotalBytes
      ? Math.round(memoryUsedBytes / memoryTotalBytes * 1000) / 10 : 0,
    sampledAt: new Date().toISOString()
  };
}

function handleLiveDiagnostics(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can view server diagnostics." });
    return;
  }
  sendJson(response, 200, { ok: true, host: hostResourceSnapshot() });
}

function handleDiagnostics(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can view server diagnostics." });
    return;
  }

  const disk = statfsSync(root);
  const totalBytes = Number(disk.blocks) * Number(disk.bsize);
  const freeBytes = Number(disk.bavail) * Number(disk.bsize);
  const host = hostResourceSnapshot();
  const pushSubscriptions = readPushSubscriptions();
  let pushFailures = [];
  if (existsSync(pushFailuresPath)) {
    try {
      pushFailures = JSON.parse(readFileSync(pushFailuresPath, "utf8")) || [];
    } catch {
      pushFailures = [];
    }
  }
  const connected = [...eventClients.values()].map((client) => client.username);
  const connectedUsers = [...new Set(connected)].sort();
  const backupStatusPath = resolve(process.env.BACKUP_STATUS_PATH || join(root, ".data", "last-backup.json"));
  let backup = { configured: false, lastSuccess: "", message: "Automatic backup status is not configured." };
  if (existsSync(backupStatusPath)) {
    try {
      backup = { configured: true, ...JSON.parse(readFileSync(backupStatusPath, "utf8")) };
    } catch {
      backup = { configured: true, lastSuccess: "", message: "Backup status file is unreadable." };
    }
  }

  const dataFiles = [
    databasePath,
    usersPath,
    ticketsPath,
    employeesPath,
    timePath,
    availabilityPath,
    customersPath,
    customerCommunicationsPath,
    warrantiesPath,
    taxesPath,
    payrollPath,
    approvalsPath,
    approvalPoliciesPath,
    ptoSettingsPath,
    dashboardLayoutsPath,
    presentationsPath,
    spreadsheetsPath,
    floorPlansPath,
    companyDocumentsPath,
    trainingVideosPath,
    jobExpensesPath,
    accessTemplatesPath,
    userThemesPath,
    trustedTwoFactorPath,
    invoiceChargesPath,
    invoicePaymentInstructionsPath,
    financePath,
    billsPath,
    bankPath,
    bankRulesPath,
    estimatesPath,
    bidsPath,
    badgesPath,
    mailAccountsPath,
    mailDraftsPath,
    mailStatePath,
    estimateTemplatesPath,
    estimateMaterialRulesPath,
    estimateLineItemsPath,
    stripeEventsPath,
    zohoPaymentSessionsPath,
    zohoPaymentEventsPath,
    securityEventsPath,
    receiptsPath,
    portalAccessPath,
    inventoryPath,
    catalogPath,
    itemCategoriesPath,
    notificationsPath,
    activityPath,
    unifiPath
  ].map((filePath) => {
    const name = filePath.split(sep).pop();
    if (!existsSync(filePath)) return { name, status: "Not created", size: 0, modified: "" };
    try {
      if (structuredPaths.has(resolve(filePath)) && structuredStore.has(filePath)) {
        const info = structuredStore.info(filePath);
        return {
          name,
          status: "Healthy",
          size: Number(info?.size) || 0,
          modified: info?.updatedAt || ""
        };
      }
      const stats = statSync(filePath);
      if (filePath === databasePath) {
        if (!structuredStore.integrityCheck()) throw new Error("SQLite integrity check failed.");
      } else if (extname(filePath) === ".json" || filePath.startsWith(join(root, ".data"))) {
        JSON.parse(readFileSync(filePath, "utf8"));
      }
      return { name, status: "Healthy", size: stats.size, modified: stats.mtime.toISOString() };
    } catch {
      return { name, status: "Unreadable", size: 0, modified: "" };
    }
  });

  const backupDate = backup.lastSuccess ? new Date(backup.lastSuccess) : null;
  const backupAgeDays = backupDate && Number.isFinite(backupDate.getTime())
    ? Math.floor((Date.now() - backupDate.getTime()) / 86400000) : null;
  const unreadableFiles = dataFiles.filter((file) => file.status === "Unreadable");
  const databaseStats = structuredStore.stats();
  const checks = [
    {
      name: "Database integrity",
      detail: unreadableFiles.length
        ? `${unreadableFiles.length} data file(s) need attention`
        : `${databaseStats.records} indexed record(s) across ${databaseStats.collections} SQLite collection(s)`,
      status: unreadableFiles.length ? "Error" : "Healthy"
    },
    {
      name: "Scheduled backup",
      detail: backupAgeDays == null ? "No successful backup has been recorded" : `Last successful backup ${backupAgeDays} day(s) ago`,
      status: backupAgeDays == null || backupAgeDays > 8 ? "Warning" : "Healthy"
    },
    {
      name: "Storage capacity",
      detail: `${totalBytes ? Math.round((1 - freeBytes / totalBytes) * 1000) / 10 : 0}% used · ${Math.round(freeBytes / 1073741824)} GB available`,
      status: totalBytes && freeBytes / totalBytes < 0.1 ? "Error" : totalBytes && freeBytes / totalBytes < 0.2 ? "Warning" : "Healthy"
    },
    {
      name: "Host CPU utilization",
      detail: `${host.cpuPercent}% across ${host.cpuCores} logical core(s) · load ${host.loadAverage.join(" / ")}`,
      status: host.cpuPercent >= 90 ? "Error" : host.cpuPercent >= 75 ? "Warning" : "Healthy"
    },
    {
      name: "Host memory utilization",
      detail: `${host.memoryUsedPercent}% used · ${Math.round(host.memoryFreeBytes / 1073741824 * 10) / 10} GB available`,
      status: host.memoryUsedPercent >= 95 ? "Error" : host.memoryUsedPercent >= 85 ? "Warning" : "Healthy"
    },
    {
      name: "Push notifications",
      detail: `${pushSubscriptions.length} registered device(s) · ${pushFailures.length} recent failure(s)`,
      status: pushFailures.length ? "Warning" : "Healthy"
    },
    {
      name: "Live update stream",
      detail: `${eventClients.size} active browser connection(s)`,
      status: "Healthy"
    },
    {
      name: "Secure public origin",
      detail: publicBaseUrl,
      status: publicBaseUrl.startsWith("https://") ? "Healthy" : "Warning"
    }
  ];
  const integrations = [
    { name: "UniFi", configured: Boolean(String(process.env.UNIFI_API_KEY || "").trim()) },
    { name: "Bank statement imports", configured: true },
    { name: "Zoho Payments", configured: zohoPaymentsConfigured() },
    { name: "Web Push", configured: Boolean(pushConfig.publicKey && pushConfig.privateKey) }
  ];

  sendJson(response, 200, {
    ok: true,
    server: {
      uptimeSeconds: Math.floor(process.uptime()),
      nodeVersion: process.version,
      memoryBytes: process.memoryUsage().rss,
      startedAt: new Date(Date.now() - process.uptime() * 1000).toISOString(),
      host
    },
    storage: {
      totalBytes,
      freeBytes,
      usedPercent: totalBytes ? Math.round((1 - freeBytes / totalBytes) * 1000) / 10 : 0,
      database: databaseStats
    },
    connections: {
      liveStreams: eventClients.size,
      users: connectedUsers
    },
    push: {
      subscriptions: pushSubscriptions.length,
      employees: [...new Set(pushSubscriptions.map((record) => record.username))].length,
      failures: pushFailures
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 20)
    },
    backup,
    backupOperationRunning,
    dataFiles,
    checks,
    integrations
  });
}

async function handleBackupControl(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can manage backups." });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  if (backupOperationRunning) {
    sendJson(response, 409, { ok: false, message: "A backup or restore is already running." });
    return;
  }

  const payload = await readJsonBody(request);
  backupOperationRunning = true;
  try {
    if (payload.action === "backup") {
      structuredStore.checkpoint();
      const status = await runBackupScript();
      logActivity(session, "backup.manual", `Created manual backup ${status.archive}.`);
      sendJson(response, 200, { ok: true, message: "Backup completed.", backup: status });
      return;
    }
    if (payload.action === "restore") {
      if (payload.confirmation !== "RESTORE") {
        sendJson(response, 400, { ok: false, message: "Type RESTORE to confirm." });
        return;
      }
      const result = await restoreLastBackup();
      logActivity(session, "backup.restored", `Restored data from ${result.archive}.`);
      broadcastAllServiceEvent("dashboard-updated", { area: "restore" });
      broadcastAllServiceEvent("tickets-updated", {});
      broadcastAllServiceEvent("schedule-updated", {});
      sendJson(response, 200, {
        ok: true,
        message: "Restore completed. Restart the website server before continuing work.",
        ...result
      });
      return;
    }
    sendJson(response, 400, { ok: false, message: "Unknown backup action." });
  } catch (error) {
    sendJson(response, 500, { ok: false, message: error.message || "Backup operation failed." });
  } finally {
    backupOperationRunning = false;
  }
}

async function handleAppStore(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { ok: false, message: "Please sign in." });
    return;
  }

  if (request.method === "GET") {
    const apps = readInstalledApps()
      .filter((app) => canAccessInstalledApp(session, app))
      .map(publicInstalledApp);
    sendJson(response, 200, {
      ok: true,
      apps,
      canManage: session.username === "Huber58"
    });
    return;
  }

  if (session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can install dashboard apps." });
    return;
  }

  if (request.method === "DELETE") {
    const url = new URL(request.url, `http://${request.headers.host}`);
    const appId = sanitizeAppId(url.searchParams.get("id"));
    const apps = readInstalledApps();
    const app = apps.find((record) => record.id === appId);
    if (!app) {
      sendJson(response, 404, { ok: false, message: "Installed app not found." });
      return;
    }
    const appPath = resolve(installedAppFilesPath, app.id);
    if (!appPath.startsWith(`${resolve(installedAppFilesPath)}${sep}`)) {
      sendJson(response, 400, { ok: false, message: "Invalid installed app path." });
      return;
    }
    rmSync(appPath, { recursive: true, force: true });
    writeInstalledApps(apps.filter((record) => record.id !== app.id));
    logActivity(session, "app.uninstalled", `Uninstalled dashboard app ${app.name}.`);
    broadcastAllServiceEvent("installed-apps-updated", { action: "removed", id: app.id });
    sendJson(response, 200, { ok: true, apps: readInstalledApps().map(publicInstalledApp) });
    return;
  }

  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }

  let archivePath = "";
  let stagingPath = "";
  let stagedInstallPath = "";
  try {
    const fileName = sanitizeUploadedZipName(request.headers["x-file-name"] || "dashboard-app.zip");
    const appUploadsPath = join(root, ".data", "app-uploads");
    mkdirSync(appUploadsPath, { recursive: true, mode: 0o700 });
    archivePath = join(appUploadsPath, `${Date.now()}-${fileName}`);
    stagingPath = mkdtempSync(join(tmpdir(), "huber-app-install-"));
    const body = await readBinaryBody(request, 50 * 1024 * 1024);
    if (body.length < 22) throw new Error("Choose a valid zip app package.");
    writeFileSync(archivePath, body, { mode: 0o600 });

    const listing = await runProcess("unzip", ["-Z1", archivePath]);
    const entries = listing.stdout.split(/\r?\n/).map((entry) => entry.trim()).filter(Boolean);
    if (!entries.length) throw new Error("The app package is empty.");
    if (entries.length > 500) throw new Error("The app package contains too many files.");
    for (const entry of entries) {
      if (ignoredArchiveNoise(entry.split("/")[0])) continue;
      if (!safeAppArchiveEntry(entry)) throw new Error(`Unsafe app package entry blocked: ${entry}`);
    }

    const sizeListing = await runProcess("unzip", ["-l", archivePath]);
    const expandedBytes = zipListingExpandedSize(sizeListing.stdout);
    if (expandedBytes > 100 * 1024 * 1024) {
      throw new Error("The expanded app package is larger than 100 MB.");
    }

    await runProcess("unzip", ["-oq", archivePath, "-d", stagingPath]);
    const sourceRoot = findAppPackageRoot(stagingPath);
    const manifestPath = join(sourceRoot, "app.json");
    if (!fsExistsSync(manifestPath) || !lstatSync(manifestPath).isFile()) {
      throw new Error("The zip must contain app.json at its root.");
    }
    const manifest = normalizeInstalledAppManifest(
      JSON.parse(fsReadFileSync(manifestPath, "utf8"))
    );
    const files = validateAppPackageFiles(sourceRoot, manifest);

    const targetPath = join(installedAppFilesPath, manifest.id);
    stagedInstallPath = join(installedAppFilesPath, `.installing-${manifest.id}-${Date.now()}`);
    cpSync(sourceRoot, stagedInstallPath, { recursive: true });
    const previousPath = `${targetPath}.previous-${Date.now()}`;
    if (fsExistsSync(targetPath)) renameSync(targetPath, previousPath);
    try {
      renameSync(stagedInstallPath, targetPath);
      stagedInstallPath = "";
      rmSync(previousPath, { recursive: true, force: true });
    } catch (error) {
      if (fsExistsSync(previousPath) && !fsExistsSync(targetPath)) renameSync(previousPath, targetPath);
      throw error;
    }

    const apps = readInstalledApps();
    const existingIndex = apps.findIndex((record) => record.id === manifest.id);
    const installed = {
      ...manifest,
      fileCount: files.length,
      installedAt: new Date().toISOString(),
      installedBy: session.username
    };
    if (existingIndex >= 0) apps[existingIndex] = installed;
    else apps.push(installed);
    writeInstalledApps(apps);
    logActivity(
      session,
      existingIndex >= 0 ? "app.updated" : "app.installed",
      `${existingIndex >= 0 ? "Updated" : "Installed"} dashboard app ${installed.name} ${installed.version}.`
    );
    broadcastAllServiceEvent("installed-apps-updated", {
      action: existingIndex >= 0 ? "updated" : "installed",
      id: installed.id
    });
    sendJson(response, 200, {
      ok: true,
      message: `${installed.name} ${existingIndex >= 0 ? "updated" : "installed"} successfully.`,
      app: publicInstalledApp(installed),
      apps: readInstalledApps().map(publicInstalledApp)
    });
  } catch (error) {
    sendJson(response, 400, { ok: false, message: error.message || "App installation failed." });
  } finally {
    if (stagedInstallPath) rmSync(stagedInstallPath, { recursive: true, force: true });
    if (stagingPath) rmSync(stagingPath, { recursive: true, force: true });
    if (archivePath) rmSync(archivePath, { force: true });
  }
}

function readInstalledApps() {
  if (!existsSync(installedAppsPath)) return [];
  try {
    const records = JSON.parse(readFileSync(installedAppsPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeInstalledApps(records) {
  writeFileSync(installedAppsPath, `${JSON.stringify(records, null, 2)}\n`, { mode: 0o600 });
}

function sanitizeAppId(value) {
  const id = String(value || "").trim().toLowerCase();
  return /^[a-z0-9][a-z0-9-]{1,47}$/.test(id) ? id : "";
}

function normalizeInstalledAppManifest(raw) {
  const id = sanitizeAppId(raw?.id);
  const name = String(raw?.name || "").trim().slice(0, 48);
  const description = String(raw?.description || "").trim().slice(0, 180);
  const version = String(raw?.version || "").trim().slice(0, 32);
  const entry = normalizeAppRelativePath(raw?.entry || "index.html");
  const icon = raw?.icon ? normalizeAppRelativePath(raw.icon) : "";
  const permission = String(raw?.permission || "").trim();
  const access = raw?.access === "owner" ? "owner" : "all";
  if (!id) throw new Error("app.json needs an id using lowercase letters, numbers, and hyphens.");
  if (!name) throw new Error("app.json needs a name.");
  if (!version || !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,31}$/.test(version)) {
    throw new Error("app.json needs a valid version such as 1.0.0.");
  }
  if (!entry || extname(entry).toLowerCase() !== ".html") {
    throw new Error("app.json entry must point to an HTML file in the package.");
  }
  if (permission && !allPermissions.includes(permission)) {
    throw new Error(`Unknown dashboard permission: ${permission}`);
  }
  return { id, name, description, version, entry, icon, permission, access };
}

function normalizeAppRelativePath(value) {
  const path = String(value || "").trim().replace(/\\/g, "/").replace(/^\.\/+/, "");
  if (!path || path.startsWith("/") || path.includes("\0")) return "";
  const segments = path.split("/");
  if (segments.some((segment) => !segment || segment === "." || segment === ".." ||
      !/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/.test(segment))) return "";
  return segments.join("/");
}

function safeAppArchiveEntry(entry) {
  if (!entry || entry.startsWith("/") || entry.startsWith("\\") ||
      entry.includes("\\") || entry.includes("\0")) return false;
  return entry.split("/").every((segment) =>
    !segment || (segment !== "." && segment !== ".." && !segment.startsWith("."))
  );
}

function zipListingExpandedSize(output) {
  let total = 0;
  for (const line of String(output || "").split(/\r?\n/)) {
    const match = line.match(/^\s*(\d+)\s+\S+\s+\S+\s+.+$/);
    if (match) total += Number(match[1]) || 0;
  }
  return total;
}

function findAppPackageRoot(stagingPath) {
  if (fsExistsSync(join(stagingPath, "app.json"))) return stagingPath;
  const entries = readdirSync(stagingPath).filter((name) => !ignoredArchiveNoise(name));
  if (entries.length === 1) {
    const candidate = join(stagingPath, entries[0]);
    if (lstatSync(candidate).isDirectory() && fsExistsSync(join(candidate, "app.json"))) {
      return candidate;
    }
  }
  throw new Error("The zip must contain app.json at its root or inside one top-level folder.");
}

function validateAppPackageFiles(basePath, manifest, currentPath = basePath, output = []) {
  const allowed = new Set([
    ".html", ".css", ".js", ".json", ".png", ".jpg", ".jpeg", ".webp", ".gif",
    ".ico", ".svg", ".woff", ".woff2", ".ttf", ".webmanifest"
  ]);
  for (const name of readdirSync(currentPath)) {
    if (ignoredArchiveNoise(name)) continue;
    if (name.startsWith(".")) throw new Error(`Hidden package file is not allowed: ${name}`);
    const absolutePath = join(currentPath, name);
    const stats = lstatSync(absolutePath);
    if (stats.isSymbolicLink()) throw new Error(`Symbolic links are not allowed: ${name}`);
    const relativePath = normalize(absolutePath.slice(basePath.length + 1)).replace(/\\/g, "/");
    if (stats.isDirectory()) {
      validateAppPackageFiles(basePath, manifest, absolutePath, output);
      continue;
    }
    if (!stats.isFile()) throw new Error(`Unsupported package item: ${relativePath}`);
    if (!allowed.has(extname(name).toLowerCase())) {
      throw new Error(`Unsupported app file type: ${relativePath}`);
    }
    output.push(relativePath);
  }
  if (output.length > 500) throw new Error("The app package contains too many files.");
  const totalBytes = output.reduce((sum, relativePath) =>
    sum + lstatSync(join(basePath, relativePath)).size, 0
  );
  if (totalBytes > 100 * 1024 * 1024) throw new Error("The expanded app package is larger than 100 MB.");
  if (!output.includes(manifest.entry)) throw new Error(`App entry file not found: ${manifest.entry}`);
  if (manifest.icon && !output.includes(manifest.icon)) throw new Error(`App icon file not found: ${manifest.icon}`);
  return output;
}

function canAccessInstalledApp(session, app) {
  if (!session) return false;
  if (session.username === "Huber58") return true;
  if (app.access === "owner") return false;
  return !app.permission || hasPermission(session, app.permission);
}

function publicInstalledApp(app) {
  const baseUrl = `/apps/${encodeURIComponent(app.id)}/`;
  return {
    id: app.id,
    name: app.name,
    description: app.description,
    version: app.version,
    permission: app.permission || "",
    access: app.access === "owner" ? "owner" : "all",
    entry: app.entry,
    href: `${baseUrl}${app.entry.split("/").map(encodeURIComponent).join("/")}`,
    iconUrl: app.icon ? `${baseUrl}${app.icon.split("/").map(encodeURIComponent).join("/")}` : "",
    installedAt: app.installedAt || "",
    installedBy: app.installedBy || "",
    fileCount: Number(app.fileCount || 0)
  };
}

function serveInstalledApp(request, response, url, session) {
  const segments = url.pathname.split("/").filter(Boolean);
  const appId = sanitizeAppId(segments[1]);
  const app = readInstalledApps().find((record) => record.id === appId);
  if (!app || !canAccessInstalledApp(session, app)) {
    if (!session) {
      response.writeHead(302, { "Location": "/login.html", "Cache-Control": "no-store" });
      response.end();
      return;
    }
    response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    response.end("App not found");
    return;
  }

  let relativePath;
  try {
    relativePath = segments.length > 2
      ? segments.slice(2).map(decodeURIComponent).join("/")
      : app.entry;
  } catch {
    relativePath = "";
  }
  relativePath = normalizeAppRelativePath(relativePath);
  const appRoot = resolve(installedAppFilesPath, app.id);
  const filePath = relativePath ? resolve(appRoot, relativePath) : "";
  const extension = extname(filePath).toLowerCase();
  const publicExtensions = new Set([
    ".html", ".css", ".js", ".json", ".png", ".jpg", ".jpeg", ".webp", ".gif",
    ".ico", ".svg", ".woff", ".woff2", ".ttf", ".webmanifest"
  ]);
  if (!filePath || !filePath.startsWith(`${appRoot}${sep}`) ||
      !publicExtensions.has(extension) || !fsExistsSync(filePath) ||
      !lstatSync(filePath).isFile()) {
    response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    response.end("Not found");
    return;
  }

  let content = fsReadFileSync(filePath);
  if (extension === ".html") {
    const html = content.toString("utf8");
    const themeAssets = `
      <script>
        (function(){var t=localStorage.getItem("huber-account-theme")||"system";var e=t==="system"?(matchMedia("(prefers-color-scheme: dark)").matches?"midnight":"professional"):t==="dark"?"midnight":t==="light"?"professional":t;var d=["midnight","ember","steel"].includes(e);document.documentElement.dataset.theme=d?"dark":"light";document.documentElement.dataset.themeStyle=e;document.documentElement.dataset.themeChoice=t;}());
      </script>
      <link rel="stylesheet" href="/theme.css">
      <script src="/theme.js" defer></script>
      <script src="/motion.js" defer></script>
      <script src="/modal-dismiss.js" defer></script>
    `;
    content = Buffer.from(html.includes("</head>")
      ? html.replace("</head>", `${themeAssets}</head>`)
      : `${themeAssets}${html}`);
  }
  response.writeHead(200, {
    "Content-Type": mimeTypes[extension] || "application/octet-stream",
    "Content-Length": content.length,
    "Cache-Control": extension === ".html" ? "no-store, private" : "private, max-age=300",
    "Vary": "Cookie"
  });
  if (request.method === "HEAD") response.end();
  else response.end(content);
}

async function handleSiteUpdate(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can update website files." });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  if (backupOperationRunning) {
    sendJson(response, 409, { ok: false, message: "Wait for the current backup or update to finish." });
    return;
  }

  backupOperationRunning = true;
  let archivePath = "";
  let stagingPath = "";
  try {
    const fileName = sanitizeUploadedZipName(request.headers["x-file-name"] || "website-update.zip");
    const uploadsPath = join(root, ".data", "site-updates");
    mkdirSync(uploadsPath, { recursive: true, mode: 0o700 });
    archivePath = join(uploadsPath, `${new Date().toISOString().replace(/[:.]/g, "-")}-${fileName}`);
    stagingPath = mkdtempSync(join(tmpdir(), "huber-site-update-"));

    const body = await readBinaryBody(request, 150 * 1024 * 1024);
    if (body.length < 22) throw new Error("Choose a valid zip file.");
    writeFileSync(archivePath, body, { mode: 0o600 });

    const result = await applySiteUpdateArchive(archivePath, stagingPath, session);
    logActivity(session, "site.update", `Applied website update with ${result.updatedFiles} files.`);
    const restartScheduledNow = result.restartRequired ? scheduleServerRestart("site update") : false;
    sendJson(response, 200, {
      ok: true,
      message: restartScheduledNow
        ? "Website files were updated. server.mjs is restarting automatically."
        : result.restartRequired
        ? "Website files were updated. Restart server.mjs so backend changes take effect."
        : "Website files were updated. Refresh the page to see static changes.",
      restartScheduled: restartScheduledNow,
      ...result
    });
  } catch (error) {
    sendJson(response, 500, { ok: false, message: error.message || "Website update failed." });
  } finally {
    backupOperationRunning = false;
    if (stagingPath) rmSync(stagingPath, { recursive: true, force: true });
    if (archivePath) rmSync(archivePath, { force: true });
  }
}

function desktopUpdateDirectory() {
  return join(root, ".data", "desktop-updates");
}

function serveDesktopUpdateManifest(response) {
  const manifestPath = join(desktopUpdateDirectory(), "latest-mac-arm64.json");
  if (!existsSync(manifestPath)) {
    sendJson(response, 404, { ok: false, message: "No desktop update has been published." });
    return;
  }
  const content = readFileSync(manifestPath);
  response.writeHead(200, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": content.length,
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  });
  response.end(content);
}

function serveDesktopUpdateBundle(request, response) {
  const bundlePath = join(desktopUpdateDirectory(), "Huber-Dashboard-mac-arm64.zip");
  if (!existsSync(bundlePath)) {
    sendJson(response, 404, { ok: false, message: "Desktop update package not found." });
    return;
  }
  const size = statSync(bundlePath).size;
  response.writeHead(200, {
    "Content-Type": "application/zip",
    "Content-Length": size,
    "Cache-Control": "no-store",
    "Content-Disposition": "attachment; filename=Huber-Dashboard-mac-arm64.zip"
  });
  if (request.method === "HEAD") response.end();
  else createReadStream(bundlePath).pipe(response);
}

async function handleDesktopUpdate(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can publish desktop updates." });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  let version = "";
  const updatesPath = desktopUpdateDirectory();
  const temporaryPath = join(updatesPath, `upload-${randomUUID()}.zip`);
  try {
    mkdirSync(updatesPath, { recursive: true, mode: 0o700 });
    const body = await readBinaryBody(request, 90 * 1024 * 1024);
    if (body.length < 22) throw new Error("Choose a valid desktop update zip.");
    writeFileSync(temporaryPath, body, { mode: 0o600 });
    const listing = await runProcess("unzip", ["-Z1", temporaryPath]);
    const entries = listing.stdout.split(/\r?\n/).map((entry) => entry.trim()).filter(Boolean);
    if (!entries.includes("app.asar") || !entries.includes("Info.plist")) {
      throw new Error("Desktop update must contain app.asar and Info.plist at its root.");
    }
    const plist = await runProcess("unzip", ["-p", temporaryPath, "Info.plist"]);
    version = desktopVersionFromPlist(plist.stdout);
    if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(version)) {
      throw new Error("The desktop update does not contain a valid embedded app version.");
    }
    const sha256 = createHash("sha256").update(body).digest("hex");
    const publishedPath = join(updatesPath, "Huber-Dashboard-mac-arm64.zip");
    renameSync(temporaryPath, publishedPath);
    const manifest = {
      version,
      platform: "darwin",
      arch: "arm64",
      url: "/desktop-updates/Huber-Dashboard-mac-arm64.zip",
      sha256,
      size: body.length,
      publishedAt: new Date().toISOString()
    };
    writeFileSync(join(updatesPath, "latest-mac-arm64.json"), JSON.stringify(manifest, null, 2), { mode: 0o600 });
    logActivity(session, "desktop.update-published", `Published Huber Dashboard desktop version ${version}.`);
    sendJson(response, 200, { ok: true, message: `Desktop version ${version} was published.`, manifest });
  } catch (error) {
    try { rmSync(temporaryPath, { force: true }); } catch {}
    sendJson(response, 500, { ok: false, message: error.message || "Desktop update could not be published." });
  }
}

function desktopVersionFromPlist(content) {
  const match = String(content || "").match(/<key>CFBundleShortVersionString<\/key>\s*<string>([^<]+)<\/string>/i);
  return match ? match[1].trim() : "";
}

function readDesktopInstallerCatalog() {
  try {
    const records = JSON.parse(readFileSync(desktopInstallerCatalogPath, "utf8"));
    return Array.isArray(records) ? records : [];
  } catch {
    return [];
  }
}

function writeDesktopInstallerCatalog(records) {
  mkdirSync(dirname(desktopInstallerCatalogPath), { recursive: true, mode: 0o700 });
  writeFileSync(desktopInstallerCatalogPath, `${JSON.stringify(records, null, 2)}\n`, { mode: 0o600 });
}

function serveDesktopInstallerCatalog(response) {
  const apps = readDesktopInstallerCatalog()
    .filter((record) => record && record.id && record.fileName)
    .map((record) => ({
      ...record,
      url: `/app-installer/packages/${encodeURIComponent(record.fileName)}`
    }))
    .sort((left, right) => String(left.name).localeCompare(String(right.name)));
  sendJson(response, 200, { version: 1, apps });
}

function serveDesktopInstallerPackage(request, response) {
  const encodedName = request.url.slice("/app-installer/packages/".length).split("?", 1)[0];
  let requestedName = "";
  try { requestedName = decodeURIComponent(encodedName); } catch {}
  const fileName = basename(requestedName);
  const catalogRecord = readDesktopInstallerCatalog().find((record) => record.fileName === fileName);
  const filePath = join(desktopInstallerPackagesPath, fileName);
  if (!catalogRecord || !fileName || !existsSync(filePath) || !statSync(filePath).isFile()) {
    sendJson(response, 404, { ok: false, message: "Application installer not found." });
    return;
  }
  const size = statSync(filePath).size;
  const contentType = extname(fileName).toLowerCase() === ".exe"
    ? "application/vnd.microsoft.portable-executable"
    : "application/x-apple-diskimage";
  response.writeHead(200, {
    "Content-Type": contentType,
    "Content-Length": size,
    "Content-Disposition": `attachment; filename="${fileName.replace(/["\\]/g, "-")}"`,
    "Cache-Control": "public, max-age=3600",
    "X-Content-Type-Options": "nosniff"
  });
  if (request.method === "HEAD") response.end();
  else createReadStream(filePath).pipe(response);
}

async function handleDesktopInstallerPublish(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can publish desktop applications." });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }

  const url = new URL(request.url, "http://localhost");
  const stage = url.searchParams.get("stage");
  try {
    mkdirSync(desktopInstallerUploadsPath, { recursive: true, mode: 0o700 });
    mkdirSync(desktopInstallerPackagesPath, { recursive: true, mode: 0o700 });

    if (stage === "start") {
      const payload = await readJsonBody(request);
      const id = String(payload.id || "").trim().toLowerCase();
      const name = String(payload.name || "").trim();
      const version = String(payload.version || "").trim();
      const description = String(payload.description || "").trim().slice(0, 300);
      const bundleName = String(payload.bundleName || "").trim().slice(0, 100);
      const platform = ["darwin", "win32"].includes(String(payload.platform)) ? String(payload.platform) : "darwin";
      const arch = ["arm64", "x64"].includes(String(payload.arch)) ? String(payload.arch) : platform === "win32" ? "x64" : "arm64";
      const requiredExtension = platform === "win32" ? ".exe" : ".dmg";
      const originalName = basename(String(payload.fileName || `application${requiredExtension}`));
      const expectedSize = Number(payload.size || 0);
      if (!/^[a-z0-9][a-z0-9-]{1,48}$/.test(id)) throw new Error("Use a lowercase app ID such as huber-dashboard.");
      if (!name || name.length > 80) throw new Error("Enter an application name.");
      if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(version)) throw new Error("Enter a valid app version.");
      if (!originalName.toLowerCase().endsWith(requiredExtension)) {
        throw new Error(platform === "win32" ? "Choose a Windows EXE file." : "Choose a macOS DMG file.");
      }
      if (!Number.isSafeInteger(expectedSize) || expectedSize < 1024 || expectedSize > 600 * 1024 * 1024) {
        throw new Error("The installer must be between 1 KB and 600 MB.");
      }
      const uploadId = randomUUID();
      const metadata = { uploadId, id, name, version, description, bundleName, platform, arch, originalName, expectedSize, uploadedBy: session.username, createdAt: new Date().toISOString() };
      writeFileSync(join(desktopInstallerUploadsPath, `${uploadId}.json`), JSON.stringify(metadata), { mode: 0o600 });
      writeFileSync(join(desktopInstallerUploadsPath, `${uploadId}.part`), Buffer.alloc(0), { mode: 0o600 });
      sendJson(response, 200, { ok: true, uploadId, received: 0 });
      return;
    }

    const uploadId = String(url.searchParams.get("uploadId") || "");
    if (!/^[0-9a-f-]{36}$/i.test(uploadId)) throw new Error("Invalid upload session.");
    const metadataPath = join(desktopInstallerUploadsPath, `${uploadId}.json`);
    const partPath = join(desktopInstallerUploadsPath, `${uploadId}.part`);
    if (!existsSync(metadataPath) || !existsSync(partPath)) throw new Error("Upload session expired or was not found.");
    const metadata = JSON.parse(readFileSync(metadataPath, "utf8"));

    if (stage === "chunk") {
      const offset = Number(request.headers["x-upload-offset"] || -1);
      const currentSize = statSync(partPath).size;
      if (offset !== currentSize) {
        sendJson(response, 409, { ok: false, message: "Upload offset changed. Retry this package.", received: currentSize });
        return;
      }
      const body = await readBinaryBody(request, 10 * 1024 * 1024);
      if (!body.length || currentSize + body.length > metadata.expectedSize) throw new Error("Invalid installer chunk.");
      appendFileSync(partPath, body);
      sendJson(response, 200, { ok: true, received: currentSize + body.length });
      return;
    }

    if (stage === "complete") {
      const finalSize = statSync(partPath).size;
      if (finalSize !== metadata.expectedSize) throw new Error(`Upload is incomplete (${finalSize} of ${metadata.expectedSize} bytes).`);
      const digest = await sha256File(partPath);
      const safeVersion = metadata.version.replace(/[^0-9A-Za-z.-]/g, "-");
      const extension = metadata.platform === "win32" ? "exe" : "dmg";
      const fileName = `${metadata.id}-${safeVersion}-${metadata.platform}-${metadata.arch}.${extension}`;
      const finalPath = join(desktopInstallerPackagesPath, fileName);
      renameSync(partPath, finalPath);
      rmSync(metadataPath, { force: true });
      const record = {
        id: metadata.id,
        name: metadata.name,
        version: metadata.version,
        description: metadata.description,
        bundleName: metadata.bundleName,
        platform: metadata.platform,
        arch: metadata.arch,
        fileName,
        size: finalSize,
        sha256: digest,
        publishedAt: new Date().toISOString()
      };
      const existingRecords = readDesktopInstallerCatalog();
      const previousRecord = existingRecords.find((item) => item.id === record.id && item.platform === record.platform && item.arch === record.arch);
      const records = existingRecords.filter((item) => !(item.id === record.id && item.platform === record.platform && item.arch === record.arch));
      records.push(record);
      writeDesktopInstallerCatalog(records);
      if (previousRecord?.fileName && previousRecord.fileName !== fileName) {
        rmSync(join(desktopInstallerPackagesPath, basename(previousRecord.fileName)), { force: true });
      }
      logActivity(session, "desktop-app.published", `Published ${record.name} ${record.version}.`);
      sendJson(response, 200, { ok: true, message: `${record.name} ${record.version} was published.`, app: { ...record, url: `/app-installer/packages/${encodeURIComponent(fileName)}` } });
      return;
    }

    throw new Error("Unknown installer publishing stage.");
  } catch (error) {
    sendJson(response, 500, { ok: false, message: error.message || "Application installer could not be published." });
  }
}

function networkTesterManifestPath() {
  return join(networkTesterUpdatesPath, "update.json");
}

function serveNetworkTesterUpdateManifest(response) {
  const manifestPath = networkTesterManifestPath();
  if (!existsSync(manifestPath)) {
    sendJson(response, 404, { ok: false, message: "No network tester update has been published." });
    return;
  }
  const content = readFileSync(manifestPath);
  response.writeHead(200, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": content.length,
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  });
  response.end(content);
}

function serveNetworkTesterUpdatePackage(request, response) {
  const encodedName = request.url.slice("/network-tester/packages/".length).split("?", 1)[0];
  let requestedName = "";
  try { requestedName = decodeURIComponent(encodedName); } catch {}
  const fileName = basename(requestedName);
  const manifest = (() => {
    try { return JSON.parse(readFileSync(networkTesterManifestPath(), "utf8")); } catch { return null; }
  })();
  const filePath = join(networkTesterUpdatesPath, fileName);
  if (!manifest || manifest.fileName !== fileName || !fileName || !existsSync(filePath) || !statSync(filePath).isFile()) {
    sendJson(response, 404, { ok: false, message: "Network tester update package not found." });
    return;
  }
  const size = statSync(filePath).size;
  response.writeHead(200, {
    "Content-Type": "application/zip",
    "Content-Length": size,
    "Content-Disposition": `attachment; filename="${fileName.replace(/["\\]/g, "-")}"`,
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  });
  if (request.method === "HEAD") response.end();
  else createReadStream(filePath).pipe(response);
}

async function handleNetworkTesterUpdatePublish(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can publish network tester updates." });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }

  const url = new URL(request.url, "http://localhost");
  const stage = url.searchParams.get("stage");
  try {
    mkdirSync(networkTesterUploadsPath, { recursive: true, mode: 0o700 });
    mkdirSync(networkTesterUpdatesPath, { recursive: true, mode: 0o700 });

    if (stage === "start") {
      const payload = await readJsonBody(request);
      const version = String(payload.version || "").trim();
      const notes = String(payload.notes || "").trim().slice(0, 1000);
      const originalName = basename(String(payload.fileName || "network-tester-update.zip"));
      const expectedSize = Number(payload.size || 0);
      if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(version)) throw new Error("Enter a valid update version.");
      if (!originalName.toLowerCase().endsWith(".zip")) throw new Error("Choose a ZIP update package.");
      if (!Number.isSafeInteger(expectedSize) || expectedSize < 1024 || expectedSize > 250 * 1024 * 1024) {
        throw new Error("The update must be between 1 KB and 250 MB.");
      }
      const uploadId = randomUUID();
      const metadata = { uploadId, version, notes, originalName, expectedSize, uploadedBy: session.username, createdAt: new Date().toISOString() };
      writeFileSync(join(networkTesterUploadsPath, `${uploadId}.json`), JSON.stringify(metadata), { mode: 0o600 });
      writeFileSync(join(networkTesterUploadsPath, `${uploadId}.part`), Buffer.alloc(0), { mode: 0o600 });
      sendJson(response, 200, { ok: true, uploadId, received: 0 });
      return;
    }

    const uploadId = String(url.searchParams.get("uploadId") || "");
    if (!/^[0-9a-f-]{36}$/i.test(uploadId)) throw new Error("Invalid upload session.");
    const metadataPath = join(networkTesterUploadsPath, `${uploadId}.json`);
    const partPath = join(networkTesterUploadsPath, `${uploadId}.part`);
    if (!existsSync(metadataPath) || !existsSync(partPath)) throw new Error("Upload session expired or was not found.");
    const metadata = JSON.parse(readFileSync(metadataPath, "utf8"));

    if (stage === "chunk") {
      const offset = Number(request.headers["x-upload-offset"] || -1);
      const currentSize = statSync(partPath).size;
      if (offset !== currentSize) {
        sendJson(response, 409, { ok: false, message: "Upload offset changed. Retry this update.", received: currentSize });
        return;
      }
      const body = await readBinaryBody(request, 10 * 1024 * 1024);
      if (!body.length || currentSize + body.length > metadata.expectedSize) throw new Error("Invalid update chunk.");
      appendFileSync(partPath, body);
      sendJson(response, 200, { ok: true, received: currentSize + body.length });
      return;
    }

    if (stage === "complete") {
      const finalSize = statSync(partPath).size;
      if (finalSize !== metadata.expectedSize) throw new Error(`Upload is incomplete (${finalSize} of ${metadata.expectedSize} bytes).`);
      const listing = await runProcess("unzip", ["-Z1", partPath]);
      const entries = listing.stdout.split(/\r?\n/).map((entry) => entry.trim()).filter(Boolean);
      const required = ["main.py", "VERSION", "install.sh"];
      if (!required.every((name) => entries.includes(name)) || !entries.some((name) => name.startsWith("huber_tester/"))) {
        throw new Error("Update ZIP must contain main.py, VERSION, install.sh, and huber_tester at its root.");
      }
      const versionFile = await runProcess("unzip", ["-p", partPath, "VERSION"]);
      if (versionFile.stdout.trim() !== metadata.version) throw new Error("The VERSION inside the package does not match the published version.");
      const digest = await sha256File(partPath);
      const safeVersion = metadata.version.replace(/[^0-9A-Za-z.-]/g, "-");
      const fileName = `huber-network-tester-${safeVersion}.zip`;
      const finalPath = join(networkTesterUpdatesPath, fileName);
      renameSync(partPath, finalPath);
      rmSync(metadataPath, { force: true });
      const previousManifest = (() => {
        try { return JSON.parse(readFileSync(networkTesterManifestPath(), "utf8")); } catch { return null; }
      })();
      const manifest = {
        version: metadata.version,
        notes: metadata.notes,
        fileName,
        url: `/network-tester/packages/${encodeURIComponent(fileName)}`,
        sha256: digest,
        size: finalSize,
        publishedAt: new Date().toISOString()
      };
      writeFileSync(networkTesterManifestPath(), `${JSON.stringify(manifest, null, 2)}\n`, { mode: 0o600 });
      if (previousManifest?.fileName && previousManifest.fileName !== fileName) {
        rmSync(join(networkTesterUpdatesPath, basename(previousManifest.fileName)), { force: true });
      }
      logActivity(session, "network-tester.update-published", `Published Huber Network Tester ${metadata.version}.`);
      sendJson(response, 200, { ok: true, message: `Network Tester ${metadata.version} was published.`, manifest });
      return;
    }

    throw new Error("Unknown network tester publishing stage.");
  } catch (error) {
    sendJson(response, 500, { ok: false, message: error.message || "Network tester update could not be published." });
  }
}

function sha256File(filePath) {
  return new Promise((resolveHash, rejectHash) => {
    const hash = createHash("sha256");
    const stream = createReadStream(filePath);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("error", rejectHash);
    stream.on("end", () => resolveHash(hash.digest("hex")));
  });
}

async function handleWipeData(request, response) {
  const session = getSession(request);
  if (!session || session.username !== "Huber58") {
    sendJson(response, 403, { ok: false, message: "Only Huber58 can wipe test data." });
    return;
  }
  if (request.method !== "POST") {
    sendJson(response, 405, { ok: false, message: "Method not allowed." });
    return;
  }
  if (backupOperationRunning) {
    sendJson(response, 409, { ok: false, message: "Wait for the backup operation to finish." });
    return;
  }

  const payload = await readJsonBody(request);
  const user = readUsers().find((record) => record.username === session.username);
  if (!user || !verifyPassword(String(payload.password || ""), user.salt, user.hash)) {
    sendJson(response, 403, { ok: false, message: "Your password is incorrect." });
    return;
  }
  if (payload.confirmation !== "WIPE") {
    sendJson(response, 400, { ok: false, message: "Wipe confirmation is required." });
    return;
  }

  [ticketAttachmentsPath, ticketSignaturesPath, receiptFilesPath, presentationImagesPath, badgePhotosPath, documentsPath]
    .forEach(assertSafeDataDirectory);
  const emptyArrayFiles = [
    ticketsPath,
    employeesPath,
    timePath,
    scheduleEventsPath,
    inventoryPath,
    catalogPath,
    notificationsPath,
    invoicesPath,
    invoiceChargesPath,
    invoicePaymentInstructionsPath,
    billsPath,
    bankRulesPath,
    estimatesPath,
    bidsPath,
    badgesPath,
    estimateLineItemsPath,
    stripeEventsPath,
    zohoPaymentSessionsPath,
    zohoPaymentEventsPath,
    securityEventsPath,
    receiptsPath,
    portalAccessPath,
    customerSessionsPath,
    activityPath,
    alertDismissalsPath,
    availabilityPath,
    pushFailuresPath,
    customersPath,
    customerCommunicationsPath,
    warrantiesPath,
    approvalsPath,
    offlineMutationsPath,
    pushSubscriptionsPath
  ];
  for (const filePath of emptyArrayFiles) {
    writeFileSync(filePath, "[]\n", { mode: 0o600 });
  }
  writeFinance({
    groups: [
      { id: "bonus-pool", name: "Bonus Pool", percent: 5 },
      { id: "employee-labor", name: "Employee Labor", percent: 35 },
      { id: "operating", name: "Operating", percent: 60 }
    ],
    laborGroupId: "employee-labor",
    payments: [],
    expenses: []
  });
  writeBankData(defaultBankData());
  writeTaxData(defaultTaxData());
  writePayrollData(defaultPayrollData());
  writeUnifiData({
    settings: { autoTickets: false },
    mappings: {},
    cache: {
      hosts: [], sites: [], devices: [], ispMetrics: [],
      networkDevices: {}, clients: {}, protect: {}, access: {},
      connectorStatus: {}, syncedAt: ""
    },
    activeOutages: []
  });
  resetDataDirectory(ticketAttachmentsPath);
  resetDataDirectory(ticketSignaturesPath);
  resetDataDirectory(receiptFilesPath);
  resetDataDirectory(presentationImagesPath);
  resetDataDirectory(badgePhotosPath);
  resetDataDirectory(documentsPath);
  broadcastAllServiceEvent("dashboard-updated", { area: "data-wipe" });
  console.info(`Operational data wiped by ${session.username} at ${new Date().toISOString()}.`);
  sendJson(response, 200, {
    ok: true,
    message: "Operational data and uploaded files were erased. Accounts and settings were preserved."
  });
}

function resetDataDirectory(directoryPath) {
  assertSafeDataDirectory(directoryPath);
  const target = resolve(directoryPath);
  rmSync(target, { recursive: true, force: true });
  mkdirSync(target, { recursive: true, mode: 0o700 });
}

function assertSafeDataDirectory(directoryPath) {
  const target = resolve(directoryPath);
  const protectedPaths = new Set([resolve("/"), resolve(root), resolve(root, ".data")]);
  if (protectedPaths.has(target) || target.length < 6) {
    throw new Error(`Refusing to clear unsafe data directory: ${target}`);
  }
}

function runProcess(command, args, options = {}) {
  return new Promise((resolveRun, rejectRun) => {
    const child = spawn(command, args, {
      cwd: options.cwd || root,
      env: options.env || process.env,
      stdio: ["ignore", "pipe", "pipe"]
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => { stdout += chunk; });
    child.stderr.on("data", (chunk) => { stderr += chunk; });
    child.on("error", rejectRun);
    child.on("close", (code) => {
      if (code === 0) resolveRun({ stdout, stderr });
      else rejectRun(new Error(stderr.trim() || `${command} exited with status ${code}.`));
    });
  });
}

function scheduleServerRestart(reason = "manual restart") {
  if (restartScheduled) return true;
  restartScheduled = true;
  setTimeout(() => {
    console.info(`Restarting server.mjs after ${reason}.`);
    const managedRunner = Boolean(process.env.INVOCATION_ID || process.env.SYSTEMD_EXEC_PID || process.env.pm_id);
    if (!managedRunner) {
      const child = spawn(process.execPath, [
        "-e",
        "setTimeout(()=>import('./server.mjs'), 1800)"
      ], {
        cwd: root,
        env: process.env,
        detached: true,
        stdio: "ignore"
      });
      child.unref();
    }
    server.close(() => process.exit(0));
    setTimeout(() => server.closeAllConnections?.(), 350).unref();
    setTimeout(() => process.exit(0), 900).unref();
  }, 900).unref();
  return true;
}

async function runBackupScript() {
  const scriptPath = join(root, "backup.mjs");
  if (!existsSync(scriptPath)) throw new Error("backup.mjs is not installed in the website folder.");
  await runProcess(process.execPath, [scriptPath], { cwd: root });
  const statusPath = join(root, ".data", "last-backup.json");
  if (!existsSync(statusPath)) throw new Error("Backup finished without writing a status file.");
  const status = JSON.parse(readFileSync(statusPath, "utf8"));
  if (!status.lastSuccess || !status.archive) {
    throw new Error(status.message || "Backup did not complete successfully.");
  }
  return status;
}

async function restoreLastBackup() {
  const dataDirectory = join(root, ".data");
  const statusPath = join(dataDirectory, "last-backup.json");
  if (!existsSync(statusPath)) throw new Error("No successful backup is available to restore.");
  const selectedStatus = JSON.parse(readFileSync(statusPath, "utf8"));
  if (!selectedStatus.archive) throw new Error("The last backup status does not contain an archive.");
  const backupPath = resolve(process.env.BACKUP_PATH || "/var/backups/huber-it");
  const archivePath = resolve(backupPath, selectedStatus.archive);
  if (!archivePath.startsWith(`${backupPath}${sep}`) || !existsSync(archivePath)) {
    throw new Error("The last backup archive could not be found.");
  }

  const safetyStatus = await runBackupScript();
  const listing = await runProcess("tar", ["-tzf", archivePath]);
  const entries = listing.stdout.split(/\r?\n/).filter(Boolean);
  if (!entries.length || entries.some((entry) =>
    entry.startsWith("/") || entry.split("/").includes("..")
  )) {
    throw new Error("The backup archive failed its safety validation.");
  }

  const stagingPath = mkdtempSync(join(tmpdir(), "huber-restore-"));
  const rollbackPath = join(root, `.data.pre-restore-${new Date().toISOString().replace(/[:.]/g, "-")}`);
  try {
    await runProcess("tar", ["-xzf", archivePath, "-C", stagingPath]);
    const restoredDataPath = join(stagingPath, ".data");
    if (!existsSync(restoredDataPath) || !statSync(restoredDataPath).isDirectory()) {
      throw new Error("The selected backup does not contain a data directory.");
    }

    structuredStore.checkpoint();
    structuredStore.close();
    structuredStore = null;
    if (existsSync(dataDirectory)) renameSync(dataDirectory, rollbackPath);
    try {
      renameSync(restoredDataPath, dataDirectory);
    } catch (error) {
      if (existsSync(rollbackPath) && !existsSync(dataDirectory)) renameSync(rollbackPath, dataDirectory);
      reopenStructuredStore();
      throw error;
    }
    reopenStructuredStore();
    sessions.clear();
    loadSessions();

    for (const name of readdirSync(stagingPath)) {
      const source = join(stagingPath, name);
      if (name.endsWith(".txt") && statSync(source).isFile()) {
        cpSync(source, join(root, name));
      }
    }
    const restoredEnv = join(stagingPath, ".env");
    if (existsSync(restoredEnv) && statSync(restoredEnv).isFile()) {
      cpSync(restoredEnv, join(root, ".env"));
    }

    writeFileSync(statusPath, JSON.stringify({
      configured: true,
      lastSuccess: selectedStatus.lastSuccess,
      archive: selectedStatus.archive,
      size: statSync(archivePath).size,
      backupPath,
      restoredAt: new Date().toISOString(),
      safetyArchive: safetyStatus.archive,
      rollbackPath,
      message: `Restored from ${selectedStatus.archive}.`
    }, null, 2), { mode: 0o600 });
  } finally {
    rmSync(stagingPath, { recursive: true, force: true });
  }

  return {
    archive: selectedStatus.archive,
    safetyArchive: safetyStatus.archive,
    rollbackPath,
    restartRequired: false
  };
}

async function applySiteUpdateArchive(archivePath, stagingPath, session) {
  const listing = await runProcess("unzip", ["-Z1", archivePath]);
  const entries = listing.stdout.split(/\r?\n/).map((entry) => entry.trim()).filter(Boolean);
  if (!entries.length) throw new Error("The uploaded zip file is empty.");
  for (const entry of entries) {
    if (!safeZipEntry(entry)) {
      throw new Error(`Unsafe zip entry blocked: ${entry}`);
    }
  }

  await runProcess("unzip", ["-oq", archivePath, "-d", stagingPath]);
  const sourceRoot = findUpdateSourceRoot(stagingPath);
  const files = collectUpdateFiles(sourceRoot);
  if (!files.length) {
    throw new Error("No website files were found in the uploaded zip.");
  }

  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const rollbackPath = join(root, ".data", "site-update-backups", stamp);
  mkdirSync(rollbackPath, { recursive: true, mode: 0o700 });

  const updated = [];
  const skipped = [];
  for (const relativePath of files) {
    if (!isDeployableWebsiteFile(relativePath)) {
      skipped.push(relativePath);
      continue;
    }
    const source = join(sourceRoot, relativePath);
    const target = join(root, relativePath);
    if (!target.startsWith(root)) {
      skipped.push(relativePath);
      continue;
    }
    if (existsSync(target) && statSync(target).isFile()) {
      const backupTarget = join(rollbackPath, relativePath);
      mkdirSync(resolve(backupTarget, ".."), { recursive: true, mode: 0o700 });
      cpSync(target, backupTarget);
    }
    mkdirSync(resolve(target, ".."), { recursive: true, mode: 0o700 });
    if (existsSync(target) && statSync(target).isDirectory()) {
      rmSync(target, { recursive: true, force: true });
    }
    cpSync(source, target);
    updated.push(relativePath);
  }

  writeFileSync(join(rollbackPath, "update-manifest.json"), JSON.stringify({
    appliedAt: new Date().toISOString(),
    appliedBy: session.username,
    updated,
    skipped
  }, null, 2), { mode: 0o600 });

  const restartRequired = updated.some((file) =>
    file === "server.mjs" ||
    file === "package.json" ||
    file === "package-lock.json" ||
    file === "pnpm-lock.yaml" ||
    file.endsWith(".mjs")
  );

  return {
    updatedFiles: updated.length,
    skippedFiles: skipped.length,
    rollbackPath,
    restartRequired,
    skipped: skipped.slice(0, 30)
  };
}

function sanitizeUploadedZipName(name) {
  const clean = String(name || "website-update.zip").split(/[\\/]/).pop()
    .replace(/[^a-zA-Z0-9._-]/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 80) || "website-update.zip";
  return clean.toLowerCase().endsWith(".zip") ? clean : `${clean}.zip`;
}

function safeZipEntry(entry) {
  if (!entry || entry.startsWith("/") || entry.startsWith("\\")) return false;
  const normalized = normalize(entry);
  if (normalized === "." || normalized.startsWith("..") || normalized.includes(`${sep}..${sep}`)) return false;
  return !entry.includes("\0");
}

function findUpdateSourceRoot(stagingPath) {
  const directFiles = readdirSync(stagingPath).filter((name) => !ignoredArchiveNoise(name));
  const directHasSiteFile = directFiles.some((name) =>
    ["server.mjs", "index.html", "dashboard.html", "package.json"].includes(name)
  );
  if (directHasSiteFile) return stagingPath;
  if (directFiles.length === 1) {
    const candidate = join(stagingPath, directFiles[0]);
    if (statSync(candidate).isDirectory()) return candidate;
  }
  return stagingPath;
}

function collectUpdateFiles(basePath, currentPath = basePath, output = []) {
  for (const name of readdirSync(currentPath)) {
    if (ignoredArchiveNoise(name)) continue;
    const absolutePath = join(currentPath, name);
    const relativePath = normalize(absolutePath.slice(basePath.length + 1));
    if (!relativePath || relativePath.startsWith("..")) continue;
    const stats = statSync(absolutePath);
    if (stats.isDirectory()) {
      if (isSkippedUpdateDirectory(relativePath)) continue;
      collectUpdateFiles(basePath, absolutePath, output);
    } else if (stats.isFile()) {
      output.push(relativePath);
    }
  }
  return output;
}

function ignoredArchiveNoise(name) {
  return name === "__MACOSX" || name === ".DS_Store";
}

function isSkippedUpdateDirectory(relativePath) {
  const parts = relativePath.split(/[\\/]/);
  return [".data", ".git", ".agents", ".codex", "node_modules"].includes(parts[0]);
}

function isDeployableWebsiteFile(relativePath) {
  const normalizedPath = normalize(relativePath).replace(/\\/g, "/");
  if (!normalizedPath || normalizedPath.startsWith("../") || normalizedPath.includes("/../")) return false;
  const parts = normalizedPath.split("/");
  if ([".data", ".git", ".agents", ".codex", "node_modules"].includes(parts[0])) return false;
  const dataFiles = new Set([
    ".env",
    "env.txt",
    "users.txt",
    "tickets.txt",
    "employees.txt",
    "time-records.txt",
    "schedule-events.txt",
    "roles.txt",
    "inventory.txt",
    "catalog.txt",
    "notifications.txt",
    "invoices.txt"
  ]);
  return !dataFiles.has(normalizedPath);
}

function readBinaryBody(request, limit) {
  return new Promise((resolveBody, reject) => {
    const chunks = [];
    let size = 0;
    let tooLarge = false;
    request.on("data", (chunk) => {
      if (tooLarge) return;
      size += chunk.length;
      if (size > limit) {
        tooLarge = true;
        reject(new Error(`File exceeds the ${Math.round(limit / 1024 / 1024)} MB upload limit.`));
        return;
      }
      chunks.push(chunk);
    });
    request.on("end", () => {
      if (!tooLarge) resolveBody(Buffer.concat(chunks));
    });
    request.on("error", reject);
  });
}

function readTextBody(request, limit) {
  return new Promise((resolveBody, reject) => {
    let body = "";
    request.setEncoding("utf8");
    request.on("data", (chunk) => {
      body += chunk;
      if (body.length > limit) {
        request.destroy();
        reject(new Error("Request body is too large."));
      }
    });
    request.on("end", () => resolveBody(body));
    request.on("error", reject);
  });
}

function publicOrigin(request) {
  const protocol = String(request.headers["x-forwarded-proto"] || (isSecureRequest(request) ? "https" : "http"))
    .split(",")[0].trim() === "https" ? "https" : "http";
  const host = String(request.headers["x-forwarded-host"] || request.headers.host || "localhost")
    .split(",")[0].trim();
  if (!/^[a-zA-Z0-9.-]+(?::\d{1,5})?$/.test(host)) return `${protocol}://localhost`;
  return `${protocol}://${host}`;
}

function validUsername(username) {
  return /^[a-zA-Z0-9._-]{3,40}$/.test(username);
}

function hasPermission(session, permission) {
  if (!session) return false;
  if (session.username === "Huber58") return true;
  return effectivePermissions(session).includes(permission);
}

function effectivePermissions(session) {
  if (!session) return [];
  if (session.username === "Huber58") return [...allPermissions];
  const permissions = new Set(session.permissions || []);
  if (permissions.has("time-adjust")) permissions.add("employee-time");
  const inherited = {
    "service-tickets": ["customers", "customer-portal", "warranties"],
    "dispatch": ["schedule"],
    "route-planning": ["dispatch"],
    "inventory-scanner": ["inventory"],
    "schedule": ["availability"],
    "invoicing": ["estimates"],
    "finance": ["bills", "banking", "profit-loss"],
    "reports": ["payroll"]
  };
  for (const [parent, children] of Object.entries(inherited)) {
    if (permissions.has(parent)) children.forEach((permission) => permissions.add(permission));
  }
  return [...permissions];
}

function hashPassword(password, salt) {
  return scryptSync(password, salt, 64).toString("hex");
}

function verifyPassword(password, salt, expectedHash) {
  try {
    const actual = Buffer.from(hashPassword(password, salt), "hex");
    const expected = Buffer.from(expectedHash, "hex");
    return actual.length === expected.length && timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

function base32Encode(buffer) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = "";
  for (const byte of buffer) bits += byte.toString(2).padStart(8, "0");
  let output = "";
  for (let index = 0; index < bits.length; index += 5) {
    output += alphabet[parseInt(bits.slice(index, index + 5).padEnd(5, "0"), 2)];
  }
  return output;
}

function base32Decode(value) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = "";
  for (const character of String(value).replace(/=|\s/g, "").toUpperCase()) {
    const index = alphabet.indexOf(character);
    if (index < 0) return Buffer.alloc(0);
    bits += index.toString(2).padStart(5, "0");
  }
  const bytes = [];
  for (let index = 0; index + 8 <= bits.length; index += 8) {
    bytes.push(parseInt(bits.slice(index, index + 8), 2));
  }
  return Buffer.from(bytes);
}

function totpCode(secret, counter = Math.floor(Date.now() / 30000)) {
  const key = base32Decode(secret);
  if (!key.length) return "";
  const message = Buffer.alloc(8);
  message.writeBigUInt64BE(BigInt(counter));
  const digest = createHmac("sha1", key).update(message).digest();
  const offset = digest[digest.length - 1] & 15;
  const number = (digest.readUInt32BE(offset) & 0x7fffffff) % 1000000;
  return String(number).padStart(6, "0");
}

function verifyTotp(secret, code) {
  const normalized = String(code || "").replace(/\s/g, "");
  if (!/^\d{6}$/.test(normalized)) return false;
  const counter = Math.floor(Date.now() / 30000);
  return [-1, 0, 1].some((offset) => totpCode(secret, counter + offset) === normalized);
}

function hashRecoveryCode(code) {
  return createHash("sha256")
    .update(String(code || "").replace(/\s/g, "").toUpperCase())
    .digest("hex");
}

function consumeRecoveryCode(user, code) {
  const hash = hashRecoveryCode(code);
  if (!user.recoveryHashes?.includes(hash)) return false;
  const users = readUsers();
  const saved = users.find((record) => record.username === user.username);
  if (!saved) return false;
  saved.recoveryHashes = (saved.recoveryHashes || []).filter((candidate) => candidate !== hash);
  writeUsers(users);
  return true;
}

function readJsonBody(request) {
  return new Promise((resolve, reject) => {
    let body = "";
    let size = 0;
    request.setEncoding("utf8");
    request.on("data", (chunk) => {
      body += chunk;
      size += Buffer.byteLength(chunk, "utf8");
      if (size > 1_000_000) {
        request.destroy();
        reject(new Error("Request body too large."));
      }
    });
    request.on("end", () => {
      try {
        resolve(JSON.parse(body || "{}"));
      } catch (error) {
        reject(error);
      }
    });
    request.on("error", reject);
    request.on("aborted", () => reject(new Error("Request aborted.")));
  });
}

function sendJson(response, status, payload) {
  const content = JSON.stringify(payload);
  const acceptsGzip = /\bgzip\b/i.test(String(response.req?.headers?.["accept-encoding"] || ""));
  const shouldCompress = acceptsGzip && Buffer.byteLength(content) >= 16 * 1024;
  const body = shouldCompress ? gzipSync(content, { level: 1 }) : content;
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store, private",
    "CDN-Cache-Control": "no-store",
    "Cloudflare-CDN-Cache-Control": "no-store",
    "Content-Length": Buffer.byteLength(body),
    "Vary": "Cookie, Accept-Encoding"
  };
  if (shouldCompress) headers["Content-Encoding"] = "gzip";
  response.writeHead(status, headers);
  response.end(body);
}

function normalizeConfiguredBaseUrl(value) {
  const input = String(value || "").trim();
  if (!input) return "";
  try {
    const url = new URL(input);
    return ["http:", "https:"].includes(url.protocol) ? url.origin : "";
  } catch {
    console.warn(`Ignoring invalid server base URL: ${input}`);
    return "";
  }
}

function lanHealthCorsHeaders(request) {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
    "Access-Control-Allow-Headers": "X-Huber-LAN-Probe",
    "Access-Control-Max-Age": "600",
    "Cache-Control": "no-store",
    "Vary": "Origin"
  };
}

function loadLocalEnv() {
  const envPath = join(root, ".env");

  if (!existsSync(envPath)) {
    return;
  }

  const lines = readFileSync(envPath, "utf8").split(/\r?\n/);

  for (const line of lines) {
    const trimmed = line.trim();

    if (!trimmed || trimmed.startsWith("#")) {
      continue;
    }

    const separator = trimmed.indexOf("=");

    if (separator === -1) {
      continue;
    }

    const key = trimmed.slice(0, separator).trim();
    const value = trimmed.slice(separator + 1).trim().replace(/^["']|["']$/g, "");

    if (!process.env[key]) {
      process.env[key] = value;
    }
  }
}
